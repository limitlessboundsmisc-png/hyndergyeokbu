package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record BetterCombatActionStatePayload(
        int generation,
        boolean active
) implements CustomPacketPayload {

    public static final Type<BetterCombatActionStatePayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "better_combat_action_state"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            BetterCombatActionStatePayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    BetterCombatActionStatePayload::generation,

                    ByteBufCodecs.BOOL,
                    BetterCombatActionStatePayload::active,

                    BetterCombatActionStatePayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}