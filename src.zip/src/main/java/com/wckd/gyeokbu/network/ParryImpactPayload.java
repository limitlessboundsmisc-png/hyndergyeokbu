package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.weapon.ParryStyle;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client successful-Parry impact event.
 *
 * The server remains authoritative about whether a Parry succeeded and sends
 * the resolved Successful Parry semantic identity (style, handedness, and
 * dual-wield state) with the defender. Clients use those values to resolve the
 * same local animation profile without re-classifying the weapon independently.
 */
public record ParryImpactPayload(
        int defenderEntityId,
        int parryStyleOrdinal,
        boolean twoHanded,
        boolean dualWield,
        float incomingX,
        float incomingY,
        float incomingZ
) implements CustomPacketPayload {

    public ParryStyle parryStyle() {
        ParryStyle[] values = ParryStyle.values();
        return parryStyleOrdinal >= 0 && parryStyleOrdinal < values.length
                ? values[parryStyleOrdinal]
                : ParryStyle.GENERIC;
    }

    public static final Type<ParryImpactPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "parry_impact"
                    )
            );

    /*
     * NeoForge/Minecraft 1.21.1 exposes composite overloads through six
     * fields. Keep the packet as one value by composing the first six fields
     * into a small header and adding incomingZ at the outer level.
     */
    private record Header(
            int defenderEntityId,
            int parryStyleOrdinal,
            boolean twoHanded,
            boolean dualWield,
            float incomingX,
            float incomingY
    ) {
        private static final StreamCodec<RegistryFriendlyByteBuf, Header> STREAM_CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.VAR_INT,
                        Header::defenderEntityId,

                        ByteBufCodecs.VAR_INT,
                        Header::parryStyleOrdinal,

                        ByteBufCodecs.BOOL,
                        Header::twoHanded,

                        ByteBufCodecs.BOOL,
                        Header::dualWield,

                        ByteBufCodecs.FLOAT,
                        Header::incomingX,

                        ByteBufCodecs.FLOAT,
                        Header::incomingY,

                        Header::new
                );
    }

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            ParryImpactPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    Header.STREAM_CODEC,
                    payload -> new Header(
                            payload.defenderEntityId(),
                            payload.parryStyleOrdinal(),
                            payload.twoHanded(),
                            payload.dualWield(),
                            payload.incomingX(),
                            payload.incomingY()
                    ),

                    ByteBufCodecs.FLOAT,
                    ParryImpactPayload::incomingZ,

                    (header, incomingZ) -> new ParryImpactPayload(
                            header.defenderEntityId(),
                            header.parryStyleOrdinal(),
                            header.twoHanded(),
                            header.dualWield(),
                            header.incomingX(),
                            header.incomingY(),
                            incomingZ
                    )
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
