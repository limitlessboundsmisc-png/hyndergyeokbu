package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Build 1 only synchronizes persistent Parry / Block stance modes.
 * Successful-Parry reaction animation modes were removed.
 */
public record DefenseAnimationSyncPayload(
        int entityId,
        int mode
) implements CustomPacketPayload {

    public static final int NONE = 0;
    public static final int PARRY = 1;
    public static final int BLOCK = 2;

    public static final Type<DefenseAnimationSyncPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "defense_animation_sync"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            DefenseAnimationSyncPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    DefenseAnimationSyncPayload::entityId,
                    ByteBufCodecs.VAR_INT,
                    DefenseAnimationSyncPayload::mode,
                    DefenseAnimationSyncPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
