package com.wckd.gyeokbu.network;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class ClientCombatSyncState {

    private static final int LOCAL_MISSED_PARRY_COOLDOWN_TICKS = 20;

    private static volatile boolean defenseMovementPenalty = false;
    private static volatile int parryCooldownTicks = 0;

    /*
     * Local prediction keeps the Parry animation responsive immediately after
     * the click. It is independent of physical RMB release because Parry is a
     * click-activated action.
     */
    private static volatile int localParryVisualTicks = 0;
    private static volatile int localParryEntityId = -1;

    /*
     * Tracks the local attempt until the server confirms success or confirms a
     * miss. This lets a delayed successful-Parry packet cancel the locally
     * predicted missed-Parry cooldown.
     */
    private static volatile int pendingParryResultEntityId = -1;
    private static volatile boolean awaitingParryResult = false;

    /* Legacy placeholder while old stun classes remain dormant in the tree. */
    private static volatile int stunMode = StunStateSyncPayload.NONE;

    /* entityId -> synchronized Parry / Block stance mode. */
    private static final Map<Integer, Integer> DEFENSE_ANIMATION_MODES =
            new ConcurrentHashMap<>();

    /* Prevent a stale PARRY packet from visually regressing an active BLOCK. */
    private static final Map<Integer, Boolean> FIRST_PERSON_BLOCK_LATCH =
            new ConcurrentHashMap<>();

    private ClientCombatSyncState() {
    }

    public static boolean isDefenseMovementPenaltyActive() {
        return defenseMovementPenalty;
    }

    public static void setDefenseMovementPenalty(boolean active) {
        defenseMovementPenalty = active;
    }

    public static int getParryCooldownTicks() {
        return parryCooldownTicks;
    }

    public static boolean isParryCooldownActive() {
        return parryCooldownTicks > 0;
    }

    public static void setParryCooldownTicks(int ticks) {
        parryCooldownTicks = Math.max(0, ticks);

        if (parryCooldownTicks > 0) {
            localParryVisualTicks = 0;
            localParryEntityId = -1;
            awaitingParryResult = false;
            pendingParryResultEntityId = -1;
        }
    }

    public static boolean isLocalParryPredictionActive() {
        return localParryVisualTicks > 0
                && localParryEntityId >= 0;
    }

    public static void beginLocalParryPrediction(int entityId, int ticks) {
        if (isParryCooldownActive()
                || isLocalParryPredictionActive()
                || awaitingParryResult) {
            return;
        }

        localParryEntityId = entityId;
        localParryVisualTicks = Math.max(0, ticks);
        pendingParryResultEntityId = entityId;
        awaitingParryResult = true;
    }

    public static void confirmLocalParrySuccess(int entityId) {
        if (!awaitingParryResult
                || entityId != pendingParryResultEntityId) {
            return;
        }

        awaitingParryResult = false;
        pendingParryResultEntityId = -1;
        localParryVisualTicks = 0;
        localParryEntityId = -1;

        /* A success is immediately reusable. */
        parryCooldownTicks = 0;
    }

    public static void clearLocalParryPrediction() {
        localParryVisualTicks = 0;
        localParryEntityId = -1;
        awaitingParryResult = false;
        pendingParryResultEntityId = -1;
    }

    public static void tickParryCooldown() {
        if (parryCooldownTicks > 0) {
            parryCooldownTicks--;

            if (parryCooldownTicks == 0
                    && awaitingParryResult) {
                awaitingParryResult = false;
                pendingParryResultEntityId = -1;
            }
        }

        if (localParryVisualTicks > 0) {
            localParryVisualTicks--;

            if (localParryVisualTicks == 0) {
                localParryEntityId = -1;

                /*
                 * The local Parry window expired with no success confirmation.
                 * Mirror the full server missed-Parry lock immediately instead
                 * of waiting for the network packet.
                 */
                if (awaitingParryResult) {
                    parryCooldownTicks = Math.max(
                            parryCooldownTicks,
                            LOCAL_MISSED_PARRY_COOLDOWN_TICKS
                    );
                }
            }
        }
    }

    public static int getStunMode() {
        return stunMode;
    }

    public static void setStunMode(int mode) {
        stunMode = mode;
    }

    public static boolean isHardStunned() {
        return stunMode == StunStateSyncPayload.HARD;
    }

    public static boolean isAnyStunActive() {
        return stunMode != StunStateSyncPayload.NONE;
    }

    public static int getDefenseAnimationMode(int entityId) {
        int synchronizedMode = DEFENSE_ANIMATION_MODES.getOrDefault(
                entityId,
                DefenseAnimationSyncPayload.NONE
        );

        if (synchronizedMode == DefenseAnimationSyncPayload.NONE
                && entityId == localParryEntityId
                && localParryVisualTicks > 0
                && parryCooldownTicks <= 0) {
            return DefenseAnimationSyncPayload.PARRY;
        }

        return synchronizedMode;
    }

    public static boolean isDefenseAnimationActive(int entityId) {
        return getDefenseAnimationMode(entityId)
                != DefenseAnimationSyncPayload.NONE;
    }

    public static int getFirstPersonDefenseVisualMode(int entityId) {
        return getDefenseAnimationMode(entityId);
    }

    public static void setDefenseAnimationMode(
            int entityId,
            int mode
    ) {
        if (mode == DefenseAnimationSyncPayload.NONE) {
            DEFENSE_ANIMATION_MODES.remove(entityId);
            FIRST_PERSON_BLOCK_LATCH.remove(entityId);

            if (entityId == localParryEntityId) {
                localParryVisualTicks = 0;
                localParryEntityId = -1;
            }

            /*
             * A NONE packet without a cooldown is a normal successful/rejected
             * end state. A missed Parry's cooldown packet clears this before
             * NONE arrives, so do not leave a stale local attempt behind.
             */
            if (parryCooldownTicks <= 0
                    && entityId == pendingParryResultEntityId) {
                awaitingParryResult = false;
                pendingParryResultEntityId = -1;
            }

            return;
        }

        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            FIRST_PERSON_BLOCK_LATCH.put(entityId, true);
            DEFENSE_ANIMATION_MODES.put(
                    entityId,
                    DefenseAnimationSyncPayload.BLOCK
            );
            return;
        }

        if (mode == DefenseAnimationSyncPayload.PARRY) {
            if (FIRST_PERSON_BLOCK_LATCH.getOrDefault(entityId, false)) {
                return;
            }

            DEFENSE_ANIMATION_MODES.put(
                    entityId,
                    DefenseAnimationSyncPayload.PARRY
            );
        }
    }

    public static void reset() {
        defenseMovementPenalty = false;
        parryCooldownTicks = 0;
        stunMode = StunStateSyncPayload.NONE;
        clearLocalParryPrediction();
        DEFENSE_ANIMATION_MODES.clear();
        FIRST_PERSON_BLOCK_LATCH.clear();
    }
}
