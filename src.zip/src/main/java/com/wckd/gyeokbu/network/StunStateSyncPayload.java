package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record StunStateSyncPayload(
        int mode
) implements CustomPacketPayload {

    public static final int NONE =
            0;

    public static final int HARD =
            1;

    public static final int SOFT =
            2;

    public static final Type<StunStateSyncPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "stun_state_sync"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            StunStateSyncPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    StunStateSyncPayload::mode,
                    StunStateSyncPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}