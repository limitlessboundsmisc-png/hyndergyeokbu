package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Mirrors the remaining server-authoritative missed-Parry cooldown to the
 * owning client. The client uses this only to suppress impossible RMB attempts;
 * the server remains the final authority on whether defense may start.
 */
public record ParryCooldownSyncPayload(
        int ticks
) implements CustomPacketPayload {

    public static final Type<ParryCooldownSyncPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "parry_cooldown_sync"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            ParryCooldownSyncPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    ParryCooldownSyncPayload::ticks,
                    ParryCooldownSyncPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
