package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record DefenseMovementSyncPayload(
        boolean active
) implements CustomPacketPayload {

    public static final Type<DefenseMovementSyncPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "defense_movement_sync"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            DefenseMovementSyncPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.BOOL,
                    DefenseMovementSyncPayload::active,
                    DefenseMovementSyncPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}