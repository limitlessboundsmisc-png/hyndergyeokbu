package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.client.AnimationPoseConfig;
import com.wckd.gyeokbu.client.BetterCombatActionTracker;
import com.wckd.gyeokbu.client.BetterCombatParryCompat;
import com.wckd.gyeokbu.client.ClientMovementEvents;
import com.wckd.gyeokbu.client.ClientParryFeedback;
import com.wckd.gyeokbu.client.SuccessAnimationKind;
import com.wckd.gyeokbu.client.SuccessAnimationRuntime;
import com.wckd.gyeokbu.combat.AttackCommitManager;
import com.wckd.gyeokbu.combat.DefenseManager;
import com.wckd.gyeokbu.weapon.HandStyle;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

import java.util.Locale;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        bus = EventBusSubscriber.Bus.MOD
)
public final class NetworkHandler {

    private NetworkHandler() {
    }

    @SubscribeEvent
    public static void registerPayloads(
            RegisterPayloadHandlersEvent event
    ) {
        PayloadRegistrar registrar = event.registrar("1");

        registrar.playToServer(
                DefenseInputPayload.TYPE,
                DefenseInputPayload.STREAM_CODEC,
                NetworkHandler::handleDefenseInput
        );

        registrar.playToServer(
                FallbackWeaponSyncPayload.TYPE,
                FallbackWeaponSyncPayload.STREAM_CODEC,
                NetworkHandler::handleFallbackWeaponSync
        );

        registrar.playToServer(
                DeveloperMessagesPayload.TYPE,
                DeveloperMessagesPayload.STREAM_CODEC,
                NetworkHandler::handleDeveloperMessages
        );

        registrar.playToServer(
                BetterCombatActionStatePayload.TYPE,
                BetterCombatActionStatePayload.STREAM_CODEC,
                NetworkHandler::handleBetterCombatActionState
        );

        registrar.playToClient(
                BetterCombatHitConfirmPayload.TYPE,
                BetterCombatHitConfirmPayload.STREAM_CODEC,
                NetworkHandler::handleBetterCombatHitConfirm
        );

        registrar.playToClient(
                DefenseMovementSyncPayload.TYPE,
                DefenseMovementSyncPayload.STREAM_CODEC,
                NetworkHandler::handleMovementSync
        );

        registrar.playToClient(
                ParryCooldownSyncPayload.TYPE,
                ParryCooldownSyncPayload.STREAM_CODEC,
                NetworkHandler::handleParryCooldownSync
        );

        registrar.playToClient(
                DefenseAnimationSyncPayload.TYPE,
                DefenseAnimationSyncPayload.STREAM_CODEC,
                NetworkHandler::handleDefenseAnimationSync
        );

        registrar.playToClient(
                DefenseAttackCancelPayload.TYPE,
                DefenseAttackCancelPayload.STREAM_CODEC,
                NetworkHandler::handleDefenseAttackCancel
        );

        /*
         * Legacy payload registrations remain temporarily so the dormant old
         * reward classes can still compile while Build 1 is tested. No new V2
         * baseline mechanic sends stun state.
         */
        registrar.playToClient(
                StunStateSyncPayload.TYPE,
                StunStateSyncPayload.STREAM_CODEC,
                NetworkHandler::handleStunSync
        );

        registrar.playToClient(
                BlockDamageVisualPayload.TYPE,
                BlockDamageVisualPayload.STREAM_CODEC,
                NetworkHandler::handleBlockDamageVisual
        );

        registrar.playToClient(
                ParryImpactPayload.TYPE,
                ParryImpactPayload.STREAM_CODEC,
                NetworkHandler::handleParryImpact
        );

        registrar.playToClient(
                ReloadAnimationConfigPayload.TYPE,
                ReloadAnimationConfigPayload.STREAM_CODEC,
                NetworkHandler::handleReloadAnimationConfig
        );
    }

    private static void handleDefenseInput(
            DefenseInputPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }

            if (payload.pressed()) {
                DefenseManager.startDefense(player);
            } else {
                DefenseManager.releaseDefenseInput(player);
            }
    
        });
    }

    private static void handleDeveloperMessages(
            DeveloperMessagesPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            if (context.player() instanceof ServerPlayer player) {
                DefenseManager.setDeveloperMessagesEnabled(player, payload.enabled());
            }
    
        });
    }

    private static void handleFallbackWeaponSync(
            FallbackWeaponSyncPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }

            ResourceLocation requestedId;
            try {
                requestedId =
                        ResourceLocation.parse(
                                payload.itemId()
                        );
            } catch (Exception exception) {
                return;
            }

            ResourceLocation heldId =
                    BuiltInRegistries.ITEM.getKey(
                            player.getMainHandItem().getItem()
                    );

            if (!requestedId.equals(heldId)) {
                return;
            }

            if (!payload.enabled()) {
                WeaponClassifier.removeUserFallback(
                        heldId
                );
                return;
            }

            /* Recognized weapons never need the fallback registry. */
            if (WeaponClassifier.classifyNatural(
                    player.getMainHandItem()
            ).isSupported()) {
                return;
            }

            ParryStyle style;
            try {
                style =
                        ParryStyle.valueOf(
                                payload.styleName()
                                        .toUpperCase(
                                                Locale.ROOT
                                        )
                        );
            } catch (Exception exception) {
                style =
                        ParryStyle.GENERIC;
            }

            WeaponClassifier.setUserFallback(
                    heldId,
                    style
            );
    
        });
    }

    private static void handleBetterCombatActionState(
            BetterCombatActionStatePayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }

            if (payload.active()) {
                AttackCommitManager.beginAttack(
                        player,
                        payload.generation()
                );
            } else {
                AttackCommitManager.endAttack(
                        player,
                        payload.generation()
                );
            }
    
        });
    }

    private static void handleBetterCombatHitConfirm(
            BetterCombatHitConfirmPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            BetterCombatActionTracker.markAttackConfirmed(
                    payload.generation()
            );
    
        });
    }

    private static void handleMovementSync(
            DefenseMovementSyncPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            ClientCombatSyncState.setDefenseMovementPenalty(
                    payload.active()
            );
    
        });
    }

    private static void handleParryCooldownSync(
            ParryCooldownSyncPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            ClientCombatSyncState.setParryCooldownTicks(
                    payload.ticks()
            );
    
        });
    }

    /**
     * Build 1 only synchronizes the underlying Parry / Block stance mode.
     * There is no successful-Parry reaction animation layer anymore.
     */
    private static void handleDefenseAnimationSync(
            DefenseAnimationSyncPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            ClientCombatSyncState.setDefenseAnimationMode(
                    payload.entityId(),
                    payload.mode()
            );

            /*
             * For the local player, movement slowdown follows the same
             * server-authoritative PARRY/BLOCK state that drives the stance.
             * This keeps click-mode Parry visual + movement timing together:
             * both remain active after RMB release, and both end immediately when
             * the 0.20 s window expires or a normal Parry succeeds.
             *
             * The dedicated movement packet remains registered for compatibility;
             * this state sync is the final local correction for the same transition.
             */
            Minecraft minecraft = Minecraft.getInstance();
            if (minecraft.player != null
                    && minecraft.player.getId() == payload.entityId()) {
                ClientCombatSyncState.setDefenseMovementPenalty(
                        payload.mode() != DefenseAnimationSyncPayload.NONE
                );
            }
    
        });
    }

    private static void handleDefenseAttackCancel(
            DefenseAttackCancelPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            if (payload.cancel()) {
                BetterCombatParryCompat.stopAttackAnimationForEntity(
                        payload.entityId()
                );
            }
    
        });
    }

    private static void handleBlockDamageVisual(
            BlockDamageVisualPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            ClientMovementEvents.suppressDamageVisuals(
                    payload.suppressTicks(),
                    payload.suppressHurtFlash()
            );
    
        });
    }

    private static void handleParryImpact(
            ParryImpactPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            ClientCombatSyncState.confirmLocalParrySuccess(
                    payload.defenderEntityId()
            );

            SuccessAnimationRuntime.start(
                    payload.defenderEntityId(),
                    SuccessAnimationKind.PARRY,
                    payload.parryStyle(),
                    payload.twoHanded()
                            ? HandStyle.TWO_HANDED
                            : HandStyle.ONE_HANDED,
                    payload.dualWield()
            );

            ClientParryFeedback.play(
                    payload.defenderEntityId(),
                    payload.incomingX(),
                    payload.incomingY(),
                    payload.incomingZ()
            );
    
        });
    }

    private static void handleStunSync(
            StunStateSyncPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            ClientCombatSyncState.setStunMode(
                    payload.mode()
            );
    
        });
    }

    private static void handleReloadAnimationConfig(
            ReloadAnimationConfigPayload payload,
            IPayloadContext context
    ) {
        context.enqueueWork(() -> {

            AnimationPoseConfig.ReloadResult result = AnimationPoseConfig.reload();
            com.wckd.gyeokbu.client.SuccessAnimationConfig.clearRuntimeProfileCache();
            com.wckd.gyeokbu.client.SuccessAnimationRuntime.clearRuntimeState();

            if (Minecraft.getInstance().player != null) {
                Minecraft.getInstance()
                        .player
                        .displayClientMessage(
                                Component.literal(result.message()),
                                false
                        );
            }
    
        });
    }
}
