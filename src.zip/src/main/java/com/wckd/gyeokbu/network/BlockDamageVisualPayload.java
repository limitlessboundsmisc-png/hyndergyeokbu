package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record BlockDamageVisualPayload(
        int suppressTicks,
        boolean suppressHurtFlash
) implements CustomPacketPayload {

    public static final Type<BlockDamageVisualPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "block_damage_visual"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            BlockDamageVisualPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    BlockDamageVisualPayload::suppressTicks,
                    ByteBufCodecs.BOOL,
                    BlockDamageVisualPayload::suppressHurtFlash,
                    BlockDamageVisualPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
