package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client request to enable/disable Gyeokbu's universal fallback profile for
 * the exact registry item currently held by that player.
 *
 * The server validates that the requested registry id matches the player's
 * real main-hand item and that the item is naturally unrecognized before it
 * accepts an enable request.
 */
public record FallbackWeaponSyncPayload(
        String itemId,
        String styleName,
        boolean enabled
) implements CustomPacketPayload {

    public static final Type<FallbackWeaponSyncPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "fallback_weapon_sync"
                    )
            );

    public static final StreamCodec<ByteBuf, FallbackWeaponSyncPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.STRING_UTF8,
                    FallbackWeaponSyncPayload::itemId,
                    ByteBufCodecs.STRING_UTF8,
                    FallbackWeaponSyncPayload::styleName,
                    ByteBufCodecs.BOOL,
                    FallbackWeaponSyncPayload::enabled,
                    FallbackWeaponSyncPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
