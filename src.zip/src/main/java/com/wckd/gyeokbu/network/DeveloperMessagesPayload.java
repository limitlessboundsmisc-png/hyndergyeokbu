package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client preference for Gyeokbu developer/actionbar messages. */
public record DeveloperMessagesPayload(
        boolean enabled
) implements CustomPacketPayload {

    public static final Type<DeveloperMessagesPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "developer_messages"
                    )
            );

    public static final StreamCodec<ByteBuf, DeveloperMessagesPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.BOOL,
                    DeveloperMessagesPayload::enabled,
                    DeveloperMessagesPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
