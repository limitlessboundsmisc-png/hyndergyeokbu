package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client signal used by /gyeokbu reloadanimations.
 */
public record ReloadAnimationConfigPayload(
        int requestId
) implements CustomPacketPayload {

    public static final Type<ReloadAnimationConfigPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "reload_animation_config"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            ReloadAnimationConfigPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    ReloadAnimationConfigPayload::requestId,
                    ReloadAnimationConfigPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
