package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record BetterCombatHitConfirmPayload(
        int generation
) implements CustomPacketPayload {

    public static final Type<BetterCombatHitConfirmPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "better_combat_hit_confirm"
                    )
            );

    public static final StreamCodec<
            RegistryFriendlyByteBuf,
            BetterCombatHitConfirmPayload
            > STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.VAR_INT,
                    BetterCombatHitConfirmPayload::generation,
                    BetterCombatHitConfirmPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}