package com.wckd.gyeokbu.network;

import com.wckd.gyeokbu.GyeokbuV2;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record DefenseInputPayload(
        boolean pressed
) implements CustomPacketPayload {

    public static final Type<DefenseInputPayload> TYPE =
            new Type<>(
                    ResourceLocation.fromNamespaceAndPath(
                            GyeokbuV2.MODID,
                            "defense_input"
                    )
            );

    public static final StreamCodec<ByteBuf, DefenseInputPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ByteBufCodecs.BOOL,
                    DefenseInputPayload::pressed,
                    DefenseInputPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {

        return TYPE;
    }
}
