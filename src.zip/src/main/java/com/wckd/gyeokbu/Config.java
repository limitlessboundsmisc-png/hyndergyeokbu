package com.wckd.gyeokbu;

import java.util.List;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.common.ModConfigSpec;

/** Common/server configuration for Gyeokbu. */
public final class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    /* Existing template settings are preserved for project compatibility. */
    public static final ModConfigSpec.BooleanValue LOG_DIRT_BLOCK = BUILDER
            .comment("Whether to log the dirt block on common setup")
            .define("logDirtBlock", true);

    public static final ModConfigSpec.IntValue MAGIC_NUMBER = BUILDER
            .comment("A magic number")
            .defineInRange("magicNumber", 42, 0, Integer.MAX_VALUE);

    public static final ModConfigSpec.ConfigValue<String> MAGIC_NUMBER_INTRODUCTION = BUILDER
            .comment("What you want the introduction message to be for the magic number")
            .define("magicNumberIntroduction", "The magic number is... ");

    public static final ModConfigSpec.ConfigValue<List<? extends String>> ITEM_STRINGS = BUILDER
            .comment("A list of items to log on common setup.")
            .defineListAllowEmpty("items", List.of("minecraft:iron_ingot"), () -> "", Config::validateRegisteredItemName);

    /* ================================================================ */
    /* SURVIVAL / ACQUISITION                                           */
    /* ================================================================ */
    static {
        BUILDER.push("survivalAcquisition");
    }

    public static final ModConfigSpec.BooleanValue SURVIVAL_ACQUISITION_ENABLED = BUILDER
            .comment(
                    "Master switch for Gyeokbu-owned Survival acquisition hooks.",
                    "When false, Gyeokbu enchantments are filtered from the vanilla Enchanting Table and supplemental exploration loot is disabled.",
                    "Librarian membership remains datapack/tag-driven so packs can replace it cleanly."
            )
            .define("survivalAcquisitionEnabled", true);

    public static final ModConfigSpec.IntValue DEFAULT_WEAPON_SLOTS = BUILDER
            .comment("Default number of Gyeokbu enchantment slots on supported weapons.")
            .defineInRange("defaultWeaponSlots", 3, 1, 16);

    public static final ModConfigSpec.IntValue DEFAULT_SHIELD_SLOTS = BUILDER
            .comment("Default total number of Gyeokbu enchantment slots on shields.")
            .defineInRange("defaultShieldSlots", 1, 1, 16);

    public static final ModConfigSpec.DoubleValue COMMON_LOOT_CHANCE = BUILDER
            .comment("Supplemental Gyeokbu enchanted-book chance for Common exploration loot sources.")
            .defineInRange("commonLootChance", 0.06D, 0.0D, 1.0D);

    public static final ModConfigSpec.DoubleValue ADVANCED_LOOT_CHANCE = BUILDER
            .comment("Supplemental Gyeokbu enchanted-book chance for Advanced exploration loot sources.")
            .defineInRange("advancedLootChance", 0.12D, 0.0D, 1.0D);

    public static final ModConfigSpec.DoubleValue ELITE_LOOT_CHANCE = BUILDER
            .comment("Supplemental Gyeokbu enchanted-book chance for Elite exploration loot sources.")
            .defineInRange("eliteLootChance", 0.20D, 0.0D, 1.0D);

    public static final ModConfigSpec.DoubleValue LOOT_FREQUENCY_MULTIPLIER = BUILDER
            .comment("Global multiplier applied to all three supplemental Gyeokbu exploration-book chances.")
            .defineInRange("lootFrequencyMultiplier", 1.0D, 0.0D, 10.0D);

    public static final ModConfigSpec.BooleanValue COMMON_LOOT_ENABLED = BUILDER
            .comment("Whether Gyeokbu's Common supplemental exploration tier is enabled.")
            .define("commonLootEnabled", true);

    public static final ModConfigSpec.BooleanValue ADVANCED_LOOT_ENABLED = BUILDER
            .comment("Whether Gyeokbu's Advanced supplemental exploration tier is enabled.")
            .define("advancedLootEnabled", true);

    public static final ModConfigSpec.BooleanValue ELITE_LOOT_ENABLED = BUILDER
            .comment("Whether Gyeokbu's Elite supplemental exploration tier is enabled.")
            .define("eliteLootEnabled", true);

    public static final ModConfigSpec.BooleanValue SUPPLEMENTAL_LOOT_ENABLED = BUILDER
            .comment("Whether Gyeokbu's own additive Common/Advanced/Elite exploration-book rolls are enabled.")
            .define("supplementalLootEnabled", true);

    public static final ModConfigSpec.ConfigValue<List<? extends String>> EXPLICIT_WEAPON_INCLUSIONS = BUILDER
            .comment(
                    "Optional item IDs to force into Gyeokbu weapon support. Explicit exclusions still win.",
                    "This is intended for modpack compatibility; animation stance remains a separate concern."
            )
            .defineListAllowEmpty("explicitWeaponInclusions", List.of(), () -> "", Config::validateResourceLocation);

    public static final ModConfigSpec.ConfigValue<List<? extends String>> EXPLICIT_WEAPON_EXCLUSIONS = BUILDER
            .comment("Optional item IDs to explicitly exclude from Gyeokbu weapon support.")
            .defineListAllowEmpty("explicitWeaponExclusions", List.of(), () -> "", Config::validateResourceLocation);

    public static final ModConfigSpec.ConfigValue<List<? extends String>> PARRY_CAPABLE_SHIELDS = BUILDER
            .comment(
                    "Optional shield item IDs known to have an external Parry system.",
                    "This supplements the gyeokbuv2:parry_capable_shields item tag."
            )
            .defineListAllowEmpty("parryCapableShields", List.of(), () -> "", Config::validateResourceLocation);

    static {
        BUILDER.pop();
    }

    static final ModConfigSpec SPEC = BUILDER.build();

    private Config() {
    }

    private static boolean validateRegisteredItemName(final Object obj) {
        if (!(obj instanceof String itemName)) {
            return false;
        }
        try {
            return BuiltInRegistries.ITEM.containsKey(ResourceLocation.parse(itemName));
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private static boolean validateResourceLocation(final Object obj) {
        if (!(obj instanceof String id) || id.isBlank()) {
            return false;
        }
        try {
            ResourceLocation.parse(id);
            return true;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    public static boolean isExplicitWeaponIncluded(ResourceLocation id) {
        return containsId(EXPLICIT_WEAPON_INCLUSIONS.get(), id);
    }

    public static boolean isExplicitWeaponExcluded(ResourceLocation id) {
        return containsId(EXPLICIT_WEAPON_EXCLUSIONS.get(), id);
    }

    public static boolean isConfiguredParryCapableShield(ResourceLocation id) {
        return containsId(PARRY_CAPABLE_SHIELDS.get(), id);
    }

    private static boolean containsId(List<? extends String> configured, ResourceLocation id) {
        if (id == null) {
            return false;
        }
        String target = id.toString();
        for (String entry : configured) {
            if (target.equals(entry)) {
                return true;
            }
        }
        return false;
    }
}
