package com.wckd.gyeokbu;

import com.wckd.gyeokbu.client.AnimationPoseConfig;
import com.wckd.gyeokbu.client.BladeColorOverrideConfig;
import com.wckd.gyeokbu.client.GlaiveParryAnimation;
import com.wckd.gyeokbu.client.DeveloperMessageConfig;
import com.wckd.gyeokbu.client.ParryParticleTransitionConfig;
import dev.kosmx.playerAnim.minecraftApi.PlayerAnimationAccess;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

@Mod(
        value = GyeokbuV2.MODID,
        dist = Dist.CLIENT
)
@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public class GyeokbuV2Client {

    public GyeokbuV2Client(
            ModContainer container
    ) {

        container.registerExtensionPoint(
                IConfigScreenFactory.class,
                ConfigurationScreen::new
        );

        /*
         * Better Combat attack animation layer:
         * priority 2000.
         *
         * Gyeokbu defense:
         * priority 3000.
         *
         * Therefore an active Gyeokbu defensive pose
         * wins over Better Combat attacks.
         */
        PlayerAnimationAccess
                .REGISTER_ANIMATION_EVENT
                .register(
                        (player, animationStack) ->
                                animationStack.addAnimLayer(
                                        3000,
                                        new GlaiveParryAnimation(
                                                player
                                        )
                                )
                );
    }

    @SubscribeEvent
    static void onClientSetup(
            FMLClientSetupEvent event
    ) {

        event.enqueueWork(() -> {
            AnimationPoseConfig.initialize();
            ParryParticleTransitionConfig.initialize();
            BladeColorOverrideConfig.initialize();
            DeveloperMessageConfig.initialize();
        });

        GyeokbuV2.LOGGER.info(
                "HELLO FROM CLIENT SETUP"
        );

        GyeokbuV2.LOGGER.info(
                "MINECRAFT NAME >> {}",
                Minecraft.getInstance()
                        .getUser()
                        .getName()
        );
    }
}