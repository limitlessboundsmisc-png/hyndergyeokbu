package com.wckd.gyeokbu.mixin.client;

import com.wckd.gyeokbu.client.AnimationPoseConfig;
import com.wckd.gyeokbu.client.DualWieldPoseConfig;
import com.wckd.gyeokbu.client.StanceEditorCamera;
import com.wckd.gyeokbu.client.SuccessAnimationConfig;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Real Stance Editor orbit camera.
 *
 * IMPORTANT:
 * This orbit camera belongs ONLY to the Third Person editor tab.
 *
 * When the editor is in First Person, Minecraft's real first-person camera
 * must remain untouched so PlayerAnimator/Better Combat can render the
 * actual first-person stance from the player's eyes.
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Shadow
    protected abstract void setPosition(
            double x,
            double y,
            double z
    );

    @Shadow
    protected abstract void setRotation(
            float yaw,
            float pitch
    );

    @Shadow
    public abstract Vec3 getPosition();

    @Inject(
            method = "setup",
            at = @At("TAIL")
    )
    private void gyeokbu$applyRealStanceEditorOrbit(
            net.minecraft.world.level.BlockGetter level,
            Entity entity,
            boolean detached,
            boolean mirrored,
            float partialTick,
            CallbackInfo callbackInfo
    ) {

        /*
         * The V16 bug was here:
         * StanceEditorCamera.isActive() stays true for BOTH editor views.
         *
         * So after V16 selected FIRST_PERSON, this mixin still moved that
         * first-person camera around the player like a third-person orbit.
         *
         * First Person must bypass this mixin completely.
         */
        if (!StanceEditorCamera.isActive()) {
            return;
        }

        /*
         * F8 First-Person stance editing must always preview level, even if
         * the player was looking up/down before opening the editor. This only
         * changes the camera for the editor; it does not rewrite player pitch.
         */
        if (AnimationPoseConfig.isEditorActive()
                && AnimationPoseConfig.isEditorFirstPerson()
                && !(SuccessAnimationConfig.isEditorActive()
                && !SuccessAnimationConfig.isEditorFirstPerson())) {
            setRotation(
                    entity.getYRot(),
                    0.0F
            );
            return;
        }

        if (DualWieldPoseConfig.isEditorFirstPerson()
                || SuccessAnimationConfig.isEditorFirstPerson()) {
            return;
        }

        Vec3 target =
                entity.getEyePosition(
                        partialTick
                );

        Vec3 currentPosition =
                getPosition();

        Vec3 baseOffset =
                currentPosition.subtract(
                        target
                );

        double distance =
                baseOffset.length();

        if (distance < 0.001D) {
            distance = 4.0D;
        }

        double baseYaw =
                Math.atan2(
                        baseOffset.z,
                        baseOffset.x
                );

        double basePitch =
                Math.asin(
                        Math.max(
                                -1.0D,
                                Math.min(
                                        1.0D,
                                        baseOffset.y
                                                / distance
                                )
                        )
                );

        double yaw =
                baseYaw
                        + Math.toRadians(
                                StanceEditorCamera
                                        .getYawOffsetDegrees()
                        );

        double pitch =
                basePitch
                        + Math.toRadians(
                                StanceEditorCamera
                                        .getPitchOffsetDegrees()
                        );

        double maxPitch =
                Math.toRadians(
                        80.0D
                );

        pitch =
                Math.max(
                        -maxPitch,
                        Math.min(
                                maxPitch,
                                pitch
                        )
                );

        double horizontal =
                Math.cos(
                        pitch
                )
                        * distance;

        double x =
                target.x
                        + Math.cos(
                                yaw
                        )
                        * horizontal;

        double y =
                target.y
                        + Math.sin(
                                pitch
                        )
                        * distance;

        double z =
                target.z
                        + Math.sin(
                                yaw
                        )
                        * horizontal;

        setPosition(
                x,
                y,
                z
        );

        double dx =
                target.x - x;

        double dy =
                target.y - y;

        double dz =
                target.z - z;

        double horizontalLook =
                Math.sqrt(
                        dx * dx
                                + dz * dz
                );

        float cameraYaw =
                (float) Math.toDegrees(
                        Math.atan2(
                                -dx,
                                dz
                        )
                );

        float cameraPitch =
                (float) Math.toDegrees(
                        -Math.atan2(
                                dy,
                                horizontalLook
                        )
                );

        setRotation(
                cameraYaw,
                cameraPitch
        );
    }
}
