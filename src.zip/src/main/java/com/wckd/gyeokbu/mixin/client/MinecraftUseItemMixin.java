package com.wckd.gyeokbu.mixin.client;

import com.wckd.gyeokbu.compat.ThrowableWeaponCompat;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Native throwable-use routing after normal world interactions have had first
 * priority.
 *
 * Plain RMB:
 * - successful block/entity interaction -> Minecraft keeps the click
 * - otherwise native throwable item use is suppressed -> Gyeokbu can Parry
 *
 * Shift + RMB:
 * - native item/mod use proceeds untouched
 */
@Mixin(MultiPlayerGameMode.class)
public abstract class MinecraftUseItemMixin {

    @Inject(
            method = "useItem",
            at = @At("HEAD"),
            cancellable = true
    )
    private void gyeokbu$routeThrowableUse(
            Player player,
            InteractionHand hand,
            CallbackInfoReturnable<InteractionResult> callbackInfo
    ) {
        if (ThrowableWeaponCompat.shouldBlockNativePlainUse(player)) {
            callbackInfo.setReturnValue(InteractionResult.PASS);
        }
    }
}
