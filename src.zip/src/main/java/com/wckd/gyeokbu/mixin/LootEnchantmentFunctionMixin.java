package com.wckd.gyeokbu.mixin;

import com.wckd.gyeokbu.enchantment.GyeokbuGeneratedEnchantmentSanitizer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.EnchantRandomlyFunction;
import net.minecraft.world.level.storage.loot.functions.EnchantWithLevelsFunction;
import net.minecraft.world.level.storage.loot.functions.SetEnchantmentsFunction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Final loot-generation guard for enchantment functions that may apply an
 * enchantment directly rather than using EnchantmentHelper.selectEnchantment.
 */
@Mixin({
        EnchantRandomlyFunction.class,
        EnchantWithLevelsFunction.class,
        SetEnchantmentsFunction.class
})
public abstract class LootEnchantmentFunctionMixin {

    @Inject(method = "run", at = @At("RETURN"), cancellable = true)
    private void gyeokbu$sanitizeGeneratedLootItem(
            ItemStack stack,
            LootContext context,
            CallbackInfoReturnable<ItemStack> cir
    ) {
        cir.setReturnValue(GyeokbuGeneratedEnchantmentSanitizer.sanitize(cir.getReturnValue()));
    }
}
