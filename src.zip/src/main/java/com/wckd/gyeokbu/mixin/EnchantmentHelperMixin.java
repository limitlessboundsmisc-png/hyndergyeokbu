package com.wckd.gyeokbu.mixin;

import com.wckd.gyeokbu.enchantment.GyeokbuEnchantingRules;
import net.minecraft.core.Holder;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.stream.Stream;

/**
 * Applies Gyeokbu dependency/incompatibility filtering to Minecraft's generic
 * cost-based enchantment generation, not only the Enchanting Table menu.
 */
@Mixin(EnchantmentHelper.class)
public abstract class EnchantmentHelperMixin {

    @Inject(method = "selectEnchantment", at = @At("RETURN"), cancellable = true)
    private static void gyeokbu$filterGeneratedEnchantments(
            RandomSource random,
            ItemStack stack,
            int level,
            Stream<Holder<Enchantment>> possibleEnchantments,
            CallbackInfoReturnable<List<EnchantmentInstance>> cir
    ) {
        cir.setReturnValue(GyeokbuEnchantingRules.filterTableRoll(stack, cir.getReturnValue()));
    }
}
