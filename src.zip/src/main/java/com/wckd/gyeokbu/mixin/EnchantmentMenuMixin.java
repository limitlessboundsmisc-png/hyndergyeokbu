package com.wckd.gyeokbu.mixin;

import com.wckd.gyeokbu.enchantment.GyeokbuEnchantingRules;
import net.minecraft.core.RegistryAccess;
import net.minecraft.world.inventory.EnchantmentMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/** Filters the real table roll before both the visible clue and click result use it. */
@Mixin(EnchantmentMenu.class)
public abstract class EnchantmentMenuMixin {

    @Inject(method = "getEnchantmentList", at = @At("RETURN"), cancellable = true)
    private void gyeokbu$filterEnchantmentList(
            RegistryAccess registryAccess,
            ItemStack stack,
            int slot,
            int cost,
            CallbackInfoReturnable<List<EnchantmentInstance>> cir
    ) {
        cir.setReturnValue(GyeokbuEnchantingRules.filterTableRoll(stack, cir.getReturnValue()));
    }
}
