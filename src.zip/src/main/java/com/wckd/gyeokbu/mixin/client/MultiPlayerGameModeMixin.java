package com.wckd.gyeokbu.mixin.client;

import com.wckd.gyeokbu.client.DefenseKeyHandler;
import com.wckd.gyeokbu.client.SuccessAnimationRuntime;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Lets Minecraft's normal world-interaction pipeline win over Gyeokbu RMB.
 *
 * A successful/consumed block or entity interaction means the click already
 * did something meaningful (door, chest, button, villager, modded interactable,
 * etc.), so the same physical press must not also begin a Parry later in
 * ClientTick.Post.
 */
@Mixin(MultiPlayerGameMode.class)
public abstract class MultiPlayerGameModeMixin {

    @Inject(
            method = "useItemOn",
            at = @At("RETURN")
    )
    private void gyeokbu$prioritizeBlockInteraction(
            LocalPlayer player,
            InteractionHand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<InteractionResult> callbackInfo
    ) {
        markIfConsumed(callbackInfo.getReturnValue());
    }

    @Inject(
            method = "interact",
            at = @At("RETURN")
    )
    private void gyeokbu$prioritizeEntityInteraction(
            Player player,
            Entity target,
            InteractionHand hand,
            CallbackInfoReturnable<InteractionResult> callbackInfo
    ) {
        markIfConsumed(callbackInfo.getReturnValue());
    }

    @Inject(
            method = "interactAt",
            at = @At("RETURN")
    )
    private void gyeokbu$prioritizeSpecificEntityInteraction(
            Player player,
            Entity target,
            EntityHitResult hitResult,
            InteractionHand hand,
            CallbackInfoReturnable<InteractionResult> callbackInfo
    ) {
        markIfConsumed(callbackInfo.getReturnValue());
    }

    @Inject(
            method = "attack",
            at = @At("HEAD")
    )
    private void gyeokbu$interruptSuccessfulParryOnAttack(
            Player player,
            Entity target,
            org.spongepowered.asm.mixin.injection.callback.CallbackInfo callbackInfo
    ) {
        if (player instanceof LocalPlayer) {
            SuccessAnimationRuntime.cancelLocal();
        }
    }

    private static void markIfConsumed(InteractionResult result) {
        if (result != null && result.consumesAction()) {
            DefenseKeyHandler.markVanillaInteractionConsumed();
        }
    }

}
