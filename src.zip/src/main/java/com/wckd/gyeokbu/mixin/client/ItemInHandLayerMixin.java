package com.wckd.gyeokbu.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.wckd.gyeokbu.client.AnimationPoseConfig;
import com.wckd.gyeokbu.client.ClientParryFeedback;
import com.wckd.gyeokbu.client.DualWieldPoseConfig;
import com.wckd.gyeokbu.client.SuccessAnimationConfig;
import com.wckd.gyeokbu.client.SuccessAnimationRuntime;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Gyeokbu-only MAINHAND item transform.
 *
 * Vanilla first attaches the item to the hand. Immediately before the model
 * is rendered, Gyeokbu may add a visual translation and rotation.
 *
 * This does NOT detach the real ItemStack, alter reach, or create an entity.
 * Even exaggerated/floating poses remain parented to the player's hand.
 */
@Mixin(ItemInHandLayer.class)
public abstract class ItemInHandLayerMixin {

    @Inject(
            method = "renderArmWithItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
                    shift = At.Shift.BEFORE
            )
    )
    private void gyeokbu$transformHeldWeapon(
            LivingEntity entity,
            ItemStack stack,
            ItemDisplayContext displayContext,
            HumanoidArm arm,
            PoseStack poseStack,
            MultiBufferSource buffer,
            int packedLight,
            CallbackInfo callbackInfo
    ) {

        if (!(entity instanceof Player player)) {
            return;
        }

        net.minecraft.client.Minecraft minecraft =
                net.minecraft.client.Minecraft.getInstance();

        boolean successEditor =
                SuccessAnimationConfig.isEditorActive()
                        && minecraft.player == player;

        boolean dualPoseEditor =
                DualWieldPoseConfig.isEditorActive()
                        && minecraft.player == player;

        boolean firstPerson =
                minecraft.player == player
                        && minecraft.options.getCameraType()
                        == net.minecraft.client.CameraType.FIRST_PERSON;

        boolean successRuntime =
                entity instanceof net.minecraft.client.player.AbstractClientPlayer clientPlayer
                        && SuccessAnimationRuntime.isActive(clientPlayer, firstPerson);

        boolean dualWield =
                DualWieldRules.isDualWield(player)
                        || dualPoseEditor
                        || successEditor
                        || successRuntime;

        if (!dualWield && arm != player.getMainArm()) {
            return;
        }

        boolean mainHand = arm == player.getMainArm();
        Vec3f position;
        Vec3f rotation;

        if (successEditor
                && SuccessAnimationRuntime.isEditorPreviewActive(
                (net.minecraft.client.player.AbstractClientPlayer) player,
                firstPerson
        )) {
            position = SuccessAnimationRuntime.weaponPosition(
                    (net.minecraft.client.player.AbstractClientPlayer) player,
                    firstPerson,
                    mainHand
            );
            rotation = SuccessAnimationRuntime.weaponRotation(
                    (net.minecraft.client.player.AbstractClientPlayer) player,
                    firstPerson,
                    mainHand
            );
        } else if (successEditor) {
            position = SuccessAnimationConfig.getEditorWeaponPosition(mainHand);
            rotation = SuccessAnimationConfig.getEditorWeaponRotation(mainHand);
        } else if (dualPoseEditor) {
            /*
             * The dual-wield editor owns both held-item transforms directly.
             * Do not route this through runtime loadout validation: otherwise
             * the offhand preview can silently refuse to move while editing.
             */
            position = DualWieldPoseConfig.getEditorWeaponPosition(mainHand);
            rotation = DualWieldPoseConfig.getEditorWeaponRotation(mainHand);
        } else if (successRuntime
                && entity instanceof net.minecraft.client.player.AbstractClientPlayer clientPlayer) {
            position = SuccessAnimationRuntime.weaponPosition(clientPlayer, firstPerson, mainHand);
            rotation = SuccessAnimationRuntime.weaponRotation(clientPlayer, firstPerson, mainHand);
        } else {
            position = dualWield
                    ? DualWieldPoseConfig.getWeaponPositionFor(entity, arm)
                    : AnimationPoseConfig.getWeaponPositionFor(entity);
            rotation = dualWield
                    ? DualWieldPoseConfig.getWeaponRotationFor(entity, arm)
                    : AnimationPoseConfig.getWeaponRotationFor(entity);
        }

        if (position != null
                && (position.getX() != 0.0F
                || position.getY() != 0.0F
                || position.getZ() != 0.0F)) {

            poseStack.translate(
                    position.getX(),
                    position.getY(),
                    position.getZ()
            );
        }

        if (rotation != null
                && (rotation.getX() != 0.0F
                || rotation.getY() != 0.0F
                || rotation.getZ() != 0.0F)) {

            poseStack.mulPose(
                    new Quaternionf()
                            .rotationXYZ(
                                    rotation.getX(),
                                    rotation.getY(),
                                    rotation.getZ()
                            )
            );
        }

        if (mainHand
                && ClientCombatSyncState.isDefenseAnimationActive(player.getId())) {
            ClientParryFeedback.captureThirdPersonWeaponAnchor(
                    player,
                    poseStack
            );
        }
    }
}
