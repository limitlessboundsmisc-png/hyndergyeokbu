package com.wckd.gyeokbu;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.MapCodec;
import com.mojang.brigadier.Command;
import com.wckd.gyeokbu.particle.ModParticles;
import com.wckd.gyeokbu.loot.GyeokbuBookLootModifier;
import com.wckd.gyeokbu.network.ReloadAnimationConfigPayload;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import org.slf4j.Logger;

import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

@Mod(GyeokbuV2.MODID)
public class GyeokbuV2 {

    public static final String MODID =
            "gyeokbuv2";

    public static final Logger LOGGER =
            LogUtils.getLogger();

    public static final DeferredRegister.Blocks BLOCKS =
            DeferredRegister.createBlocks(
                    MODID
            );

    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(
                    MODID
            );

    public static final DeferredRegister<CreativeModeTab>
            CREATIVE_MODE_TABS =
            DeferredRegister.create(
                    Registries.CREATIVE_MODE_TAB,
                    MODID
            );

    public static final DeferredRegister<MapCodec<? extends IGlobalLootModifier>>
            GLOBAL_LOOT_MODIFIER_SERIALIZERS =
            DeferredRegister.create(
                    NeoForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS,
                    MODID
            );

    public static final Supplier<MapCodec<GyeokbuBookLootModifier>>
            GYEOKBU_BOOK_LOOT_MODIFIER =
            GLOBAL_LOOT_MODIFIER_SERIALIZERS.register(
                    "gyeokbu_book",
                    () -> GyeokbuBookLootModifier.CODEC
            );

    public static final DeferredBlock<Block> EXAMPLE_BLOCK =
            BLOCKS.registerSimpleBlock(
                    "example_block",
                    BlockBehaviour.Properties
                            .of()
                            .mapColor(
                                    MapColor.STONE
                            )
            );

    public static final DeferredItem<BlockItem>
            EXAMPLE_BLOCK_ITEM =
            ITEMS.registerSimpleBlockItem(
                    "example_block",
                    EXAMPLE_BLOCK
            );

    public static final DeferredItem<Item> EXAMPLE_ITEM =
            ITEMS.registerSimpleItem(
                    "example_item",
                    new Item.Properties()
                            .food(
                                    new FoodProperties.Builder()
                                            .alwaysEdible()
                                            .nutrition(1)
                                            .saturationModifier(2F)
                                            .build()
                            )
            );

    public static final DeferredHolder<
            CreativeModeTab,
            CreativeModeTab
            > GYEOKBU_ENCHANTMENTS_TAB =
            CREATIVE_MODE_TABS.register(
                    "gyeokbu_enchantments",
                    () ->
                            CreativeModeTab.builder()
                                    .title(
                                            Component.translatable(
                                                    "itemGroup.gyeokbuv2.enchantments"
                                            )
                                    )
                                    .withTabsBefore(
                                            CreativeModeTabs.COMBAT
                                    )
                                    .icon(
                                            () -> Items.ENCHANTED_BOOK.getDefaultInstance()
                                    )
                                    .displayItems(
                                            (parameters, output) -> {
                                                var provider = parameters.holders();

                                                ItemStack cursedBook = Items.ENCHANTED_BOOK.getDefaultInstance();
                                                cursedBook.set(
                                                        DataComponents.CUSTOM_NAME,
                                                        Component.literal("Cursed Book").withStyle(style -> style
                                                                .withColor(ChatFormatting.DARK_RED)
                                                                .withBold(true)
                                                                .withItalic(true))
                                                );
                                                output.accept(cursedBook);

                                                for (int level = 1; level <= 3; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, GyeokbuEnchantments.REFLECT, level));
                                                }

                                                for (int level = 1; level <= 3; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, GyeokbuEnchantments.SOFT_BLOW, level));
                                                }

                                                for (int level = 1; level <= 2; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, GyeokbuEnchantments.CONCUSSION, level));
                                                }

                                                for (int level = 1; level <= 3; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, GyeokbuEnchantments.VULNERABILITY, level));
                                                }

                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.BLAST_NEGATION));

                                                for (int level = 1; level <= 3; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, GyeokbuEnchantments.MASTERY, level));
                                                }

                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.SWEEPING_GUARD));

                                                for (int level = 1; level <= 3; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, GyeokbuEnchantments.BLOCK, level));
                                                }

                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.PERFECT_BLOCK));
                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.BLOCKING_STANCE));
                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.PUSHBACK));
                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.PROJECTILE_REFLECT));
                                                output.accept(GyeokbuEnchantments.createBook(
                                                        provider, GyeokbuEnchantments.BLAST_GUARD));

                                                for (int level = 1; level <= 2; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, Enchantments.KNOCKBACK, level));
                                                }

                                                for (int level = 1; level <= 2; level++) {
                                                    output.accept(GyeokbuEnchantments.createBook(
                                                            provider, Enchantments.FIRE_ASPECT, level));
                                                }

                                            }
                                    )
                                    .build()
            );

    public GyeokbuV2(
            IEventBus modEventBus,
            ModContainer modContainer
    ) {

        modEventBus.addListener(
                this::commonSetup
        );

        BLOCKS.register(
                modEventBus
        );

        ITEMS.register(
                modEventBus
        );

        CREATIVE_MODE_TABS.register(
                modEventBus
        );

        GLOBAL_LOOT_MODIFIER_SERIALIZERS.register(
                modEventBus
        );

        /*
         * GYEOKBU CUSTOM PARTICLES
         */
        ModParticles.PARTICLE_TYPES.register(
                modEventBus
        );

        NeoForge.EVENT_BUS.register(
                this
        );

        modContainer.registerConfig(
                ModConfig.Type.COMMON,
                Config.SPEC
        );
    }

    private void commonSetup(
            FMLCommonSetupEvent event
    ) {

        LOGGER.info(
                "HELLO FROM COMMON SETUP"
        );

        if (Config.LOG_DIRT_BLOCK
                .getAsBoolean()) {

            LOGGER.info(
                    "DIRT BLOCK >> {}",
                    BuiltInRegistries.BLOCK
                            .getKey(
                                    Blocks.DIRT
                            )
            );
        }

        LOGGER.info(
                "{}{}",
                Config.MAGIC_NUMBER_INTRODUCTION
                        .get(),
                Config.MAGIC_NUMBER
                        .getAsInt()
        );

        Config.ITEM_STRINGS
                .get()
                .forEach(
                        item ->
                                LOGGER.info(
                                        "ITEM >> {}",
                                        item
                                )
                );
    }

    @SubscribeEvent
    public void onServerStarting(
            ServerStartingEvent event
    ) {

        LOGGER.info(
                "HELLO from server starting"
        );
    }
    @SubscribeEvent
    public void onRegisterCommands(
            RegisterCommandsEvent event
    ) {

        event.getDispatcher()
                .register(
                        Commands.literal(
                                        "gyeokbu"
                                )
                                .then(
                                        Commands.literal(
                                                        "reloadanimations"
                                                )
                                                .executes(
                                                        context -> {

                                                            net.minecraft.server.level.ServerPlayer player =
                                                                    context.getSource()
                                                                            .getPlayerOrException();

                                                            PacketDistributor.sendToPlayer(
                                                                    player,
                                                                    new ReloadAnimationConfigPayload(
                                                                            1
                                                                    )
                                                            );

                                                            return Command.SINGLE_SUCCESS;
                                                        }
                                                )
                                )
                );
    }

}