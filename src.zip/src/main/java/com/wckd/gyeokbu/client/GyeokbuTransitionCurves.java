package com.wckd.gyeokbu.client;

import dev.kosmx.playerAnim.core.util.Vec3f;

/**
 * Shared client-side interpolation curves used by Gyeokbu pose transitions.
 *
 * Stance curves remain in the original DefenseTransitionConfig path.
 * Successful Parry has its own richer curve set so F8 can expose more
 * expressive impact without changing the working stance system.
 */
public final class GyeokbuTransitionCurves {

    private GyeokbuTransitionCurves() {
    }

    public static float apply(float t, DefenseTransitionConfig.Mode mode) {
        float clamped = clamp01(t);

        return switch (mode) {
            case SNAP -> 1.0F;
            case LINEAR -> clamped;
            case SMOOTH -> smoothStep5(clamped);
            case QUICK -> easeOutCubic(clamped);
            case OVERSHOOT -> subtleOvershoot(clamped);
        };
    }

    private static float smoothStep5(float t) {
        // Quintic smoothstep: zero velocity at both ends.
        return t * t * t * (t * (t * 6.0F - 15.0F) + 10.0F);
    }

    /**
     * Successful Parry-only curves. Stance interpolation continues to use
     * {@link #apply(float, DefenseTransitionConfig.Mode)} unchanged.
     */
    public static float applySuccess(
            float t,
            SuccessTransitionMode mode
    ) {
        float clamped = clamp01(t);

        return switch (mode) {
            case SNAP -> 1.0F;
            case LINEAR -> clamped;
            case SMOOTH -> smoothStep5(clamped);
            case EASE_IN -> easeInCubic(clamped);
            case EASE_OUT -> easeOutCubic(clamped);
            case QUICK -> easeOutQuartic(clamped);
            case STRONG_EASE_IN -> easeInQuintic(clamped);
            case STRONG_EASE_OUT -> easeOutQuintic(clamped);
            case OVERSHOOT -> subtleOvershoot(clamped);
        };
    }


    /**
     * Samples one continuous Successful Parry path through Start -> End ->
     * Current. The End Pose is an exact waypoint rather than the endpoint of
     * one interpolation that is immediately followed by a second interpolation.
     * This keeps velocity continuous at the impact pose for all non-snap modes.
     */
    public static SuccessAnimationConfig.PoseData sampleSuccessWaypoint(
            SuccessAnimationConfig.PoseData start,
            SuccessAnimationConfig.PoseData end,
            SuccessAnimationConfig.PoseData current,
            float progress,
            float impactFraction,
            SuccessTransitionMode mode
    ) {
        SuccessAnimationConfig.PoseData a = start == null
                ? SuccessAnimationConfig.PoseData.empty()
                : start;
        SuccessAnimationConfig.PoseData b = end == null
                ? a
                : end;
        SuccessAnimationConfig.PoseData c = current == null
                ? b
                : current;

        float t = clamp01(progress);
        float impact = Math.max(0.01F, Math.min(0.99F, impactFraction));

        if (mode == null) {
            mode = SuccessTransitionMode.SMOOTH;
        }

        if (mode == SuccessTransitionMode.SNAP) {
            return t < impact
                    ? a.copy()
                    : t < 1.0F ? b.copy() : c.copy();
        }

        if (mode == SuccessTransitionMode.LINEAR) {
            if (t < impact) {
                return SuccessAnimationConfig.blend(a, b, t / impact);
            }
            return SuccessAnimationConfig.blend(b, c, (t - impact) / (1.0F - impact));
        }

        CurveProfile profile = CurveProfile.forMode(mode);
        float d1 = impact;
        float d2 = 1.0F - impact;
        boolean beforeImpact = t < impact;
        float local = beforeImpact ? t / d1 : (t - impact) / d2;

        SuccessAnimationConfig.PoseData result = SuccessAnimationConfig.PoseData.empty();
        for (SuccessAnimationChannel channel : SuccessAnimationChannel.values()) {
            float aValue = a.value(channel);
            float bValue = b.value(channel);
            float cValue = c.value(channel);

            float incomingVelocity = (bValue - aValue) / d1;
            float outgoingVelocity = (cValue - bValue) / d2;
            float velocityAtImpact = sharedVelocity(
                    incomingVelocity,
                    outgoingVelocity,
                    profile.middleVelocityFactor
            );

            float value;
            if (beforeImpact) {
                float tangentStart = (bValue - aValue) * profile.startVelocityFactor;
                float tangentEnd = velocityAtImpact * d1;
                value = cubicHermiteScalar(
                        aValue,
                        bValue,
                        tangentStart,
                        tangentEnd,
                        local
                );
            } else {
                float tangentStart = velocityAtImpact * d2;
                float tangentEnd = (cValue - bValue) * profile.endVelocityFactor;
                value = cubicHermiteScalar(
                        bValue,
                        cValue,
                        tangentStart,
                        tangentEnd,
                        local
                );
            }

            result = result.withValue(channel, value);
        }
        return result;
    }

    /** Vector equivalent used by live arm rendering where value0 is the true
     * lower PlayerAnimator recovery target for the current pose. */
    public static Vec3f sampleSuccessWaypoint(
            Vec3f start,
            Vec3f end,
            Vec3f current,
            float progress,
            float impactFraction,
            SuccessTransitionMode mode
    ) {
        Vec3f a = start == null ? new Vec3f(0.0F, 0.0F, 0.0F) : start;
        Vec3f b = end == null ? a : end;
        Vec3f c = current == null ? b : current;

        float t = clamp01(progress);
        float impact = Math.max(0.01F, Math.min(0.99F, impactFraction));
        if (mode == null) {
            mode = SuccessTransitionMode.SMOOTH;
        }

        if (mode == SuccessTransitionMode.SNAP) {
            return t < impact
                    ? copyVec(a)
                    : t < 1.0F ? copyVec(b) : copyVec(c);
        }
        if (mode == SuccessTransitionMode.LINEAR) {
            if (t < impact) {
                return blendVec(a, b, t / impact);
            }
            return blendVec(b, c, (t - impact) / (1.0F - impact));
        }

        CurveProfile profile = CurveProfile.forMode(mode);
        float d1 = impact;
        float d2 = 1.0F - impact;
        Vec3f velocityIntoB = scaleDifference(a, b, 1.0F / d1);
        Vec3f velocityOutOfB = scaleDifference(b, c, 1.0F / d2);
        Vec3f velocityAtB = sharedVelocity(
                velocityIntoB,
                velocityOutOfB,
                profile.middleVelocityFactor
        );

        if (t < impact) {
            float local = t / impact;
            Vec3f tangentStart = scaleDifference(a, b, profile.startVelocityFactor);
            Vec3f tangentEnd = scaleDifference(velocityAtB, d1);
            return cubicHermite(a, b, tangentStart, tangentEnd, local);
        }

        float local = (t - impact) / d2;
        Vec3f tangentStart = scaleDifference(velocityAtB, d2);
        Vec3f tangentEnd = scaleDifference(b, c, profile.endVelocityFactor);
        return cubicHermite(b, c, tangentStart, tangentEnd, local);
    }


    private static float cubicHermiteScalar(
            float p0,
            float p1,
            float m0,
            float m1,
            float t
    ) {
        float t2 = t * t;
        float t3 = t2 * t;
        float h00 = 2.0F * t3 - 3.0F * t2 + 1.0F;
        float h10 = t3 - 2.0F * t2 + t;
        float h01 = -2.0F * t3 + 3.0F * t2;
        float h11 = t3 - t2;
        return h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1;
    }

    private static Vec3f copyVec(Vec3f value) {
        if (value == null) {
            return new Vec3f(0.0F, 0.0F, 0.0F);
        }
        return new Vec3f(value.getX(), value.getY(), value.getZ());
    }

    private static Vec3f blendVec(Vec3f from, Vec3f to, float t) {
        float clamped = clamp01(t);
        return new Vec3f(
                from.getX() + (to.getX() - from.getX()) * clamped,
                from.getY() + (to.getY() - from.getY()) * clamped,
                from.getZ() + (to.getZ() - from.getZ()) * clamped
        );
    }

    private static Vec3f scaleDifference(Vec3f from, Vec3f to, float factor) {
        return new Vec3f(
                (to.getX() - from.getX()) * factor,
                (to.getY() - from.getY()) * factor,
                (to.getZ() - from.getZ()) * factor
        );
    }

    private static Vec3f scaleDifference(Vec3f value, float factor) {
        return new Vec3f(
                value.getX() * factor,
                value.getY() * factor,
                value.getZ() * factor
        );
    }

    private static float sharedVelocity(
            float incoming,
            float outgoing,
            float factor
    ) {
        if (Math.abs(incoming) < 1.0E-5F
                || Math.abs(outgoing) < 1.0E-5F
                || incoming * outgoing < 0.0F) {
            return 0.0F;
        }
        return (incoming + outgoing) * 0.5F * factor;
    }

    private static Vec3f sharedVelocity(
            Vec3f incoming,
            Vec3f outgoing,
            float factor
    ) {
        return new Vec3f(
                sharedVelocity(incoming.getX(), outgoing.getX(), factor),
                sharedVelocity(incoming.getY(), outgoing.getY(), factor),
                sharedVelocity(incoming.getZ(), outgoing.getZ(), factor)
        );
    }

    private static Vec3f cubicHermite(
            Vec3f p0,
            Vec3f p1,
            Vec3f m0,
            Vec3f m1,
            float t
    ) {
        float t2 = t * t;
        float t3 = t2 * t;
        float h00 = 2.0F * t3 - 3.0F * t2 + 1.0F;
        float h10 = t3 - 2.0F * t2 + t;
        float h01 = -2.0F * t3 + 3.0F * t2;
        float h11 = t3 - t2;
        return new Vec3f(
                h00 * p0.getX() + h10 * m0.getX() + h01 * p1.getX() + h11 * m1.getX(),
                h00 * p0.getY() + h10 * m0.getY() + h01 * p1.getY() + h11 * m1.getY(),
                h00 * p0.getZ() + h10 * m0.getZ() + h01 * p1.getZ() + h11 * m1.getZ()
        );
    }

    private record CurveProfile(
            float startVelocityFactor,
            float endVelocityFactor,
            float middleVelocityFactor
    ) {
        private static CurveProfile forMode(SuccessTransitionMode mode) {
            return switch (mode) {
                case SMOOTH -> new CurveProfile(0.0F, 0.0F, 1.0F);
                case EASE_IN -> new CurveProfile(0.0F, 1.5F, 1.0F);
                case EASE_OUT -> new CurveProfile(1.5F, 0.0F, 1.0F);
                case QUICK -> new CurveProfile(2.5F, 0.0F, 1.0F);
                case STRONG_EASE_IN -> new CurveProfile(0.0F, 2.0F, 1.0F);
                case STRONG_EASE_OUT -> new CurveProfile(2.0F, 0.0F, 1.0F);
                case OVERSHOOT -> new CurveProfile(1.2F, 0.0F, 1.15F);
                default -> new CurveProfile(1.0F, 1.0F, 1.0F);
            };
        }
    }

    private static float easeInCubic(float t) {
        return t * t * t;
    }

    private static float easeOutQuartic(float t) {
        float inverse = 1.0F - t;
        float inverse2 = inverse * inverse;
        return 1.0F - inverse2 * inverse2;
    }

    private static float easeInQuintic(float t) {
        return t * t * t * t * t;
    }

    private static float easeOutQuintic(float t) {
        float inverse = 1.0F - t;
        float inverse2 = inverse * inverse;
        float inverse4 = inverse2 * inverse2;
        return 1.0F - inverse4 * inverse;
    }

    private static float easeOutCubic(float t) {
        float inverse = 1.0F - t;
        return 1.0F - inverse * inverse * inverse;
    }

    private static float subtleOvershoot(float t) {
        // A deliberately restrained back-curve. The peak is only about 3% past
        // the target so the motion reads as a physical settle, not a bounce.
        final float c1 = 0.9F;
        final float c3 = c1 + 1.0F;
        float shifted = t - 1.0F;

        return 1.0F
                + c3 * shifted * shifted * shifted
                + c1 * shifted * shifted;
    }

    private static float clamp01(float value) {
        return Math.max(0.0F, Math.min(1.0F, value));
    }
}
