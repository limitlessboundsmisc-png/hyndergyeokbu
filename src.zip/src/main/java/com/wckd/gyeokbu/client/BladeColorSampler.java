package com.wckd.gyeokbu.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.FastColor;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Best-effort client-side blade palette extraction for successful-Parry sparks.
 *
 * Arbitrary modded models do not expose a semantic "blade" region, so this
 * samples the sprites actually used by the held item and filters colors that
 * are strongly likely to be dark/black or wooden brown handle material.
 */
public final class BladeColorSampler {

    private static final int WHITE = 0xFFFFFF;
    private static final int MAX_PALETTE_COLORS = 24;

    private BladeColorSampler() {
    }

    public static int[] sample(ItemStack stack, LivingEntity holder) {
        if (stack == null || stack.isEmpty()) {
            return new int[]{WHITE};
        }

        int[] override = BladeColorOverrideConfig.paletteFor(stack);
        if (override != null && override.length > 0) {
            return brighterHalf(override);
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return new int[]{WHITE};
        }

        try {
            BakedModel root = minecraft.getItemRenderer().getModel(
                    stack,
                    minecraft.level,
                    holder,
                    holder == null ? 0 : holder.getId()
            );

            Set<TextureAtlasSprite> sprites = java.util.Collections.newSetFromMap(
                    new IdentityHashMap<>()
            );

            for (BakedModel pass : root.getRenderPasses(stack, false)) {
                collectSprites(pass, sprites);
            }

            Map<Integer, ColorBucket> buckets = new HashMap<>();
            for (TextureAtlasSprite sprite : sprites) {
                sampleSprite(sprite, buckets);
            }

            if (buckets.isEmpty()) {
                return new int[]{WHITE};
            }

            List<ColorBucket> ranked = new ArrayList<>(buckets.values());
            ranked.sort(Comparator.comparingInt(ColorBucket::count).reversed());

            int count = Math.min(MAX_PALETTE_COLORS, ranked.size());
            int[] palette = new int[count];
            for (int i = 0; i < count; i++) {
                palette[i] = ranked.get(i).averageRgb();
            }
            return brighterHalf(palette);
        } catch (Throwable ignored) {
            /* Custom renderers may not expose normal baked sprites. */
            return new int[]{WHITE};
        }
    }

    private static void collectSprites(
            BakedModel model,
            Set<TextureAtlasSprite> sprites
    ) {
        RandomSource random = RandomSource.create(0x4759454FL);
        collectQuadSprites(model.getQuads(null, null, random), sprites);

        for (Direction direction : Direction.values()) {
            collectQuadSprites(
                    model.getQuads(null, direction, RandomSource.create(0x4759454FL + direction.ordinal())),
                    sprites
            );
        }
    }

    private static void collectQuadSprites(
            List<BakedQuad> quads,
            Set<TextureAtlasSprite> sprites
    ) {
        for (BakedQuad quad : quads) {
            if (quad != null && quad.getSprite() != null) {
                sprites.add(quad.getSprite());
            }
        }
    }

    private static void sampleSprite(
            TextureAtlasSprite sprite,
            Map<Integer, ColorBucket> buckets
    ) {
        int width = Math.max(1, sprite.contents().width());
        int height = Math.max(1, sprite.contents().height());

        /* Cap work for unusually large modded textures while still sampling broadly. */
        int xStep = Math.max(1, width / 32);
        int yStep = Math.max(1, height / 32);

        for (int y = 0; y < height; y += yStep) {
            for (int x = 0; x < width; x += xStep) {
                int abgr = sprite.getPixelRGBA(0, x, y);
                int alpha = FastColor.ABGR32.alpha(abgr);
                if (alpha < 64) {
                    continue;
                }

                int red = FastColor.ABGR32.red(abgr);
                int green = FastColor.ABGR32.green(abgr);
                int blue = FastColor.ABGR32.blue(abgr);

                if (!isLikelyBladeColor(red, green, blue)) {
                    continue;
                }

                /* 4 bits/channel merges tiny texture-noise variations. */
                int key = ((red >> 4) << 8) | ((green >> 4) << 4) | (blue >> 4);
                buckets.computeIfAbsent(key, ignored -> new ColorBucket())
                        .add(red, green, blue);
            }
        }
    }


    /** Keep only the brighter half of the sampled candidate colors. */
    private static int[] brighterHalf(int[] colors) {
        if (colors == null || colors.length <= 1) {
            return colors == null || colors.length == 0 ? new int[]{WHITE} : colors;
        }

        Integer[] sorted = new Integer[colors.length];
        for (int i = 0; i < colors.length; i++) {
            sorted[i] = colors[i];
        }

        java.util.Arrays.sort(sorted, Comparator.comparingDouble(BladeColorSampler::brightness));
        int start = colors.length / 2;
        int count = Math.max(1, colors.length - start);
        int[] bright = new int[count];
        for (int i = 0; i < count; i++) {
            bright[i] = sorted[start + i];
        }
        return bright;
    }

    private static double brightness(int rgb) {
        int red = (rgb >> 16) & 0xFF;
        int green = (rgb >> 8) & 0xFF;
        int blue = rgb & 0xFF;
        return 0.2126D * red + 0.7152D * green + 0.0722D * blue;
    }
    public static boolean isAllowedBladeColor(int rgb) {
        int red = (rgb >> 16) & 0xFF;
        int green = (rgb >> 8) & 0xFF;
        int blue = rgb & 0xFF;
        return isLikelyBladeColor(red, green, blue);
    }

    private static boolean isLikelyBladeColor(int red, int green, int blue) {
        int max = Math.max(red, Math.max(green, blue));
        int min = Math.min(red, Math.min(green, blue));

        /* Exclude black and very dark handle/outline pixels. */
        if (max < 58) {
            return false;
        }

        float value = max / 255.0F;
        float saturation = max == 0 ? 0.0F : (max - min) / (float) max;
        float hue = hueDegrees(red, green, blue, max, min);

        /*
         * Exclude ordinary brown/wood tones while keeping bright gold/bronze
         * blade colors. Brown is primarily orange/yellow hue at lower value.
         */
        boolean brown = hue >= 15.0F
                && hue <= 55.0F
                && saturation >= 0.28F
                && value < 0.78F
                && red >= green
                && green > blue;

        return !brown;
    }

    private static float hueDegrees(
            int red,
            int green,
            int blue,
            int max,
            int min
    ) {
        if (max == min) {
            return 0.0F;
        }

        float delta = max - min;
        float hue;
        if (max == red) {
            hue = 60.0F * (((green - blue) / delta) % 6.0F);
        } else if (max == green) {
            hue = 60.0F * (((blue - red) / delta) + 2.0F);
        } else {
            hue = 60.0F * (((red - green) / delta) + 4.0F);
        }

        return hue < 0.0F ? hue + 360.0F : hue;
    }

    private static final class ColorBucket {
        private long red;
        private long green;
        private long blue;
        private int count;

        void add(int red, int green, int blue) {
            this.red += red;
            this.green += green;
            this.blue += blue;
            this.count++;
        }

        int count() {
            return count;
        }

        int averageRgb() {
            int divisor = Math.max(1, count);
            int r = (int) (red / divisor);
            int g = (int) (green / divisor);
            int b = (int) (blue / divisor);
            return (r << 16) | (g << 8) | b;
        }
    }
}
