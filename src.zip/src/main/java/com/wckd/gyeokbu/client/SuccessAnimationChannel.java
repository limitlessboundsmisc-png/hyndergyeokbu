package com.wckd.gyeokbu.client;

public enum SuccessAnimationChannel {
    MAIN_ARM_X("main_arm_x", Group.ARMS), MAIN_ARM_Y("main_arm_y", Group.ARMS), MAIN_ARM_Z("main_arm_z", Group.ARMS),
    OFF_ARM_X("off_arm_x", Group.ARMS), OFF_ARM_Y("off_arm_y", Group.ARMS), OFF_ARM_Z("off_arm_z", Group.ARMS),
    MAIN_WEAPON_POS_X("main_weapon_pos_x", Group.MAIN_WEAPON), MAIN_WEAPON_POS_Y("main_weapon_pos_y", Group.MAIN_WEAPON), MAIN_WEAPON_POS_Z("main_weapon_pos_z", Group.MAIN_WEAPON),
    MAIN_WEAPON_ROT_X("main_weapon_rot_x", Group.MAIN_WEAPON), MAIN_WEAPON_ROT_Y("main_weapon_rot_y", Group.MAIN_WEAPON), MAIN_WEAPON_ROT_Z("main_weapon_rot_z", Group.MAIN_WEAPON),
    OFF_WEAPON_POS_X("off_weapon_pos_x", Group.OFF_WEAPON), OFF_WEAPON_POS_Y("off_weapon_pos_y", Group.OFF_WEAPON), OFF_WEAPON_POS_Z("off_weapon_pos_z", Group.OFF_WEAPON),
    OFF_WEAPON_ROT_X("off_weapon_rot_x", Group.OFF_WEAPON), OFF_WEAPON_ROT_Y("off_weapon_rot_y", Group.OFF_WEAPON), OFF_WEAPON_ROT_Z("off_weapon_rot_z", Group.OFF_WEAPON);

    private final String jsonName;
    private final Group group;

    SuccessAnimationChannel(String jsonName, Group group) {
        this.jsonName = jsonName;
        this.group = group;
    }

    public String jsonName() { return jsonName; }
    public Group group() { return group; }
    public boolean isOffWeapon() { return group == Group.OFF_WEAPON; }

    public enum Group { ARMS, MAIN_WEAPON, OFF_WEAPON }
}
