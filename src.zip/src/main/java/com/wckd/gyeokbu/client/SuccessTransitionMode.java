package com.wckd.gyeokbu.client;

import java.util.Locale;

/**
 * Successful Parry-specific interpolation modes.
 *
 * These are intentionally separate from the stance transition modes so
 * Successful Parry can expose more expressive impact curves without changing
 * the working stance animation system.
 */
public enum SuccessTransitionMode {
    SNAP("Snap"),
    LINEAR("Linear"),
    SMOOTH("Smooth"),
    EASE_IN("Ease In"),
    EASE_OUT("Ease Out"),
    QUICK("Quick"),
    STRONG_EASE_IN("Strong Ease In"),
    STRONG_EASE_OUT("Strong Ease Out"),
    OVERSHOOT("Overshoot");

    private final String displayName;

    SuccessTransitionMode(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }

    public static SuccessTransitionMode fromSerializedName(
            String value,
            SuccessTransitionMode fallback
    ) {
        if (value == null) {
            return fallback;
        }

        return switch (value.trim().toLowerCase(Locale.ROOT)) {
            case "snap" -> SNAP;
            case "linear" -> LINEAR;
            case "smooth" -> SMOOTH;
            case "ease_in" -> EASE_IN;
            case "ease_out" -> EASE_OUT;
            case "quick" -> QUICK;
            case "strong_ease_in" -> STRONG_EASE_IN;
            case "strong_ease_out" -> STRONG_EASE_OUT;
            case "overshoot" -> OVERSHOOT;
            default -> fallback;
        };
    }
}
