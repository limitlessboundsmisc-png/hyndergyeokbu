package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.player.AbstractClientPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Client-only interpolation for Gyeokbu stance visuals.
 *
 * The server still changes PARRY/BLOCK/NONE immediately. Each client receives
 * that synchronized state and performs its own visual interpolation locally,
 * so there is no per-frame networking and no effect on combat timing.
 */
public final class DefensePoseTransitionRuntime {

    public static final String RIGHT_ARM = "right_arm";
    public static final String LEFT_ARM = "left_arm";
    public static final String MAIN_WEAPON_POSITION = "main_weapon_position";
    public static final String MAIN_WEAPON_ROTATION = "main_weapon_rotation";
    public static final String OFF_WEAPON_POSITION = "off_weapon_position";
    public static final String OFF_WEAPON_ROTATION = "off_weapon_rotation";

    private static final Map<ViewKey, ViewState> VIEWS = new HashMap<>();
    private static final Map<ChannelKey, ChannelState> CHANNELS = new HashMap<>();

    private DefensePoseTransitionRuntime() {
    }

    /**
     * True while the actual defense state is active OR while an animated
     * release transition is still visually returning to the underlying pose.
     */
    public static boolean isVisualActive(
            AbstractClientPlayer player,
            boolean firstPerson,
            int currentMode
    ) {
        ViewState view = observeMode(
                player,
                firstPerson,
                currentMode
        );

        if (currentMode != DefenseAnimationSyncPayload.NONE) {
            return true;
        }

        /*
         * Click-mode Parry is a short, server-authoritative timing window.
         * When that window ends (success, miss, or cooldown rejection), the
         * Parry pose must disappear immediately instead of spending the stance
         * transition duration visually easing out. Otherwise a rejected click
         * during missed-Parry cooldown can look like a new Parry started.
         *
         * Block release keeps the configured exit interpolation.
         */
        if (view.transitionFromMode == DefenseAnimationSyncPayload.PARRY) {
            clearViewIfIdle(player, firstPerson);
            return false;
        }

        if (!DefenseTransitionConfig.isAnimated()) {
            clearViewIfIdle(player, firstPerson);
            return false;
        }

        long now = System.nanoTime();
        boolean exiting = view.transitionFromMode != DefenseAnimationSyncPayload.NONE
                && now < view.transitionStartNanos
                + DefenseTransitionConfig.durationNanos();

        if (!exiting) {
            clearViewIfIdle(player, firstPerson);
        }

        return exiting;
    }

    /**
     * Samples one visual vector channel. The caller supplies the live target
     * and the underlying/base value for this render frame.
     *
     * When the target mode changes midway through a transition, the new
     * transition starts from the last value that was actually rendered. This
     * keeps PARRY -> BLOCK and early-release interruptions continuous.
     */
    public static Vec3f sample(
            AbstractClientPlayer player,
            boolean firstPerson,
            String channel,
            int currentMode,
            Vec3f activeTarget,
            Vec3f baseValue
    ) {
        ViewState view = observeMode(
                player,
                firstPerson,
                currentMode
        );

        Vec3f target = currentMode == DefenseAnimationSyncPayload.NONE
                || activeTarget == null
                ? baseValue
                : activeTarget;

        /* Match isVisualActive(): Parry release is visually immediate. */
        if (currentMode == DefenseAnimationSyncPayload.NONE
                && view.transitionFromMode == DefenseAnimationSyncPayload.PARRY) {
            return baseValue;
        }

        ChannelKey key = new ChannelKey(
                player.getUUID(),
                firstPerson,
                channel
        );

        ChannelState state = CHANNELS.computeIfAbsent(
                key,
                ignored -> new ChannelState()
        );

        if (!DefenseTransitionConfig.isAnimated()) {
            state.generation = view.generation;
            state.initialized = true;
            state.from = target;
            state.lastOutput = target;
            return target;
        }

        long now = System.nanoTime();

        if (!state.initialized) {
            state.initialized = true;
            state.generation = view.generation;
            state.from = baseValue;
            state.lastOutput = baseValue;
        } else if (state.generation != view.generation) {
            /*
             * lastOutput is the exact value rendered on the previous frame.
             * Using it here prevents a new transition from snapping back to a
             * fixed start pose before moving toward its new target.
             */
            state.from = state.lastOutput;
            state.generation = view.generation;
        }

        float progress = transitionProgress(view, now);
        Vec3f output = lerp(
                state.from,
                target,
                progress
        );

        state.lastOutput = output;
        return output;
    }

    /**
     * Seeds the next defensive transition from an already-playing visual pose.
     * This is used when a Successful Parry is interrupted by a new Parry so
     * the new defensive stance continues smoothly from the exact pose the
     * player was seeing instead of snapping back to the underlying base pose.
     */
    public static void seedFromPose(
            AbstractClientPlayer player,
            boolean firstPerson,
            SuccessAnimationConfig.PoseData pose
    ) {
        if (player == null || pose == null) {
            return;
        }

        ViewState state = VIEWS.computeIfAbsent(
                new ViewKey(player.getUUID(), firstPerson),
                ignored -> new ViewState()
        );
        state.pendingSeed = pose.copy();
    }

    public static void reset() {
        VIEWS.clear();
        CHANNELS.clear();
    }

    private static ViewState observeMode(
            AbstractClientPlayer player,
            boolean firstPerson,
            int currentMode
    ) {
        ViewKey key = new ViewKey(
                player.getUUID(),
                firstPerson
        );

        ViewState state = VIEWS.computeIfAbsent(
                key,
                ignored -> new ViewState()
        );

        if (!state.initialized) {
            state.initialized = true;
            state.currentMode = DefenseAnimationSyncPayload.NONE;
            state.transitionFromMode = DefenseAnimationSyncPayload.NONE;
            state.transitionStartNanos = System.nanoTime();
        }

        if (state.currentMode != currentMode) {
            state.transitionFromMode = state.currentMode;
            state.currentMode = currentMode;
            state.transitionStartNanos = System.nanoTime();
            state.generation++;
        }

        return state;
    }

    private static float transitionProgress(
            ViewState view,
            long now
    ) {
        long duration = DefenseTransitionConfig.durationNanos();

        if (duration <= 0L) {
            return 1.0F;
        }

        double raw = (double) (now - view.transitionStartNanos)
                / (double) duration;

        float t = (float) Math.max(
                0.0D,
                Math.min(1.0D, raw)
        );

        return applyCurve(t);
    }

    /**
     * Converts normalized time into normalized visual movement.
     *
     * SNAP: immediate visual placement.
     * LINEAR: exact constant-speed interpolation.
     * SMOOTH: natural acceleration and deceleration with zero velocity at
     * both ends.
     * QUICK: fast response followed by a controlled settle.
     * OVERSHOOT: a restrained follow-through that settles just past the
     * target without the large bounce of a generic back curve.
     */
    private static float applyCurve(float t) {
        return GyeokbuTransitionCurves.apply(t, DefenseTransitionConfig.mode());
    }


    private static Vec3f lerp(
            Vec3f from,
            Vec3f to,
            float progress
    ) {
        float inverse = 1.0F - progress;

        return new Vec3f(
                from.getX() * inverse + to.getX() * progress,
                from.getY() * inverse + to.getY() * progress,
                from.getZ() * inverse + to.getZ() * progress
        );
    }

    private static void clearViewIfIdle(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        UUID uuid = player.getUUID();

        VIEWS.remove(
                new ViewKey(uuid, firstPerson)
        );

        CHANNELS.keySet().removeIf(
                key -> key.playerId.equals(uuid)
                        && key.firstPerson == firstPerson
        );
    }

    private record ViewKey(
            UUID playerId,
            boolean firstPerson
    ) {
    }

    private record ChannelKey(
            UUID playerId,
            boolean firstPerson,
            String channel
    ) {
    }

    private static final class ViewState {
        private boolean initialized;
        private int currentMode;
        private int transitionFromMode;
        private long transitionStartNanos;
        private long generation;
        private SuccessAnimationConfig.PoseData pendingSeed;
    }

    private static final class ChannelState {
        private boolean initialized;
        private long generation;
        private Vec3f from;
        private Vec3f lastOutput;
    }
}
