package com.wckd.gyeokbu.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Optional per-item blade palettes for modded weapons whose model cannot be
 * separated into blade/handle colors reliably from baked-model data alone.
 *
 * Format:
 * {
 *   "minecraft:diamond_sword": ["#5CE6E6", "#8CFFFF"]
 * }
 */
public final class BladeColorOverrideConfig {

    private static final Map<ResourceLocation, int[]> OVERRIDES = new HashMap<>();

    private BladeColorOverrideConfig() {
    }

    public static void initialize() {
        reload();
    }

    public static void reload() {
        OVERRIDES.clear();
        Path path = getPath();

        try {
            Files.createDirectories(path.getParent());
            if (!Files.exists(path)) {
                Files.writeString(path, "{}\n", StandardCharsets.UTF_8);
                return;
            }

            JsonObject root = JsonParser.parseString(
                    Files.readString(path, StandardCharsets.UTF_8)
            ).getAsJsonObject();

            for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
                ResourceLocation itemId;
                try {
                    itemId = ResourceLocation.parse(entry.getKey());
                } catch (Exception ignored) {
                    continue;
                }

                if (!entry.getValue().isJsonArray()) {
                    continue;
                }

                JsonArray array = entry.getValue().getAsJsonArray();
                List<Integer> colors = new ArrayList<>();
                for (JsonElement element : array) {
                    if (!element.isJsonPrimitive()) {
                        continue;
                    }

                    Integer color = parseColor(element.getAsString());
                    if (color != null && BladeColorSampler.isAllowedBladeColor(color)) {
                        colors.add(color);
                    }
                }

                if (!colors.isEmpty()) {
                    int[] palette = new int[colors.size()];
                    for (int i = 0; i < colors.size(); i++) {
                        palette[i] = colors.get(i);
                    }
                    OVERRIDES.put(itemId, palette);
                }
            }
        } catch (Exception exception) {
            OVERRIDES.clear();
            GyeokbuV2.LOGGER.error(
                    "Failed to load Gyeokbu blade-color overrides. Automatic color sampling will be used.",
                    exception
            );
        }
    }

    public static int[] paletteFor(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return null;
        }

        ResourceLocation itemId = BuiltInRegistries.ITEM.getKey(stack.getItem());
        int[] palette = OVERRIDES.get(itemId);
        return palette == null ? null : palette.clone();
    }

    private static Integer parseColor(String raw) {
        if (raw == null) {
            return null;
        }

        String value = raw.trim().toUpperCase(Locale.ROOT);
        if (value.startsWith("#")) {
            value = value.substring(1);
        } else if (value.startsWith("0X")) {
            value = value.substring(2);
        }

        if (value.length() != 6) {
            return null;
        }

        try {
            return Integer.parseInt(value, 16) & 0xFFFFFF;
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private static Path getPath() {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("blade_color_overrides.json");
    }
}
