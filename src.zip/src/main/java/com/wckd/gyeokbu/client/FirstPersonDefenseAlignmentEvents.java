package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * First-person-only visual alignment for the PlayerAnimator defense model.
 *
 * Activation:
 *   one immediate snap to the current look direction.
 *
 * While held:
 *   update only CURRENT body/head yaw and let Minecraft's normal render
 *   interpolation move from the previous value to the new value. This keeps
 *   the model visually locked to the player's look direction without the
 *   repeated hard snapping from V15.
 *
 * Release:
 *   stop touching the visual values immediately.
 *
 * This is local visual state only. No packet or server rotation is changed.
 */
@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public final class FirstPersonDefenseAlignmentEvents {

    private static boolean wasActive =
            false;

    private FirstPersonDefenseAlignmentEvents() {
    }

    @SubscribeEvent
    public static void onClientTick(
            ClientTickEvent.Post event
    ) {

        Minecraft minecraft =
                Minecraft.getInstance();

        LocalPlayer player =
                minecraft.player;

        boolean successFirstPersonEditor =
                SuccessAnimationConfig.isEditorFirstPerson();

        if (player == null
                || minecraft.options
                        .getCameraType()
                        != CameraType.FIRST_PERSON
                || (AnimationPoseConfig.isEditorActive()
                && !successFirstPersonEditor)
                || (DualWieldPoseConfig.isEditorActive()
                && !successFirstPersonEditor)) {

            wasActive =
                    false;

            return;
        }

        int visualMode =
                ClientCombatSyncState
                        .getFirstPersonDefenseVisualMode(
                                player.getId()
                        );

        boolean active =
                successFirstPersonEditor
                        || DefensePoseTransitionRuntime.isVisualActive(
                        player,
                        true,
                        visualMode
                )
                        || SuccessAnimationRuntime.isActive(player, true);

        if (!active) {

            wasActive =
                    false;

            return;
        }

        /*
         * During the Successful Parry first-person editor, the body/head must
         * follow the actual camera view direction exactly. The normal
         * interpolated body-yaw path is useful for live defense, but it leaves
         * the editor one render state behind the player's POV.
         */
        if (successFirstPersonEditor) {
            float lookYaw =
                    player.getViewYRot(1.0F);

            player.yBodyRot =
                    lookYaw;
            player.yBodyRotO =
                    lookYaw;
            player.yHeadRot =
                    lookYaw;
            player.yHeadRotO =
                    lookYaw;

            wasActive =
                    true;

            return;
        }

        float lookYaw =
                player.getYRot();

        if (!wasActive) {

            /*
             * Initial responsiveness:
             * remove all body-yaw catch-up on the frame Gyeokbu begins.
             */
            player.yBodyRot =
                    lookYaw;

            player.yBodyRotO =
                    lookYaw;

            player.yHeadRot =
                    lookYaw;

            player.yHeadRotO =
                    lookYaw;

            wasActive =
                    true;

            return;
        }

        /*
         * While held:
         * only move CURRENT values. We intentionally keep the previous
         * render values untouched so interpolation produces a smooth visual
         * follow instead of a hard snap every tick.
         */
        player.yBodyRot =
                lookYaw;

        player.yHeadRot =
                lookYaw;
    }
}
