package com.wckd.gyeokbu.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;

import java.lang.reflect.Method;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Optional third-person compatibility bridge for EMF-backed player animation
 * packs such as Fresh Moves.
 *
 * During a live Successful Parry in third person, Gyeokbu owns the Success
 * arm/item channels. EMF custom player animations must therefore not inject a
 * second body/head/root presentation over that render. We pause EMF's custom
 * animations only for the duration of that player's third-person render.
 *
 * The bridge is reflection-based so EMF remains optional. No common/server code
 * references EMF classes directly.
 *
 * First person is deliberately never paused.
 */
@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public final class ThirdPersonSuccessPresentationCompat {

    private static final Set<Integer> PAUSED_ENTITIES =
            ConcurrentHashMap.newKeySet();

    private static volatile boolean initialized = false;
    private static volatile boolean unavailable = false;

    private static Method emfEntityOf;
    private static Method pauseAllCustomAnimations;
    private static Method resumeAllCustomAnimations;

    private ThirdPersonSuccessPresentationCompat() {
    }

    /**
     * Pauses EMF custom animations immediately before a third-person player
     * render when Successful Parry is running, then restores them immediately
     * after that render. This keeps the compatibility scoped to the affected
     * render instead of changing persistent player/model state.
     */
    @SubscribeEvent
    public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        if (!(event.getEntity() instanceof AbstractClientPlayer player)) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        boolean localFirstPerson =
                minecraft.player == player
                        && minecraft.options.getCameraType() == CameraType.FIRST_PERSON;

        if (localFirstPerson
                || !SuccessAnimationRuntime.isRunning(player, false)) {
            release(player.getId());
            return;
        }

        pause(player);
    }

    @SubscribeEvent
    public static void onRenderPlayerPost(RenderPlayerEvent.Post event) {
        release(event.getEntity().getId());
    }

    /**
     * Safety cleanup for a render canceled by another event listener. Normally
     * RenderPlayerEvent.Post handles this immediately; this only releases
     * entities that are no longer in a live third-person Success render state.
     */
    @SubscribeEvent
    public static void onClientTick(net.neoforged.neoforge.client.event.ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            clear();
            return;
        }

        for (Integer entityId : PAUSED_ENTITIES.toArray(Integer[]::new)) {
            Entity entity = minecraft.level.getEntity(entityId);
            if (!(entity instanceof AbstractClientPlayer player)
                    || !SuccessAnimationRuntime.isRunning(player, false)) {
                release(entityId);
            }
        }
    }

    @SubscribeEvent
    public static void onClientLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        clear();
    }

    private static void pause(AbstractClientPlayer player) {
        if (player == null
                || !ModList.get().isLoaded("entity_model_features")
                || PAUSED_ENTITIES.contains(player.getId())) {
            return;
        }

        if (!ensureInitialized()) {
            return;
        }

        try {
            Object emfEntity = emfEntityOf.invoke(null, player);
            if (emfEntity == null) {
                return;
            }

            Object result = pauseAllCustomAnimations.invoke(null, emfEntity);
            if (Boolean.TRUE.equals(result)) {
                PAUSED_ENTITIES.add(player.getId());
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            /* Optional compatibility must never destabilize the client. */
        }
    }

    /** Resume EMF custom animations for an entity previously isolated here. */
    public static void release(int entityId) {
        if (!PAUSED_ENTITIES.remove(entityId)) {
            return;
        }

        if (!ensureInitialized()) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }

        Entity entity = minecraft.level.getEntity(entityId);
        if (entity == null) {
            return;
        }

        try {
            Object emfEntity = emfEntityOf.invoke(null, entity);
            if (emfEntity != null) {
                resumeAllCustomAnimations.invoke(null, emfEntity);
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            /* Optional compatibility must never destabilize the client. */
        }
    }

    /** Release every entity still tracked by this bridge. */
    public static void clear() {
        for (Integer entityId : PAUSED_ENTITIES.toArray(Integer[]::new)) {
            release(entityId);
        }
        PAUSED_ENTITIES.clear();
    }

    private static synchronized boolean ensureInitialized() {
        if (initialized) {
            return true;
        }
        if (unavailable) {
            return false;
        }

        try {
            Class<?> api = Class.forName(
                    "traben.entity_model_features.EMFAnimationApi"
            );

            emfEntityOf = api.getMethod(
                    "emfEntityOf",
                    Entity.class
            );

            Class<?> emfEntityType = emfEntityOf.getReturnType();

            pauseAllCustomAnimations = api.getMethod(
                    "pauseAllCustomAnimationsForEntity",
                    emfEntityType
            );

            resumeAllCustomAnimations = api.getMethod(
                    "resumeAllCustomAnimationsForEntity",
                    emfEntityType
            );

            initialized = true;
            return true;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            unavailable = true;
            return false;
        }
    }
}
