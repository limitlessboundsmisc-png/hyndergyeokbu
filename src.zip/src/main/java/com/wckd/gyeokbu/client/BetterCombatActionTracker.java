package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.BetterCombatActionStatePayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public final class BetterCombatActionTracker {

    private static boolean initialized = false;
    private static boolean disabledAfterError = false;

    private static boolean attackActive = false;
    private static boolean attackConfirmed = false;

    private static int attackGeneration = 0;

    /*
     * Keep a strong reference to the reflection proxy.
     */
    private static Object attackStartListener = null;

    private static Class<?> clientApiClass = null;
    private static Method isWeaponSwingInProgressMethod = null;

    private BetterCombatActionTracker() {
    }

    @SubscribeEvent
    public static void onClientTick(
            ClientTickEvent.Post event
    ) {

        Minecraft minecraft =
                Minecraft.getInstance();

        if (minecraft.player == null) {

            resetLocalState();
            return;
        }

        ensureInitialized();

        if (!initialized
                || disabledAfterError
                || !attackActive) {

            return;
        }

        /*
         * Better Combat has finished the current
         * attack animation/action.
         */
        if (!isBetterCombatSwingActive()) {

            PacketDistributor.sendToServer(
                    new BetterCombatActionStatePayload(
                            attackGeneration,
                            false
                    )
            );

            attackActive =
                    false;

            attackConfirmed =
                    false;
        }
    }

    /**
     * Before a Gyeokbu defense request is sent, reconcile Better Combat's
     * tracked attack state with its live swing state.
     *
     * Some custom Better Combat weapon definitions can leave the event-driven
     * attack marker alive longer than the actual swing. Sending the matching
     * end packet first prevents that stale marker from making the server reject
     * an otherwise idle Parry. A genuinely active swing is never cleared here,
     * so the existing hit-confirm anti-abuse rule remains intact.
     */
    public static void synchronizeBeforeParryRequest() {

        if (!ModList.get().isLoaded("bettercombat")
                || !attackActive) {
            return;
        }

        ensureInitialized();

        boolean stale =
                disabledAfterError
                        || !initialized
                        || !isBetterCombatSwingActive();

        if (!stale) {
            return;
        }

        PacketDistributor.sendToServer(
                new BetterCombatActionStatePayload(
                        attackGeneration,
                        false
                )
        );

        attackActive = false;
        attackConfirmed = false;
    }

    public static boolean canAttemptParry() {

        /*
         * Better Combat absent:
         * Gyeokbu behaves normally.
         */
        if (!ModList.get()
                .isLoaded("bettercombat")) {

            return true;
        }

        /*
         * No active attack:
         * free to parry.
         */
        if (!attackActive) {
            return true;
        }

        /*
         * Active swing:
         * parry requires a server-confirmed,
         * positive-damage melee hit.
         */
        return attackConfirmed;
    }

    public static void markAttackConfirmed(
            int generation
    ) {

        if (!attackActive) {
            return;
        }

        if (generation
                != attackGeneration) {

            return;
        }

        attackConfirmed =
                true;
    }

    private static void beginAttack() {

        attackGeneration++;

        /*
         * Avoid ever using zero if the int wraps.
         */
        if (attackGeneration <= 0) {
            attackGeneration = 1;
        }

        attackActive =
                true;

        attackConfirmed =
                false;

        PacketDistributor.sendToServer(
                new BetterCombatActionStatePayload(
                        attackGeneration,
                        true
                )
        );
    }

    private static void ensureInitialized() {

        if (initialized
                || disabledAfterError
                || !ModList.get()
                .isLoaded("bettercombat")) {

            return;
        }

        try {

            /*
             * Better Combat 2.4.0 public client event:
             *
             * BetterCombatClientEvents.ATTACK_START
             */
            Class<?> eventsClass =
                    Class.forName(
                            "net.bettercombat.api.client.BetterCombatClientEvents"
                    );

            Class<?> attackStartInterface =
                    Class.forName(
                            "net.bettercombat.api.client.BetterCombatClientEvents$PlayerAttackStart"
                    );

            Field attackStartField =
                    eventsClass.getField(
                            "ATTACK_START"
                    );

            Object publisher =
                    attackStartField.get(
                            null
                    );

            attackStartListener =
                    Proxy.newProxyInstance(
                            BetterCombatActionTracker.class
                                    .getClassLoader(),

                            new Class<?>[]{
                                    attackStartInterface
                            },

                            (proxy, method, args) -> {

                                if ("onPlayerAttackStart"
                                        .equals(
                                                method.getName()
                                        )) {

                                    beginAttack();
                                }

                                return null;
                            }
                    );

            Method registerMethod =
                    publisher.getClass()
                            .getMethod(
                                    "register",
                                    Object.class
                            );

            registerMethod.invoke(
                    publisher,
                    attackStartListener
            );

            /*
             * Better Combat's client API lets us
             * determine when the swing has ended.
             */
            clientApiClass =
                    Class.forName(
                            "net.bettercombat.api.MinecraftClient_BetterCombat"
                    );

            isWeaponSwingInProgressMethod =
                    clientApiClass.getMethod(
                            "isWeaponSwingInProgress"
                    );

            initialized =
                    true;

            GyeokbuV2.LOGGER.info(
                    "Better Combat attack commit tracking enabled."
            );

        } catch (ReflectiveOperationException exception) {

            disabledAfterError =
                    true;

            GyeokbuV2.LOGGER.warn(
                    "Could not initialize Better Combat attack tracking. "
                            + "Gyeokbu will not use Better Combat hit-confirm locking "
                            + "for this session.",
                    exception
            );
        }
    }

    private static boolean isBetterCombatSwingActive() {

        Minecraft minecraft =
                Minecraft.getInstance();

        if (minecraft.player == null
                || clientApiClass == null
                || isWeaponSwingInProgressMethod == null
                || !clientApiClass.isInstance(
                minecraft
        )) {

            return false;
        }

        try {

            return (boolean)
                    isWeaponSwingInProgressMethod.invoke(
                            minecraft
                    );

        } catch (ReflectiveOperationException exception) {

            disabledAfterError =
                    true;

            GyeokbuV2.LOGGER.warn(
                    "Better Combat swing-state lookup failed.",
                    exception
            );

            return false;
        }
    }

    private static void resetLocalState() {

        attackActive =
                false;

        attackConfirmed =
                false;

        attackGeneration =
                0;
    }
}