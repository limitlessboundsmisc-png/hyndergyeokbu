package com.wckd.gyeokbu.client;

import dev.kosmx.playerAnim.core.util.Vec3f;

/**
 * Shared first-person arm-pose math.
 *
 * Successful Parry and the defense animation layer both author arm rotations
 * in PlayerAnimator's Z -> Y -> X order. The player's camera pitch must be
 * applied as a parent rotation instead of simply adding to the saved X value.
 */
public final class FirstPersonPoseMath {

    private FirstPersonPoseMath() {
    }

    public static Vec3f applyCameraPitch(
            Vec3f savedPose,
            float cameraPitch
    ) {
        if (savedPose == null
                || Math.abs(cameraPitch) < 0.000001F) {
            return savedPose;
        }

        double x = savedPose.getX();
        double y = savedPose.getY();
        double z = savedPose.getZ();

        double cx = Math.cos(x);
        double sx = Math.sin(x);
        double cy = Math.cos(y);
        double sy = Math.sin(y);
        double cz = Math.cos(z);
        double sz = Math.sin(z);

        /* Saved arm matrix: Rz(z) * Ry(y) * Rx(x). */
        double s00 = cz * cy;
        double s01 = cz * sy * sx - sz * cx;
        double s02 = cz * sy * cx + sz * sx;

        double s10 = sz * cy;
        double s11 = sz * sy * sx + cz * cx;
        double s12 = sz * sy * cx - cz * sx;

        double s20 = -sy;
        double s21 = cy * sx;
        double s22 = cy * cx;

        double cp = Math.cos(cameraPitch);
        double sp = Math.sin(cameraPitch);

        /* Parent camera pitch: Rx(pitch) * savedMatrix. */
        double m00 = s00;
        double m01 = s01;
        double m02 = s02;

        double m10 = cp * s10 - sp * s20;
        double m11 = cp * s11 - sp * s21;
        double m12 = cp * s12 - sp * s22;

        double m20 = sp * s10 + cp * s20;
        double m21 = sp * s11 + cp * s21;
        double m22 = sp * s12 + cp * s22;

        /* Decompose back to Rz * Ry * Rx. */
        double sinY = clampUnit(-m20);
        double outY = Math.asin(sinY);
        double cosY = Math.cos(outY);

        double outX;
        double outZ;

        if (Math.abs(cosY) > 0.000001D) {
            outX = Math.atan2(m21, m22);
            outZ = Math.atan2(m10, m00);
        } else {
            /* Gimbal-lock fallback: keep a stable equivalent with X = 0. */
            outX = 0.0D;
            outZ = Math.atan2(-m01, m11);
        }

        return new Vec3f(
                (float) outX,
                (float) outY,
                (float) outZ
        );
    }

    private static double clampUnit(
            double value
    ) {
        return Math.max(-1.0D, Math.min(1.0D, value));
    }
}
