package com.wckd.gyeokbu.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.compat.BetterCombatWeaponMetadata;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.HandStyle;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Client-side Successful Parry animation configuration and editor state.
 *
 * The editable animation is intentionally independent from the normal Stance
 * editor. A Successful Parry is represented as:
 *
 *     current/custom Start Pose -> selected End Pose -> current live pose
 *
 * The whole sequence uses one total duration and one Successful Parry curve.
 * The authored End Pose is reached at an automatically chosen impact point
 * near one third of the total duration, leaving the remaining time for the
 * recovery back to the underlying pose.
 *
 * Start Pose can either be the player's current pose at the moment of success,
 * or an authored custom pose.  There is always at least one End Pose variant.
 *
 * First- and Third-Person are independent editable profiles with explicit copy tools.
 */
public final class SuccessAnimationConfig {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .create();

    private static final int DEFAULT_TOTAL_DURATION_TICKS = 6;
    private static final int MIN_TOTAL_DURATION_TICKS = 2;
    private static final int MAX_DURATION_TICKS = 50;
    private static final int MAX_END_POSES = 8;

    /*
     * The last successfully resolved/saved Successful Parry profile pair is
     * cached by canonical profile identity. Runtime and F8 therefore share
     * the same profile source instead of independently reconstructing it.
     */
    private static final Map<ProfileId, RuntimeProfileSet> RUNTIME_PROFILE_CACHE =
            new ConcurrentHashMap<>();

    private static boolean editorActive;
    private static boolean editorDual;
    private static boolean editorFirstPerson;
    private static ParryStyle editorStyle = ParryStyle.GENERIC;
    private static ResourceLocation editorItemId;
    private static ProfileSource editorProfileSource = ProfileSource.STYLE;
    /** Separate overview selection; editorPoint may temporarily be -1 for Start Pose editing. */
    private static int editorSelectedEndPose = 0;
    private static int editorPoint = 0;
    private static DefaultHandedness editorDefaultHandedness = DefaultHandedness.ONE_HANDED;
    private static HandStyle editorStyleHandedness = HandStyle.ONE_HANDED;
    private static boolean editorPoseTargetActive = false;

    private static Profile editorThirdProfile = Profile.empty();
    private static Profile editorFirstProfile = Profile.empty();

    private static Profile savedThirdProfile = Profile.empty();
    private static Profile savedFirstProfile = Profile.empty();

    /*
     * F8-only transition link state. When enabled, the currently visible
     * profile becomes the transition-settings source for both views. The
     * pre-link values are kept so disabling the link restores each view to
     * exactly the transition settings it had before linking.
     */
    private static boolean editorTransitionLinkEnabled;
    private static TransitionSettings preLinkThirdTransition;
    private static TransitionSettings preLinkFirstTransition;

    private static Profile clipboard;
    private static PoseData poseClipboard;

    private SuccessAnimationConfig() {
    }

    public enum DefaultHandedness {
        ONE_HANDED,
        TWO_HANDED;

        public String displayName() {
            return this == ONE_HANDED ? "One-Handed" : "Two-Handed";
        }
    }

    public enum ProfileSource {
        DEFAULT,
        FALLBACK,
        ITEM_OVERRIDE,
        STYLE
    }

    public record ProfileId(
            ProfileSource source,
            ParryStyle style,
            ResourceLocation itemId,
            DefaultHandedness handedness,
            HandStyle styleHandedness,
            boolean dualWield
    ) {
        public static ProfileId defaultProfile(
                boolean dualWield,
                DefaultHandedness handedness
        ) {
            return new ProfileId(
                    ProfileSource.DEFAULT,
                    ParryStyle.GENERIC,
                    null,
                    handedness,
                    null,
                    dualWield
            );
        }

        public static ProfileId fallback(
                boolean dualWield
        ) {
            return new ProfileId(
                    ProfileSource.FALLBACK,
                    ParryStyle.GENERIC,
                    null,
                    null,
                    null,
                    dualWield
            );
        }

            public static ProfileId itemOverride(
                boolean dualWield,
                ParryStyle style,
                ResourceLocation itemId
        ) {
            /* Exact-item identity is the item path itself; category is metadata,
             * not part of the persisted filename or cache identity. */
            return new ProfileId(
                    ProfileSource.ITEM_OVERRIDE,
                    ParryStyle.GENERIC,
                    itemId,
                    null,
                    null,
                    dualWield
            );
        }

        public static ProfileId style(
                boolean dualWield,
                ParryStyle style,
                HandStyle handStyle
        ) {
            return new ProfileId(
                    ProfileSource.STYLE,
                    style == null ? ParryStyle.GENERIC : style,
                    null,
                    null,
                    handStyle,
                    dualWield
            );
        }

        public static ProfileId style(
                boolean dualWield,
                ParryStyle style
        ) {
            return style(dualWield, style, null);
        }
    }

    /** The exact third-/first-person files that belong to one profile identity. */
    public record RuntimeProfileSet(
            ProfileId identity,
            Profile thirdPerson,
            Profile firstPerson
    ) {
        public RuntimeProfileSet copy() {
            return new RuntimeProfileSet(
                    identity,
                    thirdPerson == null ? null : thirdPerson.copy(),
                    firstPerson == null ? null : firstPerson.copy()
            );
        }
    }

    public enum PointAMode {
        CURRENT,
        CUSTOM;

        public String displayName() {
            return this == CURRENT ? "Current Pose" : "Custom Pose";
        }
    }

    /**
     * Open the normal category editor.  The exact held item is remembered for
     * Save Held/Clear Held Save, but category browsing always edits the selected
     * category profile rather than accidentally switching to an exact item file.
     */
    public static void beginEditor(
            SuccessAnimationKind kind,
            boolean dual
    ) {
        clearTransitionLinkState();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }

        ItemStack main = mc.player.getMainHandItem();
        editorDual = dual;
        WeaponProfile initialProfile = WeaponClassifier.classifyNatural(main);
        editorStyle = initialProfile.parryStyle();
        editorStyleHandedness = initialProfile.handStyle();
        editorItemId = main.isEmpty()
                ? null
                : BuiltInRegistries.ITEM.getKey(main.getItem());
        editorFirstPerson = mc.options.getCameraType() == net.minecraft.client.CameraType.FIRST_PERSON;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;

        if (editorItemId != null && hasItemOverrideFor(dual, editorItemId)) {
            editorProfileSource = ProfileSource.ITEM_OVERRIDE;
            loadEditorItemOverride(kind);
        } else if (!heldWeaponIsNaturallySupported(main)) {
            editorProfileSource = ProfileSource.FALLBACK;
            editorStyle = ParryStyle.GENERIC;
            loadFallbackProfile();
        } else {
            editorProfileSource = ProfileSource.STYLE;
            loadEditorProfiles(kind, editorStyle, false);
        }
        editorActive = true;
    }

    private static boolean heldWeaponIsNaturallySupported(ItemStack stack) {
        return WeaponClassifier.classifyNatural(stack).isSupported();
    }

    /** Open the separately editable DEFAULT profile. */
    public static void beginDefaultEditor(
            SuccessAnimationKind kind,
            boolean dual
    ) {
        clearTransitionLinkState();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }

        ItemStack main = mc.player.getMainHandItem();
        editorDual = dual;
        editorProfileSource = ProfileSource.DEFAULT;
        editorDefaultHandedness = detectDefaultHandedness(main);
        editorStyleHandedness = HandStyle.ONE_HANDED;
        editorStyle = WeaponClassifier.classifyNatural(main).parryStyle();
        editorItemId = main.isEmpty()
                ? null
                : BuiltInRegistries.ITEM.getKey(main.getItem());
        editorFirstPerson = mc.options.getCameraType() == net.minecraft.client.CameraType.FIRST_PERSON;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;

        loadEditorProfiles(kind, ParryStyle.GENERIC, true);
        editorActive = true;
    }

    public static void endEditor() {
        clearTransitionLinkState();
        editorActive = false;
        editorDual = false;
        editorFirstPerson = false;
        editorDefaultHandedness = DefaultHandedness.ONE_HANDED;
        editorStyle = ParryStyle.GENERIC;
        editorItemId = null;
        editorProfileSource = ProfileSource.STYLE;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;
        editorThirdProfile = Profile.empty();
        editorFirstProfile = Profile.empty();
        savedThirdProfile = Profile.empty();
        savedFirstProfile = Profile.empty();
    }

    public static boolean isEditorActive() {
        return editorActive;
    }

    public static boolean isEditorDual() {
        return editorDual;
    }

    public static boolean isEditorFirstPerson() {
        return editorActive && editorFirstPerson;
    }

    public static void setEditorFirstPerson(boolean firstPerson) {
        if (!editorActive || editorFirstPerson == firstPerson) {
            editorFirstPerson = firstPerson;
            return;
        }

        editorFirstPerson = firstPerson;
        editorSelectedEndPose = nearestExistingEndPose(editorSelectedEndPose);
        if (editorPoint >= 0) {
            editorPoint = editorSelectedEndPose;
        }
    }

    public static boolean isTransitionLinkEnabled() {
        return editorActive && editorTransitionLinkEnabled;
    }

    /**
     * Toggle the temporary F8 transition link. Enabling uses the currently
     * visible view as the source and applies its transition mode/timing to
     * both views. Disabling restores the exact pre-link values.
     */
    public static void toggleTransitionLink() {
        if (!editorActive) {
            return;
        }

        if (!editorTransitionLinkEnabled) {
            preLinkThirdTransition = captureTransitionSettings(editorThirdProfile);
            preLinkFirstTransition = captureTransitionSettings(editorFirstProfile);

            Profile source = getActiveEditorProfile();
            applyTransitionSettings(editorThirdProfile, source);
            applyTransitionSettings(editorFirstProfile, source);
            editorTransitionLinkEnabled = true;
            return;
        }

        restorePreLinkTransitionSettings();
    }

    private static void restorePreLinkTransitionSettings() {
        if (preLinkThirdTransition != null) {
            applyTransitionSettings(editorThirdProfile, preLinkThirdTransition);
        }
        if (preLinkFirstTransition != null) {
            applyTransitionSettings(editorFirstProfile, preLinkFirstTransition);
        }

        editorTransitionLinkEnabled = false;
        preLinkThirdTransition = null;
        preLinkFirstTransition = null;
    }

    private static void clearTransitionLinkState() {
        editorTransitionLinkEnabled = false;
        preLinkThirdTransition = null;
        preLinkFirstTransition = null;
    }

    private static TransitionSettings captureTransitionSettings(Profile profile) {
        Profile normalized = normalize(profile);
        return new TransitionSettings(
                normalized.transitionMode,
                normalized.totalDurationTicks
        );
    }

    private static void applyTransitionSettings(Profile profile, Profile source) {
        if (profile == null || source == null) {
            return;
        }
        profile.transitionMode = source.transitionMode;
        profile.totalDurationTicks = source.totalDurationTicks;
    }

    private static void applyTransitionSettings(
            Profile profile,
            TransitionSettings settings
    ) {
        if (profile == null || settings == null) {
            return;
        }
        profile.transitionMode = settings.mode();
        profile.totalDurationTicks = settings.totalTicks();
    }

    public static SuccessAnimationKind getEditorKind() {
        return SuccessAnimationKind.PARRY;
    }

    public static ParryStyle getEditorStyle() {
        return editorStyle;
    }

    public static ResourceLocation getEditorItemId() {
        return editorItemId;
    }

    public static boolean isEditorDefaultProfile() {
        return editorProfileSource == ProfileSource.DEFAULT;
    }

    public static ProfileSource getEditorProfileSource() {
        return editorProfileSource;
    }

    public static boolean isEditorFallbackProfile() {
        return editorProfileSource == ProfileSource.FALLBACK;
    }

    public static ProfileId getEditorProfileId() {
        return switch (editorProfileSource) {
            case DEFAULT -> ProfileId.defaultProfile(editorDual, editorDefaultHandedness);
            case FALLBACK -> ProfileId.fallback(editorDual);
            case ITEM_OVERRIDE -> ProfileId.itemOverride(editorDual, editorStyle, editorItemId);
            case STYLE -> ProfileId.style(editorDual, editorStyle, editorStyleHandedness);
        };
    }

    /** Return the canonical identity of the profile currently being edited. */
    public static String getEditorProfileIdentity() {
        return getEditorProfileId().toString();
    }

    public static DefaultHandedness getEditorDefaultHandedness() {
        return editorDefaultHandedness;
    }

    public static HandStyle getEditorStyleHandedness() {
        return editorStyleHandedness;
    }

    public static boolean isEditorStyleHandedVariant() {
        return BetterCombatWeaponMetadata.isAvailable()
                && editorProfileSource == ProfileSource.STYLE;
    }

    public static void cycleEditorDefaultHandedness() {
        clearTransitionLinkState();
        if (editorProfileSource != ProfileSource.DEFAULT) {
            return;
        }
        editorDefaultHandedness = editorDefaultHandedness == DefaultHandedness.ONE_HANDED
                ? DefaultHandedness.TWO_HANDED
                : DefaultHandedness.ONE_HANDED;
        editorProfileSource = ProfileSource.DEFAULT;
        editorThirdProfile = loadDefaultProfile(false, editorDefaultHandedness);
        editorFirstProfile = loadDefaultProfile(true, editorDefaultHandedness);
        savedThirdProfile = editorThirdProfile.copy();
        savedFirstProfile = editorFirstProfile.copy();
        clampEditorPoint();
    }

    /* Kept for compatibility with older callers. Successful Parry profiles no
       longer use this property to determine whether the animation plays. */
    public static boolean isEditorEnabled() {
        return true;
    }

    public static void setEditorEnabled(boolean enabled) {
        /* Intentionally ignored. "Use Default" controls profile selection. */
    }

    /** Select the exact item override that runtime prioritizes when Default is disabled. */
    public static boolean selectEditorItemOverride() {
        clearTransitionLinkState();
        if (!editorActive || editorItemId == null || !hasItemOverrideFor(editorDual, editorItemId)) {
            return false;
        }

        editorProfileSource = ProfileSource.ITEM_OVERRIDE;
        editorStyleHandedness = HandStyle.ONE_HANDED;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;
        loadEditorItemOverride(SuccessAnimationKind.PARRY);
        clampEditorPoint();
        return true;
    }

    /** Select the single shared Successful Parry FALLBACK profile used by unknown weapons. */
    public static void selectEditorFallback() {
        clearTransitionLinkState();
        if (!editorActive) {
            return;
        }

        editorProfileSource = ProfileSource.FALLBACK;
        editorStyle = ParryStyle.GENERIC;
        editorStyleHandedness = HandStyle.ONE_HANDED;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;
        loadFallbackProfile();
        clampEditorPoint();
    }

    public static void selectEditorStyle(
            ParryStyle style
    ) {
        selectEditorStyle(style, detectStyleHandednessForEditor(style));
    }

    public static void selectEditorStyle(
            ParryStyle style,
            HandStyle handStyle
    ) {
        clearTransitionLinkState();
        if (!editorActive || style == null || style == ParryStyle.GENERIC) {
            return;
        }

        editorProfileSource = ProfileSource.STYLE;
        editorStyle = style;
        editorStyleHandedness = handStyle == null
                ? HandStyle.ONE_HANDED
                : handStyle;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;
        /* Category browsing never opens the exact item file. */
        editorThirdProfile = loadProfileForEditorStyle(style, false);
        editorFirstProfile = loadProfileForEditorStyle(style, true);
        savedThirdProfile = editorThirdProfile.copy();
        savedFirstProfile = editorFirstProfile.copy();


        clampEditorPoint();
    }

    public static void selectDefaultProfile() {
        clearTransitionLinkState();
        if (!editorActive) {
            return;
        }

        editorProfileSource = ProfileSource.DEFAULT;
        Minecraft mc = Minecraft.getInstance();
        ItemStack main = mc.player == null
                ? ItemStack.EMPTY
                : mc.player.getMainHandItem();
        editorDefaultHandedness = detectDefaultHandedness(main);
        editorStyle = ParryStyle.GENERIC;
        editorSelectedEndPose = 0;
        editorPoint = 0;
        editorPoseTargetActive = false;
        editorThirdProfile = loadDefaultProfile(false, editorDefaultHandedness);
        editorFirstProfile = loadDefaultProfile(true, editorDefaultHandedness);
        savedThirdProfile = editorThirdProfile.copy();
        savedFirstProfile = editorFirstProfile.copy();


        clampEditorPoint();
    }

    public static int getEditorPoint() {
        return editorPoint;
    }

    /** Number of End Pose slots, including intentional gaps used to preserve pose numbers. */
    public static int getEditorPointCount() {
        return Math.max(1, getActiveEditorProfile().pointBs.size());
    }

    /** Actual End Pose indices, preserving gaps so pose numbers remain stable. */
    public static List<Integer> getExistingEndPoseIndices() {
        Profile p = getActiveEditorProfile();
        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < p.pointBs.size(); i++) {
            if (p.pointBs.get(i) != null) {
                indices.add(i);
            }
        }
        return indices;
    }

    public static int getExistingEndPoseCount() {
        return getExistingEndPoseIndices().size();
    }

    public static boolean hasEndPose(int index) {
        Profile p = getActiveEditorProfile();
        return index >= 0 && index < p.pointBs.size() && p.pointBs.get(index) != null;
    }

    /** Select the requested End Pose or the nearest existing slot if it was deleted. */
    public static void selectEditorPoint(int point) {
        int selected = nearestExistingEndPose(point);
        editorSelectedEndPose = selected;
        editorPoint = selected;
        editorPoseTargetActive = true;
    }

    /** Select an End Pose without unexpectedly switching view or target mode. */
    public static void setSelectedEndPose(int index) {
        int selected = nearestExistingEndPose(index);
        editorSelectedEndPose = selected;
        if (!editorPoseTargetActive) {
            editorPoint = selected;
        }
    }

    /** Advance through actual existing End Poses, not empty gap slots. */
    public static void cycleSelectedEndPoseForEditing() {
        List<Integer> existing = getExistingEndPoseIndices();
        if (existing.isEmpty()) {
            return;
        }
        int current = getSelectedEndPose();
        int position = existing.indexOf(current);
        int next = existing.get((position + 1) % existing.size());
        selectEndPoseForEditing(next);
    }

    public static int getSelectedEndPose() {
        if (!hasEndPose(editorSelectedEndPose)) {
            editorSelectedEndPose = nearestExistingEndPose(editorSelectedEndPose);
        }
        return editorSelectedEndPose;
    }

    /** Add the lowest missing End Pose slot, copying the opposite view's same slot when present. */
    public static boolean addPointBSmart() {
        Profile target = getActiveEditorProfile();
        int newIndex = findNextMissingEndPoseIndex(target);
        if (newIndex < 0 || newIndex >= MAX_END_POSES) {
            return false;
        }

        Profile opposite = editorFirstPerson ? editorThirdProfile : editorFirstProfile;
        PoseData source = poseAt(opposite, newIndex);
        ensureEndPoseSlot(target, newIndex);
        target.pointBs.set(newIndex, source == null ? PoseData.empty() : source.copy());

        editorSelectedEndPose = newIndex;
        if (editorPoseTargetActive) {
            editorPoint = newIndex;
        }
        return true;
    }

    /** Backward-compatible add entry point. */
    public static void addPointB() {
        addPointBSmart();
    }

    public enum CrossViewEndPoseTransferState {
        CREATE,
        OVERWRITE,
        UNAVAILABLE
    }

    public static CrossViewEndPoseTransferState getCrossViewEndPoseTransferState() {
        if (!editorActive || editorPoint < 0 || !hasEndPose(getSelectedEndPose())) {
            return CrossViewEndPoseTransferState.UNAVAILABLE;
        }

        int index = getSelectedEndPose();
        Profile target = editorFirstPerson ? editorThirdProfile : editorFirstProfile;
        if (index < target.pointBs.size() && target.pointBs.get(index) != null) {
            return CrossViewEndPoseTransferState.OVERWRITE;
        }
        return index >= 0 && index < MAX_END_POSES
                ? CrossViewEndPoseTransferState.CREATE
                : CrossViewEndPoseTransferState.UNAVAILABLE;
    }

    /** Copy the current in-memory End Pose to the same numbered End Pose in the opposite view. */
    public static boolean copySelectedEndPoseToOtherView() {
        if (getCrossViewEndPoseTransferState() == CrossViewEndPoseTransferState.UNAVAILABLE) {
            return false;
        }

        int index = getSelectedEndPose();
        Profile source = getActiveEditorProfile();
        Profile target = editorFirstPerson ? editorThirdProfile : editorFirstProfile;
        PoseData sourcePose = poseAt(source, index);
        if (sourcePose == null) {
            return false;
        }

        ensureEndPoseSlot(target, index);
        target.pointBs.set(index, sourcePose.copy());
        return true;
    }

    public static boolean canRemovePointB() {
        return getExistingEndPoseCount() > 1;
    }

    public static void removePointB() {
        removePointB(getSelectedEndPose());
    }

    /** Remove one End Pose without renumbering later poses. */
    public static void removePointB(int index) {
        if (!editorActive) {
            return;
        }

        Profile p = getActiveEditorProfile();
        if (!canRemovePointB() || !hasEndPose(index)) {
            return;
        }

        p.pointBs.set(index, null);
        trimTrailingEndPoseSlots(p);

        int next = existingEndPoseAfterRemoval(p, index);
        editorSelectedEndPose = next;
        if (editorPoseTargetActive && editorPoint >= 0) {
            editorPoint = next;
        }
        clampEditorPoint();
    }

    public static void cyclePointAMode() {
        Profile p = getActiveEditorProfile();
        p.pointAMode = p.pointAMode == PointAMode.CURRENT
                ? PointAMode.CUSTOM
                : PointAMode.CURRENT;
    }

    public static PointAMode getPointAMode() {
        return getActiveEditorProfile().pointAMode;
    }

    public static boolean isEditorPointACustom() {
        return getPointAMode() == PointAMode.CUSTOM;
    }

    public static void setPointAMode(PointAMode mode) {
        if (!editorActive || mode == null) {
            return;
        }
        getActiveEditorProfile().pointAMode = mode;
    }

    public static SuccessTransitionMode getTransitionMode() {
        return getActiveEditorProfile().transitionMode;
    }

    public static void cycleTransitionMode() {
        Profile p = getActiveEditorProfile();
        SuccessTransitionMode next = nextMode(p.transitionMode);

        if (editorTransitionLinkEnabled) {
            editorThirdProfile.transitionMode = next;
            editorFirstProfile.transitionMode = next;
            return;
        }

        p.transitionMode = next;
    }

    public static int getTotalDurationTicks() {
        return getActiveEditorProfile().totalDurationTicks;
    }

    public static int getImpactTicks() {
        return impactTicks(getActiveEditorProfile().totalDurationTicks);
    }

    public static int getRecoveryTicks() {
        int total = getActiveEditorProfile().totalDurationTicks;
        return Math.max(1, total - impactTicks(total));
    }

    public static void adjustTotalDurationTicks(int delta) {
        Profile p = getActiveEditorProfile();
        int next = clampTotalDuration(p.totalDurationTicks + delta);

        if (editorTransitionLinkEnabled) {
            editorThirdProfile.totalDurationTicks = next;
            editorFirstProfile.totalDurationTicks = next;
            return;
        }

        p.totalDurationTicks = next;
    }

    public static int impactTicks(int totalDurationTicks) {
        int total = clampTotalDuration(totalDurationTicks);
        return Math.max(1, Math.min(total - 1, Math.round(total / 3.0F)));
    }

    public static float getEditorValue(
            SuccessAnimationChannel channel
    ) {
        return editorPose().value(channel);
    }

    public static void adjustEditorValue(
            SuccessAnimationChannel channel,
            float delta
    ) {
        Profile p = getActiveEditorProfile();

        if (editorPoint < 0) {
            if (p.pointAMode == PointAMode.CURRENT) {
                return;
            }
            p.pointA = p.pointA.withValue(
                    channel,
                    clamp(channel, p.pointA.value(channel) + delta)
            );
            return;
        }

        if (editorPoint < 0 || editorPoint >= p.pointBs.size()) {
            return;
        }

        PoseData point = p.pointBs.get(editorPoint);
        if (point == null) {
            point = PoseData.empty();
        }
        p.pointBs.set(
                editorPoint,
                point.withValue(
                        channel,
                        clamp(channel, point.value(channel) + delta)
                )
        );
    }

    public static void selectStartPoseForEditing() {
        editorPoint = -1;
        editorPoseTargetActive = true;
    }

    public static void selectEndPoseForEditing(int index) {
        editorSelectedEndPose = nearestExistingEndPose(index);
        editorPoint = editorSelectedEndPose;
        editorPoseTargetActive = true;
    }

    public static void leavePoseEditMode() {
        editorPoseTargetActive = false;
        editorPoint = editorSelectedEndPose;
    }

    public static boolean isEditingPoseTarget() {
        return editorPoseTargetActive;
    }

    public static boolean canCopyOverviewPose(boolean startPose) {
        if (!editorActive) {
            return false;
        }
        return !startPose || getPointAMode() == PointAMode.CUSTOM;
    }

    public static AnimationPoseConfig.SaveResult copyOverviewPose(boolean startPose) {
        if (!canCopyOverviewPose(startPose)) {
            return fail("Current Pose is live data and cannot be copied as a stored pose.");
        }
        Profile p = getActiveEditorProfile();
        poseClipboard = (startPose ? p.pointA : p.pointBs.get(getSelectedEndPose())).copy();
        return success("Copied selected Successful Parry pose.");
    }

    public static boolean canPasteOverviewPose(boolean startPose) {
        return editorActive && poseClipboard != null && (!startPose || getPointAMode() == PointAMode.CUSTOM);
    }

    public static AnimationPoseConfig.SaveResult pasteOverviewPose(boolean startPose) {
        if (!canPasteOverviewPose(startPose)) {
            return fail("No compatible Successful Parry pose is copied.");
        }
        Profile p = getActiveEditorProfile();
        if (startPose) {
            p.pointA = poseClipboard.copy();
            p.pointAMode = PointAMode.CUSTOM;
        } else {
            p.pointBs.set(getSelectedEndPose(), poseClipboard.copy());
        }
        return success("Pasted selected Successful Parry pose.");
    }

    /** Copy only the currently selected pose, not the whole Successful Parry profile. */
    public static boolean canCopySelectedPose() {
        if (!editorActive) {
            return false;
        }
        return editorPoint >= 0 || isEditorPointACustom();
    }

    public static boolean canPasteSelectedPose() {
        if (!editorActive || poseClipboard == null) {
            return false;
        }
        return editorPoint >= 0 || isEditorPointACustom();
    }

    public static AnimationPoseConfig.SaveResult copySelectedPose() {
        if (!canCopySelectedPose()) {
            return fail("Current Pose is live data and cannot be copied as a stored pose.");
        }
        poseClipboard = editorPose().copy();
        return success("Copied selected Successful Parry pose.");
    }

    public static AnimationPoseConfig.SaveResult pasteSelectedPose() {
        if (!canPasteSelectedPose()) {
            return fail("No compatible Successful Parry pose is copied.");
        }

        Profile p = getActiveEditorProfile();
        PoseData pasted = poseClipboard.copy();

        if (editorPoint < 0) {
            p.pointA = pasted;
            p.pointAMode = PointAMode.CUSTOM;
        } else if (editorPoint < p.pointBs.size()) {
            p.pointBs.set(editorPoint, pasted);
        }

        return success("Pasted selected Successful Parry pose.");
    }

    public static AnimationPoseConfig.ArmPose getEditorArmPose() {
        return armPose(editorPose());
    }

    public static Vec3f getEditorWeaponPosition(boolean mainHand) {
        PoseData data = editorPose();
        return mainHand
                ? vec(data,
                SuccessAnimationChannel.MAIN_WEAPON_POS_X,
                SuccessAnimationChannel.MAIN_WEAPON_POS_Y,
                SuccessAnimationChannel.MAIN_WEAPON_POS_Z)
                : vec(data,
                SuccessAnimationChannel.OFF_WEAPON_POS_X,
                SuccessAnimationChannel.OFF_WEAPON_POS_Y,
                SuccessAnimationChannel.OFF_WEAPON_POS_Z);
    }

    public static Vec3f getEditorWeaponRotation(boolean mainHand) {
        PoseData data = editorPose();
        return mainHand
                ? vec(data,
                SuccessAnimationChannel.MAIN_WEAPON_ROT_X,
                SuccessAnimationChannel.MAIN_WEAPON_ROT_Y,
                SuccessAnimationChannel.MAIN_WEAPON_ROT_Z)
                : vec(data,
                SuccessAnimationChannel.OFF_WEAPON_ROT_X,
                SuccessAnimationChannel.OFF_WEAPON_ROT_Y,
                SuccessAnimationChannel.OFF_WEAPON_ROT_Z);
    }

    public static void resetEditorArm(boolean mainHand) {
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            if (c.group() != SuccessAnimationChannel.Group.ARMS) {
                continue;
            }

            if (mainHand
                    && c != SuccessAnimationChannel.MAIN_ARM_X
                    && c != SuccessAnimationChannel.MAIN_ARM_Y
                    && c != SuccessAnimationChannel.MAIN_ARM_Z) {
                continue;
            }

            if (!mainHand
                    && c != SuccessAnimationChannel.OFF_ARM_X
                    && c != SuccessAnimationChannel.OFF_ARM_Y
                    && c != SuccessAnimationChannel.OFF_ARM_Z) {
                continue;
            }

            setEditorValue(c, 0.0F);
        }
    }

    public static void resetEditorWeapon(boolean mainHand) {
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            boolean main = c.group() == SuccessAnimationChannel.Group.MAIN_WEAPON;
            boolean off = c.group() == SuccessAnimationChannel.Group.OFF_WEAPON;

            if ((mainHand && !main) || (!mainHand && !off)) {
                continue;
            }

            setEditorValue(c, 0.0F);
        }
    }

    private static void setEditorValue(
            SuccessAnimationChannel c,
            float value
    ) {
        Profile p = getActiveEditorProfile();

        if (editorPoint < 0) {
            if (p.pointAMode != PointAMode.CURRENT) {
                p.pointA = p.pointA.withValue(c, value);
            }
            return;
        }

        PoseData point = poseAt(p, editorPoint);
        if (point == null) {
            return;
        }
        p.pointBs.set(editorPoint, point.withValue(c, value));
    }

    public static void copyAnimation() {
        clipboard = getActiveEditorProfile().copy();
    }

    public static boolean hasClipboard() {
        return clipboard != null;
    }

    public static void pasteAnimation() {
        if (clipboard == null) {
            return;
        }

        Profile pasted = clipboard.copy();
        normalize(pasted);

        if (editorFirstPerson) {
            editorFirstProfile = pasted.copy();
        } else {
            editorThirdProfile = pasted.copy();
        }

        if (editorTransitionLinkEnabled) {
            Profile source = getActiveEditorProfile();
            applyTransitionSettings(editorThirdProfile, source);
            applyTransitionSettings(editorFirstProfile, source);
        }

        clampEditorPoint();
    }

    /* Compatibility helpers used by the explicit cross-view copy controls. */
    public static void copy3pTo1p() {
        editorFirstProfile = editorThirdProfile.copy();
    }

    public static void copy1pTo3p() {
        editorThirdProfile = editorFirstProfile.copy();
    }

    public static AnimationPoseConfig.SaveResult saveDefault() {
        if (!editorActive) {
            return fail("No Successful Parry animation is being edited.");
        }

        if (editorProfileSource == ProfileSource.ITEM_OVERRIDE) {
            return fail("Save Default cannot save an ITEM OVERRIDE. Select DEFAULT or a style profile first.");
        }
        if (editorProfileSource == ProfileSource.FALLBACK) {
            return saveFallback();
        }

        ParryStyle style = editorProfileSource == ProfileSource.DEFAULT
                ? ParryStyle.GENERIC
                : editorStyle;
        return saveStyleProfiles(style);
    }

    public static AnimationPoseConfig.SaveResult saveFallback() {
        if (!editorActive) {
            return fail("No Successful Parry animation is being edited.");
        }
        if (editorProfileSource != ProfileSource.FALLBACK) {
            return fail("Save Fallback is only available while editing FALLBACK.");
        }

        try {
            Profile thirdToSave = getThirdProfileForSave().copy();
            Profile firstToSave = getFirstProfileForSave().copy();
            Path thirdPath = fallbackPath(editorDual, SuccessAnimationKind.PARRY, false);
            Path firstPath = fallbackPath(editorDual, SuccessAnimationKind.PARRY, true);
            writeProfile(thirdPath, thirdToSave);
            writeProfile(firstPath, firstToSave);

            Profile thirdCheck = readProfile(thirdPath);
            Profile firstCheck = readProfile(firstPath);
            if (!profilesEqual(thirdToSave, thirdCheck) || !profilesEqual(firstToSave, firstCheck)) {
                throw new IOException("Saved Successful Parry fallback profile did not round-trip identically.");
            }

            savedThirdProfile = thirdToSave.copy();
            savedFirstProfile = firstToSave.copy();
            publishSavedRuntimeProfiles(
                    ProfileId.fallback(editorDual),
                    thirdToSave,
                    firstToSave
            );
            return success("Saved Successful Parry fallback profile.");
        } catch (Exception e) {
            GyeokbuV2.LOGGER.error("Failed to save Successful Parry fallback profile.", e);
            return fail("Successful Parry fallback save failed. Check latest.log.");
        }
    }

    public static AnimationPoseConfig.SaveResult saveHeld() {
        if (!editorActive) {
            return fail("No Successful Parry animation is being edited.");
        }
        if (editorProfileSource == ProfileSource.DEFAULT) {
            return fail("Save Held is unavailable while editing DEFAULT.");
        }
        if (editorItemId == null) {
            return fail("No held item was captured when the editor opened.");
        }

        try {
            Profile thirdToSave = getThirdProfileForSave().copy();
            Profile firstToSave = getFirstProfileForSave().copy();
            Path thirdPath = itemPath(editorItemId, editorDual, SuccessAnimationKind.PARRY, false);
            Path firstPath = itemPath(editorItemId, editorDual, SuccessAnimationKind.PARRY, true);

            writeProfile(thirdPath, thirdToSave);
            writeProfile(firstPath, firstToSave);

            if (!profilesEqual(thirdToSave, readProfile(thirdPath))
                    || !profilesEqual(firstToSave, readProfile(firstPath))) {
                throw new IOException("Saved Successful Parry item profile did not round-trip identically.");
            }

            savedThirdProfile = thirdToSave.copy();
            savedFirstProfile = firstToSave.copy();
            publishSavedRuntimeProfiles(
                    ProfileId.itemOverride(editorDual, editorStyle, editorItemId),
                    thirdToSave,
                    firstToSave
            );

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Saved Successful Parry for " + editorItemId + "."
            );
        } catch (Exception e) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Successful Parry item profile for {}.",
                    editorItemId,
                    e
            );
            return fail("Successful Parry item save failed. Check latest.log.");
        }
    }

    public static AnimationPoseConfig.SaveResult saveCurrentGroupDefault(
            SuccessAnimationChannel.Group group
    ) {
        return saveDefault();
    }

    public static AnimationPoseConfig.SaveResult saveCurrentGroupHeld(
            SuccessAnimationChannel.Group group
    ) {
        return saveHeld();
    }

    public static boolean hasItemOverrideForCurrentItem() {
        return hasItemOverrideFor(editorDual, editorItemId);
    }

    public static boolean hasItemOverride() {
        if (editorItemId == null || editorProfileSource == ProfileSource.DEFAULT) {
            return false;
        }
        return hasItemOverrideFor(editorDual, editorItemId);
    }

    private static boolean hasItemOverrideFor(
            boolean dual,
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return false;
        }
        return Files.exists(itemPath(itemId, dual, SuccessAnimationKind.PARRY, false))
                || Files.exists(itemPath(itemId, dual, SuccessAnimationKind.PARRY, true));
    }

    public static AnimationPoseConfig.SaveResult clearItemOverride() {
        return clearEditorItemOverride();
    }

    public static AnimationPoseConfig.SaveResult clearEditorItemOverride() {
        if (editorItemId == null || editorProfileSource == ProfileSource.DEFAULT) {
            return fail("No held item profile is selected.");
        }

        try {
            Files.deleteIfExists(itemPath(editorItemId, editorDual, SuccessAnimationKind.PARRY, false));
            Files.deleteIfExists(itemPath(editorItemId, editorDual, SuccessAnimationKind.PARRY, true));
            invalidateRuntimeProfile(ProfileId.itemOverride(editorDual, editorStyle, editorItemId));

            /* Return to the exact profile runtime will resolve after removing
               the item override. */
            Minecraft mc = Minecraft.getInstance();
            ItemStack stack = mc.player == null
                    ? ItemStack.EMPTY
                    : mc.player.getMainHandItem();
            WeaponProfile natural = WeaponClassifier.classifyNatural(stack);
            if (!natural.isSupported() || natural.parryStyle() == ParryStyle.GENERIC) {
                selectEditorFallback();
            } else {
                selectEditorStyle(
                        natural.parryStyle(),
                        BetterCombatWeaponMetadata.isAvailable()
                                ? natural.handStyle()
                                : HandStyle.ONE_HANDED
                );
            }
            clampEditorPoint();

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Cleared exact-item Successful Parry override."
            );
        } catch (IOException e) {
            GyeokbuV2.LOGGER.error("Failed to clear Successful Parry item override.", e);
            return fail("Clear failed. Check latest.log.");
        }
    }

    /** Restore the last saved state, matching the Stance editor's Revert Saved. */
    public static AnimationPoseConfig.SaveResult revertDefault() {
        if (!editorActive) {
            return fail("No Successful Parry animation is being edited.");
        }

        editorThirdProfile = savedThirdProfile.copy();
        editorFirstProfile = savedFirstProfile.copy();
        clearTransitionLinkState();
        clampEditorPoint();
        return success("Reverted to the last saved Successful Parry animation.");
    }

    /** Restore the shipped/bundled baseline without saving it to disk. */
    public static AnimationPoseConfig.SaveResult resetToBundledDefault() {
        Profile third = readBundledProfile(
                editorProfileSource == ProfileSource.DEFAULT ? ParryStyle.GENERIC : editorStyle,
                editorDual,
                false
        );
        Profile first = readBundledProfile(
                editorProfileSource == ProfileSource.DEFAULT ? ParryStyle.GENERIC : editorStyle,
                editorDual,
                true
        );

        if (third == null) {
            third = fallbackProfile(
                    editorProfileSource == ProfileSource.DEFAULT ? ParryStyle.GENERIC : editorStyle,
                    editorDual,
                    false
            );
        }
        if (first == null) {
            first = fallbackProfile(
                    editorProfileSource == ProfileSource.DEFAULT ? ParryStyle.GENERIC : editorStyle,
                    editorDual,
                    true
            );
        }

        editorThirdProfile = third.copy();
        editorFirstProfile = first.copy();
        clearTransitionLinkState();

        clampEditorPoint();
        return success("Loaded bundled Successful Parry baseline.");
    }

    public static boolean hasUnsavedEditorChanges() {
        if (!editorActive) {
            return false;
        }

        return !profilesEqual(editorThirdProfile, savedThirdProfile)
                || !profilesEqual(editorFirstProfile, savedFirstProfile);
    }

    /** Convenience overload used by F8 buttons and BooleanSupplier method references. */
    public static boolean isDefaultEnabled() {
        return isDefaultEnabled(false);
    }

    public static boolean isDefaultEnabled(boolean dual) {
        Path path = defaultEnabledPath(dual);
        try {
            return Files.exists(path)
                    && Files.readString(path, StandardCharsets.UTF_8)
                    .trim()
                    .equalsIgnoreCase("true");
        } catch (IOException e) {
            return false;
        }
    }

    public static void setDefaultEnabled(
            boolean dual,
            boolean enabled
    ) {
        try {
            Files.createDirectories(defaultEnabledPath(dual).getParent());
            Files.writeString(
                    defaultEnabledPath(dual),
                    Boolean.toString(enabled),
                    StandardCharsets.UTF_8
            );
            clearRuntimeProfileCache();
        } catch (IOException e) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Successful Parry Use Default setting.",
                    e
            );
        }
    }

    /**
     * Resolve both views through one canonical Successful Parry profile identity.
     * This is the only runtime resolution entry point; the legacy single-view
     * method below simply delegates to it.
     */
    public static RuntimeProfileSet resolveRuntimeProfiles(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            ItemStack stack
    ) {
        return resolveRuntimeProfiles(
                itemId,
                style,
                dual,
                stack,
                null
        );
    }

    /**
     * Runtime resolver with an optional server-authoritative handedness value.
     * When supplied, this value is used instead of re-classifying the item on
     * the client. This keeps multiplayer Successful Parry presentation from
     * selecting a different profile than the server resolved for the hit.
     */
    public static RuntimeProfileSet resolveRuntimeProfiles(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            ItemStack stack,
            HandStyle resolvedHandStyle
    ) {
        ProfileId identity = resolveRuntimeProfileId(
                itemId,
                style,
                dual,
                stack,
                resolvedHandStyle
        );
        RuntimeProfileSet cached = RUNTIME_PROFILE_CACHE.get(identity);
        if (cached != null && persistedProfilePairExists(identity)) {
            return cached.copy();
        }
        if (cached != null) {
            RUNTIME_PROFILE_CACHE.remove(identity, cached);
        }

        Profile third = loadRuntimeProfile(identity, false);
        Profile first = loadRuntimeProfile(identity, true);
        RuntimeProfileSet resolved = new RuntimeProfileSet(
                identity,
                third == null ? null : normalize(third),
                first == null ? null : normalize(first)
        );

        RUNTIME_PROFILE_CACHE.put(identity, resolved.copy());
        return resolved;
    }

    /**
     * The canonical identity resolver shared by runtime and persisted editor
     * saves. Successful Parry Default intentionally ignores weapon category.
     */
    private static ProfileId resolveRuntimeProfileId(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            ItemStack stack,
            HandStyle resolvedHandStyle
    ) {
        if (isDefaultEnabled(dual)) {
            HandStyle effectiveHandStyle = resolvedHandStyle;
            if (effectiveHandStyle == null) {
                DefaultHandedness detected = detectDefaultHandedness(stack);
                effectiveHandStyle = detected == DefaultHandedness.TWO_HANDED
                        ? HandStyle.TWO_HANDED
                        : HandStyle.ONE_HANDED;
            }
            return ProfileId.defaultProfile(
                    dual,
                    effectiveHandStyle == HandStyle.TWO_HANDED
                            ? DefaultHandedness.TWO_HANDED
                            : DefaultHandedness.ONE_HANDED
            );
        }

        if (itemId != null && hasItemOverrideFor(dual, itemId)) {
            return ProfileId.itemOverride(dual, style, itemId);
        }

        WeaponProfile natural = stack == null || stack.isEmpty()
                ? WeaponProfile.unknown()
                : WeaponClassifier.classifyNatural(stack);

        if (!natural.isSupported() || natural.parryStyle() == ParryStyle.GENERIC) {
            return ProfileId.fallback(dual);
        }

        HandStyle handStyle = resolvedHandStyle;
        if (handStyle == null && BetterCombatWeaponMetadata.isAvailable()) {
            BetterCombatWeaponMetadata.Metadata metadata =
                    BetterCombatWeaponMetadata.get(stack);
            if (metadata.present()) {
                handStyle = metadata.twoHanded()
                        ? HandStyle.TWO_HANDED
                        : HandStyle.ONE_HANDED;
            }
        }

        return ProfileId.style(
                dual,
                natural.parryStyle(),
                handStyle
        );
    }

    /** Only a complete on-disk pair may act as the persistent runtime cache source. */
    private static boolean persistedProfilePairExists(ProfileId identity) {
        Path third = persistedProfilePath(identity, false);
        Path first = persistedProfilePath(identity, true);
        return third != null && first != null
                && Files.exists(third)
                && Files.exists(first);
    }

    private static Path persistedProfilePath(ProfileId identity, boolean firstPerson) {
        return switch (identity.source()) {
            case DEFAULT -> defaultVariantPath(
                    identity.dualWield(),
                    SuccessAnimationKind.PARRY,
                    firstPerson,
                    identity.handedness()
            );
            case FALLBACK -> fallbackPath(
                    identity.dualWield(),
                    SuccessAnimationKind.PARRY,
                    firstPerson
            );
            case ITEM_OVERRIDE -> itemPath(
                    identity.itemId(),
                    identity.dualWield(),
                    SuccessAnimationKind.PARRY,
                    firstPerson
            );
            case STYLE -> stylePath(
                    identity.style(),
                    identity.dualWield(),
                    SuccessAnimationKind.PARRY,
                    firstPerson,
                    identity.styleHandedness()
            );
        };
    }

    /** Load only the file(s) belonging to the exact canonical identity. */
    private static Profile loadRuntimeProfile(
            ProfileId identity,
            boolean firstPerson
    ) {
        if (identity == null) {
            return null;
        }

        return switch (identity.source()) {
            case DEFAULT -> {
                Profile p = readProfile(
                        defaultVariantPath(
                                identity.dualWield(),
                                SuccessAnimationKind.PARRY,
                                firstPerson,
                                identity.handedness()
                        )
                );
                if (p == null) {
                    p = readBundledProfile(
                            ParryStyle.GENERIC,
                            identity.dualWield(),
                            firstPerson
                    );
                }
                yield p == null
                        ? fallbackProfile(ParryStyle.GENERIC, identity.dualWield(), firstPerson)
                        : p;
            }
            case FALLBACK -> {
                Profile p = readProfile(
                        fallbackPath(
                                identity.dualWield(),
                                SuccessAnimationKind.PARRY,
                                firstPerson
                        )
                );
                if (p == null) {
                    p = readBundledProfile(
                            ParryStyle.GENERIC,
                            identity.dualWield(),
                            firstPerson
                    );
                }
                yield p == null
                        ? fallbackProfile(ParryStyle.GENERIC, identity.dualWield(), firstPerson)
                        : p;
            }
            case ITEM_OVERRIDE -> {
                Profile p = readProfile(
                        itemPath(
                                identity.itemId(),
                                identity.dualWield(),
                                SuccessAnimationKind.PARRY,
                                firstPerson
                        )
                );
                yield p == null
                        ? fallbackProfile(ParryStyle.GENERIC, identity.dualWield(), firstPerson)
                        : p;
            }
            case STYLE -> {
                Profile p = readProfile(
                        stylePath(
                                identity.style(),
                                identity.dualWield(),
                                SuccessAnimationKind.PARRY,
                                firstPerson,
                                identity.styleHandedness()
                        )
                );
                if (p == null && identity.styleHandedness() != null) {
                    p = readProfile(
                            stylePath(
                                    identity.style(),
                                    identity.dualWield(),
                                    SuccessAnimationKind.PARRY,
                                    firstPerson,
                                    null
                            )
                    );
                }
                if (p == null) {
                    p = readBundledProfile(
                            identity.style(),
                            identity.dualWield(),
                            firstPerson
                    );
                }
                yield p == null
                        ? fallbackProfile(identity.style(), identity.dualWield(), firstPerson)
                        : p;
            }
        };
    }

    public static Profile resolveProfile(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            boolean firstPerson
    ) {
        ItemStack stack = Minecraft.getInstance().player == null
                ? ItemStack.EMPTY
                : Minecraft.getInstance().player.getMainHandItem();
        return resolveProfile(itemId, style, dual, firstPerson, stack);
    }

    public static Profile resolveProfile(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            boolean firstPerson,
            ItemStack stack
    ) {
        RuntimeProfileSet resolved = resolveRuntimeProfiles(
                itemId,
                style,
                dual,
                stack
        );
        return firstPerson ? resolved.firstPerson() : resolved.thirdPerson();
    }

    /** Runtime/debug helper: returns the canonical profile identity currently resolved. */
    public static ProfileId resolveRuntimeProfileIdentity(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            ItemStack stack
    ) {
        return resolveRuntimeProfileId(itemId, style, dual, stack, null);
    }

    /** Publish a pair after a successful user save so runtime uses the exact saved data. */
    public static void publishSavedRuntimeProfiles(
            ProfileId identity,
            Profile thirdPerson,
            Profile firstPerson
    ) {
        if (identity == null || thirdPerson == null || firstPerson == null) {
            return;
        }
        RUNTIME_PROFILE_CACHE.put(
                identity,
                new RuntimeProfileSet(
                        identity,
                        normalize(thirdPerson.copy()),
                        normalize(firstPerson.copy())
                )
        );
    }

    public static void invalidateRuntimeProfile(ProfileId identity) {
        if (identity != null) {
            RUNTIME_PROFILE_CACHE.remove(identity);
        }
    }

    public static void clearRuntimeProfileCache() {
        RUNTIME_PROFILE_CACHE.clear();
    }

    public static PoseData parryPose(
            ItemStack stack,
            ParryStyle style,
            boolean dual,
            boolean firstPerson
    ) {
        PoseData data = PoseData.empty();

        if (dual) {
            for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
                data = data.withValue(
                        c,
                        DualWieldPoseConfig.getVisualValueForStyle(
                                style,
                                DefenseAnimationSyncPayload.PARRY,
                                firstPerson,
                                c
                        )
                );
            }
            return data;
        }

        ItemStack safe = stack == null ? ItemStack.EMPTY : stack;
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            data = data.withValue(
                    c,
                    AnimationPoseConfig.getVisualValueFor(
                            safe,
                            style,
                            DefenseAnimationSyncPayload.PARRY,
                            firstPerson,
                            c
                    )
            );
        }
        return data;
    }

    public static PoseData parryPose(
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            boolean firstPerson
    ) {
        ItemStack stack = ItemStack.EMPTY;
        if (itemId != null) {
            var item = BuiltInRegistries.ITEM.get(itemId);
            if (item != null) {
                stack = new ItemStack(item);
            }
        }
        return parryPose(stack, style, dual, firstPerson);
    }

    public static Profile fallbackProfile(
            ParryStyle style,
            boolean dual,
            boolean firstPerson
    ) {
        Minecraft mc = Minecraft.getInstance();
        ItemStack stack = mc.player == null
                ? ItemStack.EMPTY
                : mc.player.getMainHandItem();
        PoseData current = parryPose(stack, style, dual, firstPerson);

        Profile p = Profile.empty();
        p.pointAMode = PointAMode.CURRENT;
        p.pointA = current.copy();
        p.pointBs.add(current.copy());
        return p;
    }

    public static String displayName() {
        return switch (editorProfileSource) {
            case DEFAULT -> "DEFAULT SUCCESSFUL PARRY";
            case FALLBACK -> "FALLBACK SUCCESSFUL PARRY";
            case ITEM_OVERRIDE -> "ITEM OVERRIDE SUCCESSFUL PARRY";
            case STYLE -> pretty(editorStyle) + " SUCCESSFUL PARRY";
        };
    }

    public static String sourceLabel() {
        return switch (editorProfileSource) {
            case DEFAULT -> "DEFAULT";
            case FALLBACK -> "FALLBACK";
            case ITEM_OVERRIDE -> "ITEM OVERRIDE";
            case STYLE -> BetterCombatWeaponMetadata.isAvailable()
                    ? (editorStyleHandedness == HandStyle.TWO_HANDED ? "2H " : "1H ") + pretty(editorStyle)
                    : pretty(editorStyle);
        };
    }

    public static String editorProfileLabel() {
        return switch (editorProfileSource) {
            case DEFAULT -> BetterCombatWeaponMetadata.isAvailable()
                    ? "DEFAULT • " + (editorDefaultHandedness == DefaultHandedness.TWO_HANDED ? "2H" : "1H")
                    : "DEFAULT";
            case FALLBACK -> "FALLBACK";
            case ITEM_OVERRIDE -> "ITEM OVERRIDE";
            case STYLE -> pretty(editorStyle);
        };
    }

    /** Used by the editor Play button and preview renderer. */
    public static PoseData getEditorCurrentPreviewPose() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return PoseData.empty();
        }

        ItemStack stack = mc.player.getMainHandItem();
        ParryStyle currentStyle = WeaponClassifier.classifyNatural(stack).parryStyle();
        boolean dual = DualWieldRules.isDualWield(mc.player);
        int mode = ClientCombatSyncState.getDefenseAnimationMode(mc.player.getId());
        if (mode == DefenseAnimationSyncPayload.NONE) {
            mode = DefenseAnimationSyncPayload.PARRY;
        }

        PoseData data = PoseData.empty();
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            float value = dual
                    ? DualWieldPoseConfig.getVisualValueForStyle(
                            currentStyle, mode, editorFirstPerson, c)
                    : AnimationPoseConfig.getVisualValueFor(
                            stack, currentStyle, mode, editorFirstPerson, c);
            data = data.withValue(c, value);
        }
        return data;
    }

    /** Return the complete profile currently being edited. */
    public static Profile getEditorProfileCopy() {
        return getActiveEditorProfile().copy();
    }

    private static void loadEditorProfiles(
            SuccessAnimationKind kind,
            ParryStyle style,
            boolean defaultProfile
    ) {
        if (defaultProfile) {
            editorProfileSource = ProfileSource.DEFAULT;
            editorThirdProfile = loadDefaultProfile(false, editorDefaultHandedness);
            editorFirstProfile = loadDefaultProfile(true, editorDefaultHandedness);
        } else {
            editorProfileSource = ProfileSource.STYLE;
            editorThirdProfile = loadProfileForEditorStyle(style, false);
            editorFirstProfile = loadProfileForEditorStyle(style, true);
        }


        savedThirdProfile = editorThirdProfile.copy();
        savedFirstProfile = editorFirstProfile.copy();
    }

    private static Profile loadProfileForEditorStyle(
            ParryStyle style,
            boolean firstPerson
    ) {
        Profile p = readProfile(
                stylePath(
                        style,
                        editorDual,
                        SuccessAnimationKind.PARRY,
                        firstPerson,
                        BetterCombatWeaponMetadata.isAvailable()
                                ? editorStyleHandedness
                                : null
                )
        );
        if (p != null) {
            return normalize(p);
        }

        /* A new handedness variant starts from the legacy category profile on
         * first use. It is only written to the new variant file when saved,
         * keeping existing user animations intact while making 1H/2H edits independent. */
        if (BetterCombatWeaponMetadata.isAvailable()) {
            p = readProfile(
                    stylePath(style, editorDual, SuccessAnimationKind.PARRY, firstPerson)
            );
            if (p != null) {
                return normalize(p);
            }
        }

        p = readBundledProfile(style, editorDual, firstPerson);
        if (p != null) {
            return normalize(p);
        }

        return fallbackProfile(style, editorDual, firstPerson);
    }

    private static Profile loadDefaultProfile(
            boolean firstPerson,
            DefaultHandedness handedness
    ) {
        Profile p = readProfile(
                defaultVariantPath(
                        editorDual,
                        SuccessAnimationKind.PARRY,
                        firstPerson,
                        handedness
                )
        );
        if (p != null) {
            return normalize(p);
        }

        /* Missing Default variants must never borrow a user-edited Generic file. */
        p = readBundledProfile(
                ParryStyle.GENERIC,
                editorDual,
                firstPerson
        );
        if (p != null) {
            return normalize(p);
        }

        return fallbackProfile(
                ParryStyle.GENERIC,
                editorDual,
                firstPerson
        );
    }

    private static void loadFallbackProfile() {
        Profile third = readProfile(
                fallbackPath(editorDual, SuccessAnimationKind.PARRY, false)
        );
        Profile first = readProfile(
                fallbackPath(editorDual, SuccessAnimationKind.PARRY, true)
        );

        if (third == null) {
            third = readBundledProfile(ParryStyle.GENERIC, editorDual, false);
        }
        if (first == null) {
            first = readBundledProfile(ParryStyle.GENERIC, editorDual, true);
        }

        editorThirdProfile = third == null
                ? fallbackProfile(ParryStyle.GENERIC, editorDual, false)
                : normalize(third);
        editorFirstProfile = first == null
                ? fallbackProfile(ParryStyle.GENERIC, editorDual, true)
                : normalize(first);

        savedThirdProfile = editorThirdProfile.copy();
        savedFirstProfile = editorFirstProfile.copy();
    }

    private static void loadEditorItemOverride(SuccessAnimationKind kind) {
        Profile third = readProfile(itemPath(editorItemId, editorDual, kind, false));
        Profile first = readProfile(itemPath(editorItemId, editorDual, kind, true));
        editorThirdProfile = third == null
                ? fallbackProfile(editorStyle, editorDual, false)
                : normalize(third);
        editorFirstProfile = first == null
                ? fallbackProfile(editorStyle, editorDual, true)
                : normalize(first);

        savedThirdProfile = editorThirdProfile.copy();
        savedFirstProfile = editorFirstProfile.copy();
    }

    private static Profile getActiveEditorProfile() {
        return editorFirstPerson
                ? editorFirstProfile
                : editorThirdProfile;
    }

    private static Profile getCurrentViewProfile() {
        return editorFirstPerson ? editorFirstProfile : editorThirdProfile;
    }

    private static Profile getThirdProfileForSave() {
        return editorThirdProfile;
    }

    private static Profile getFirstProfileForSave() {
        return editorFirstProfile;
    }

    private static void clampEditorPoint() {
        int selected = nearestExistingEndPose(editorSelectedEndPose);
        editorSelectedEndPose = selected;
        if (editorPoseTargetActive && editorPoint >= 0) {
            editorPoint = selected;
        }
    }

    private static PoseData editorPose() {
        Profile p = getActiveEditorProfile();

        if (editorPoint < 0) {
            if (p.pointAMode == PointAMode.CURRENT) {
                return currentUnderlyingPose(editorFirstPerson);
            }
            return p.pointA == null ? PoseData.empty() : p.pointA;
        }

        PoseData point = poseAt(p, editorPoint);
        return point == null ? PoseData.empty() : point;
    }

    private static PoseData poseAt(Profile profile, int index) {
        if (profile == null || profile.pointBs == null
                || index < 0 || index >= profile.pointBs.size()) {
            return null;
        }
        return profile.pointBs.get(index);
    }

    private static int findNextMissingEndPoseIndex(Profile profile) {
        if (profile == null || profile.pointBs == null) {
            return 0;
        }
        for (int i = 0; i < MAX_END_POSES; i++) {
            if (i >= profile.pointBs.size() || profile.pointBs.get(i) == null) {
                return i;
            }
        }
        return -1;
    }

    private static void ensureEndPoseSlot(Profile profile, int index) {
        if (profile.pointBs == null) {
            profile.pointBs = new ArrayList<>();
        }
        while (profile.pointBs.size() <= index && profile.pointBs.size() < MAX_END_POSES) {
            profile.pointBs.add(null);
        }
    }

    private static void trimTrailingEndPoseSlots(Profile profile) {
        while (profile.pointBs.size() > 1
                && profile.pointBs.get(profile.pointBs.size() - 1) == null) {
            profile.pointBs.remove(profile.pointBs.size() - 1);
        }
        if (profile.pointBs.isEmpty()) {
            profile.pointBs.add(PoseData.empty());
        }
    }

    private static int existingEndPoseAfterRemoval(Profile profile, int removedIndex) {
        if (profile != null && profile.pointBs != null) {
            for (int i = Math.max(0, removedIndex); i < profile.pointBs.size(); i++) {
                if (profile.pointBs.get(i) != null) {
                    return i;
                }
            }
        }
        return nearestExistingEndPose(Math.max(0, removedIndex - 1));
    }

    private static int nearestExistingEndPose(int requested) {
        List<Integer> existing = getExistingEndPoseIndices();
        if (existing.isEmpty()) {
            Profile p = getActiveEditorProfile();
            ensureEndPoseSlot(p, 0);
            if (p.pointBs.get(0) == null) {
                p.pointBs.set(0, PoseData.empty());
            }
            return 0;
        }

        int clamped = Math.max(0, Math.min(requested, MAX_END_POSES - 1));
        int best = existing.get(0);
        int bestDistance = Math.abs(best - clamped);
        for (int i = 1; i < existing.size(); i++) {
            int candidate = existing.get(i);
            int distance = Math.abs(candidate - clamped);
            if (distance < bestDistance || (distance == bestDistance && candidate < best)) {
                best = candidate;
                bestDistance = distance;
            }
        }
        return best;
    }

    private static PoseData currentUnderlyingPose(
            boolean firstPerson
    ) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return PoseData.empty();
        }

        ItemStack stack = mc.player.getMainHandItem();
        ParryStyle style = WeaponClassifier.classifyNatural(stack).parryStyle();
        return parryPose(
                stack,
                style,
                DualWieldRules.isDualWield(mc.player),
                firstPerson
        );
    }

    private static float baseParryValue(
            SuccessAnimationChannel c,
            boolean firstPerson
    ) {
        Minecraft mc = Minecraft.getInstance();
        ItemStack stack = mc.player == null
                ? ItemStack.EMPTY
                : mc.player.getMainHandItem();

        if (editorDual) {
            return DualWieldPoseConfig.getVisualValueForStyle(
                    editorStyle,
                    DefenseAnimationSyncPayload.PARRY,
                    firstPerson,
                    c
            );
        }

        return AnimationPoseConfig.getVisualValueFor(
                stack,
                editorStyle,
                DefenseAnimationSyncPayload.PARRY,
                firstPerson,
                c
        );
    }

    public static PoseData blend(
            PoseData a,
            PoseData b,
            float t
    ) {
        PoseData out = PoseData.empty();
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            out = out.withValue(
                    c,
                    a.value(c) + (b.value(c) - a.value(c)) * t
            );
        }
        return out;
    }

    private static int clampTotalDuration(int value) {
        return Math.max(MIN_TOTAL_DURATION_TICKS, Math.min(MAX_DURATION_TICKS, value));
    }

    private static SuccessTransitionMode nextMode(
            SuccessTransitionMode mode
    ) {
        SuccessTransitionMode[] values = SuccessTransitionMode.values();
        return values[(mode.ordinal() + 1) % values.length];
    }

    private static float clamp(
            SuccessAnimationChannel c,
            float value
    ) {
        if (c.name().contains("POS")) {
            return Math.max(-4F, Math.min(4F, value));
        }
        return Math.max(-(float) Math.PI, Math.min((float) Math.PI, value));
    }

    private static Vec3f vec(
            PoseData data,
            SuccessAnimationChannel x,
            SuccessAnimationChannel y,
            SuccessAnimationChannel z
    ) {
        return new Vec3f(
                data.value(x),
                data.value(y),
                data.value(z)
        );
    }

    private static AnimationPoseConfig.ArmPose armPose(
            PoseData data
    ) {
        return new AnimationPoseConfig.ArmPose(
                vec(data,
                        SuccessAnimationChannel.MAIN_ARM_X,
                        SuccessAnimationChannel.MAIN_ARM_Y,
                        SuccessAnimationChannel.MAIN_ARM_Z),
                vec(data,
                        SuccessAnimationChannel.OFF_ARM_X,
                        SuccessAnimationChannel.OFF_ARM_Y,
                        SuccessAnimationChannel.OFF_ARM_Z)
        );
    }

    private static Profile normalize(Profile p) {
        if (p == null) {
            return null;
        }
        if (p.pointA == null) {
            p.pointA = PoseData.empty();
        }
        p.pointA = sanitizePose(p.pointA);

        if (p.pointBs == null) {
            p.pointBs = new ArrayList<>();
        }
        if (p.pointBs.isEmpty()) {
            p.pointBs.add(p.pointA.copy());
        }
        if (p.pointBs.size() > MAX_END_POSES) {
            p.pointBs = new ArrayList<>(p.pointBs.subList(0, MAX_END_POSES));
        }

        for (int i = 0; i < p.pointBs.size(); i++) {
            PoseData pose = p.pointBs.get(i);
            p.pointBs.set(i, pose == null ? null : sanitizePose(pose));
        }
        trimTrailingEndPoseSlots(p);

        p.totalDurationTicks = clampTotalDuration(p.totalDurationTicks);
        if (p.transitionMode == null) {
            p.transitionMode = SuccessTransitionMode.SMOOTH;
        }
        return p;
    }

    /** Remove NaN/infinite pose components before they can reach rendering or interpolation. */
    private static PoseData sanitizePose(PoseData pose) {
        if (pose == null) {
            return PoseData.empty();
        }

        PoseData sanitized = PoseData.empty();
        for (SuccessAnimationChannel channel : SuccessAnimationChannel.values()) {
            float value = pose.value(channel);
            sanitized = sanitized.withValue(
                    channel,
                    Float.isFinite(value) ? value : 0F
            );
        }
        return sanitized;
    }

    private static boolean profilesEqual(
            Profile a,
            Profile b
    ) {
        if (a == b) {
            return true;
        }
        if (a == null || b == null) {
            return false;
        }

        if (a.pointAMode != b.pointAMode
                || a.transitionMode != b.transitionMode
                || a.totalDurationTicks != b.totalDurationTicks) {
            return false;
        }

        if (!poseEqual(a.pointA, b.pointA)
                || a.pointBs.size() != b.pointBs.size()) {
            return false;
        }

        for (int i = 0; i < a.pointBs.size(); i++) {
            if (!poseEqual(a.pointBs.get(i), b.pointBs.get(i))) {
                return false;
            }
        }

        return true;
    }

    private static boolean poseEqual(
            PoseData a,
            PoseData b
    ) {
        if (a == b) {
            return true;
        }
        if (a == null || b == null) {
            return false;
        }
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            if (Float.compare(a.value(c), b.value(c)) != 0) {
                return false;
            }
        }
        return true;
    }

    private static AnimationPoseConfig.SaveResult saveStyleProfiles(
            ParryStyle style
    ) {
        try {
            Profile thirdToSave = getThirdProfileForSave().copy();
            Profile firstToSave = getFirstProfileForSave().copy();

            Path thirdPath = stylePathForSave(style, false);
            Path firstPath = stylePathForSave(style, true);
            writeProfile(thirdPath, thirdToSave);
            writeProfile(firstPath, firstToSave);

            Profile thirdCheck = readProfile(thirdPath);
            Profile firstCheck = readProfile(firstPath);
            if (!profilesEqual(thirdToSave, thirdCheck)
                    || !profilesEqual(firstToSave, firstCheck)) {
                throw new IOException("Saved Successful Parry profile did not round-trip identically.");
            }

            savedThirdProfile = thirdToSave.copy();
            savedFirstProfile = firstToSave.copy();
            publishSavedRuntimeProfiles(
                    getEditorProfileId(),
                    thirdToSave,
                    firstToSave
            );

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Saved Successful Parry " + pretty(style) + " profile."
            );
        } catch (Exception e) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Successful Parry style profile {}.",
                    style,
                    e
            );
            return fail("Successful Parry save failed. Check latest.log.");
        }
    }

    private static Path stylePathForSave(
            ParryStyle style,
            boolean firstPerson
    ) {
        if (editorProfileSource == ProfileSource.DEFAULT) {
            return defaultVariantPath(
                    editorDual,
                    SuccessAnimationKind.PARRY,
                    firstPerson,
                    editorDefaultHandedness
            );
        }
        if (editorProfileSource == ProfileSource.FALLBACK) {
            return fallbackPath(
                    editorDual,
                    SuccessAnimationKind.PARRY,
                    firstPerson
            );
        }
        if (editorProfileSource == ProfileSource.STYLE) {
            return stylePath(
                    style,
                    editorDual,
                    SuccessAnimationKind.PARRY,
                    firstPerson,
                    BetterCombatWeaponMetadata.isAvailable()
                            ? editorStyleHandedness
                            : null
            );
        }
        throw new IllegalStateException("ITEM_OVERRIDE cannot be saved through stylePathForSave().");
    }

    private static void writeStyleViewPair(
            ParryStyle style,
            Profile thirdProfile,
            Profile firstProfile
    ) throws IOException {
        writeProfile(stylePathForSave(style, false), thirdProfile);
        writeProfile(stylePathForSave(style, true), firstProfile);
    }

    private static void writeItemViewPair(
            ResourceLocation itemId,
            Profile thirdProfile,
            Profile firstProfile
    ) throws IOException {
        writeProfile(
                itemPath(itemId, editorDual, SuccessAnimationKind.PARRY, false),
                thirdProfile
        );
        writeProfile(
                itemPath(itemId, editorDual, SuccessAnimationKind.PARRY, true),
                firstProfile
        );
    }

    private static void writeProfile(
            Path path,
            Profile p
    ) throws IOException {
        Files.createDirectories(path.getParent());

        JsonObject root = new JsonObject();
        root.addProperty("format", "success_parry_animation_v5");
        root.addProperty("point_a_mode", p.pointAMode.name().toLowerCase(Locale.ROOT));
        root.add("point_a", writePose(p.pointA));

        JsonArray endPoses = new JsonArray();
        for (PoseData pose : p.pointBs) {
            endPoses.add(pose == null ? JsonNull.INSTANCE : writePose(pose));
        }
        root.add("point_b", endPoses);

        root.addProperty("transition_mode", p.transitionMode.name().toLowerCase(Locale.ROOT));
        root.addProperty("total_ticks", p.totalDurationTicks);

        String json = GSON.toJson(root);
        Path tempPath = path.resolveSibling(path.getFileName() + ".tmp");
        Files.writeString(
                tempPath,
                json,
                StandardCharsets.UTF_8
        );
        try {
            Files.move(
                    tempPath,
                    path,
                    StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING
            );
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(
                    tempPath,
                    path,
                    StandardCopyOption.REPLACE_EXISTING
            );
        }
    }

    private static JsonObject writePose(PoseData pose) {
        JsonObject object = new JsonObject();
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            object.addProperty(c.jsonName(), pose.value(c));
        }
        return object;
    }

    private static Profile readProfile(Path path) {
        if (path == null || !Files.exists(path)) {
            return null;
        }

        try {
            JsonObject root = JsonParser.parseString(
                    Files.readString(path, StandardCharsets.UTF_8)
            ).getAsJsonObject();

            Profile p = Profile.empty();

            if (root.has("point_a_mode")) {
                try {
                    p.pointAMode = PointAMode.valueOf(
                            root.get("point_a_mode")
                                    .getAsString()
                                    .toUpperCase(Locale.ROOT)
                    );
                } catch (Exception ignored) {
                    p.pointAMode = PointAMode.CURRENT;
                }
            }

            if (root.has("point_a") && root.get("point_a").isJsonObject()) {
                p.pointA = readPose(root.getAsJsonObject("point_a"));
            }

            if (root.has("point_b") && root.get("point_b").isJsonArray()) {
                p.pointBs.clear();
                JsonArray array = root.getAsJsonArray("point_b");
                for (var element : array) {
                    if (element.isJsonNull()) {
                        p.pointBs.add(null);
                    } else if (element.isJsonObject()) {
                        p.pointBs.add(readPose(element.getAsJsonObject()));
                    }
                }
            } else if (root.has("pose") && root.get("pose").isJsonObject()) {
                /* Backward compatibility with the original one-pose profile. */
                p.pointAMode = PointAMode.CURRENT;
                p.pointBs.clear();
                p.pointBs.add(readPose(root.getAsJsonObject("pose")));
                p.pointA = p.pointBs.get(0).copy();
            }

            if (root.has("transition_mode")) {
                p.transitionMode = parseSuccessMode(
                        root.get("transition_mode").getAsString(),
                        p.transitionMode
                );
                if (root.has("total_ticks")) {
                    p.totalDurationTicks = clampTotalDuration(root.get("total_ticks").getAsInt());
                }
            } else {
                /* Migrate legacy split timing into the unified Successful Parry timing model.
                 * Keep the previous total duration and use Start→End's curve as the single curve. */
                int legacyA = root.has("a_to_b_ticks")
                        ? clampLegacyDuration(root.get("a_to_b_ticks").getAsInt())
                        : 3;
                int legacyB = root.has("b_to_default_ticks")
                        ? clampLegacyDuration(root.get("b_to_default_ticks").getAsInt())
                        : 5;
                p.totalDurationTicks = clampTotalDuration(legacyA + legacyB);

                if (root.has("a_to_b_mode")) {
                    p.transitionMode = parseSuccessMode(
                            root.get("a_to_b_mode").getAsString(),
                            p.transitionMode
                    );
                } else if (root.has("b_to_default_mode")) {
                    p.transitionMode = parseSuccessMode(
                            root.get("b_to_default_mode").getAsString(),
                            p.transitionMode
                    );
                }
            }

            return normalize(p);
        } catch (Exception e) {
            GyeokbuV2.LOGGER.error(
                    "Failed to read Successful Parry animation profile {}.",
                    path,
                    e
            );
            return null;
        }
    }

    private static PoseData readPose(JsonObject object) {
        PoseData data = PoseData.empty();
        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            if (object.has(c.jsonName())) {
                data = data.withValue(
                        c,
                        object.get(c.jsonName()).getAsFloat()
                );
            }
        }
        return data;
    }

    private static int clampLegacyDuration(int value) {
        return Math.max(1, Math.min(MAX_DURATION_TICKS, value));
    }

    private static SuccessTransitionMode parseSuccessMode(
            String value,
            SuccessTransitionMode fallback
    ) {
        return SuccessTransitionMode.fromSerializedName(
                value,
                fallback
        );
    }

    private static Profile readBundledProfile(
            ParryStyle style,
            boolean dual,
            boolean firstPerson
    ) {
        String relative = "success_animations/"
                + (dual ? "dual_wield/" : "single/")
                + SuccessAnimationKind.PARRY.folder()
                + "/"
                + (firstPerson ? "first_person/" : "third_person/")
                + "styles/"
                + style.name().toLowerCase(Locale.ROOT)
                + ".json";

        try {
            if (!BundledStanceDefaults.has(relative)) {
                return null;
            }

            JsonObject root = JsonParser.parseString(
                    BundledStanceDefaults.readText(relative)
            ).getAsJsonObject();

            Profile p = Profile.empty();
            p.pointAMode = PointAMode.CURRENT;

            Minecraft mc = Minecraft.getInstance();
            ItemStack stack = mc.player == null
                    ? ItemStack.EMPTY
                    : mc.player.getMainHandItem();

            p.pointA = parryPose(
                    stack,
                    style,
                    dual,
                    firstPerson
            );
            p.pointBs.clear();

            if (root.has("point_b") && root.get("point_b").isJsonArray()) {
                for (var element : root.getAsJsonArray("point_b")) {
                    if (element.isJsonNull()) {
                        p.pointBs.add(null);
                    } else if (element.isJsonObject()) {
                        p.pointBs.add(readPose(element.getAsJsonObject()));
                    }
                }
            } else if (root.has("pose") && root.get("pose").isJsonObject()) {
                p.pointBs.add(readPose(root.getAsJsonObject("pose")));
            }

            return normalize(p);
        } catch (Exception exception) {
            /* Bundled profiles are packaged resources, so there is no filesystem Path here. */
            GyeokbuV2.LOGGER.error(
                    "Failed to read bundled Successful Parry profile {}.",
                    relative,
                    exception
            );
            return null;
        }
    }

    private static Path root(
            boolean dual,
            SuccessAnimationKind kind,
            boolean firstPerson
    ) {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("success_animations")
                .resolve(dual ? "dual_wield" : "single")
                .resolve(kind.folder())
                .resolve(firstPerson ? "first_person" : "third_person");
    }

    private static DefaultHandedness detectDefaultHandedness(ItemStack stack) {
        if (stack != null && !stack.isEmpty()) {
            BetterCombatWeaponMetadata.Metadata metadata = BetterCombatWeaponMetadata.get(stack);
            if (metadata.present()) {
                return metadata.twoHanded()
                        ? DefaultHandedness.TWO_HANDED
                        : DefaultHandedness.ONE_HANDED;
            }
        }
        return DefaultHandedness.ONE_HANDED;
    }

    /**
     * UI-safe resolver for the currently held weapon's handedness when a style
     * selector needs a concrete 1H/2H profile. The editor remains the owner of
     * the resulting selection; this method only observes the current stack.
     */
    public static HandStyle detectStyleHandednessForUi(ParryStyle style) {
        return detectStyleHandednessForEditor(style);
    }

    private static HandStyle detectStyleHandednessForEditor(ParryStyle style) {
        if (!BetterCombatWeaponMetadata.isAvailable()) {
            return HandStyle.ONE_HANDED;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            ItemStack stack = mc.player.getMainHandItem();
            WeaponProfile profile = WeaponClassifier.classifyNatural(stack);
            if (profile.isSupported() && profile.parryStyle() == style) {
                return profile.handStyle();
            }
        }
        return HandStyle.ONE_HANDED;
    }

    private static Path defaultVariantPath(
            boolean dual,
            SuccessAnimationKind kind,
            boolean firstPerson,
            DefaultHandedness handedness
    ) {
        DefaultHandedness safeHandedness = handedness == null
                ? DefaultHandedness.ONE_HANDED
                : handedness;
        return root(dual, kind, firstPerson)
                .resolve("styles")
                .resolve("default_"
                        + (safeHandedness == DefaultHandedness.TWO_HANDED ? "two_handed" : "one_handed")
                        + ".json");
    }

    private static Path stylePath(
            ParryStyle style,
            boolean dual,
            SuccessAnimationKind kind,
            boolean firstPerson
    ) {
        return stylePath(style, dual, kind, firstPerson, null);
    }

    private static Path fallbackPath(
            boolean dual,
            SuccessAnimationKind kind,
            boolean firstPerson
    ) {
        return root(dual, kind, firstPerson)
                .resolve("fallback.json");
    }

    private static Path stylePath(
            ParryStyle style,
            boolean dual,
            SuccessAnimationKind kind,
            boolean firstPerson,
            HandStyle handStyle
    ) {
        String file = style.name().toLowerCase(Locale.ROOT);
        if (handStyle != null && BetterCombatWeaponMetadata.isAvailable()) {
            file += handStyle == HandStyle.TWO_HANDED
                    ? "_two_handed"
                    : "_one_handed";
        }
        return root(dual, kind, firstPerson)
                .resolve("styles")
                .resolve(file + ".json");
    }

    /** Directory path used by the save methods; third-person is canonical. */
    private static Path stylePath(
            ParryStyle style,
            boolean dual,
            SuccessAnimationKind kind
    ) {
        return stylePath(style, dual, kind, false);
    }

    private static Path itemPath(
            ResourceLocation id,
            boolean dual,
            SuccessAnimationKind kind,
            boolean firstPerson
    ) {
        if (id == null) {
            return null;
        }

        return root(dual, kind, firstPerson)
                .resolve("items")
                .resolve(id.getNamespace())
                .resolve(id.getPath() + ".json");
    }

    /** Directory helper retained for current callers. */
    private static Path itemPath(
            ResourceLocation id,
            boolean dual,
            SuccessAnimationKind kind
    ) {
        return itemPath(id, dual, kind, false);
    }

    private static Path defaultEnabledPath(boolean dual) {
        return root(
                dual,
                SuccessAnimationKind.PARRY,
                false
        ).resolve("default_enabled.txt");
    }

    private static AnimationPoseConfig.SaveResult success(String message) {
        return new AnimationPoseConfig.SaveResult(true, message);
    }

    private static AnimationPoseConfig.SaveResult fail(String message) {
        return new AnimationPoseConfig.SaveResult(false, message);
    }

    private static String pretty(ParryStyle style) {
        if (style == null || style == ParryStyle.GENERIC) {
            return "Default";
        }

        StringBuilder result = new StringBuilder();
        for (String word : style.name().toLowerCase(Locale.ROOT).split("_")) {
            if (word.isEmpty()) {
                continue;
            }
            if (!result.isEmpty()) {
                result.append(' ');
            }
            result.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1));
        }
        return result.toString();
    }

    private record TransitionSettings(
            SuccessTransitionMode mode,
            int totalTicks
    ) {
    }

    public static final class Profile {
        PointAMode pointAMode = PointAMode.CURRENT;
        PoseData pointA = PoseData.empty();
        List<PoseData> pointBs = new ArrayList<>();
        SuccessTransitionMode transitionMode = SuccessTransitionMode.SMOOTH;
        int totalDurationTicks = DEFAULT_TOTAL_DURATION_TICKS;

        static Profile empty() {
            Profile p = new Profile();
            p.pointBs.add(p.pointA.copy());
            return p;
        }

        Profile copy() {
            Profile p = new Profile();
            p.pointAMode = pointAMode;
            p.pointA = pointA == null ? PoseData.empty() : pointA.copy();
            p.pointBs.clear();
            if (pointBs != null) {
                for (PoseData point : pointBs) {
                    p.pointBs.add(point == null ? null : point.copy());
                }
            }
            p.transitionMode = transitionMode;
            p.totalDurationTicks = totalDurationTicks;
            return p;
        }
    }

    public static final class PoseData {
        private final EnumMap<SuccessAnimationChannel, Float> values =
                new EnumMap<>(SuccessAnimationChannel.class);

        private PoseData() {
            for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
                values.put(c, 0F);
            }
        }

        public static PoseData empty() {
            return new PoseData();
        }

        public float value(SuccessAnimationChannel channel) {
            return values.getOrDefault(channel, 0F);
        }

        public PoseData withValue(
                SuccessAnimationChannel channel,
                float value
        ) {
            PoseData p = copy();
            p.values.put(channel, value);
            return p;
        }

        public PoseData copy() {
            PoseData p = new PoseData();
            p.values.putAll(values);
            return p;
        }
    }
}
