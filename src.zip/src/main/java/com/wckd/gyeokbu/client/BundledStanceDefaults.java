package com.wckd.gyeokbu.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.Minecraft;

import java.nio.file.FileAlreadyExistsException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Immutable Gyeokbu-authored stance resources shipped inside the mod JAR.
 *
 * On startup they are copied into config/gyeokbuv2 only when the destination
 * file is missing. Existing user files are never replaced.
 */
public final class BundledStanceDefaults {

    private static final String RESOURCE_ROOT =
            "assets/" + GyeokbuV2.MODID + "/shipped_stance_defaults/";

    private static final String INDEX_RESOURCE =
            RESOURCE_ROOT + "index.json";

    private BundledStanceDefaults() {
    }

    public static void seedMissingConfigFiles() {
        try {
            Path configRoot = getConfigRoot();
            Files.createDirectories(configRoot);

            int seeded = 0;
            for (String relativePath : readIndex()) {
                Path destination = resolveConfigPath(relativePath);
                if (Files.exists(destination)) {
                    continue;
                }

                Files.createDirectories(destination.getParent());

                try (InputStream input = open(relativePath)) {
                    Files.copy(
                            input,
                            destination
                    );
                    seeded++;
                } catch (FileAlreadyExistsException ignored) {
                    /* Another initialization path created it first. */
                }
            }

            if (seeded > 0) {
                GyeokbuV2.LOGGER.info(
                        "Seeded {} missing Gyeokbu stance config file(s) from bundled defaults.",
                        seeded
                );
            }
        } catch (Exception exception) {
            /*
             * Bundled resources are the preferred source, but stance loading
             * still has its existing hardcoded/legacy fallbacks. A damaged or
             * incomplete JAR should therefore log the problem rather than make
             * the whole client fail during setup.
             */
            GyeokbuV2.LOGGER.error(
                    "Could not seed bundled Gyeokbu stance defaults; falling back to existing stance recovery paths.",
                    exception
            );
        }
    }

    public static boolean has(String relativePath) {
        String resource = resourcePath(relativePath);
        return BundledStanceDefaults.class
                .getClassLoader()
                .getResource(resource) != null;
    }

    /**
     * True when an external config file is not the untouched copy of the
     * bundled file at the same relative path. Files without a bundled
     * counterpart are always user-authored overrides.
     */
    public static boolean isUserOverride(
            Path configPath,
            String relativePath
    ) throws IOException {
        if (configPath == null || !Files.exists(configPath)) {
            return false;
        }

        if (!has(relativePath)) {
            return true;
        }

        String external = Files.readString(
                configPath,
                StandardCharsets.UTF_8
        );
        String bundled = readText(relativePath);

        /*
         * Compare parsed JSON rather than raw bytes. F8 rewrites formatting,
         * so whitespace/key-order differences alone must not turn an official
         * default into a higher-priority user override.
         */
        try {
            JsonElement externalJson = JsonParser.parseString(external);
            JsonElement bundledJson = JsonParser.parseString(bundled);
            return !externalJson.equals(bundledJson);
        } catch (RuntimeException malformedJson) {
            /* The normal loaders will report malformed user JSON themselves. */
            return true;
        }
    }

    public static String readText(String relativePath) throws IOException {
        try (InputStream input = open(relativePath)) {
            return new String(
                    input.readAllBytes(),
                    StandardCharsets.UTF_8
            );
        }
    }

    public static Path resolveConfigPath(String relativePath) {
        Path root = getConfigRoot().toAbsolutePath().normalize();
        Path resolved = root.resolve(normalizeRelativePath(relativePath))
                .toAbsolutePath()
                .normalize();

        if (!resolved.startsWith(root)) {
            throw new IllegalArgumentException(
                    "Invalid bundled stance path: " + relativePath
            );
        }

        return resolved;
    }

    private static Path getConfigRoot() {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID);
    }

    private static List<String> readIndex() throws IOException {
        try (InputStream input = openAbsolute(INDEX_RESOURCE)) {
            String text = new String(
                    input.readAllBytes(),
                    StandardCharsets.UTF_8
            );

            JsonObject root = JsonParser.parseString(text)
                    .getAsJsonObject();
            JsonArray files = root.getAsJsonArray("files");

            List<String> result = new ArrayList<>(files.size());
            for (JsonElement element : files) {
                result.add(normalizeRelativePath(element.getAsString()));
            }
            return result;
        }
    }

    private static InputStream open(String relativePath) throws IOException {
        return openAbsolute(resourcePath(relativePath));
    }

    private static InputStream openAbsolute(String resourcePath) throws IOException {
        InputStream input = BundledStanceDefaults.class
                .getClassLoader()
                .getResourceAsStream(resourcePath);

        if (input == null) {
            throw new IOException(
                    "Missing bundled Gyeokbu stance resource: " + resourcePath
            );
        }
        return input;
    }

    private static String resourcePath(String relativePath) {
        return RESOURCE_ROOT + normalizeRelativePath(relativePath);
    }

    private static String normalizeRelativePath(String relativePath) {
        String normalized = relativePath.replace('\\', '/');
        while (normalized.startsWith("/")) {
            normalized = normalized.substring(1);
        }

        if (normalized.isBlank()
                || normalized.equals("..")
                || normalized.startsWith("../")
                || normalized.contains("/../")) {
            throw new IllegalArgumentException(
                    "Invalid bundled stance relative path: " + relativePath
            );
        }

        return normalized;
    }
}
