package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.particle.ModParticles;
import com.wckd.gyeokbu.particle.ParrySparkParticle;
import com.wckd.gyeokbu.particle.StunCritParticle;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;

@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT,
        bus = EventBusSubscriber.Bus.MOD
)
public final class ClientParticleEvents {

    private ClientParticleEvents() {
    }

    @SubscribeEvent
    public static void registerParticleProviders(
            RegisterParticleProvidersEvent event
    ) {

        /*
         * Actual individual sizes:
         *
         * BIG    = 100%
         * MEDIUM = 72%
         * SMALL  = 48%
         * TINY   = 28%
         */

        event.registerSpriteSet(
                ModParticles.STUN_CRIT_BIG.get(),
                spriteSet ->
                        new StunCritParticle.Provider(
                                spriteSet,
                                1.00F
                        )
        );

        event.registerSpriteSet(
                ModParticles.STUN_CRIT_MEDIUM.get(),
                spriteSet ->
                        new StunCritParticle.Provider(
                                spriteSet,
                                0.72F
                        )
        );

        event.registerSpriteSet(
                ModParticles.STUN_CRIT_SMALL.get(),
                spriteSet ->
                        new StunCritParticle.Provider(
                                spriteSet,
                                0.48F
                        )
        );

        event.registerSpriteSet(
                ModParticles.STUN_CRIT_TINY.get(),
                spriteSet ->
                        new StunCritParticle.Provider(
                                spriteSet,
                                0.28F
                        )
        );

        event.registerSpriteSet(
                ModParticles.PARRY_SPARK.get(),
                ParrySparkParticle.Provider::new
        );
    }
}