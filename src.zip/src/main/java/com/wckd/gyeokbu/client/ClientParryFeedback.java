package com.wckd.gyeokbu.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.wckd.gyeokbu.particle.ModParticles;
import com.wckd.gyeokbu.particle.ParrySparkParticle;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Client-only successful-Parry VFX placement.
 *
 * Third person starts from the real held-item render pivot captured from
 * ItemInHandLayer after Gyeokbu's stance offsets have been applied, then
 * projects the impact point outward along the incoming contact direction so
 * the burst reads as a blade contact rather than a hand/grip effect. The
 * resulting burst is world-space and does not follow player/camera movement.
 * Local first person uses the same contact-side idea from its hand anchor.
 */
public final class ClientParryFeedback {

    private static final Map<Integer, RenderAnchor> THIRD_PERSON_ANCHORS =
            new ConcurrentHashMap<>();

    private ClientParryFeedback() {
    }

    /**
     * Called from ItemInHandLayerMixin immediately before the main-hand item is
     * rendered. At this point the PoseStack contains vanilla hand attachment
     * plus Gyeokbu's current weapon translation/rotation.
     */
    public static void captureThirdPersonWeaponAnchor(
            Player player,
            PoseStack poseStack
    ) {
        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.level == null) {
            return;
        }

        Vector3f cameraRelative =
                poseStack.last()
                        .pose()
                        .getTranslation(new Vector3f());

        Vec3 cameraPosition =
                minecraft.gameRenderer
                        .getMainCamera()
                        .getPosition();

        Vec3 worldPosition =
                cameraPosition.add(
                        cameraRelative.x(),
                        cameraRelative.y(),
                        cameraRelative.z()
                );

        THIRD_PERSON_ANCHORS.put(
                player.getId(),
                new RenderAnchor(
                        worldPosition,
                        player.tickCount
                )
        );
    }

    public static void play(
            int defenderEntityId,
            float incomingX,
            float incomingY,
            float incomingZ
    ) {
        Minecraft minecraft = Minecraft.getInstance();

        if (minecraft.level == null) {
            return;
        }

        if (!(minecraft.level.getEntity(defenderEntityId)
                instanceof AbstractClientPlayer defender)) {
            return;
        }

        Vec3 incoming = new Vec3(
                incomingX,
                incomingY,
                incomingZ
        );

        if (incoming.lengthSqr() < 0.0001D) {
            incoming = defender.getLookAngle().scale(-1.0D);
        }

        incoming = incoming.normalize();

        boolean localFirstPerson =
                minecraft.player == defender
                        && minecraft.options
                                .getCameraType()
                                == CameraType.FIRST_PERSON;

        Vec3 contact = localFirstPerson
                ? firstPersonContact(minecraft, defender, incoming)
                : thirdPersonContact(defender, incoming);

        spawnMetalContact(
                minecraft,
                contact,
                incoming,
                defender
        );
    }

    private static Vec3 firstPersonContact(
            Minecraft minecraft,
            AbstractClientPlayer defender,
            Vec3 incoming
    ) {
        Vec3 cameraPosition =
                minecraft.gameRenderer
                        .getMainCamera()
                        .getPosition();

        Vec3 forward = defender.getViewVector(1.0F);
        if (forward.lengthSqr() < 0.0001D) {
            forward = new Vec3(0.0D, 0.0D, 1.0D);
        }
        forward = forward.normalize();

        Vec3 right = forward.cross(new Vec3(0.0D, 1.0D, 0.0D));
        if (right.lengthSqr() < 0.0001D) {
            right = new Vec3(1.0D, 0.0D, 0.0D);
        }
        right = right.normalize();

        Vec3 up = right.cross(forward);
        if (up.lengthSqr() < 0.0001D) {
            up = new Vec3(0.0D, 1.0D, 0.0D);
        }
        up = up.normalize();

        double handSide =
                defender.getMainArm() == HumanoidArm.RIGHT
                        ? 0.18D
                        : -0.18D;

        Vec3 contact = cameraPosition
                .add(forward.scale(0.58D))
                .add(right.scale(handSide))
                .add(up.scale(-0.18D));

        /*
         * Preserve useful stance-editor translation in first person without
         * trying to reconstruct the entire rendered weapon model.
         */
        Vec3f configuredOffset =
                AnimationPoseConfig.getWeaponPositionFor(defender);

        if (configuredOffset != null) {
            contact = contact
                    .add(right.scale(configuredOffset.getX()))
                    .add(up.scale(configuredOffset.getY()))
                    .add(forward.scale(configuredOffset.getZ()));
        }

        /*
         * Project from the visible hand/weapon anchor toward the incoming
         * source. For the usual front-facing Parry this lands around the outer
         * half/tip of the rendered weapon instead of at the hand itself.
         */
        Vec3 towardSource = incoming.scale(-1.0D);
        return contact.add(towardSource.scale(0.24D));
    }

    private static Vec3 thirdPersonContact(
            AbstractClientPlayer defender,
            Vec3 incoming
    ) {
        RenderAnchor tracked =
                THIRD_PERSON_ANCHORS.get(defender.getId());

        Vec3 grip;

        if (tracked != null
                && Math.abs(defender.tickCount - tracked.tick()) <= 2) {
            grip = tracked.position();
        } else {
            grip = fallbackThirdPersonGrip(defender);
        }

        /*
         * The tracked transform is the rendered held-item pivot/grip after the
         * current Gyeokbu stance/model offsets. Push the contact outward toward
         * the parried source so a normal sword Parry reads near the blade/tip.
         * This is intentionally based on the live render pose rather than the
         * camera, and the spawned particles remain fixed in world space.
         *
         * Arbitrary modded models do not expose a universal "blade tip" point,
         * so the contact-side projection is the compatibility-safe fallback.
         */
        Vec3 towardSource = incoming.scale(-1.0D);
        return grip
                .add(towardSource.scale(0.52D))
                .add(0.0D, 0.04D, 0.0D);
    }

    private static Vec3 fallbackThirdPersonGrip(
            AbstractClientPlayer defender
    ) {
        Vec3 forward = new Vec3(
                defender.getLookAngle().x,
                0.0D,
                defender.getLookAngle().z
        );

        if (forward.lengthSqr() < 0.0001D) {
            forward = new Vec3(0.0D, 0.0D, 1.0D);
        }
        forward = forward.normalize();

        Vec3 right = new Vec3(
                -forward.z,
                0.0D,
                forward.x
        );

        double handSide =
                defender.getMainArm() == HumanoidArm.RIGHT
                        ? 0.30D
                        : -0.30D;

        return defender.position()
                .add(0.0D, defender.getBbHeight() * 0.70D, 0.0D)
                .add(forward.scale(0.18D))
                .add(right.scale(handSide));
    }

    private static void spawnMetalContact(
            Minecraft minecraft,
            Vec3 contact,
            Vec3 incoming,
            AbstractClientPlayer defender
    ) {
        if (minecraft.level == null) {
            return;
        }

        Vec3 worldUp = new Vec3(0.0D, 1.0D, 0.0D);
        Vec3 towardSource = incoming.scale(-1.0D);
        Vec3 side = incoming.cross(worldUp);

        if (side.lengthSqr() < 0.0001D) {
            Vec3 look = defender.getLookAngle();
            side = new Vec3(-look.z, 0.0D, look.x);
        }

        if (side.lengthSqr() < 0.0001D) {
            side = new Vec3(1.0D, 0.0D, 0.0D);
        }

        side = side.normalize();

        Vec3 lift = side.cross(incoming);
        if (lift.lengthSqr() < 0.0001D) {
            lift = worldUp;
        }
        lift = lift.normalize();

        /*
         * Every shape still begins with all sparks layered at the exact same
         * contact point. Shape only changes the outward travel vectors.
         */
        final int sparkCount = ParryParticleTransitionConfig.particleCount();
        ThreadLocalRandom random = ThreadLocalRandom.current();
        ParryParticleTransitionConfig.Shape shape =
                ParryParticleTransitionConfig.shape();

        int[] palette = ParryParticleTransitionConfig.dynamicColors()
                ? BladeColorSampler.sample(defender.getMainHandItem(), defender)
                : new int[]{0xFFFFFF};

        /* Also ends any older in-progress burst before these sparks are created. */
        ParrySparkParticle.beginBurst(defender.getId(), palette);

        double burstRotation = random.nextDouble(0.0D, Math.PI * 2.0D);
        double spokeSpacing = (Math.PI * 2.0D) / sparkCount;

        /*
         * Shattered Ring guarantees a couple of longer spokes, with an
         * occasional third one, so it always reads as an imperfect ring
         * instead of merely relying on lucky random speed variation.
         */
        int shatteredA = random.nextInt(sparkCount);
        int shatteredB;
        do {
            shatteredB = random.nextInt(sparkCount);
        } while (shatteredB == shatteredA);

        int shatteredC = -1;
        if (random.nextDouble() < 0.40D) {
            do {
                shatteredC = random.nextInt(sparkCount);
            } while (shatteredC == shatteredA || shatteredC == shatteredB);
        }

        try {
            for (int i = 0; i < sparkCount; i++) {
                double angle;
                double speed;
                double depth;

            switch (shape) {
                case SHATTERED_RING -> {
                    double angleJitter = random.nextDouble(
                            -spokeSpacing * 0.42D,
                            spokeSpacing * 0.42D
                    );
                    angle = burstRotation + spokeSpacing * i + angleJitter;
                    speed = random.nextDouble(0.175D, 0.236D);

                    if (i == shatteredA || i == shatteredB || i == shatteredC) {
                        speed *= random.nextDouble(1.55D, 2.10D);
                    }

                    depth = random.nextDouble(-0.055D, 0.056D);
                }

                case SPARK_FAN -> {
                    /*
                     * A broad upward shower of metal sparks. Keep a little
                     * random rotation/jitter so repeated Parries do not make
                     * an identical comb-shaped fan.
                     */
                    double fanSpan = Math.toRadians(150.0D);
                    double fanCenter = Math.PI * 0.5D
                            + random.nextDouble(-0.16D, 0.161D);
                    double rowProgress = sparkCount <= 1
                            ? 0.0D
                            : i / (double) (sparkCount - 1);
                    double fanOffset = (rowProgress - 0.5D) * fanSpan;
                    double angleJitter = random.nextDouble(-0.075D, 0.076D);

                    angle = burstRotation * 0.08D
                            + fanCenter
                            + fanOffset
                            + angleJitter;
                    speed = random.nextDouble(0.165D, 0.255D);
                    depth = random.nextDouble(-0.038D, 0.039D);
                }

                case STARBURST -> {
                    double angleJitter = random.nextDouble(
                            -spokeSpacing * 0.18D,
                            spokeSpacing * 0.18D
                    );
                    angle = burstRotation + spokeSpacing * i + angleJitter;

                    /* Alternating long/short spokes make a sharp impact star. */
                    double lengthMultiplier = (i & 1) == 0
                            ? random.nextDouble(1.42D, 1.70D)
                            : random.nextDouble(0.72D, 0.94D);
                    speed = random.nextDouble(0.175D, 0.226D)
                            * lengthMultiplier;
                    depth = random.nextDouble(-0.045D, 0.046D);
                }

                case RING -> {
                    double angleJitter = random.nextDouble(
                            -spokeSpacing * 0.38D,
                            spokeSpacing * 0.38D
                    );
                    angle = burstRotation + spokeSpacing * i + angleJitter;
                    speed = random.nextDouble(0.180D, 0.241D);
                    depth = random.nextDouble(-0.050D, 0.051D);
                }

                default -> throw new IllegalStateException(
                        "Unexpected Parry particle shape: " + shape
                );
            }

            Vec3 radial = side
                    .scale(Math.cos(angle))
                    .add(lift.scale(Math.sin(angle)))
                    .normalize();

            /*
             * Give every spark a small one-time push toward the parried
             * attacker/projectile. The shape still controls the radial spread,
             * while this bias makes Expand/Fall travel outward in front of the
             * defender instead of lingering directly behind an advancing player.
             */
            Vec3 velocity = radial
                    .scale(speed)
                    .add(incoming.scale(depth))
                    .add(towardSource.scale(0.060D));

                minecraft.level.addParticle(
                        ModParticles.PARRY_SPARK.get(),
                        contact.x,
                        contact.y,
                        contact.z,
                        velocity.x,
                        velocity.y,
                        velocity.z
                );
            }
        } finally {
            ParrySparkParticle.endBurst();
        }
    }

    private record RenderAnchor(
            Vec3 position,
            int tick
    ) {
    }
}
