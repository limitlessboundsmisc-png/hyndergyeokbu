package com.wckd.gyeokbu.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.DeveloperMessagesPayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Client-side persisted preference for optional Gyeokbu developer messages. */
@EventBusSubscriber(modid = GyeokbuV2.MODID, value = Dist.CLIENT)
public final class DeveloperMessageConfig {

    private static final boolean DEFAULT_ENABLED = false;
    private static volatile boolean enabled = DEFAULT_ENABLED;

    private DeveloperMessageConfig() {
    }

    public static void initialize() {
        reload();
    }

    public static boolean enabled() {
        return enabled;
    }

    /** Reapply the persisted client preference whenever a new server session starts. */
    @SubscribeEvent
    public static void onClientLogin(ClientPlayerNetworkEvent.LoggingIn event) {
        syncToServer();
    }

    public static void toggleAndSync() {
        enabled = !enabled;
        save();
        syncToServer();
    }

    public static void syncToServer() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.getConnection() == null) {
            return;
        }

        PacketDistributor.sendToServer(
                new DeveloperMessagesPayload(enabled)
        );
    }

    public static void reload() {
        Path path = getPath();

        try {
            Files.createDirectories(path.getParent());

            if (!Files.exists(path)) {
                write();
                return;
            }

            JsonObject root = JsonParser.parseString(
                    Files.readString(path, StandardCharsets.UTF_8)
            ).getAsJsonObject();

            enabled = root.has("enabled")
                    ? root.get("enabled").getAsBoolean()
                    : DEFAULT_ENABLED;
        } catch (Exception exception) {
            enabled = DEFAULT_ENABLED;
            GyeokbuV2.LOGGER.error(
                    "Failed to load Gyeokbu developer-message config. Using defaults.",
                    exception
            );
        }
    }

    private static void save() {
        try {
            write();
        } catch (IOException exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu developer-message config.",
                    exception
            );
        }
    }

    private static void write() throws IOException {
        Path path = getPath();
        Files.createDirectories(path.getParent());

        String json = """
                {
                  "enabled": %s
                }
                """.formatted(enabled);

        Files.writeString(path, json, StandardCharsets.UTF_8);
    }

    private static Path getPath() {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("developer_messages.json");
    }
}
