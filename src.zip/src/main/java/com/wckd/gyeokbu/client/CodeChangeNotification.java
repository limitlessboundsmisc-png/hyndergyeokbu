package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/** Displays the current Gyeokbu change number once when joining a world/server. */
@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public final class CodeChangeNotification {

    /* Increment this for each new Gyeokbu implementation package. */
    private static final int CURRENT_CHANGE_NUMBER = 45;

    private static final int DISPLAY_TICKS = 60;

    private static int remainingTicks = 0;

    private CodeChangeNotification() {
    }

    @SubscribeEvent
    public static void onClientLogin(ClientPlayerNetworkEvent.LoggingIn event) {
        SuccessAnimationConfig.clearRuntimeProfileCache();
        SuccessAnimationRuntime.clearRuntimeState();
        remainingTicks = DISPLAY_TICKS;
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (remainingTicks <= 0) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            return;
        }

        minecraft.player.displayClientMessage(
                Component.literal("CHANGED! (" + CURRENT_CHANGE_NUMBER + ")"),
                true
        );
        remainingTicks--;
    }

    @SubscribeEvent
    public static void onClientLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        SuccessAnimationConfig.clearRuntimeProfileCache();
        SuccessAnimationRuntime.clearRuntimeState();
        remainingTicks = 0;
    }
}
