package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.compat.ShieldParryCompat;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import com.wckd.gyeokbu.enchantment.GyeokbuVanillaEnchantmentSlots;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

import java.util.ArrayList;
import java.util.List;

/** Client-only Minecraft-style descriptions and dedicated Gyeokbu slot display. */
@EventBusSubscriber(modid = GyeokbuV2.MODID, value = Dist.CLIENT)
public final class GyeokbuEnchantmentTooltipEvents {

    private GyeokbuEnchantmentTooltipEvents() {
    }

    @SubscribeEvent
    public static void onTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        if (stack.isEmpty()) {
            return;
        }

        if (stack.is(Items.ENCHANTED_BOOK)) {
            addEnchantmentBookTooltip(event, stack);
            return;
        }

        if (!GyeokbuEnchantments.isEligibleWeaponForEnchantments(stack)
                && !GyeokbuEnchantments.isShield(stack)) {
            return;
        }

        addActiveVanillaBridgeTooltip(event.getToolTip(), stack);
        addWeaponSlotSection(event.getToolTip(), stack, "tooltip.gyeokbuv2.slots.header");
    }

    private static void addEnchantmentBookTooltip(ItemTooltipEvent event, ItemStack book) {
        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(book);
        Player player = event.getEntity();
        ItemStack target = player == null ? ItemStack.EMPTY : getHeldCompatibleTarget(player);
        boolean bookProvidesBlock = contains(enchantments, GyeokbuEnchantments.BLOCK)
                || contains(enchantments, GyeokbuEnchantments.PERFECT_BLOCK);
        boolean blockRequirementMet = bookProvidesBlock
                || (!target.isEmpty() && GyeokbuEnchantments.isShield(target))
                || (!target.isEmpty() && player != null
                && GyeokbuEnchantments.hasBlockProvider(player.level(), target));

        boolean relevant = false;

        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            int level = enchantments.getLevel(enchantment);
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)
                    || GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                continue;
            }

            Component description = getGyeokbuDescription(enchantment, level);
            if (description == null) {
                continue;
            }

            MutableComponent line = description.copy().withStyle(ChatFormatting.GRAY);

            if (GyeokbuEnchantments.requiresBlockProvider(enchantment)) {
                appendCondition(line, requirement("Requires Block", blockRequirementMet));
            }

            if (!target.isEmpty() && GyeokbuEnchantments.isShield(target)) {
                if (GyeokbuEnchantments.isWeaponOnlyEnchantment(enchantment)) {
                    appendCondition(line, requirement("Weapon Only", false));
                } else if (GyeokbuEnchantments.isParryEnchantment(enchantment)) {
                    boolean capable = ShieldParryCompat.isParryCapableShield(target)
                            && GyeokbuEnchantments.isShieldParryCompatibleEnchantment(enchantment);
                    appendCondition(line, requirement("Requires Shield Parry", capable));
                }
            }

            appendIncompatibilityWarning(line, enchantment);
            event.getToolTip().add(line);
            relevant = true;
        }

        boolean hasKnockback = getLevel(enchantments, Enchantments.KNOCKBACK) > 0;
        boolean hasFireAspect = getLevel(enchantments, Enchantments.FIRE_ASPECT) > 0;

        if (hasKnockback || hasFireAspect) {
            addSeparator(event.getToolTip());
            if (hasKnockback) {
                event.getToolTip().add(Component.translatable("tooltip.gyeokbuv2.knockback.parry")
                        .withStyle(ChatFormatting.GRAY));
            }
            if (hasFireAspect) {
                event.getToolTip().add(Component.translatable("tooltip.gyeokbuv2.fire_aspect.parry")
                        .withStyle(ChatFormatting.GRAY));
            }
            relevant = true;
        }

        if (!relevant || target.isEmpty()) {
            return;
        }

        addWeaponSlotSection(event.getToolTip(), target, "tooltip.gyeokbuv2.slots.held_weapon");
    }

    private static MutableComponent requirement(String text, boolean met) {
        return Component.literal("[" + text + "]")
                .withStyle(met ? ChatFormatting.GREEN : ChatFormatting.RED);
    }

    private static void appendCondition(MutableComponent line, Component condition) {
        line.append(Component.literal(" - ").withStyle(ChatFormatting.DARK_GRAY));
        line.append(condition);
    }

    private static void appendIncompatibilityWarning(
            MutableComponent line,
            Holder<Enchantment> enchantment
    ) {
        String incompatible = null;
        if (enchantment.is(GyeokbuEnchantments.SOFT_BLOW)) {
            incompatible = "Concussion";
        } else if (enchantment.is(GyeokbuEnchantments.CONCUSSION)) {
            incompatible = "Soft Blow";
        } else if (enchantment.is(GyeokbuEnchantments.BLOCK)) {
            incompatible = "Perfect Block";
        } else if (enchantment.is(GyeokbuEnchantments.PERFECT_BLOCK)) {
            incompatible = "Block";
        }

        if (incompatible != null) {
            appendCondition(
                    line,
                    Component.literal("[Incompatible with " + incompatible + "]")
                            .withStyle(ChatFormatting.GOLD)
            );
        }
    }

    private static void addActiveVanillaBridgeTooltip(List<Component> tooltip, ItemStack weapon) {
        int knockbackLevel = GyeokbuVanillaEnchantmentSlots.getActiveLevel(weapon, Enchantments.KNOCKBACK);
        int fireAspectLevel = GyeokbuVanillaEnchantmentSlots.getActiveLevel(weapon, Enchantments.FIRE_ASPECT);
        if (knockbackLevel <= 0 && fireAspectLevel <= 0) {
            return;
        }

        addSeparator(tooltip);
        if (knockbackLevel > 0) {
            tooltip.add(Component.translatable("tooltip.gyeokbuv2.knockback.parry")
                    .withStyle(ChatFormatting.GRAY));
        }
        if (fireAspectLevel > 0) {
            tooltip.add(Component.translatable("tooltip.gyeokbuv2.fire_aspect.parry")
                    .withStyle(ChatFormatting.GRAY));
        }
    }

    private static void addSeparator(List<Component> tooltip) {
        tooltip.add(Component.literal("----------------").withStyle(ChatFormatting.DARK_GRAY));
    }

    private static ItemStack getHeldCompatibleTarget(Player player) {
        ItemStack mainHand = player.getMainHandItem();
        if (GyeokbuEnchantments.isEligibleWeaponForEnchantments(mainHand)
                || GyeokbuEnchantments.isShield(mainHand)) {
            return mainHand;
        }

        ItemStack offhand = player.getOffhandItem();
        if (GyeokbuEnchantments.isEligibleWeaponForEnchantments(offhand)
                || GyeokbuEnchantments.isShield(offhand)) {
            return offhand;
        }

        return ItemStack.EMPTY;
    }

    /** Slots are vertical and use full vanilla-style enchantment names/levels. */
    private static void addWeaponSlotSection(List<Component> tooltip, ItemStack weapon, String headerKey) {
        tooltip.add(Component.empty());
        tooltip.add(Component.translatable(headerKey).withStyle(ChatFormatting.GOLD));

        List<Component> labels = getOccupiedSlotLabels(weapon);
        int capacity = GyeokbuEnchantments.getCapacity(weapon);
        for (int i = 0; i < capacity; i++) {
            Component label = i < labels.size() ? labels.get(i) : Component.empty();
            tooltip.add(makeSlotLine(label));
        }
    }

    private static Component makeSlotLine(Component label) {
        MutableComponent line = Component.literal("[ ").withStyle(ChatFormatting.DARK_GRAY);
        if (!label.getString().isEmpty()) {
            line.append(label);
        } else {
            line.append(Component.literal("   ").withStyle(ChatFormatting.GRAY));
        }
        line.append(Component.literal(" ]").withStyle(ChatFormatting.DARK_GRAY));
        return line;
    }

    private static List<Component> getOccupiedSlotLabels(ItemStack weapon) {
        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(weapon);
        int capacity = GyeokbuEnchantments.getCapacity(weapon);
        List<Component> labels = new ArrayList<>(capacity);

        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            int level = enchantments.getLevel(enchantment);
            if (GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)
                    && !GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                int slotCost = GyeokbuEnchantments.getOriginalSlotCost(enchantment);
                Component fullName = fullName(enchantment, level);
                for (int i = 0; i < slotCost; i++) {
                    labels.add(fullName);
                }
            } else if (!GyeokbuEnchantments.isShield(weapon)
                    && enchantment.is(Enchantments.KNOCKBACK)
                    && GyeokbuVanillaEnchantmentSlots.isActive(weapon, Enchantments.KNOCKBACK)) {
                labels.add(fullName(enchantment, level));
            } else if (!GyeokbuEnchantments.isShield(weapon)
                    && enchantment.is(Enchantments.FIRE_ASPECT)
                    && GyeokbuVanillaEnchantmentSlots.isActive(weapon, Enchantments.FIRE_ASPECT)) {
                labels.add(fullName(enchantment, level));
            }

            if (labels.size() >= capacity) {
                break;
            }
        }

        return labels.size() > capacity
                ? new ArrayList<>(labels.subList(0, capacity))
                : labels;
    }

    private static Component fullName(Holder<Enchantment> enchantment, int level) {
        return Enchantment.getFullname(enchantment, level)
                .copy().withStyle(ChatFormatting.LIGHT_PURPLE);
    }

    private static Component getGyeokbuDescription(Holder<Enchantment> enchantment, int level) {
        if (enchantment.is(GyeokbuEnchantments.REFLECT)) {
            return Component.translatable("enchantment.gyeokbuv2.reflect.description");
        }
        if (enchantment.is(GyeokbuEnchantments.SOFT_BLOW)) {
            return Component.translatable("enchantment.gyeokbuv2.soft_blow.description");
        }
        if (enchantment.is(GyeokbuEnchantments.CONCUSSION)) {
            return Component.translatable("enchantment.gyeokbuv2.concussion.description");
        }
        if (enchantment.is(GyeokbuEnchantments.VULNERABILITY)) {
            return Component.translatable("enchantment.gyeokbuv2.vulnerability.description");
        }
        if (enchantment.is(GyeokbuEnchantments.BLAST_NEGATION)) {
            return Component.translatable("enchantment.gyeokbuv2.blast_negation.description");
        }
        if (enchantment.is(GyeokbuEnchantments.MASTERY)) {
            return Component.translatable("enchantment.gyeokbuv2.mastery.description");
        }
        if (enchantment.is(GyeokbuEnchantments.SWEEPING_GUARD)) {
            return Component.translatable("enchantment.gyeokbuv2.sweeping_guard.description");
        }
        if (enchantment.is(GyeokbuEnchantments.BLOCK)) {
            return Component.translatable("enchantment.gyeokbuv2.block.description");
        }
        if (enchantment.is(GyeokbuEnchantments.PERFECT_BLOCK)) {
            return Component.translatable("enchantment.gyeokbuv2.perfect_block.description");
        }
        if (enchantment.is(GyeokbuEnchantments.BLOCKING_STANCE)) {
            return Component.translatable("enchantment.gyeokbuv2.blocking_stance.description");
        }
        if (enchantment.is(GyeokbuEnchantments.PUSHBACK)) {
            return Component.translatable("enchantment.gyeokbuv2.pushback.description");
        }
        if (enchantment.is(GyeokbuEnchantments.PROJECTILE_REFLECT)) {
            return Component.translatable("enchantment.gyeokbuv2.projectile_reflect.description");
        }
        if (enchantment.is(GyeokbuEnchantments.BLAST_GUARD)) {
            return Component.translatable("enchantment.gyeokbuv2.blast_guard.description");
        }
        return null;
    }

    private static boolean contains(ItemEnchantments enchantments, ResourceKey<Enchantment> key) {
        return getLevel(enchantments, key) > 0;
    }

    private static int getLevel(ItemEnchantments enchantments, ResourceKey<Enchantment> key) {
        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(key)) {
                return enchantments.getLevel(enchantment);
            }
        }
        return 0;
    }
}
