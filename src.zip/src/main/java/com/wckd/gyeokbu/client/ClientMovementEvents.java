package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.combat.DefenseManager;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.MovementInputUpdateEvent;

@EventBusSubscriber(
        modid = GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public final class ClientMovementEvents {

    private static int damageTiltSuppressTicks =
            0;

    private static Double savedDamageTiltStrength =
            null;

    private static int hurtFlashSuppressTicks =
            0;

    private static boolean hardStunRotationCaptured =
            false;

    private static float hardStunLockedYaw =
            0.0F;

    private static float hardStunLockedPitch =
            0.0F;

    private ClientMovementEvents() {
    }

    public static void suppressDamageVisuals(
            int ticks,
            boolean suppressHurtFlash
    ) {

        int safeTicks = Math.max(0, ticks);

        damageTiltSuppressTicks =
                Math.max(
                        damageTiltSuppressTicks,
                        safeTicks
                );

        if (suppressHurtFlash) {
            hurtFlashSuppressTicks = Math.max(
                    hurtFlashSuppressTicks,
                    safeTicks
            );
        }

        /*
         * Apply suppression IMMEDIATELY when the block packet
         * reaches the client instead of waiting for the next
         * ClientTickEvent.Post.
         *
         * Waiting until the next tick allowed one or two rendered
         * frames of vanilla hurt-camera movement to slip through,
         * creating the brief "impact frame" the player could see.
         *
         * We only change Damage Tilt. The player's real hurt state
         * is untouched, so the normal red damage feedback remains.
         */
        Minecraft minecraft =
                Minecraft.getInstance();

        if (savedDamageTiltStrength == null) {

            savedDamageTiltStrength =
                    minecraft.options
                            .damageTiltStrength()
                            .get();
        }

        minecraft.options
                .damageTiltStrength()
                .set(0.0D);

        if (suppressHurtFlash && minecraft.player != null) {
            minecraft.player.hurtTime = 0;
            minecraft.player.hurtDuration = 0;
        }
    }

    @SubscribeEvent
    public static void onMovementInputUpdate(
            MovementInputUpdateEvent event
    ) {

        Minecraft minecraft =
                Minecraft.getInstance();

        if (minecraft.player == null) {
            return;
        }

        /*
         * HARD STUN ONLY.
         */
        if (ClientCombatSyncState
                .isHardStunned()) {

            event.getInput().leftImpulse =
                    0.0F;

            event.getInput().forwardImpulse =
                    0.0F;

            event.getInput().jumping =
                    false;

            minecraft.player.setSprinting(
                    false
            );

            return;
        }

        if (ClientCombatSyncState
                .isDefenseMovementPenaltyActive()) {

            event.getInput().leftImpulse *=
                    DefenseManager
                            .DEFENSE_MOVEMENT_MULTIPLIER;

            event.getInput().forwardImpulse *=
                    DefenseManager
                            .DEFENSE_MOVEMENT_MULTIPLIER;

            minecraft.player.setSprinting(
                    false
            );
        }
    }

    @SubscribeEvent
    public static void onClientTick(
            ClientTickEvent.Post event
    ) {

        Minecraft minecraft =
                Minecraft.getInstance();

        updateDamageTiltSuppression(
                minecraft
        );

        updateHurtFlashSuppression(
                minecraft
        );

        if (minecraft.player == null) {

            ClientCombatSyncState.reset();
            DefensePoseTransitionRuntime.reset();
            hardStunRotationCaptured = false;
            return;
        }

        if (ClientCombatSyncState.isHardStunned()) {
            if (!hardStunRotationCaptured) {
                hardStunLockedYaw = minecraft.player.getYRot();
                hardStunLockedPitch = minecraft.player.getXRot();
                hardStunRotationCaptured = true;
            }

            minecraft.player.setYRot(hardStunLockedYaw);
            minecraft.player.setXRot(hardStunLockedPitch);
            minecraft.player.yHeadRot = hardStunLockedYaw;
            minecraft.player.yHeadRotO = hardStunLockedYaw;
            minecraft.player.yBodyRot = hardStunLockedYaw;
            minecraft.player.yBodyRotO = hardStunLockedYaw;

            minecraft.options.keyAttack.setDown(false);
            minecraft.options.keyJump.setDown(false);
            minecraft.player.setSprinting(false);
        } else {
            hardStunRotationCaptured = false;

            if (ClientCombatSyncState.isDefenseMovementPenaltyActive()) {
                minecraft.player.setSprinting(false);
            }
        }
    }

    private static void updateDamageTiltSuppression(
            Minecraft minecraft
    ) {

        if (damageTiltSuppressTicks > 0) {

            if (savedDamageTiltStrength == null) {

                savedDamageTiltStrength =
                        minecraft.options
                                .damageTiltStrength()
                                .get();
            }

            minecraft.options
                    .damageTiltStrength()
                    .set(0.0D);

            damageTiltSuppressTicks--;

            return;
        }

        if (savedDamageTiltStrength != null) {

            minecraft.options
                    .damageTiltStrength()
                    .set(
                            savedDamageTiltStrength
                    );

            savedDamageTiltStrength =
                    null;
        }
    }

    private static void updateHurtFlashSuppression(
            Minecraft minecraft
    ) {
        if (hurtFlashSuppressTicks <= 0) {
            return;
        }

        if (minecraft.player != null) {
            /*
             * Perfect Block has already reduced the direct melee damage to
             * zero server-side. Clearing the local hurt timers prevents the
             * vanilla red damage tint/hurt animation from falsely implying
             * that damage was taken. Normal 50% Blocks do not use this flag.
             */
            minecraft.player.hurtTime = 0;
            minecraft.player.hurtDuration = 0;
        }

        hurtFlashSuppressTicks--;
    }

}