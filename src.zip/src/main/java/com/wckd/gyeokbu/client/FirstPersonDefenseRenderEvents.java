package com.wckd.gyeokbu.client;

/**
 * V14 used NeoForge's direct first-person RenderHandEvent path.
 *
 * V15 intentionally returns to PlayerAnimator/Better Combat first person,
 * so this class is kept as an inert placeholder. Keeping the file prevents
 * users from having to manually delete it when merging the patch.
 */
public final class FirstPersonDefenseRenderEvents {

    private FirstPersonDefenseRenderEvents() {
    }
}
