package com.wckd.gyeokbu.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/** Client-only successful-Parry particle appearance and motion settings. */
public final class ParryParticleTransitionConfig {

    public enum Shape {
        RING("Ring"),
        SHATTERED_RING("Shattered Ring"),
        SPARK_FAN("Spark Fan"),
        STARBURST("Starburst");

        private final String displayName;

        Shape(String displayName) {
            this.displayName = displayName;
        }

        public String displayName() {
            return displayName;
        }
    }

    public enum Motion {
        EXPAND("Expand"),
        FALL("Fall"),
        EXPAND_FALL("Expand + Fall");

        private final String displayName;

        Motion(String displayName) {
            this.displayName = displayName;
        }

        public String displayName() {
            return displayName;
        }

        public boolean expands() {
            return this == EXPAND || this == EXPAND_FALL;
        }

        public boolean falls() {
            return this == FALL || this == EXPAND_FALL;
        }
    }

    private static final DefenseTransitionConfig.Mode DEFAULT_MODE =
            DefenseTransitionConfig.Mode.SMOOTH;
    private static final Shape DEFAULT_SHAPE = Shape.RING;
    private static final Motion DEFAULT_MOTION = Motion.EXPAND;
    private static final int DEFAULT_DURATION_TICKS = 6;
    private static final int MIN_DURATION_TICKS = 1;
    private static final int MAX_DURATION_TICKS = 20;
    private static final int DEFAULT_TURN_DELAY_TICKS = 1;
    private static final int MIN_TURN_DELAY_TICKS = 1;
    private static final int MAX_TURN_DELAY_TICKS = 20;
    private static final int DEFAULT_PARTICLE_COUNT = 8;
    private static final int MIN_PARTICLE_COUNT = 1;
    private static final int MAX_PARTICLE_COUNT = 32;
    private static final float DEFAULT_OPACITY = 1.0F;
    private static final float MIN_OPACITY = 0.0F;
    private static final float MAX_OPACITY = 1.0F;
    private static final boolean DEFAULT_DYNAMIC_COLORS = false;
    private static final float DEFAULT_SIZE = 1.0F;
    private static final float MIN_SIZE = 0.25F;
    private static final float MAX_SIZE = 3.0F;

    private static volatile DefenseTransitionConfig.Mode mode = DEFAULT_MODE;
    private static volatile Shape shape = DEFAULT_SHAPE;
    private static volatile Motion motion = DEFAULT_MOTION;
    private static volatile int durationTicks = DEFAULT_DURATION_TICKS;
    private static volatile int turnDelayTicks = DEFAULT_TURN_DELAY_TICKS;
    private static volatile int particleCount = DEFAULT_PARTICLE_COUNT;
    private static volatile float opacity = DEFAULT_OPACITY;
    private static volatile boolean dynamicColors = DEFAULT_DYNAMIC_COLORS;
    private static volatile float size = DEFAULT_SIZE;

    private ParryParticleTransitionConfig() {
    }

    public static void initialize() {
        reload();
    }

    public static void reload() {
        Path path = getPath();

        try {
            Files.createDirectories(path.getParent());

            if (!Files.exists(path)) {
                write();
                return;
            }

            JsonObject root = JsonParser.parseString(
                    Files.readString(path, StandardCharsets.UTF_8)
            ).getAsJsonObject();

            DefenseTransitionConfig.Mode loadedMode = DEFAULT_MODE;
            if (root.has("mode")) {
                loadedMode = DefenseTransitionConfig.Mode.fromSerializedName(
                        root.get("mode").getAsString(),
                        DEFAULT_MODE
                );
            }

            Shape loadedShape = DEFAULT_SHAPE;
            if (root.has("shape")) {
                try {
                    loadedShape = Shape.valueOf(
                            root.get("shape").getAsString().trim().toUpperCase(Locale.ROOT)
                    );
                } catch (IllegalArgumentException ignored) {
                    loadedShape = DEFAULT_SHAPE;
                }
            }

            Motion loadedMotion = DEFAULT_MOTION;
            if (root.has("motion")) {
                try {
                    loadedMotion = Motion.valueOf(
                            root.get("motion").getAsString().trim().toUpperCase(Locale.ROOT)
                    );
                } catch (IllegalArgumentException ignored) {
                    loadedMotion = DEFAULT_MOTION;
                }
            }

            int loadedDuration = root.has("duration_ticks")
                    ? root.get("duration_ticks").getAsInt()
                    : DEFAULT_DURATION_TICKS;
            int loadedTurnDelay = root.has("turn_delay_ticks")
                    ? root.get("turn_delay_ticks").getAsInt()
                    : DEFAULT_TURN_DELAY_TICKS;
            int loadedParticleCount = root.has("particle_count")
                    ? root.get("particle_count").getAsInt()
                    : DEFAULT_PARTICLE_COUNT;
            float loadedOpacity = root.has("opacity")
                    ? root.get("opacity").getAsFloat()
                    : DEFAULT_OPACITY;
            boolean loadedDynamicColors = root.has("dynamic_colors")
                    ? root.get("dynamic_colors").getAsBoolean()
                    : DEFAULT_DYNAMIC_COLORS;
            float loadedSize = root.has("size")
                    ? root.get("size").getAsFloat()
                    : DEFAULT_SIZE;

            mode = loadedMode;
            shape = loadedShape;
            motion = loadedMotion;
            durationTicks = clampDuration(loadedDuration);
            turnDelayTicks = clampTurnDelay(loadedTurnDelay);
            particleCount = clampParticleCount(loadedParticleCount);
            opacity = clampOpacity(loadedOpacity);
            dynamicColors = loadedDynamicColors;
            size = clampSize(loadedSize);
        } catch (Exception exception) {
            mode = DEFAULT_MODE;
            shape = DEFAULT_SHAPE;
            motion = DEFAULT_MOTION;
            durationTicks = DEFAULT_DURATION_TICKS;
            turnDelayTicks = DEFAULT_TURN_DELAY_TICKS;
            particleCount = DEFAULT_PARTICLE_COUNT;
            opacity = DEFAULT_OPACITY;
            dynamicColors = DEFAULT_DYNAMIC_COLORS;
            size = DEFAULT_SIZE;

            GyeokbuV2.LOGGER.error(
                    "Failed to load Gyeokbu Parry particle transition config. Using defaults.",
                    exception
            );
        }
    }

    public static DefenseTransitionConfig.Mode mode() {
        return mode;
    }

    public static int durationTicks() {
        return durationTicks;
    }

    public static int turnDelayTicks() {
        return turnDelayTicks;
    }

    public static Shape shape() {
        return shape;
    }

    public static int particleCount() {
        return particleCount;
    }

    public static Motion motion() {
        return motion;
    }

    public static float opacity() {
        return opacity;
    }

    public static int opacityPercent() {
        return Math.round(opacity * 100.0F);
    }

    public static boolean dynamicColors() {
        return dynamicColors;
    }

    public static float size() {
        return size;
    }

    public static int sizePercent() {
        return Math.round(size * 100.0F);
    }

    public static void adjustSize(float delta) {
        size = clampSize(size + delta);
        save();
    }

    public static void cycleShape() {
        Shape[] shapes = Shape.values();
        shape = shapes[(shape.ordinal() + 1) % shapes.length];
        save();
    }

    public static void cycleMotion() {
        Motion[] motions = Motion.values();
        motion = motions[(motion.ordinal() + 1) % motions.length];
        save();
    }

    public static void cycleMode() {
        DefenseTransitionConfig.Mode[] modes = DefenseTransitionConfig.Mode.values();
        mode = modes[(mode.ordinal() + 1) % modes.length];
        save();
    }

    public static void adjustDurationTicks(int delta) {
        durationTicks = clampDuration(durationTicks + delta);
        save();
    }

    public static void adjustTurnDelayTicks(int delta) {
        turnDelayTicks = clampTurnDelay(turnDelayTicks + delta);
        save();
    }

    public static void adjustParticleCount(int delta) {
        particleCount = clampParticleCount(particleCount + delta);
        save();
    }

    public static void adjustOpacity(float delta) {
        opacity = clampOpacity(opacity + delta);
        save();
    }

    public static void toggleDynamicColors() {
        dynamicColors = !dynamicColors;
        save();
    }

    /** Applies the shared Gyeokbu transition curves to particle previews. */
    public static float applyCurve(float rawProgress) {
        return GyeokbuTransitionCurves.apply(rawProgress, mode);
    }

    private static int clampDuration(int value) {
        return Math.max(MIN_DURATION_TICKS, Math.min(MAX_DURATION_TICKS, value));
    }

    private static int clampTurnDelay(int value) {
        return Math.max(MIN_TURN_DELAY_TICKS, Math.min(MAX_TURN_DELAY_TICKS, value));
    }

    private static int clampParticleCount(int value) {
        return Math.max(MIN_PARTICLE_COUNT, Math.min(MAX_PARTICLE_COUNT, value));
    }

    private static float clampSize(float value) {
        float clamped = Math.max(MIN_SIZE, Math.min(MAX_SIZE, value));
        return Math.round(clamped * 20.0F) / 20.0F;
    }

    private static float clampOpacity(float value) {
        float clamped = Math.max(MIN_OPACITY, Math.min(MAX_OPACITY, value));
        return Math.round(clamped * 20.0F) / 20.0F;
    }

    private static void save() {
        try {
            write();
        } catch (IOException exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu Parry particle transition config.",
                    exception
            );
        }
    }

    private static void write() throws IOException {
        Path path = getPath();
        Files.createDirectories(path.getParent());

        String json = """
                {
                  "mode": "%s",
                  "shape": "%s",
                  "motion": "%s",
                  "duration_ticks": %d,
                  "turn_delay_ticks": %d,
                  "particle_count": %d,
                  "dynamic_colors": %s,
                  "size": %.2f,
                  "opacity": %.2f
                }
                """.formatted(
                mode.name().toLowerCase(Locale.ROOT),
                shape.name().toLowerCase(Locale.ROOT),
                motion.name().toLowerCase(Locale.ROOT),
                durationTicks,
                turnDelayTicks,
                particleCount,
                dynamicColors,
                size,
                opacity
        );

        Files.writeString(path, json, StandardCharsets.UTF_8);
    }

    private static Path getPath() {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("parry_particle_transition.json");
    }
}
