package com.wckd.gyeokbu.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Per-mainhand dual-wield visual stances.
 *
 * Modern dual-wield stance storage:
 * - default stance is selected by the main-hand ParryStyle
 * - within each layer, exact pair saves override main-weapon saves, then category defaults
 * - user-authored files override untouched seeded/shipped files
 * - 3P and 1P weapon transforms remain independently editable
 * - First- and Third-Person pose sets are independent and can be copied explicitly
 */
public final class DualWieldPoseConfig {

    private static final Map<ParryStyle, DualPoseSet> THIRD_PERSON =
            new EnumMap<>(ParryStyle.class);

    private static final Map<ParryStyle, DualPoseSet> FIRST_PERSON =
            new EnumMap<>(ParryStyle.class);

    /* Saved loadout-specific dual-wield overrides. Priority is Pair -> Main Weapon -> Default. */
    private static final Map<ResourceLocation, DualPoseSet> MAIN_THIRD_PERSON = new HashMap<>();
    private static final Map<ResourceLocation, DualPoseSet> MAIN_FIRST_PERSON = new HashMap<>();
    private static final Map<ResourceLocation, ParryStyle> MAIN_STYLE_ASSIGNMENTS = new HashMap<>();

    private static final Map<PairKey, DualPoseSet> PAIR_THIRD_PERSON = new HashMap<>();
    private static final Map<PairKey, DualPoseSet> PAIR_FIRST_PERSON = new HashMap<>();
    private static final Map<PairKey, ParryStyle> PAIR_STYLE_ASSIGNMENTS = new HashMap<>();

    /* First- and Third-Person workspaces are always independent. */
    private static final Map<ParryStyle, DualPoseSet> LINKED_THIRD_PERSON = new EnumMap<>(ParryStyle.class);
    private static final Map<ParryStyle, DualPoseSet> LINKED_FIRST_PERSON = new EnumMap<>(ParryStyle.class);
    private static final Map<ResourceLocation, DualPoseSet> LINKED_MAIN_THIRD_PERSON = new HashMap<>();
    private static final Map<ResourceLocation, DualPoseSet> LINKED_MAIN_FIRST_PERSON = new HashMap<>();
    private static final Map<ResourceLocation, ParryStyle> LINKED_MAIN_STYLE_ASSIGNMENTS = new HashMap<>();
    private static final Map<PairKey, DualPoseSet> LINKED_PAIR_THIRD_PERSON = new HashMap<>();
    private static final Map<PairKey, DualPoseSet> LINKED_PAIR_FIRST_PERSON = new HashMap<>();
    private static final Map<PairKey, ParryStyle> LINKED_PAIR_STYLE_ASSIGNMENTS = new HashMap<>();
    private static final Map<ParryStyle, Boolean> LINKED_VIEW_STATES = new EnumMap<>(ParryStyle.class);

    /* Untouched seeded files are shipped defaults; changed/new files are user overrides. */
    private static final Set<ParryStyle> USER_THIRD_STYLES = new HashSet<>();
    private static final Set<ParryStyle> USER_FIRST_STYLES = new HashSet<>();
    private static final Set<ResourceLocation> USER_MAIN_THIRD = new HashSet<>();
    private static final Set<ResourceLocation> USER_MAIN_FIRST = new HashSet<>();
    private static final Set<PairKey> USER_PAIR_THIRD = new HashSet<>();
    private static final Set<PairKey> USER_PAIR_FIRST = new HashSet<>();

    private static final Set<ParryStyle> USER_LINKED_THIRD_STYLES = new HashSet<>();
    private static final Set<ParryStyle> USER_LINKED_FIRST_STYLES = new HashSet<>();
    private static final Set<ResourceLocation> USER_LINKED_MAIN_THIRD = new HashSet<>();
    private static final Set<ResourceLocation> USER_LINKED_MAIN_FIRST = new HashSet<>();
    private static final Set<PairKey> USER_LINKED_PAIR_THIRD = new HashSet<>();
    private static final Set<PairKey> USER_LINKED_PAIR_FIRST = new HashSet<>();

    private static volatile List<ParryStyle> AVAILABLE_DUAL_STYLES = null;

    private static boolean editorActive = false;
    private static boolean editorFirstPerson = false;
    /* Linked Views was retired. First- and Third-Person are always independent. */
    private static final boolean editorViewsLinked = false;
    private static int editorMode = DefenseAnimationSyncPayload.PARRY;
    private static ParryStyle editorStyle = ParryStyle.GENERIC;
    private static ParryStyle editorNaturalStyle = ParryStyle.GENERIC;
    private static ResourceLocation editorMainItemId = null;
    private static ResourceLocation editorOffItemId = null;

    private static DualPoseSet editorThirdPerson = neutral();
    private static DualPoseSet editorFirstPersonPose = neutral();
    private static DualPoseSet editorThirdPersonOriginal = neutral();
    private static DualPoseSet editorFirstPersonOriginal = neutral();

    private static DualPoseSet editorLinkedThirdPerson = neutral();
    private static DualPoseSet editorLinkedFirstPerson = neutral();
    private static DualPoseSet editorLinkedThirdPersonOriginal = neutral();
    private static DualPoseSet editorLinkedFirstPersonOriginal = neutral();

    private static DualPoseSet clipboardThirdPerson = null;
    private static DualPoseSet clipboardFirstPerson = null;
    private static ParryStyle clipboardSourceStyle = null;

    private DualWieldPoseConfig() {
    }

    public static void initialize() {
        reload();
    }

    public static void reload() {
        THIRD_PERSON.clear();
        FIRST_PERSON.clear();
        MAIN_THIRD_PERSON.clear();
        MAIN_FIRST_PERSON.clear();
        MAIN_STYLE_ASSIGNMENTS.clear();
        PAIR_THIRD_PERSON.clear();
        PAIR_FIRST_PERSON.clear();
        PAIR_STYLE_ASSIGNMENTS.clear();
        LINKED_THIRD_PERSON.clear();
        LINKED_FIRST_PERSON.clear();
        LINKED_MAIN_THIRD_PERSON.clear();
        LINKED_MAIN_FIRST_PERSON.clear();
        LINKED_MAIN_STYLE_ASSIGNMENTS.clear();
        LINKED_PAIR_THIRD_PERSON.clear();
        LINKED_PAIR_FIRST_PERSON.clear();
        LINKED_PAIR_STYLE_ASSIGNMENTS.clear();
        LINKED_VIEW_STATES.clear();
        USER_THIRD_STYLES.clear();
        USER_FIRST_STYLES.clear();
        USER_MAIN_THIRD.clear();
        USER_MAIN_FIRST.clear();
        USER_PAIR_THIRD.clear();
        USER_PAIR_FIRST.clear();
        USER_LINKED_THIRD_STYLES.clear();
        USER_LINKED_FIRST_STYLES.clear();
        USER_LINKED_MAIN_THIRD.clear();
        USER_LINKED_MAIN_FIRST.clear();
        USER_LINKED_PAIR_THIRD.clear();
        USER_LINKED_PAIR_FIRST.clear();
        AVAILABLE_DUAL_STYLES = null;

        try {
            loadOverrideIndexes(false);
            // Linked Views was retired; legacy linked indexes are ignored.

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to load Gyeokbu dual-wield override indexes.",
                    exception
            );
        }
    }

    public static boolean isEditorActive() {
        return editorActive;
    }

    public static boolean isEditorFirstPerson() {
        return editorActive && editorFirstPerson;
    }

    public static int getEditorMode() {
        return editorMode;
    }

    public static ParryStyle getEditorStyle() {
        return editorStyle;
    }

    public static void beginEditor() {
        Minecraft minecraft = Minecraft.getInstance();
        ItemStack main = minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getMainHandItem();
        ItemStack off = minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getOffhandItem();

        ResourceLocation mainId = itemId(main);
        ResourceLocation offId = itemId(off);
        ParryStyle natural = WeaponClassifier.classifyNatural(main).parryStyle();
        ParryStyle style = resolveActiveAssignedStyle(mainId, offId, natural);
        beginEditor(style);
    }

    public static void beginEditor(ParryStyle style) {
        Minecraft minecraft = Minecraft.getInstance();
        ItemStack main = minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getMainHandItem();
        ItemStack off = minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getOffhandItem();

        editorMainItemId = itemId(main);
        editorOffItemId = itemId(off);
        editorNaturalStyle = WeaponClassifier.classifyNatural(main).parryStyle();

        if (style == null) {
            style = editorNaturalStyle == null ? ParryStyle.GENERIC : editorNaturalStyle;
        }

        ensureStyleLoaded(style);
        editorStyle = style;
        editorMode = DefenseAnimationSyncPayload.PARRY;
        editorFirstPerson = minecraft.options.getCameraType() == CameraType.FIRST_PERSON;

        editorThirdPerson = resolveSavedEditorPose(style, false, false);
        editorFirstPersonPose = resolveSavedEditorPose(style, true, false);
        editorThirdPersonOriginal = copy(editorThirdPerson);
        editorFirstPersonOriginal = copy(editorFirstPersonPose);
        editorLinkedThirdPerson = neutral();
        editorLinkedFirstPerson = neutral();
        editorLinkedThirdPersonOriginal = neutral();
        editorLinkedFirstPersonOriginal = neutral();

        editorActive = true;
    }

    public static void endEditor() {
        editorActive = false;
        editorFirstPerson = false;
        editorMode = DefenseAnimationSyncPayload.PARRY;
        editorMainItemId = null;
        editorOffItemId = null;
    }

    public static void setEditorFirstPerson(boolean firstPersonView) {
        if (editorActive) {
            editorFirstPerson = firstPersonView;
        }
    }



    public static void switchEditorStyle(ParryStyle style) {
        if (!editorActive || style == null) {
            return;
        }

        ensureStyleLoaded(style);
        editorStyle = style;
        editorThirdPerson = resolveSavedEditorPose(style, false, false);
        editorFirstPersonPose = resolveSavedEditorPose(style, true, false);
        editorThirdPersonOriginal = copy(editorThirdPerson);
        editorFirstPersonOriginal = copy(editorFirstPersonPose);
    }

    public static ParryStyle getEditorNaturalStyle() {
        return editorNaturalStyle;
    }

    public static void setEditorMode(int mode) {

        if (mode == DefenseAnimationSyncPayload.PARRY
                || mode == DefenseAnimationSyncPayload.BLOCK) {
            editorMode = mode;
        }
    }

    public static AnimationPoseConfig.ArmPose getEditorPose() {
        if (!editorActive) {
            return null;
        }

        DualPoseSet set = activeEditorSet();

        return new AnimationPoseConfig.ArmPose(
                arm(set, editorMode, true),
                arm(set, editorMode, false)
        );
    }

    public static Vec3f getEditorWeaponPosition(boolean mainHand) {
        if (!editorActive) {
            return null;
        }

        return weaponPosition(activeEditorSet(), editorMode, mainHand);
    }

    public static Vec3f getEditorWeaponRotation(boolean mainHand) {
        if (!editorActive) {
            return null;
        }

        return weaponRotation(activeEditorSet(), editorMode, mainHand);
    }

    public static void adjustEditorArm(boolean mainHand, int axis, float delta) {
        if (!editorActive) {
            return;
        }

        DualPoseSet set = activeEditorSet();
        Vec3f updated = adjust(
                arm(set, editorMode, mainHand),
                axis,
                delta,
                -(float) Math.PI,
                (float) Math.PI
        );

        setActiveEditorSet(replaceArm(set, editorMode, mainHand, updated));
    }

    public static void adjustEditorWeaponPosition(boolean mainHand, int axis, float delta) {
        if (!editorActive) {
            return;
        }

        DualPoseSet set = activeEditorSet();
        Vec3f updated = adjust(
                weaponPosition(set, editorMode, mainHand),
                axis,
                delta,
                -4.0F,
                4.0F
        );

        setActiveEditorSet(replaceWeaponPosition(set, editorMode, mainHand, updated));
    }

    public static void adjustEditorWeaponRotation(boolean mainHand, int axis, float delta) {
        if (!editorActive) {
            return;
        }

        DualPoseSet set = activeEditorSet();
        Vec3f updated = adjust(
                weaponRotation(set, editorMode, mainHand),
                axis,
                delta,
                -(float) Math.PI,
                (float) Math.PI
        );

        setActiveEditorSet(replaceWeaponRotation(set, editorMode, mainHand, updated));
    }

    public static void resetEditorArm(boolean mainHand) {
        if (!editorActive) {
            return;
        }

        setActiveEditorSet(
                replaceArm(activeEditorSet(), editorMode, mainHand, zero())
        );
    }

    public static void resetEditorWeapon(boolean mainHand) {
        if (!editorActive) {
            return;
        }

        DualPoseSet set = activeEditorSet();
        set = replaceWeaponPosition(set, editorMode, mainHand, zero());
        set = replaceWeaponRotation(set, editorMode, mainHand, zero());
        setActiveEditorSet(set);
    }

    public static void copyParryToBlock() {
        if (!editorActive) {
            return;
        }

        DualPoseSet source = activeEditorSet();
        setActiveEditorSet(new DualPoseSet(
                copyVec(source.parryMainArm()),
                copyVec(source.parryOffArm()),
                copyVec(source.parryMainWeaponPosition()),
                copyVec(source.parryMainWeaponRotation()),
                copyVec(source.parryOffWeaponPosition()),
                copyVec(source.parryOffWeaponRotation()),

                copyVec(source.parryMainArm()),
                copyVec(source.parryOffArm()),
                copyVec(source.parryMainWeaponPosition()),
                copyVec(source.parryMainWeaponRotation()),
                copyVec(source.parryOffWeaponPosition()),
                copyVec(source.parryOffWeaponRotation())
        ));
    }

    public static void copyBlockToParry() {
        if (!editorActive) {
            return;
        }

        DualPoseSet source = activeEditorSet();
        setActiveEditorSet(new DualPoseSet(
                copyVec(source.blockMainArm()),
                copyVec(source.blockOffArm()),
                copyVec(source.blockMainWeaponPosition()),
                copyVec(source.blockMainWeaponRotation()),
                copyVec(source.blockOffWeaponPosition()),
                copyVec(source.blockOffWeaponRotation()),

                copyVec(source.blockMainArm()),
                copyVec(source.blockOffArm()),
                copyVec(source.blockMainWeaponPosition()),
                copyVec(source.blockMainWeaponRotation()),
                copyVec(source.blockOffWeaponPosition()),
                copyVec(source.blockOffWeaponRotation())
        ));
    }

    /** Copy arm rotations 3P -> 1P; target weapon transforms start neutral. */
    public static void copyThirdPersonToFirstPerson() {
        if (!editorActive) return;
        editorFirstPersonPose = copy(editorThirdPerson);
    }


    /** Copy arm rotations 1P -> 3P; target weapon transforms start neutral. */
    public static void copyFirstPersonToThirdPerson() {
        if (!editorActive) return;
        editorThirdPerson = copy(editorFirstPersonPose);
    }


    public static AnimationPoseConfig.SaveResult copyEditorStanceToClipboard() {
        if (!editorActive) {
            return new AnimationPoseConfig.SaveResult(false, "Dual-wield editor is not active.");
        }

        clipboardThirdPerson = copy(activeThirdEditorSet());
        clipboardFirstPerson = copy(activeFirstEditorSet());
        clipboardSourceStyle = editorStyle;

        return new AnimationPoseConfig.SaveResult(
                true,
                "Copied DUAL " + editorStyle.name() + " stance."
        );
    }

    public static AnimationPoseConfig.SaveResult pasteClipboardIntoEditor() {
        if (!editorActive) {
            return new AnimationPoseConfig.SaveResult(false, "Dual-wield editor is not active.");
        }

        if (!hasStanceClipboard()) {
            return new AnimationPoseConfig.SaveResult(false, "Dual stance clipboard is empty.");
        }

        if (editorViewsLinked) {
            editorLinkedThirdPerson = copy(clipboardThirdPerson);
            editorLinkedFirstPerson = copy(clipboardFirstPerson);
            enforceLinkedSharedArmsFrom(editorFirstPerson);
        } else {
            editorThirdPerson = copy(clipboardThirdPerson);
            editorFirstPersonPose = copy(clipboardFirstPerson);
        }

        return new AnimationPoseConfig.SaveResult(
                true,
                "Pasted DUAL " + clipboardSourceStyle.name()
                        + " into DUAL " + editorStyle.name() + ". Save when ready."
        );
    }

    public static boolean hasStanceClipboard() {
        return clipboardThirdPerson != null
                && clipboardFirstPerson != null
                && clipboardSourceStyle != null;
    }

    public static String getStanceClipboardSourceName() {
        return clipboardSourceStyle == null
                ? "<empty>"
                : "DUAL_" + clipboardSourceStyle.name();
    }


    public static AnimationPoseConfig.SaveResult saveAsDefault() {
        if (!editorActive) {
            return new AnimationPoseConfig.SaveResult(false, "Dual-wield editor is not active.");
        }

        if (editorNaturalStyle == ParryStyle.GENERIC
                || editorStyle != editorNaturalStyle) {
            return new AnimationPoseConfig.SaveResult(
                    false,
                    "Borrowed dual stances cannot be saved as the default. Use Main Weapon or This Pair."
            );
        }

        try {
            DualPoseSet third = copy(activeThirdEditorSet());
            DualPoseSet first = copy(activeFirstEditorSet());

            if (editorViewsLinked) {
                write(getLinkedThirdPersonDefaultPath(editorStyle), third);
                write(getLinkedFirstPersonDefaultPath(editorStyle), first);
                LINKED_THIRD_PERSON.put(editorStyle, copy(third));
                LINKED_FIRST_PERSON.put(editorStyle, copy(first));
                USER_LINKED_THIRD_STYLES.add(editorStyle);
                USER_LINKED_FIRST_STYLES.add(editorStyle);
                editorLinkedThirdPersonOriginal = copy(third);
                editorLinkedFirstPersonOriginal = copy(first);
            } else {
                write(getThirdPersonPath(editorStyle), third);
                write(getFirstPersonPath(editorStyle), first);
                write(getThirdPersonDefaultPath(editorStyle), third);
                write(getFirstPersonDefaultPath(editorStyle), first);
                THIRD_PERSON.put(editorStyle, copy(third));
                FIRST_PERSON.put(editorStyle, copy(first));
                USER_THIRD_STYLES.add(editorStyle);
                USER_FIRST_STYLES.add(editorStyle);
                editorThirdPersonOriginal = copy(third);
                editorFirstPersonOriginal = copy(first);
            }

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Saved " + displayStyle(editorStyle) + " as the default dual-wield stance."
            );

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu dual-wield default stance for {}.",
                    editorStyle,
                    exception
            );
            return new AnimationPoseConfig.SaveResult(false, "Dual-wield save failed. Check latest.log.");
        }
    }

    public static AnimationPoseConfig.SaveResult saveToMainWeapon() {
        if (!editorActive || editorMainItemId == null) {
            return new AnimationPoseConfig.SaveResult(false, "No main weapon is available to save.");
        }

        try {
            DualPoseSet third = copy(activeThirdEditorSet());
            DualPoseSet first = copy(activeFirstEditorSet());

            if (editorViewsLinked) {
                LINKED_MAIN_THIRD_PERSON.put(editorMainItemId, copy(third));
                LINKED_MAIN_FIRST_PERSON.put(editorMainItemId, copy(first));
                LINKED_MAIN_STYLE_ASSIGNMENTS.put(editorMainItemId, editorStyle);
                write(getLinkedMainPosePath(editorMainItemId, false), third);
                write(getLinkedMainPosePath(editorMainItemId, true), first);
                writeMainAssignments(true);
                USER_LINKED_MAIN_THIRD.add(editorMainItemId);
                USER_LINKED_MAIN_FIRST.add(editorMainItemId);
                editorLinkedThirdPersonOriginal = copy(third);
                editorLinkedFirstPersonOriginal = copy(first);
            } else {
                MAIN_THIRD_PERSON.put(editorMainItemId, copy(third));
                MAIN_FIRST_PERSON.put(editorMainItemId, copy(first));
                MAIN_STYLE_ASSIGNMENTS.put(editorMainItemId, editorStyle);
                write(getMainPosePath(editorMainItemId, false), third);
                write(getMainPosePath(editorMainItemId, true), first);
                writeMainAssignments(false);
                USER_MAIN_THIRD.add(editorMainItemId);
                USER_MAIN_FIRST.add(editorMainItemId);
                editorThirdPersonOriginal = copy(third);
                editorFirstPersonOriginal = copy(first);
            }

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Saved this dual stance to the main weapon."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error("Failed to save dual stance to main weapon {}.", editorMainItemId, exception);
            return new AnimationPoseConfig.SaveResult(false, "Main weapon save failed. Check latest.log.");
        }
    }

    public static AnimationPoseConfig.SaveResult saveToThisPair() {
        PairKey pair = editorPairKey();
        if (!editorActive || pair == null) {
            return new AnimationPoseConfig.SaveResult(false, "Two valid held weapons are required for a pair save.");
        }

        try {
            DualPoseSet third = copy(activeThirdEditorSet());
            DualPoseSet first = copy(activeFirstEditorSet());

            if (editorViewsLinked) {
                LINKED_PAIR_THIRD_PERSON.put(pair, copy(third));
                LINKED_PAIR_FIRST_PERSON.put(pair, copy(first));
                LINKED_PAIR_STYLE_ASSIGNMENTS.put(pair, editorStyle);
                write(getLinkedPairPosePath(pair, false), third);
                write(getLinkedPairPosePath(pair, true), first);
                writePairAssignments(true);
                USER_LINKED_PAIR_THIRD.add(pair);
                USER_LINKED_PAIR_FIRST.add(pair);
                editorLinkedThirdPersonOriginal = copy(third);
                editorLinkedFirstPersonOriginal = copy(first);
            } else {
                PAIR_THIRD_PERSON.put(pair, copy(third));
                PAIR_FIRST_PERSON.put(pair, copy(first));
                PAIR_STYLE_ASSIGNMENTS.put(pair, editorStyle);
                write(getPairPosePath(pair, false), third);
                write(getPairPosePath(pair, true), first);
                writePairAssignments(false);
                USER_PAIR_THIRD.add(pair);
                USER_PAIR_FIRST.add(pair);
                editorThirdPersonOriginal = copy(third);
                editorFirstPersonOriginal = copy(first);
            }

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Saved this dual stance only to the current weapon pair."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error("Failed to save dual stance to pair {}.", pair, exception);
            return new AnimationPoseConfig.SaveResult(false, "Pair save failed. Check latest.log.");
        }
    }

    public static boolean hasMainWeaponSave() {
        if (editorMainItemId == null) return false;
        return editorViewsLinked
                ? LINKED_MAIN_STYLE_ASSIGNMENTS.containsKey(editorMainItemId)
                : MAIN_STYLE_ASSIGNMENTS.containsKey(editorMainItemId);
    }

    public static boolean hasPairSave() {
        PairKey pair = editorPairKey();
        if (pair == null) return false;
        return editorViewsLinked
                ? LINKED_PAIR_STYLE_ASSIGNMENTS.containsKey(pair)
                : PAIR_STYLE_ASSIGNMENTS.containsKey(pair);
    }

    public static AnimationPoseConfig.SaveResult clearMainWeaponSave() {
        if (editorMainItemId == null) {
            return new AnimationPoseConfig.SaveResult(false, "No main weapon save is selected.");
        }
        try {
            if (editorViewsLinked) {
                LINKED_MAIN_THIRD_PERSON.remove(editorMainItemId);
                LINKED_MAIN_FIRST_PERSON.remove(editorMainItemId);
                LINKED_MAIN_STYLE_ASSIGNMENTS.remove(editorMainItemId);
                USER_LINKED_MAIN_THIRD.remove(editorMainItemId);
                USER_LINKED_MAIN_FIRST.remove(editorMainItemId);
                Files.deleteIfExists(getLinkedMainPosePath(editorMainItemId, false));
                Files.deleteIfExists(getLinkedMainPosePath(editorMainItemId, true));
                writeMainAssignments(true);
            } else {
                MAIN_THIRD_PERSON.remove(editorMainItemId);
                MAIN_FIRST_PERSON.remove(editorMainItemId);
                MAIN_STYLE_ASSIGNMENTS.remove(editorMainItemId);
                USER_MAIN_THIRD.remove(editorMainItemId);
                USER_MAIN_FIRST.remove(editorMainItemId);
                Files.deleteIfExists(getMainPosePath(editorMainItemId, false));
                Files.deleteIfExists(getMainPosePath(editorMainItemId, true));
                writeMainAssignments(false);
            }
            return new AnimationPoseConfig.SaveResult(true, "Cleared the main weapon dual stance save.");
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error("Failed to clear dual main weapon save {}.", editorMainItemId, exception);
            return new AnimationPoseConfig.SaveResult(false, "Could not clear main weapon save. Check latest.log.");
        }
    }

    public static AnimationPoseConfig.SaveResult clearPairSave() {
        PairKey pair = editorPairKey();
        if (pair == null) {
            return new AnimationPoseConfig.SaveResult(false, "No weapon pair save is selected.");
        }
        try {
            if (editorViewsLinked) {
                LINKED_PAIR_THIRD_PERSON.remove(pair);
                LINKED_PAIR_FIRST_PERSON.remove(pair);
                LINKED_PAIR_STYLE_ASSIGNMENTS.remove(pair);
                USER_LINKED_PAIR_THIRD.remove(pair);
                USER_LINKED_PAIR_FIRST.remove(pair);
                Files.deleteIfExists(getLinkedPairPosePath(pair, false));
                Files.deleteIfExists(getLinkedPairPosePath(pair, true));
                writePairAssignments(true);
            } else {
                PAIR_THIRD_PERSON.remove(pair);
                PAIR_FIRST_PERSON.remove(pair);
                PAIR_STYLE_ASSIGNMENTS.remove(pair);
                USER_PAIR_THIRD.remove(pair);
                USER_PAIR_FIRST.remove(pair);
                Files.deleteIfExists(getPairPosePath(pair, false));
                Files.deleteIfExists(getPairPosePath(pair, true));
                writePairAssignments(false);
            }
            return new AnimationPoseConfig.SaveResult(true, "Cleared this weapon pair's dual stance save.");
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error("Failed to clear dual pair save {}.", pair, exception);
            return new AnimationPoseConfig.SaveResult(false, "Could not clear pair save. Check latest.log.");
        }
    }

    /** Reloads the currently selected style from its highest-priority saved scope. */
    public static AnimationPoseConfig.SaveResult revertToSavedDefault() {
        if (!editorActive) {
            return new AnimationPoseConfig.SaveResult(false, "Dual-wield editor is not active.");
        }

        try {
            if (editorViewsLinked) {
                editorLinkedThirdPerson = resolveSavedEditorPose(editorStyle, false, true);
                editorLinkedFirstPerson = resolveSavedEditorPose(editorStyle, true, true);
                enforceLinkedSharedArmsFrom(editorFirstPerson);
                editorLinkedThirdPersonOriginal = copy(editorLinkedThirdPerson);
                editorLinkedFirstPersonOriginal = copy(editorLinkedFirstPerson);
            } else {
                editorThirdPerson = resolveSavedEditorPose(editorStyle, false, false);
                editorFirstPersonPose = resolveSavedEditorPose(editorStyle, true, false);
                editorThirdPersonOriginal = copy(editorThirdPerson);
                editorFirstPersonOriginal = copy(editorFirstPersonPose);
            }

            return new AnimationPoseConfig.SaveResult(true, "Reverted to the last saved dual-wield stance.");
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error("Failed to revert Gyeokbu dual-wield stance for {}.", editorStyle, exception);
            return new AnimationPoseConfig.SaveResult(false, "Dual-wield revert failed. Check latest.log.");
        }
    }

    /** Loads the immutable Gyeokbu-authored stance bundled in the mod JAR. */
    public static AnimationPoseConfig.SaveResult resetEditorToBundledDefault() {
        if (!editorActive) {
            return new AnimationPoseConfig.SaveResult(
                    false,
                    "Dual-wield editor is not active."
            );
        }

        try {
            DualPoseSet bundled =
                    getBundledEditorDefault(
                            editorFirstPerson
                    );

            if (editorViewsLinked) {
                if (editorFirstPerson) {
                    editorLinkedFirstPerson = copy(bundled);
                } else {
                    editorLinkedThirdPerson = copy(bundled);
                }
                enforceLinkedSharedArmsFrom(editorFirstPerson);
            } else if (editorFirstPerson) {
                editorFirstPersonPose = copy(bundled);
            } else {
                editorThirdPerson = copy(bundled);
            }

            return new AnimationPoseConfig.SaveResult(
                    true,
                    "Loaded official shipped "
                            + displayStyle(editorStyle)
                            + (editorFirstPerson
                            ? " first-person default."
                            : " third-person default.")
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to load official bundled dual-wield default for {}.",
                    editorStyle,
                    exception
            );
            return new AnimationPoseConfig.SaveResult(
                    false,
                    "Dual-wield reset to shipped default failed. Check latest.log."
            );
        }
    }

    private static DualPoseSet getBundledEditorDefault(
            boolean firstPerson
    ) throws IOException {
        String view = firstPerson
                ? "first_person"
                : "third_person";

        PairKey pair = editorPairKey();
        if (pair != null) {
            String pairPath = bundledPairPath(
                    pair,
                    firstPerson,
                    editorViewsLinked
            );
            if (BundledStanceDefaults.has(pairPath)) {
                return readBundled(pairPath);
            }
        }

        if (editorMainItemId != null) {
            String mainPath = bundledMainPath(
                    editorMainItemId,
                    firstPerson,
                    editorViewsLinked
            );
            if (BundledStanceDefaults.has(mainPath)) {
                return readBundled(mainPath);
            }
        }

        if (editorViewsLinked) {
            String linkedStyle =
                    "dual_wield/legacy_linked_views/defaults/"
                            + view
                            + "/"
                            + editorStyle.name().toLowerCase(Locale.ROOT)
                            + ".json";
            if (BundledStanceDefaults.has(linkedStyle)) {
                return readBundled(linkedStyle);
            }
        }

        String stylePath =
                "dual_wield/defaults/"
                        + view
                        + "/"
                        + editorStyle.name().toLowerCase(Locale.ROOT)
                        + ".json";
        if (BundledStanceDefaults.has(stylePath)) {
            return readBundled(stylePath);
        }

        return neutral();
    }

    private static String bundledMainPath(
            ResourceLocation itemId,
            boolean firstPerson,
            boolean linked
    ) {
        return "dual_wield/"
                + (linked ? "legacy_linked_views/" : "")
                + "main_weapon/"
                + (firstPerson ? "first_person/" : "third_person/")
                + itemId.getNamespace()
                + "/"
                + itemId.getPath()
                + ".json";
    }

    private static String bundledPairPath(
            PairKey pair,
            boolean firstPerson,
            boolean linked
    ) {
        return "dual_wield/"
                + (linked ? "legacy_linked_views/" : "")
                + "pairs/"
                + (firstPerson ? "first_person/" : "third_person/")
                + pair.main().getNamespace()
                + "/"
                + pair.main().getPath()
                + "/"
                + pair.off().getNamespace()
                + "/"
                + pair.off().getPath()
                + ".json";
    }

    public static boolean hasUnsavedEditorChanges() {
        if (!editorActive) return false;
        if (editorViewsLinked) {
            return !poseSetsEqual(editorLinkedThirdPerson, editorLinkedThirdPersonOriginal)
                    || !poseSetsEqual(editorLinkedFirstPerson, editorLinkedFirstPersonOriginal);
        }
        return !poseSetsEqual(editorThirdPerson, editorThirdPersonOriginal)
                || !poseSetsEqual(editorFirstPersonPose, editorFirstPersonOriginal);
    }

    /** Success-animation editor lookup for one per-mainhand dual stance. */
    public static float getVisualValueForStyle(
            ParryStyle style,
            int mode,
            boolean firstPerson,
            SuccessAnimationChannel channel
    ) {
        ensureStyleLoaded(style);
        DualPoseSet set = firstPerson ? FIRST_PERSON.get(style) : THIRD_PERSON.get(style);
        if (set == null) return 0.0F;
        Vec3f mainArm = arm(set, mode, true);
        Vec3f offArm = arm(set, mode, false);
        boolean mainWeapon = channel.group() != SuccessAnimationChannel.Group.OFF_WEAPON;
        Vec3f pos = weaponPosition(set, mode, mainWeapon);
        Vec3f rot = weaponRotation(set, mode, mainWeapon);
        return switch (channel) {
            case MAIN_ARM_X -> mainArm.getX(); case MAIN_ARM_Y -> mainArm.getY(); case MAIN_ARM_Z -> mainArm.getZ();
            case OFF_ARM_X -> offArm.getX(); case OFF_ARM_Y -> offArm.getY(); case OFF_ARM_Z -> offArm.getZ();
            case MAIN_WEAPON_POS_X, OFF_WEAPON_POS_X -> pos.getX();
            case MAIN_WEAPON_POS_Y, OFF_WEAPON_POS_Y -> pos.getY();
            case MAIN_WEAPON_POS_Z, OFF_WEAPON_POS_Z -> pos.getZ();
            case MAIN_WEAPON_ROT_X, OFF_WEAPON_ROT_X -> rot.getX();
            case MAIN_WEAPON_ROT_Y, OFF_WEAPON_ROT_Y -> rot.getY();
            case MAIN_WEAPON_ROT_Z, OFF_WEAPON_ROT_Z -> rot.getZ();
        };
    }

    public static AnimationPoseConfig.ArmPose getRuntimePose(
            AbstractClientPlayer player,
            int mode,
            boolean firstPersonView
    ) {
        DualPoseSet set = resolveRuntimePose(player, firstPersonView);
        return new AnimationPoseConfig.ArmPose(
                arm(set, mode, true),
                arm(set, mode, false)
        );
    }

    public static Vec3f getWeaponPositionFor(
            LivingEntity entity,
            HumanoidArm arm
    ) {
        if (!(entity instanceof AbstractClientPlayer player)) {
            return null;
        }

        Minecraft minecraft = Minecraft.getInstance();
        boolean mainHand = arm == player.getMainArm();

        if (editorActive && minecraft.player == player) {
            return getEditorWeaponPosition(mainHand);
        }

        if (!DualWieldRules.isDualWield(player)) {
            return null;
        }

        boolean localFirstPerson = minecraft.player == player
                && minecraft.options.getCameraType() == CameraType.FIRST_PERSON;

        int mode = localFirstPerson
                ? ClientCombatSyncState.getFirstPersonDefenseVisualMode(player.getId())
                : ClientCombatSyncState.getDefenseAnimationMode(player.getId());

        if (!DefensePoseTransitionRuntime.isVisualActive(
                player,
                localFirstPerson,
                mode
        )) {
            return null;
        }

        Vec3f target = zero();

        if (mode == DefenseAnimationSyncPayload.PARRY
                || mode == DefenseAnimationSyncPayload.BLOCK) {

            target = weaponPosition(
                    resolveRuntimePose(player, localFirstPerson),
                    mode,
                    mainHand
            );
        }

        return DefensePoseTransitionRuntime.sample(
                player,
                localFirstPerson,
                mainHand
                        ? DefensePoseTransitionRuntime.MAIN_WEAPON_POSITION
                        : DefensePoseTransitionRuntime.OFF_WEAPON_POSITION,
                mode,
                target,
                zero()
        );
    }

    public static Vec3f getWeaponRotationFor(
            LivingEntity entity,
            HumanoidArm arm
    ) {
        if (!(entity instanceof AbstractClientPlayer player)) {
            return null;
        }

        Minecraft minecraft = Minecraft.getInstance();
        boolean mainHand = arm == player.getMainArm();

        if (editorActive && minecraft.player == player) {
            return getEditorWeaponRotation(mainHand);
        }

        if (!DualWieldRules.isDualWield(player)) {
            return null;
        }

        boolean localFirstPerson = minecraft.player == player
                && minecraft.options.getCameraType() == CameraType.FIRST_PERSON;

        int mode = localFirstPerson
                ? ClientCombatSyncState.getFirstPersonDefenseVisualMode(player.getId())
                : ClientCombatSyncState.getDefenseAnimationMode(player.getId());

        if (!DefensePoseTransitionRuntime.isVisualActive(
                player,
                localFirstPerson,
                mode
        )) {
            return null;
        }

        Vec3f target = zero();

        if (mode == DefenseAnimationSyncPayload.PARRY
                || mode == DefenseAnimationSyncPayload.BLOCK) {

            target = weaponRotation(
                    resolveRuntimePose(player, localFirstPerson),
                    mode,
                    mainHand
            );
        }

        return DefensePoseTransitionRuntime.sample(
                player,
                localFirstPerson,
                mainHand
                        ? DefensePoseTransitionRuntime.MAIN_WEAPON_ROTATION
                        : DefensePoseTransitionRuntime.OFF_WEAPON_ROTATION,
                mode,
                target,
                zero()
        );
    }

    public static Path getDirectory() {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("dual_wield");
    }

    public static List<ParryStyle> getAvailableDualStyles() {
        List<ParryStyle> cached = AVAILABLE_DUAL_STYLES;
        if (cached != null) return cached;

        List<ParryStyle> result = new ArrayList<>();
        for (ParryStyle candidate : ParryStyle.values()) {
            if (candidate == ParryStyle.GENERIC) continue;
            boolean found = false;
            for (var item : BuiltInRegistries.ITEM) {
                WeaponProfile profile = WeaponClassifier.classifyNatural(item);
                if (profile.isSupported()
                        && !profile.isTwoHanded()
                        && profile.parryStyle() == candidate) {
                    found = true;
                    break;
                }
            }
            if (found) result.add(candidate);
        }
        AVAILABLE_DUAL_STYLES = List.copyOf(result);
        return AVAILABLE_DUAL_STYLES;
    }

    private static boolean isDualStyleAvailable(ParryStyle style) {
        return style != null && getAvailableDualStyles().contains(style);
    }

    public static ParryStyle getAssignedStyleForCurrentLoadout() {
        return resolveNormalAssignedStyle(editorMainItemId, editorOffItemId, editorNaturalStyle);
    }

    private static DualPoseSet activeThirdEditorSet() {
        return editorViewsLinked ? editorLinkedThirdPerson : editorThirdPerson;
    }

    private static DualPoseSet activeFirstEditorSet() {
        return editorViewsLinked ? editorLinkedFirstPerson : editorFirstPersonPose;
    }

    private static DualPoseSet resolveSavedEditorPose(
            ParryStyle style,
            boolean firstPerson,
            boolean linked
    ) {
        ensureStyleLoaded(style);
        PairKey pair = editorPairKey();

        DualPoseSet userPose = resolvePoseLayer(
                style,
                editorMainItemId,
                pair,
                firstPerson,
                linked,
                true
        );
        if (userPose != null) {
            return copy(userPose);
        }

        DualPoseSet shippedPose = resolvePoseLayer(
                style,
                editorMainItemId,
                pair,
                firstPerson,
                linked,
                false
        );
        if (shippedPose != null) {
            return copy(shippedPose);
        }

        if (linked) {
            return copy(firstPerson ? editorFirstPersonPose : editorThirdPerson);
        }

        return neutral();
    }

    private static void prepareLinkedEditorWorkspace(ParryStyle style) {
        DualPoseSet third = resolveSavedEditorPose(style, false, true);
        DualPoseSet first = resolveSavedEditorPose(style, true, true);

        boolean hasSaved = hasLinkedSavedPose(style);
        if (!hasSaved) {
            third = copy(editorThirdPerson);
            first = copy(editorFirstPersonPose);
        }

        editorLinkedThirdPerson = third;
        editorLinkedFirstPerson = first;
        enforceLinkedSharedArmsFrom(editorFirstPerson);
        editorLinkedThirdPersonOriginal = copy(editorLinkedThirdPerson);
        editorLinkedFirstPersonOriginal = copy(editorLinkedFirstPerson);
    }

    private static boolean hasLinkedSavedPose(ParryStyle style) {
        PairKey pair = editorPairKey();
        if (pair != null
                && LINKED_PAIR_STYLE_ASSIGNMENTS.get(pair) == style
                && (LINKED_PAIR_THIRD_PERSON.containsKey(pair)
                || LINKED_PAIR_FIRST_PERSON.containsKey(pair))) {
            return true;
        }
        if (editorMainItemId != null
                && LINKED_MAIN_STYLE_ASSIGNMENTS.get(editorMainItemId) == style
                && (LINKED_MAIN_THIRD_PERSON.containsKey(editorMainItemId)
                || LINKED_MAIN_FIRST_PERSON.containsKey(editorMainItemId))) {
            return true;
        }
        return LINKED_THIRD_PERSON.containsKey(style) || LINKED_FIRST_PERSON.containsKey(style);
    }

    private static void enforceLinkedSharedArmsFrom(boolean firstPersonSource) {
        DualPoseSet source = firstPersonSource ? editorLinkedFirstPerson : editorLinkedThirdPerson;
        DualPoseSet target = firstPersonSource ? editorLinkedThirdPerson : editorLinkedFirstPerson;
        DualPoseSet mirrored = new DualPoseSet(
                copyVec(source.parryMainArm()), copyVec(source.parryOffArm()),
                copyVec(target.parryMainWeaponPosition()), copyVec(target.parryMainWeaponRotation()),
                copyVec(target.parryOffWeaponPosition()), copyVec(target.parryOffWeaponRotation()),
                copyVec(source.blockMainArm()), copyVec(source.blockOffArm()),
                copyVec(target.blockMainWeaponPosition()), copyVec(target.blockMainWeaponRotation()),
                copyVec(target.blockOffWeaponPosition()), copyVec(target.blockOffWeaponRotation())
        );
        if (firstPersonSource) editorLinkedThirdPerson = mirrored;
        else editorLinkedFirstPerson = mirrored;
    }

    private static DualPoseSet resolveRuntimePose(AbstractClientPlayer player, boolean firstPerson) {
        ResourceLocation mainId = itemId(player.getMainHandItem());
        ResourceLocation offId = itemId(player.getOffhandItem());
        PairKey pair = pairKey(mainId, offId);
        ParryStyle natural = getMainhandStyle(player);
        ParryStyle style = resolveActiveAssignedStyle(mainId, offId, natural);
        ensureStyleLoaded(style);

        /* Linked Views was retired; runtime uses only the normal hierarchy. */
        DualPoseSet pose = resolvePoseLayer(
                style, mainId, pair, firstPerson, false, true
        );
        if (pose != null) return pose;

        return resolvePoseLayer(
                style, mainId, pair, firstPerson, false, false
        );
    }

    private static DualPoseSet resolvePoseLayer(
            ParryStyle style,
            ResourceLocation mainId,
            PairKey pair,
            boolean firstPerson,
            boolean linked,
            boolean userOnly
    ) {
        Map<PairKey, ParryStyle> pairAssignments = linked
                ? LINKED_PAIR_STYLE_ASSIGNMENTS : PAIR_STYLE_ASSIGNMENTS;
        Map<ResourceLocation, ParryStyle> mainAssignments = linked
                ? LINKED_MAIN_STYLE_ASSIGNMENTS : MAIN_STYLE_ASSIGNMENTS;
        Map<PairKey, DualPoseSet> pairPoses = linked
                ? (firstPerson ? LINKED_PAIR_FIRST_PERSON : LINKED_PAIR_THIRD_PERSON)
                : (firstPerson ? PAIR_FIRST_PERSON : PAIR_THIRD_PERSON);
        Map<ResourceLocation, DualPoseSet> mainPoses = linked
                ? (firstPerson ? LINKED_MAIN_FIRST_PERSON : LINKED_MAIN_THIRD_PERSON)
                : (firstPerson ? MAIN_FIRST_PERSON : MAIN_THIRD_PERSON);
        Map<ParryStyle, DualPoseSet> stylePoses = linked
                ? (firstPerson ? LINKED_FIRST_PERSON : LINKED_THIRD_PERSON)
                : (firstPerson ? FIRST_PERSON : THIRD_PERSON);

        Set<PairKey> userPairs = linked
                ? (firstPerson ? USER_LINKED_PAIR_FIRST : USER_LINKED_PAIR_THIRD)
                : (firstPerson ? USER_PAIR_FIRST : USER_PAIR_THIRD);
        Set<ResourceLocation> userMains = linked
                ? (firstPerson ? USER_LINKED_MAIN_FIRST : USER_LINKED_MAIN_THIRD)
                : (firstPerson ? USER_MAIN_FIRST : USER_MAIN_THIRD);
        Set<ParryStyle> userStyles = linked
                ? (firstPerson ? USER_LINKED_FIRST_STYLES : USER_LINKED_THIRD_STYLES)
                : (firstPerson ? USER_FIRST_STYLES : USER_THIRD_STYLES);

        if (pair != null
                && availableAssignment(pairAssignments.get(pair)) == style
                && userPairs.contains(pair) == userOnly) {
            DualPoseSet pose = pairPoses.get(pair);
            if (pose != null) return pose;
        }

        if (mainId != null
                && availableAssignment(mainAssignments.get(mainId)) == style
                && userMains.contains(mainId) == userOnly) {
            DualPoseSet pose = mainPoses.get(mainId);
            if (pose != null) return pose;
        }

        if (userStyles.contains(style) == userOnly) {
            return stylePoses.get(style);
        }

        return null;
    }

    private static ParryStyle resolveActiveAssignedStyle(
            ResourceLocation mainId,
            ResourceLocation offId,
            ParryStyle natural
    ) {
        PairKey pair = pairKey(mainId, offId);
        if (pair != null) {
            ParryStyle normal = availableAssignment(PAIR_STYLE_ASSIGNMENTS.get(pair));
            if (normal != null) return normal;
        }
        if (mainId != null) {
            ParryStyle normal = availableAssignment(MAIN_STYLE_ASSIGNMENTS.get(mainId));
            if (normal != null) return normal;
        }
        return natural == null ? ParryStyle.GENERIC : natural;
    }

    private static ParryStyle availableAssignment(ParryStyle style) {
        return style != null && isDualStyleAvailable(style) ? style : null;
    }

    private static ParryStyle resolveNormalAssignedStyle(
            ResourceLocation mainId,
            ResourceLocation offId,
            ParryStyle natural
    ) {
        PairKey pair = pairKey(mainId, offId);
        ParryStyle style = pair == null ? null : PAIR_STYLE_ASSIGNMENTS.get(pair);
        if (style != null && !isDualStyleAvailable(style)) style = null;
        if (style == null && mainId != null) {
            style = MAIN_STYLE_ASSIGNMENTS.get(mainId);
            if (style != null && !isDualStyleAvailable(style)) style = null;
        }
        if (style == null) style = natural == null ? ParryStyle.GENERIC : natural;
        return style;
    }

    private static ParryStyle resolveLinkedAssignedStyle(
            ResourceLocation mainId,
            ResourceLocation offId,
            ParryStyle fallback
    ) {
        PairKey pair = pairKey(mainId, offId);
        ParryStyle style = pair == null ? null : LINKED_PAIR_STYLE_ASSIGNMENTS.get(pair);
        if (style != null && !isDualStyleAvailable(style)) style = null;
        if (style == null && mainId != null) {
            style = LINKED_MAIN_STYLE_ASSIGNMENTS.get(mainId);
            if (style != null && !isDualStyleAvailable(style)) style = null;
        }
        return style == null ? fallback : style;
    }

    private static ResourceLocation itemId(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return null;
        return BuiltInRegistries.ITEM.getKey(stack.getItem());
    }

    private static PairKey editorPairKey() {
        return pairKey(editorMainItemId, editorOffItemId);
    }

    private static PairKey pairKey(ResourceLocation mainId, ResourceLocation offId) {
        return mainId == null || offId == null ? null : new PairKey(mainId, offId);
    }

    private static String displayStyle(ParryStyle style) {
        if (style == null) return "Fallback";
        String[] words = style.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder out = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (!out.isEmpty()) out.append(' ');
            out.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return out.toString();
    }

    private static boolean poseSetsEqual(DualPoseSet a, DualPoseSet b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        return vecEqual(a.parryMainArm(), b.parryMainArm())
                && vecEqual(a.parryOffArm(), b.parryOffArm())
                && vecEqual(a.parryMainWeaponPosition(), b.parryMainWeaponPosition())
                && vecEqual(a.parryMainWeaponRotation(), b.parryMainWeaponRotation())
                && vecEqual(a.parryOffWeaponPosition(), b.parryOffWeaponPosition())
                && vecEqual(a.parryOffWeaponRotation(), b.parryOffWeaponRotation())
                && vecEqual(a.blockMainArm(), b.blockMainArm())
                && vecEqual(a.blockOffArm(), b.blockOffArm())
                && vecEqual(a.blockMainWeaponPosition(), b.blockMainWeaponPosition())
                && vecEqual(a.blockMainWeaponRotation(), b.blockMainWeaponRotation())
                && vecEqual(a.blockOffWeaponPosition(), b.blockOffWeaponPosition())
                && vecEqual(a.blockOffWeaponRotation(), b.blockOffWeaponRotation());
    }

    private static boolean vecEqual(Vec3f a, Vec3f b) {
        return a != null && b != null
                && Float.compare(a.getX(), b.getX()) == 0
                && Float.compare(a.getY(), b.getY()) == 0
                && Float.compare(a.getZ(), b.getZ()) == 0;
    }

    private static String dualStyleRelativePath(
            ParryStyle style,
            boolean firstPerson,
            boolean linked
    ) {
        String view = firstPerson ? "first_person" : "third_person";
        String file = style.name().toLowerCase(Locale.ROOT) + ".json";
        return linked
                ? "dual_wield/legacy_linked_views/defaults/" + view + "/" + file
                : "dual_wield/" + view + "/" + file;
    }

    private static Path getMainPosePath(ResourceLocation itemId, boolean firstPerson) {
        return getDirectory().resolve("main_weapon")
                .resolve(firstPerson ? "first_person" : "third_person")
                .resolve(itemId.getNamespace()).resolve(itemId.getPath() + ".json");
    }

    private static Path getPairPosePath(PairKey pair, boolean firstPerson) {
        return getDirectory().resolve("pairs")
                .resolve(firstPerson ? "first_person" : "third_person")
                .resolve(pair.main().getNamespace()).resolve(pair.main().getPath())
                .resolve(pair.off().getNamespace()).resolve(pair.off().getPath() + ".json");
    }

    private static Path getLinkedDirectory() {
        return getDirectory().resolve("legacy_linked_views");
    }

    private static Path getLinkedThirdPersonDefaultPath(ParryStyle style) {
        return getLinkedDirectory().resolve("defaults/third_person")
                .resolve(style.name().toLowerCase(Locale.ROOT) + ".json");
    }

    private static Path getLinkedFirstPersonDefaultPath(ParryStyle style) {
        return getLinkedDirectory().resolve("defaults/first_person")
                .resolve(style.name().toLowerCase(Locale.ROOT) + ".json");
    }

    private static Path getLinkedMainPosePath(ResourceLocation itemId, boolean firstPerson) {
        return getLinkedDirectory().resolve("main_weapon")
                .resolve(firstPerson ? "first_person" : "third_person")
                .resolve(itemId.getNamespace()).resolve(itemId.getPath() + ".json");
    }

    private static Path getLinkedPairPosePath(PairKey pair, boolean firstPerson) {
        return getLinkedDirectory().resolve("pairs")
                .resolve(firstPerson ? "first_person" : "third_person")
                .resolve(pair.main().getNamespace()).resolve(pair.main().getPath())
                .resolve(pair.off().getNamespace()).resolve(pair.off().getPath() + ".json");
    }

    private static Path getMainAssignmentsPath(boolean linked) {
        return (linked ? getLinkedDirectory() : getDirectory()).resolve("main_weapon_assignments.json");
    }

    private static Path getPairAssignmentsPath(boolean linked) {
        return (linked ? getLinkedDirectory() : getDirectory()).resolve("pair_stance_assignments.json");
    }

    private static Path getLinkedViewStatesPath() {
        return getLinkedDirectory().resolve("view_states.json");
    }

    private static void loadOverrideIndexes(boolean linked) throws IOException {
        Map<ResourceLocation, ParryStyle> mainAssignments = linked
                ? LINKED_MAIN_STYLE_ASSIGNMENTS : MAIN_STYLE_ASSIGNMENTS;
        Map<PairKey, ParryStyle> pairAssignments = linked
                ? LINKED_PAIR_STYLE_ASSIGNMENTS : PAIR_STYLE_ASSIGNMENTS;
        Map<ResourceLocation, DualPoseSet> mainThird = linked
                ? LINKED_MAIN_THIRD_PERSON : MAIN_THIRD_PERSON;
        Map<ResourceLocation, DualPoseSet> mainFirst = linked
                ? LINKED_MAIN_FIRST_PERSON : MAIN_FIRST_PERSON;
        Map<PairKey, DualPoseSet> pairThird = linked
                ? LINKED_PAIR_THIRD_PERSON : PAIR_THIRD_PERSON;
        Map<PairKey, DualPoseSet> pairFirst = linked
                ? LINKED_PAIR_FIRST_PERSON : PAIR_FIRST_PERSON;

        Path mainPath = getMainAssignmentsPath(linked);
        if (Files.exists(mainPath)) {
            JsonObject root = JsonParser.parseString(Files.readString(mainPath, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
                try {
                    ResourceLocation id = ResourceLocation.parse(entry.getKey());
                    if (!BuiltInRegistries.ITEM.containsKey(id)) continue;
                    ParryStyle style = ParryStyle.valueOf(entry.getValue().getAsString());
                    boolean assignmentUser = isUserAssignment(
                            linked
                                    ? "dual_wield/legacy_linked_views/main_weapon_assignments.json"
                                    : "dual_wield/main_weapon_assignments.json",
                            id.toString(),
                            style.name()
                    );
                    mainAssignments.put(id, style);
                    Path thirdPath = linked ? getLinkedMainPosePath(id, false) : getMainPosePath(id, false);
                    Path firstPath = linked ? getLinkedMainPosePath(id, true) : getMainPosePath(id, true);
                    if (Files.exists(thirdPath)) {
                        mainThird.put(id, read(thirdPath));
                        if (assignmentUser || BundledStanceDefaults.isUserOverride(
                                thirdPath, bundledMainPath(id, false, linked))) {
                            (linked ? USER_LINKED_MAIN_THIRD : USER_MAIN_THIRD).add(id);
                        }
                    }
                    if (Files.exists(firstPath)) {
                        mainFirst.put(id, read(firstPath));
                        if (assignmentUser || BundledStanceDefaults.isUserOverride(
                                firstPath, bundledMainPath(id, true, linked))) {
                            (linked ? USER_LINKED_MAIN_FIRST : USER_MAIN_FIRST).add(id);
                        }
                    }
                } catch (Exception ignored) { }
            }
        }

        Path pairPath = getPairAssignmentsPath(linked);
        if (Files.exists(pairPath)) {
            JsonObject root = JsonParser.parseString(Files.readString(pairPath, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
                try {
                    PairKey pair = PairKey.parse(entry.getKey());
                    if (pair == null
                            || !BuiltInRegistries.ITEM.containsKey(pair.main())
                            || !BuiltInRegistries.ITEM.containsKey(pair.off())) continue;
                    ParryStyle style = ParryStyle.valueOf(entry.getValue().getAsString());
                    boolean assignmentUser = isUserAssignment(
                            linked
                                    ? "dual_wield/legacy_linked_views/pair_stance_assignments.json"
                                    : "dual_wield/pair_stance_assignments.json",
                            pair.serialized(),
                            style.name()
                    );
                    pairAssignments.put(pair, style);
                    Path thirdPath = linked ? getLinkedPairPosePath(pair, false) : getPairPosePath(pair, false);
                    Path firstPath = linked ? getLinkedPairPosePath(pair, true) : getPairPosePath(pair, true);
                    if (Files.exists(thirdPath)) {
                        pairThird.put(pair, read(thirdPath));
                        if (assignmentUser || BundledStanceDefaults.isUserOverride(
                                thirdPath, bundledPairPath(pair, false, linked))) {
                            (linked ? USER_LINKED_PAIR_THIRD : USER_PAIR_THIRD).add(pair);
                        }
                    }
                    if (Files.exists(firstPath)) {
                        pairFirst.put(pair, read(firstPath));
                        if (assignmentUser || BundledStanceDefaults.isUserOverride(
                                firstPath, bundledPairPath(pair, true, linked))) {
                            (linked ? USER_LINKED_PAIR_FIRST : USER_PAIR_FIRST).add(pair);
                        }
                    }
                } catch (Exception ignored) { }
            }
        }

        if (linked) {
            for (ParryStyle style : ParryStyle.values()) {
                Path third = getLinkedThirdPersonDefaultPath(style);
                Path first = getLinkedFirstPersonDefaultPath(style);
                if (Files.exists(third)) {
                    LINKED_THIRD_PERSON.put(style, read(third));
                    if (BundledStanceDefaults.isUserOverride(
                            third, dualStyleRelativePath(style, false, true))) {
                        USER_LINKED_THIRD_STYLES.add(style);
                    }
                }
                if (Files.exists(first)) {
                    LINKED_FIRST_PERSON.put(style, read(first));
                    if (BundledStanceDefaults.isUserOverride(
                            first, dualStyleRelativePath(style, true, true))) {
                        USER_LINKED_FIRST_STYLES.add(style);
                    }
                }
            }
        }
    }

    private static boolean isUserAssignment(
            String bundledRelativePath,
            String key,
            String value
    ) throws IOException {
        if (!BundledStanceDefaults.has(bundledRelativePath)) {
            return true;
        }

        JsonObject bundled = JsonParser.parseString(
                BundledStanceDefaults.readText(bundledRelativePath)
        ).getAsJsonObject();

        return !bundled.has(key)
                || !value.equals(bundled.get(key).getAsString());
    }

    private static void writeMainAssignments(boolean linked) throws IOException {
        JsonObject root = new JsonObject();
        Map<ResourceLocation, ParryStyle> map = linked ? LINKED_MAIN_STYLE_ASSIGNMENTS : MAIN_STYLE_ASSIGNMENTS;
        for (Map.Entry<ResourceLocation, ParryStyle> entry : map.entrySet()) {
            root.addProperty(entry.getKey().toString(), entry.getValue().name());
        }
        Path path = getMainAssignmentsPath(linked);
        Files.createDirectories(path.getParent());
        Files.writeString(path, root.toString(), StandardCharsets.UTF_8);
    }

    private static void writePairAssignments(boolean linked) throws IOException {
        JsonObject root = new JsonObject();
        Map<PairKey, ParryStyle> map = linked ? LINKED_PAIR_STYLE_ASSIGNMENTS : PAIR_STYLE_ASSIGNMENTS;
        for (Map.Entry<PairKey, ParryStyle> entry : map.entrySet()) {
            root.addProperty(entry.getKey().serialized(), entry.getValue().name());
        }
        Path path = getPairAssignmentsPath(linked);
        Files.createDirectories(path.getParent());
        Files.writeString(path, root.toString(), StandardCharsets.UTF_8);
    }

    private static void loadLinkedViewStates() throws IOException {
        Path path = getLinkedViewStatesPath();
        if (!Files.exists(path)) return;
        JsonObject root = JsonParser.parseString(Files.readString(path, StandardCharsets.UTF_8)).getAsJsonObject();
        for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
            try {
                LINKED_VIEW_STATES.put(ParryStyle.valueOf(entry.getKey()), entry.getValue().getAsBoolean());
            } catch (Exception ignored) { }
        }
    }

    private static void setLinkedViewState(ParryStyle style, boolean linked) {
        if (style == null) return;
        LINKED_VIEW_STATES.put(style, linked);
        try {
            JsonObject root = new JsonObject();
            for (Map.Entry<ParryStyle, Boolean> entry : LINKED_VIEW_STATES.entrySet()) {
                root.addProperty(entry.getKey().name(), Boolean.TRUE.equals(entry.getValue()));
            }
            Path path = getLinkedViewStatesPath();
            Files.createDirectories(path.getParent());
            Files.writeString(path, root.toString(), StandardCharsets.UTF_8);
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error("Failed to save dual-wield legacy linked-workspace mode state.", exception);
        }
    }

    private static ParryStyle getMainhandStyle(AbstractClientPlayer player) {
        return WeaponClassifier.classifyNatural(player.getMainHandItem()).parryStyle();
    }

    private static void ensureStyleLoaded(ParryStyle style) {
        if (THIRD_PERSON.containsKey(style)
                && FIRST_PERSON.containsKey(style)) {
            return;
        }

        try {
            Files.createDirectories(getDirectory());

            Path thirdPath = getThirdPersonPath(style);
            Path firstPath = getFirstPersonPath(style);
            Path thirdDefault = getThirdPersonDefaultPath(style);
            Path firstDefault = getFirstPersonDefaultPath(style);

            DualPoseSet third = loadStartingPose(
                    thirdPath,
                    thirdDefault,
                    getLegacyThirdPersonPath()
            );

            DualPoseSet first = loadStartingPose(
                    firstPath,
                    firstDefault,
                    getLegacyFirstPersonPath()
            );

            if (!Files.exists(thirdPath)) {
                write(thirdPath, third);
            }
            if (!Files.exists(firstPath)) {
                write(firstPath, first);
            }
            if (!Files.exists(thirdDefault)) {
                write(thirdDefault, third);
            }
            if (!Files.exists(firstDefault)) {
                write(firstDefault, first);
            }

            THIRD_PERSON.put(style, copy(third));
            FIRST_PERSON.put(style, copy(first));

            if (BundledStanceDefaults.isUserOverride(
                    thirdPath, dualStyleRelativePath(style, false, false))) {
                USER_THIRD_STYLES.add(style);
            }
            if (BundledStanceDefaults.isUserOverride(
                    firstPath, dualStyleRelativePath(style, true, false))) {
                USER_FIRST_STYLES.add(style);
            }

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to load Gyeokbu dual-wield stance for {}.",
                    style,
                    exception
            );

            THIRD_PERSON.put(style, neutral());
            FIRST_PERSON.put(style, neutral());
        }
    }

    private static DualPoseSet loadStartingPose(
            Path active,
            Path savedDefault,
            Path legacy
    ) throws IOException {
        if (Files.exists(active)) {
            return read(active);
        }
        if (Files.exists(savedDefault)) {
            return read(savedDefault);
        }
        if (Files.exists(legacy)) {
            return read(legacy);
        }
        return neutral();
    }

    private static Path getThirdPersonPath(ParryStyle style) {
        return getDirectory()
                .resolve("third_person")
                .resolve(style.name().toLowerCase() + ".json");
    }

    private static Path getFirstPersonPath(ParryStyle style) {
        return getDirectory()
                .resolve("first_person")
                .resolve(style.name().toLowerCase() + ".json");
    }

    private static Path getThirdPersonDefaultPath(ParryStyle style) {
        return getDirectory()
                .resolve("defaults")
                .resolve("third_person")
                .resolve(style.name().toLowerCase() + ".json");
    }

    private static Path getFirstPersonDefaultPath(ParryStyle style) {
        return getDirectory()
                .resolve("defaults")
                .resolve("first_person")
                .resolve(style.name().toLowerCase() + ".json");
    }

    private static Path getLegacyThirdPersonPath() {
        return getDirectory().resolve("third_person.json");
    }

    private static Path getLegacyFirstPersonPath() {
        return getDirectory().resolve("first_person.json");
    }

    private static DualPoseSet activeEditorSet() {
        if (editorViewsLinked) {
            return editorFirstPerson ? editorLinkedFirstPerson : editorLinkedThirdPerson;
        }
        return editorFirstPerson ? editorFirstPersonPose : editorThirdPerson;
    }

    private static void setActiveEditorSet(DualPoseSet set) {
        if (editorViewsLinked) {
            if (editorFirstPerson) {
                editorLinkedFirstPerson = set;
            } else {
                editorLinkedThirdPerson = set;
            }
            mirrorLinkedArmsFromActiveView();
            return;
        }

        if (editorFirstPerson) {
            editorFirstPersonPose = set;
        } else {
            editorThirdPerson = set;
        }
    }

    private static void mirrorLinkedArmsFromActiveView() {
        if (!editorViewsLinked) {
            return;
        }

        DualPoseSet source = editorFirstPerson
                ? editorLinkedFirstPerson
                : editorLinkedThirdPerson;
        DualPoseSet target = editorFirstPerson
                ? editorLinkedThirdPerson
                : editorLinkedFirstPerson;

        DualPoseSet mirrored = new DualPoseSet(
                copyVec(source.parryMainArm()),
                copyVec(source.parryOffArm()),
                copyVec(target.parryMainWeaponPosition()),
                copyVec(target.parryMainWeaponRotation()),
                copyVec(target.parryOffWeaponPosition()),
                copyVec(target.parryOffWeaponRotation()),
                copyVec(source.blockMainArm()),
                copyVec(source.blockOffArm()),
                copyVec(target.blockMainWeaponPosition()),
                copyVec(target.blockMainWeaponRotation()),
                copyVec(target.blockOffWeaponPosition()),
                copyVec(target.blockOffWeaponRotation())
        );

        if (editorFirstPerson) {
            editorLinkedThirdPerson = mirrored;
        } else {
            editorLinkedFirstPerson = mirrored;
        }
    }

    private static Vec3f arm(DualPoseSet set, int mode, boolean mainHand) {
        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return mainHand ? set.blockMainArm() : set.blockOffArm();
        }
        return mainHand ? set.parryMainArm() : set.parryOffArm();
    }

    private static Vec3f weaponPosition(DualPoseSet set, int mode, boolean mainHand) {
        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return mainHand
                    ? set.blockMainWeaponPosition()
                    : set.blockOffWeaponPosition();
        }
        return mainHand
                ? set.parryMainWeaponPosition()
                : set.parryOffWeaponPosition();
    }

    private static Vec3f weaponRotation(DualPoseSet set, int mode, boolean mainHand) {
        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return mainHand
                    ? set.blockMainWeaponRotation()
                    : set.blockOffWeaponRotation();
        }
        return mainHand
                ? set.parryMainWeaponRotation()
                : set.parryOffWeaponRotation();
    }

    private static DualPoseSet replaceArm(
            DualPoseSet set,
            int mode,
            boolean mainHand,
            Vec3f value
    ) {
        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return new DualPoseSet(
                    set.parryMainArm(), set.parryOffArm(),
                    set.parryMainWeaponPosition(), set.parryMainWeaponRotation(),
                    set.parryOffWeaponPosition(), set.parryOffWeaponRotation(),
                    mainHand ? value : set.blockMainArm(),
                    mainHand ? set.blockOffArm() : value,
                    set.blockMainWeaponPosition(), set.blockMainWeaponRotation(),
                    set.blockOffWeaponPosition(), set.blockOffWeaponRotation()
            );
        }

        return new DualPoseSet(
                mainHand ? value : set.parryMainArm(),
                mainHand ? set.parryOffArm() : value,
                set.parryMainWeaponPosition(), set.parryMainWeaponRotation(),
                set.parryOffWeaponPosition(), set.parryOffWeaponRotation(),
                set.blockMainArm(), set.blockOffArm(),
                set.blockMainWeaponPosition(), set.blockMainWeaponRotation(),
                set.blockOffWeaponPosition(), set.blockOffWeaponRotation()
        );
    }

    private static DualPoseSet replaceWeaponPosition(
            DualPoseSet set,
            int mode,
            boolean mainHand,
            Vec3f value
    ) {
        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return new DualPoseSet(
                    set.parryMainArm(), set.parryOffArm(),
                    set.parryMainWeaponPosition(), set.parryMainWeaponRotation(),
                    set.parryOffWeaponPosition(), set.parryOffWeaponRotation(),
                    set.blockMainArm(), set.blockOffArm(),
                    mainHand ? value : set.blockMainWeaponPosition(),
                    set.blockMainWeaponRotation(),
                    mainHand ? set.blockOffWeaponPosition() : value,
                    set.blockOffWeaponRotation()
            );
        }

        return new DualPoseSet(
                set.parryMainArm(), set.parryOffArm(),
                mainHand ? value : set.parryMainWeaponPosition(),
                set.parryMainWeaponRotation(),
                mainHand ? set.parryOffWeaponPosition() : value,
                set.parryOffWeaponRotation(),
                set.blockMainArm(), set.blockOffArm(),
                set.blockMainWeaponPosition(), set.blockMainWeaponRotation(),
                set.blockOffWeaponPosition(), set.blockOffWeaponRotation()
        );
    }

    private static DualPoseSet replaceWeaponRotation(
            DualPoseSet set,
            int mode,
            boolean mainHand,
            Vec3f value
    ) {
        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return new DualPoseSet(
                    set.parryMainArm(), set.parryOffArm(),
                    set.parryMainWeaponPosition(), set.parryMainWeaponRotation(),
                    set.parryOffWeaponPosition(), set.parryOffWeaponRotation(),
                    set.blockMainArm(), set.blockOffArm(),
                    set.blockMainWeaponPosition(),
                    mainHand ? value : set.blockMainWeaponRotation(),
                    set.blockOffWeaponPosition(),
                    mainHand ? set.blockOffWeaponRotation() : value
            );
        }

        return new DualPoseSet(
                set.parryMainArm(), set.parryOffArm(),
                set.parryMainWeaponPosition(),
                mainHand ? value : set.parryMainWeaponRotation(),
                set.parryOffWeaponPosition(),
                mainHand ? set.parryOffWeaponRotation() : value,
                set.blockMainArm(), set.blockOffArm(),
                set.blockMainWeaponPosition(), set.blockMainWeaponRotation(),
                set.blockOffWeaponPosition(), set.blockOffWeaponRotation()
        );
    }

    private static Vec3f adjust(
            Vec3f value,
            int axis,
            float delta,
            float min,
            float max
    ) {
        float x = value.getX();
        float y = value.getY();
        float z = value.getZ();

        if (axis == 0) {
            x = clamp(x + delta, min, max);
        } else if (axis == 1) {
            y = clamp(y + delta, min, max);
        } else if (axis == 2) {
            z = clamp(z + delta, min, max);
        }

        return new Vec3f(x, y, z);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static Vec3f zero() {
        return new Vec3f(0.0F, 0.0F, 0.0F);
    }

    private static Vec3f copyVec(Vec3f value) {
        return new Vec3f(value.getX(), value.getY(), value.getZ());
    }

    private static DualPoseSet neutral() {
        return new DualPoseSet(
                zero(), zero(), zero(), zero(), zero(), zero(),
                zero(), zero(), zero(), zero(), zero(), zero()
        );
    }

    private static DualPoseSet copy(DualPoseSet source) {
        if (source == null) {
            return neutral();
        }

        return new DualPoseSet(
                copyVec(source.parryMainArm()),
                copyVec(source.parryOffArm()),
                copyVec(source.parryMainWeaponPosition()),
                copyVec(source.parryMainWeaponRotation()),
                copyVec(source.parryOffWeaponPosition()),
                copyVec(source.parryOffWeaponRotation()),
                copyVec(source.blockMainArm()),
                copyVec(source.blockOffArm()),
                copyVec(source.blockMainWeaponPosition()),
                copyVec(source.blockMainWeaponRotation()),
                copyVec(source.blockOffWeaponPosition()),
                copyVec(source.blockOffWeaponRotation())
        );
    }

    private static DualPoseSet read(Path path) throws IOException {
        return readText(
                Files.readString(path, StandardCharsets.UTF_8)
        );
    }

    private static DualPoseSet readBundled(
            String relativePath
    ) throws IOException {
        return readText(
                BundledStanceDefaults.readText(relativePath)
        );
    }

    private static DualPoseSet readText(
            String text
    ) {
        JsonObject root = JsonParser.parseString(text)
                .getAsJsonObject();

        JsonObject parry = root.getAsJsonObject("parry");
        JsonObject block = root.getAsJsonObject("block");

        return new DualPoseSet(
                readVec(parry, "mainhand"),
                readVec(parry, "offhand"),
                readVec(parry, "mainhand_weapon_position"),
                readVec(parry, "mainhand_weapon_rotation"),
                readVec(parry, "offhand_weapon_position"),
                readVec(parry, "offhand_weapon_rotation"),
                readVec(block, "mainhand"),
                readVec(block, "offhand"),
                readVec(block, "mainhand_weapon_position"),
                readVec(block, "mainhand_weapon_rotation"),
                readVec(block, "offhand_weapon_position"),
                readVec(block, "offhand_weapon_rotation")
        );
    }

    private static void write(Path path, DualPoseSet pose) throws IOException {
        Files.createDirectories(path.getParent());
        Files.writeString(path, toJson(pose), StandardCharsets.UTF_8);
    }

    private static String toJson(DualPoseSet pose) {
        JsonObject root = new JsonObject();
        JsonObject parry = new JsonObject();
        JsonObject block = new JsonObject();

        parry.add("mainhand", toArray(pose.parryMainArm()));
        parry.add("offhand", toArray(pose.parryOffArm()));
        parry.add("mainhand_weapon_position", toArray(pose.parryMainWeaponPosition()));
        parry.add("mainhand_weapon_rotation", toArray(pose.parryMainWeaponRotation()));
        parry.add("offhand_weapon_position", toArray(pose.parryOffWeaponPosition()));
        parry.add("offhand_weapon_rotation", toArray(pose.parryOffWeaponRotation()));

        block.add("mainhand", toArray(pose.blockMainArm()));
        block.add("offhand", toArray(pose.blockOffArm()));
        block.add("mainhand_weapon_position", toArray(pose.blockMainWeaponPosition()));
        block.add("mainhand_weapon_rotation", toArray(pose.blockMainWeaponRotation()));
        block.add("offhand_weapon_position", toArray(pose.blockOffWeaponPosition()));
        block.add("offhand_weapon_rotation", toArray(pose.blockOffWeaponRotation()));

        root.add("parry", parry);
        root.add("block", block);
        return root.toString();
    }

    private static JsonArray toArray(Vec3f value) {
        JsonArray array = new JsonArray();
        array.add(value.getX());
        array.add(value.getY());
        array.add(value.getZ());
        return array;
    }

    private static Vec3f readVec(JsonObject object, String key) {
        if (object == null || !object.has(key)) {
            return zero();
        }

        JsonArray array = object.getAsJsonArray(key);
        if (array == null || array.size() != 3) {
            return zero();
        }

        return new Vec3f(
                array.get(0).getAsFloat(),
                array.get(1).getAsFloat(),
                array.get(2).getAsFloat()
        );
    }

    private record PairKey(ResourceLocation main, ResourceLocation off) {
        private String serialized() {
            return main + "|" + off;
        }

        private static PairKey parse(String value) {
            if (value == null) return null;
            int split = value.indexOf('|');
            if (split <= 0 || split >= value.length() - 1) return null;
            try {
                return new PairKey(
                        ResourceLocation.parse(value.substring(0, split)),
                        ResourceLocation.parse(value.substring(split + 1))
                );
            } catch (Exception exception) {
                return null;
            }
        }
    }

    private record DualPoseSet(
            Vec3f parryMainArm,
            Vec3f parryOffArm,
            Vec3f parryMainWeaponPosition,
            Vec3f parryMainWeaponRotation,
            Vec3f parryOffWeaponPosition,
            Vec3f parryOffWeaponRotation,
            Vec3f blockMainArm,
            Vec3f blockOffArm,
            Vec3f blockMainWeaponPosition,
            Vec3f blockMainWeaponRotation,
            Vec3f blockOffWeaponPosition,
            Vec3f blockOffWeaponRotation
    ) {
    }
}
