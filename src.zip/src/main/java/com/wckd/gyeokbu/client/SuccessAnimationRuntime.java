package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.weapon.HandStyle;
import com.wckd.gyeokbu.weapon.ParryStyle;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Runtime Successful Parry animation player.
 *
 * A successful Parry immediately replaces the active Parry pose visually:
 * Start Pose -> selected End Pose -> current underlying pose.
 *
 * One total duration and one Successful Parry curve govern the whole
 * sequence. The End Pose is treated as the impact waypoint at roughly one
 * third of that duration.
 *
 * The combat state is independent from this animation. Starting another
 * Parry does not interrupt the current animation; another successful Parry
 * replaces it immediately.
 */
public final class SuccessAnimationRuntime {

    private static final int FIRST_PERSON_HANDOFF_TICKS = 10;

    private static final Map<Integer, ActiveAnimation> ACTIVE =
            new ConcurrentHashMap<>();

    private static final Map<Integer, PreviewAnimation> PREVIEWS =
            new ConcurrentHashMap<>();

    /*
     * Random End-Pose shuffle bags, kept separately for runtime and editor
     * previews. A shuffle bag gives every available pose one turn before any
     * pose can be selected again, while the refill step also prevents the
     * first pose of the new bag from matching the last pose of the old bag.
     */
    private static final Map<RandomSelectionKey, RandomEndPoseBag> RANDOM_END_POSE_BAGS =
            new ConcurrentHashMap<>();

    private SuccessAnimationRuntime() {
    }

    public static void start(
            int entityId,
            SuccessAnimationKind kind,
            ParryStyle resolvedStyle,
            HandStyle resolvedHandStyle,
            boolean resolvedDualWield
    ) {
        if (kind != SuccessAnimationKind.PARRY) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }

        if (!(mc.level.getEntity(entityId) instanceof AbstractClientPlayer player)) {
            return;
        }

        /*
         * Better Combat's attack animation can contribute a body/root
         * transform on the same PlayerAnimator stack. Successful Parry must
         * take over that third-person presentation, but CHANGED! 29's
         * first-person path is already correct and must remain untouched.
         *
         * For the local player, skip this entirely while the actual camera is
         * first-person. Remote players have no first-person camera on this
         * client, so their Successful Parry is always a third-person
         * presentation and the same cancellation is appropriate.
         */
        if (shouldInterruptBetterCombatThirdPerson(mc, player)) {
            BetterCombatParryCompat.stopAttackAnimationForEntity(entityId);
        }

        ItemStack stack = player.getMainHandItem();
        ResourceLocation itemId = stack.isEmpty()
                ? null
                : BuiltInRegistries.ITEM.getKey(stack.getItem());
        ParryStyle style = resolvedStyle == null
                ? ParryStyle.GENERIC
                : resolvedStyle;
        boolean dual = resolvedDualWield;
        HandStyle handStyle = resolvedHandStyle == null
                ? HandStyle.ONE_HANDED
                : resolvedHandStyle;

        /*
         * The server has already decided which weapon category, handedness, and
         * dual-wield state belonged to the successful hit. Use those semantics
         * here instead of asking the client to classify the item again.
         */
        SuccessAnimationConfig.RuntimeProfileSet resolved =
                SuccessAnimationConfig.resolveRuntimeProfiles(
                        itemId,
                        style,
                        dual,
                        stack,
                        handStyle
                );
        SuccessAnimationConfig.Profile third = resolved.thirdPerson();
        SuccessAnimationConfig.Profile first = resolved.firstPerson();

        List<Integer> thirdPoseIndices = validEndPoseIndices(third);
        List<Integer> firstPoseIndices = validEndPoseIndices(first);
        if (third == null || first == null
                || thirdPoseIndices.isEmpty()
                || firstPoseIndices.isEmpty()) {
            GyeokbuV2.LOGGER.debug(
                    "Successful Parry runtime profile was incomplete: entity={}, profile={}, thirdPoses={}, firstPoses={}",
                    entityId,
                    resolved.identity(),
                    thirdPoseIndices.size(),
                    firstPoseIndices.size()
            );
            ACTIVE.remove(entityId);
            return;
        }

        /* The successful hit occurs while the defender is in PARRY. Capture
           that actual Parry stance as the CURRENT Start Pose before the
           synchronized defense state can fall back to NONE. */
        SuccessAnimationConfig.PoseData thirdCurrent =
                SuccessAnimationConfig.parryPose(stack, style, dual, false);
        SuccessAnimationConfig.PoseData firstCurrent =
                SuccessAnimationConfig.parryPose(stack, style, dual, true);

        /*
         * First- and Third-Person are independent profiles now. Each view gets
         * its own no-repeat shuffle bag, so every pose that exists in that view
         * is actually reachable without forcing the other view to have the
         * same number of poses.
         */
        int thirdSelected = chooseRandomEndPose(
                entityId,
                thirdPoseIndices,
                resolved.identity(),
                false,
                false
        );
        int firstSelected = chooseRandomEndPose(
                entityId,
                firstPoseIndices,
                resolved.identity(),
                true,
                false
        );

        SuccessAnimationConfig.PoseData thirdStart = third.pointAMode == SuccessAnimationConfig.PointAMode.CUSTOM
                ? third.pointA.copy()
                : thirdCurrent.copy();
        SuccessAnimationConfig.PoseData firstStart = first.pointAMode == SuccessAnimationConfig.PointAMode.CUSTOM
                ? first.pointA.copy()
                : firstCurrent.copy();

        ACTIVE.put(
                entityId,
                new ActiveAnimation(
                        resolved.identity(),
                        third,
                        first,
                        thirdStart,
                        firstStart,
                        third.pointBs.get(thirdSelected).copy(),
                        first.pointBs.get(firstSelected).copy(),
                        itemId,
                        style,
                        dual,
                        player.getHealth(),
                        System.nanoTime(),
                        thirdSelected,
                        firstSelected
                )
        );

        if (mc.player == player) {
            ClientSuccessImpactFreeze.request();
        }

        GyeokbuV2.LOGGER.debug(
                "Started Successful Parry: entity={}, profile={}, thirdPose={}, firstPose={}, thirdCount={}, firstCount={}",
                entityId,
                resolved.identity(),
                thirdSelected + 1,
                firstSelected + 1,
                thirdPoseIndices.size(),
                firstPoseIndices.size()
        );
    }

    private static boolean shouldInterruptBetterCombatThirdPerson(
            Minecraft minecraft,
            AbstractClientPlayer player
    ) {
        if (minecraft.player != player) {
            return true;
        }

        return minecraft.options.getCameraType() != net.minecraft.client.CameraType.FIRST_PERSON;
    }

    private static boolean firstPersonForEditor() {
        return SuccessAnimationConfig.isEditorFirstPerson();
    }

    /**
     * Start an editor-only preview.  The preview always starts from the pose
     * currently visible in the editor, then follows the exact configured
     * Successful Parry flow and timing.
     *
     * playVariant == -1 means Random. Otherwise it is a zero-based End Pose
     * variant index.
     */
    public static void startEditorPreview(
            int playVariant
    ) {
        if (!SuccessAnimationConfig.isEditorActive()) {
            return;
        }

        SuccessAnimationConfig.Profile profile =
                SuccessAnimationConfig.getEditorProfileCopy();
        List<Integer> poseIndices = validEndPoseIndices(profile);
        if (poseIndices.isEmpty()) {
            return;
        }

        SuccessAnimationConfig.PoseData current =
                SuccessAnimationConfig.getEditorCurrentPreviewPose();

        SuccessAnimationConfig.PoseData start =
                profile.pointAMode == SuccessAnimationConfig.PointAMode.CUSTOM
                        ? profile.pointA.copy()
                        : current.copy();

        int playerId = Minecraft.getInstance().player == null
                ? -1
                : Minecraft.getInstance().player.getId();

        if (playerId < 0) {
            return;
        }

        int selected;
        if (playVariant < 0) {
            selected = chooseRandomEndPose(
                    playerId,
                    poseIndices,
                    SuccessAnimationConfig.getEditorProfileId(),
                    firstPersonForEditor(),
                    true
            );
        } else {
            int ordinal = Math.max(0, Math.min(playVariant, poseIndices.size() - 1));
            selected = poseIndices.get(ordinal);
        }

        SuccessAnimationConfig.PoseData end =
                profile.pointBs.get(selected).copy();

        PREVIEWS.put(
                playerId,
                new PreviewAnimation(
                        profile,
                        start,
                        end,
                        current,
                        System.nanoTime()
                )
        );
    }

    public static boolean isEditorPreviewActive(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        return sampleEditorPreview(player) != null;
    }

    /**
     * Captures the exact Successful Parry presentation currently visible to
     * the local player and hands it to the normal defense-transition runtime.
     * A new Parry can therefore take over from the current frame smoothly,
     * regardless of whether the Success animation is in Start->End, End->Current,
     * or the short first-person presentation handoff.
     */
    public static void prepareDefenseInterruption(
            AbstractClientPlayer player
    ) {
        if (player == null) {
            return;
        }

        ActiveAnimation active = ACTIVE.get(player.getId());
        if (active == null) {
            return;
        }

        long now = System.nanoTime();
        captureDefenseSeed(player, true, active, now);
        captureDefenseSeed(player, false, active, now);
        ACTIVE.remove(player.getId(), active);
    }

    private static void captureDefenseSeed(
            AbstractClientPlayer player,
            boolean firstPerson,
            ActiveAnimation active,
            long now
    ) {
        SuccessAnimationConfig.Profile profile = firstPerson
                ? active.firstProfile
                : active.thirdProfile;
        SuccessAnimationConfig.PoseData start = firstPerson
                ? active.firstStart
                : active.thirdStart;
        SuccessAnimationConfig.PoseData end = firstPerson
                ? active.firstEnd
                : active.thirdEnd;

        SuccessAnimationConfig.PoseData current = currentUnderlyingPose(
                player,
                active.style,
                active.dual,
                firstPerson,
                player.getMainHandItem()
        );

        float sequenceT = progress(
                active.startedAtNanos,
                profile.totalDurationTicks,
                now
        );
        SuccessAnimationConfig.PoseData pose = sequenceT >= 1.0F
                ? current
                : sampleSuccessTrajectory(
                start,
                end,
                current,
                sequenceT,
                profile.totalDurationTicks,
                profile.transitionMode
        );

        DefensePoseTransitionRuntime.seedFromPose(
                player,
                firstPerson,
                pose
        );
    }

    public static void cancelEditorPreview() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            PREVIEWS.remove(mc.player.getId());
        }
    }

    public static void cancel(
            int entityId
    ) {
        ACTIVE.remove(entityId);
    }

    public static void cancelLocal() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            cancel(mc.player.getId());
            PREVIEWS.remove(mc.player.getId());
        }
    }

    public static boolean isActive(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        return sample(player, firstPerson) != null;
    }

    /**
     * Lightweight live-state check for render-layer ownership. Unlike
     * {@link #isActive(AbstractClientPlayer, boolean)}, this does not sample or
     * mutate the animation state. It is safe to call for every PlayerAnimator
     * bone during a render frame.
     */
    public static boolean isRunning(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        if (player == null) {
            return false;
        }

        ActiveAnimation active = ACTIVE.get(player.getId());
        if (active == null) {
            return false;
        }

        ProfilePhase phase = activePhase(active, System.nanoTime(), firstPerson);
        return phase != ProfilePhase.DONE && phase != ProfilePhase.FIRST_PERSON_HANDOFF;
    }

    /**
     * Samples the authored arm transform for the live Successful Parry layer.
     * During End -> Current recovery, {@code baseValue} is the actual lower
     * PlayerAnimator value for this arm. Using that value as the target keeps
     * the recovery attached to whatever animation is genuinely underneath
     * Gyeokbu instead of reconstructing a stale defense pose.
     */
    public static Vec3f sampleArmRotation(
            AbstractClientPlayer player,
            boolean firstPerson,
            boolean mainHand,
            Vec3f baseValue,
            float lookPitch
    ) {
        ActiveAnimation active = ACTIVE.get(player.getId());
        if (active == null) {
            return null;
        }

        long now = System.nanoTime();
        ProfilePhase phase = activePhase(active, now, firstPerson);
        if (phase == ProfilePhase.DONE || phase == ProfilePhase.FIRST_PERSON_HANDOFF) {
            return null;
        }

        SuccessAnimationConfig.Profile profile =
                firstPerson ? active.firstProfile : active.thirdProfile;
        SuccessAnimationConfig.PoseData start =
                firstPerson ? active.firstStart : active.thirdStart;
        SuccessAnimationConfig.PoseData end =
                firstPerson ? active.firstEnd : active.thirdEnd;

        Vec3f startArm = armVector(start, mainHand);
        Vec3f endArm = armVector(end, mainHand);

        if (firstPerson) {
            startArm = FirstPersonPoseMath.applyCameraPitch(startArm, lookPitch);
            endArm = FirstPersonPoseMath.applyCameraPitch(endArm, lookPitch);
        }

        float sequenceT = progress(
                active.startedAtNanos,
                profile.totalDurationTicks,
                now
        );
        if (sequenceT >= 1.0F) {
            return baseValue;
        }

        return GyeokbuTransitionCurves.sampleSuccessWaypoint(
                startArm,
                endArm,
                baseValue,
                sequenceT,
                SuccessAnimationConfig.impactTicks(profile.totalDurationTicks)
                        / (float) profile.totalDurationTicks,
                profile.transitionMode
        );
    }

    private static Vec3f armVector(
            SuccessAnimationConfig.PoseData pose,
            boolean mainHand
    ) {
        return mainHand
                ? vec(
                pose,
                SuccessAnimationChannel.MAIN_ARM_X,
                SuccessAnimationChannel.MAIN_ARM_Y,
                SuccessAnimationChannel.MAIN_ARM_Z
        )
                : vec(
                pose,
                SuccessAnimationChannel.OFF_ARM_X,
                SuccessAnimationChannel.OFF_ARM_Y,
                SuccessAnimationChannel.OFF_ARM_Z
        );
    }

    public static AnimationPoseConfig.ArmPose armPose(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        SuccessAnimationConfig.PoseData pose = getSamplePose(player, firstPerson);
        if (pose == null) {
            return null;
        }
        return armPose(pose);
    }

    public static Vec3f weaponPosition(
            AbstractClientPlayer player,
            boolean firstPerson,
            boolean mainHand
    ) {
        SuccessAnimationConfig.PoseData pose = getSamplePose(player, firstPerson);
        if (pose == null) {
            return null;
        }

        return mainHand
                ? vec(
                pose,
                SuccessAnimationChannel.MAIN_WEAPON_POS_X,
                SuccessAnimationChannel.MAIN_WEAPON_POS_Y,
                SuccessAnimationChannel.MAIN_WEAPON_POS_Z
        )
                : vec(
                pose,
                SuccessAnimationChannel.OFF_WEAPON_POS_X,
                SuccessAnimationChannel.OFF_WEAPON_POS_Y,
                SuccessAnimationChannel.OFF_WEAPON_POS_Z
        );
    }

    public static Vec3f weaponRotation(
            AbstractClientPlayer player,
            boolean firstPerson,
            boolean mainHand
    ) {
        SuccessAnimationConfig.PoseData pose = getSamplePose(player, firstPerson);
        if (pose == null) {
            return null;
        }

        return mainHand
                ? vec(
                pose,
                SuccessAnimationChannel.MAIN_WEAPON_ROT_X,
                SuccessAnimationChannel.MAIN_WEAPON_ROT_Y,
                SuccessAnimationChannel.MAIN_WEAPON_ROT_Z
        )
                : vec(
                pose,
                SuccessAnimationChannel.OFF_WEAPON_ROT_X,
                SuccessAnimationChannel.OFF_WEAPON_ROT_Y,
                SuccessAnimationChannel.OFF_WEAPON_ROT_Z
        );
    }

    private static SuccessAnimationConfig.PoseData getSamplePose(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        SuccessAnimationConfig.PoseData preview =
                sampleEditorPreview(player);
        if (preview != null) {
            return preview;
        }

        Sample sample = sample(player, firstPerson);
        return sample == null ? null : sample.pose;
    }

    private static SuccessAnimationConfig.PoseData sampleEditorPreview(
            AbstractClientPlayer player
    ) {
        PreviewAnimation preview = PREVIEWS.get(player.getId());
        if (preview == null) {
            return null;
        }

        long now = System.nanoTime();
        ProfilePhase phase = previewPhase(preview, now);
        if (phase == ProfilePhase.DONE) {
            PREVIEWS.remove(player.getId(), preview);
            return null;
        }

        float sequenceT = progress(
                preview.startedAtNanos,
                preview.profile.totalDurationTicks,
                now
        );
        if (sequenceT >= 1.0F) {
            PREVIEWS.remove(player.getId(), preview);
            return preview.current.copy();
        }

        return sampleSuccessTrajectory(
                preview.start,
                preview.end,
                preview.current,
                sequenceT,
                preview.profile.totalDurationTicks,
                preview.profile.transitionMode
        );
    }

    private static Sample sample(
            AbstractClientPlayer player,
            boolean firstPerson
    ) {
        ActiveAnimation active = ACTIVE.get(player.getId());
        if (active == null) {
            return null;
        }

        /* A successful-Parry animation is a temporary visual reaction, not a
           lockout. Taking damage immediately cancels it. */
        if (player.getHealth() < active.startHealth) {
            ACTIVE.remove(player.getId(), active);
            return null;
        }

        /*
         * Successful Parry is a visual reaction, not an input lock. Starting an
         * M1/attack immediately gives control back to the normal combat layer.
         */
        Minecraft mc = Minecraft.getInstance();
        if (player == mc.player && mc.options.keyAttack.isDown()) {
            ACTIVE.remove(player.getId(), active);
            return null;
        }

        /* A weapon swap should immediately hand rendering back to Minecraft. */
        ItemStack currentStack = player.getMainHandItem();
        ResourceLocation currentId = currentStack.isEmpty()
                ? null
                : BuiltInRegistries.ITEM.getKey(currentStack.getItem());
        if (active.itemId != null && !active.itemId.equals(currentId)) {
            ACTIVE.remove(player.getId(), active);
            return null;
        }
        if (active.itemId == null && currentId != null) {
            ACTIVE.remove(player.getId(), active);
            return null;
        }

        long now = System.nanoTime();
        ProfilePhase phase = activePhase(active, now, firstPerson);
        if (phase == ProfilePhase.DONE) {
            ACTIVE.remove(player.getId(), active);
            return null;
        }
        if (phase == ProfilePhase.FIRST_PERSON_HANDOFF) {
            return new Sample(SuccessAnimationConfig.PoseData.empty());
        }

        SuccessAnimationConfig.Profile profile = firstPerson
                ? active.firstProfile
                : active.thirdProfile;
        SuccessAnimationConfig.PoseData start = firstPerson
                ? active.firstStart
                : active.thirdStart;
        SuccessAnimationConfig.PoseData end = firstPerson
                ? active.firstEnd
                : active.thirdEnd;

        SuccessAnimationConfig.PoseData current =
                currentUnderlyingPose(
                        player,
                        active.style,
                        active.dual,
                        firstPerson,
                        currentStack
                );

        float sequenceT = progress(
                active.startedAtNanos,
                profile.totalDurationTicks,
                now
        );
        if (sequenceT >= 1.0F) {
            return new Sample(current);
        }

        return new Sample(
                sampleSuccessTrajectory(
                        start,
                        end,
                        current,
                        sequenceT,
                        profile.totalDurationTicks,
                        profile.transitionMode
                )
        );
    }

    private static ProfilePhase activePhase(
            ActiveAnimation active,
            long now,
            boolean firstPerson
    ) {
        SuccessAnimationConfig.Profile profile = firstPerson
                ? active.firstProfile
                : active.thirdProfile;
        long recoveryEnd = active.startedAtNanos
                + ticksToNanos(profile.totalDurationTicks);
        if (firstPerson) {
            long handoffEnd = recoveryEnd + ticksToNanos(FIRST_PERSON_HANDOFF_TICKS);
            if (now >= recoveryEnd && now < handoffEnd) {
                return ProfilePhase.FIRST_PERSON_HANDOFF;
            }
        }
        return phaseFor(
                active.startedAtNanos,
                profile.totalDurationTicks,
                SuccessAnimationConfig.impactTicks(profile.totalDurationTicks),
                now
        );
    }

    private static ProfilePhase previewPhase(
            PreviewAnimation preview,
            long now
    ) {
        return phaseFor(
                preview.startedAtNanos,
                preview.profile.totalDurationTicks,
                SuccessAnimationConfig.impactTicks(preview.profile.totalDurationTicks),
                now
        );
    }

    private static ProfilePhase phaseFor(
            long start,
            int totalTicks,
            int impactTicks,
            long now
    ) {
        long impactEnd = start + ticksToNanos(impactTicks);
        long totalEnd = start + ticksToNanos(totalTicks);
        if (now < impactEnd) {
            return ProfilePhase.A_TO_B;
        }
        if (now < totalEnd) {
            return ProfilePhase.B_TO_DEFAULT;
        }
        return ProfilePhase.DONE;
    }

    public static void clearRuntimeState() {
        ACTIVE.clear();
        PREVIEWS.clear();
        RANDOM_END_POSE_BAGS.clear();
        ClientSuccessImpactFreeze.clear();
    }

    public static SuccessAnimationConfig.ProfileId activeProfileId(
            AbstractClientPlayer player
    ) {
        if (player == null) {
            return null;
        }
        ActiveAnimation active = ACTIVE.get(player.getId());
        return active == null ? null : active.profileId;
    }

    private static List<Integer> validEndPoseIndices(
            SuccessAnimationConfig.Profile profile
    ) {
        if (profile == null || profile.pointBs == null) {
            return List.of();
        }

        List<Integer> indices = new ArrayList<>();
        for (int i = 0; i < profile.pointBs.size(); i++) {
            if (profile.pointBs.get(i) != null) {
                indices.add(i);
            }
        }
        return indices;
    }

    private static int chooseRandomEndPose(
            int ownerId,
            List<Integer> availableIndices,
            SuccessAnimationConfig.ProfileId profileId,
            boolean firstPerson,
            boolean editor
    ) {
        List<Integer> safeIndices = availableIndices == null
                ? List.of()
                : List.copyOf(availableIndices);
        if (safeIndices.isEmpty()) {
            return 0;
        }

        RandomSelectionKey key = new RandomSelectionKey(
                ownerId,
                profileId,
                firstPerson,
                editor
        );
        RandomEndPoseBag bag = RANDOM_END_POSE_BAGS.computeIfAbsent(
                key,
                ignored -> new RandomEndPoseBag()
        );

        if (!bag.availableIndices.equals(safeIndices) || bag.remaining.isEmpty()) {
            refillRandomEndPoseBag(bag, safeIndices);
        }

        Integer selected = bag.remaining.pollFirst();
        if (selected == null) {
            refillRandomEndPoseBag(bag, safeIndices);
            selected = bag.remaining.pollFirst();
        }

        int resolved = selected == null ? safeIndices.get(0) : selected;
        bag.previous = resolved;
        return resolved;
    }

    private static void refillRandomEndPoseBag(
            RandomEndPoseBag bag,
            List<Integer> availableIndices
    ) {
        bag.availableIndices = List.copyOf(availableIndices);
        bag.remaining.clear();

        List<Integer> shuffled = new ArrayList<>(availableIndices);

        Collections.shuffle(
                shuffled,
                ThreadLocalRandom.current()
        );

        /*
         * Refill boundaries are also non-repeating. If the last pose of the
         * previous bag would become the first pose of the new bag, swap the
         * first element with another random position.
         */
        int poseCount = shuffled.size();
        if (poseCount > 1
                && bag.previous >= 0
                && shuffled.get(0) == bag.previous) {

            int swapIndex =
                    1 + ThreadLocalRandom.current().nextInt(poseCount - 1);

            Collections.swap(
                    shuffled,
                    0,
                    swapIndex
            );
        }

        bag.remaining.addAll(shuffled);
    }

    private static SuccessAnimationConfig.PoseData currentUnderlyingPose(
            AbstractClientPlayer player,
            ParryStyle style,
            boolean dual,
            boolean firstPerson,
            ItemStack stack
    ) {
        /*
         * Outside the actual editor, a successful Parry should return to the
         * normal Minecraft pose. Gyeokbu's defense animation layer is the only
         * thing that should be supplied while a PARRY/BLOCK visual is active.
         */
        int mode = firstPerson
                ? ClientCombatSyncState.getFirstPersonDefenseVisualMode(player.getId())
                : ClientCombatSyncState.getDefenseAnimationMode(player.getId());

        if (mode != DefenseAnimationSyncPayload.PARRY
                && mode != DefenseAnimationSyncPayload.BLOCK) {
            return SuccessAnimationConfig.PoseData.empty();
        }

        SuccessAnimationConfig.PoseData data =
                SuccessAnimationConfig.PoseData.empty();

        for (SuccessAnimationChannel c : SuccessAnimationChannel.values()) {
            if (!dual && c.isOffWeapon()) {
                continue;
            }

            float value = dual
                    ? DualWieldPoseConfig.getVisualValueForStyle(
                    style,
                    mode,
                    firstPerson,
                    c
            )
                    : AnimationPoseConfig.getVisualValueFor(
                    stack,
                    style,
                    mode,
                    firstPerson,
                    c
            );

            data = data.withValue(c, value);
        }

        return data;
    }

    private static AnimationPoseConfig.ArmPose armPose(
            SuccessAnimationConfig.PoseData pose
    ) {
        return new AnimationPoseConfig.ArmPose(
                vec(
                        pose,
                        SuccessAnimationChannel.MAIN_ARM_X,
                        SuccessAnimationChannel.MAIN_ARM_Y,
                        SuccessAnimationChannel.MAIN_ARM_Z
                ),
                vec(
                        pose,
                        SuccessAnimationChannel.OFF_ARM_X,
                        SuccessAnimationChannel.OFF_ARM_Y,
                        SuccessAnimationChannel.OFF_ARM_Z
                )
        );
    }

    private static float progress(
            long start,
            int durationTicks,
            long now
    ) {
        if (durationTicks <= 0) {
            return 1F;
        }

        long duration = ticksToNanos(durationTicks);
        return Math.max(
                0F,
                Math.min(
                        1F,
                        (float) ((double) (now - start) / (double) duration)
                )
        );
    }

    private static long ticksToNanos(int ticks) {
        return ticks * 50_000_000L;
    }

    private static SuccessAnimationConfig.PoseData sampleSuccessTrajectory(
            SuccessAnimationConfig.PoseData start,
            SuccessAnimationConfig.PoseData end,
            SuccessAnimationConfig.PoseData current,
            float sequenceT,
            int totalDurationTicks,
            SuccessTransitionMode mode
    ) {
        float impactFraction = SuccessAnimationConfig.impactTicks(totalDurationTicks)
                / (float) Math.max(1, totalDurationTicks);
        return GyeokbuTransitionCurves.sampleSuccessWaypoint(
                start,
                end,
                current,
                sequenceT,
                impactFraction,
                mode
        );
    }

    private static Vec3f vec(
            SuccessAnimationConfig.PoseData pose,
            SuccessAnimationChannel x,
            SuccessAnimationChannel y,
            SuccessAnimationChannel z
    ) {
        return new Vec3f(
                pose.value(x),
                pose.value(y),
                pose.value(z)
        );
    }

    private record RandomSelectionKey(
            int ownerId,
            SuccessAnimationConfig.ProfileId profileId,
            boolean firstPerson,
            boolean editor
    ) {
    }

    private static final class RandomEndPoseBag {
        private final ArrayDeque<Integer> remaining = new ArrayDeque<>();
        private List<Integer> availableIndices = List.of();
        private int previous = -1;
    }

    private enum ProfilePhase {
        A_TO_B,
        B_TO_DEFAULT,
        FIRST_PERSON_HANDOFF,
        DONE
    }

    private record Sample(
            SuccessAnimationConfig.PoseData pose
    ) {
    }

    private record ActiveAnimation(
            SuccessAnimationConfig.ProfileId profileId,
            SuccessAnimationConfig.Profile thirdProfile,
            SuccessAnimationConfig.Profile firstProfile,
            SuccessAnimationConfig.PoseData thirdStart,
            SuccessAnimationConfig.PoseData firstStart,
            SuccessAnimationConfig.PoseData thirdEnd,
            SuccessAnimationConfig.PoseData firstEnd,
            ResourceLocation itemId,
            ParryStyle style,
            boolean dual,
            float startHealth,
            long startedAtNanos,
            int thirdSelectedEndPose,
            int firstSelectedEndPose
    ) {
    }

    private record PreviewAnimation(
            SuccessAnimationConfig.Profile profile,
            SuccessAnimationConfig.PoseData start,
            SuccessAnimationConfig.PoseData end,
            SuccessAnimationConfig.PoseData current,
            long startedAtNanos
    ) {
    }
}
