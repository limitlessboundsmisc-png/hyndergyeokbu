package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.neoforged.fml.ModList;

import java.lang.reflect.Method;

/**
 * Optional Better Combat animation-interrupt bridge used when Gyeokbu takes
 * visual ownership of a player's defense/parry.
 */
public final class BetterCombatParryCompat {

    private static volatile boolean disabledAfterError = false;
    private static volatile boolean initialized = false;
    private static Method cancelUpswingMethod;
    private static Method stopAttackAnimationMethod;

    private BetterCombatParryCompat() {
    }

    /**
     * Stops the Better Combat attack animation for a client-side player entity.
     * The packet carrying this request may be sent to every tracking client, so
     * remote viewers stop the same attack animation on their copy of the entity.
     */
    public static void stopAttackAnimationForEntity(int entityId) {
        if (disabledAfterError
                || !ModList.get().isLoaded("bettercombat")) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) {
            return;
        }

        Entity entity = minecraft.level.getEntity(entityId);
        if (entity == null) {
            return;
        }

        try {
            if (!ensureInitialized()) {
                return;
            }

            /* Only the local player's input state lives on MinecraftClient. */
            if (minecraft.player != null
                    && minecraft.player.getId() == entityId
                    && cancelUpswingMethod != null) {
                cancelUpswingMethod.invoke(minecraft);
            }

            if (stopAttackAnimationMethod != null
                    && stopAttackAnimationMethod.getDeclaringClass().isInstance(entity)) {
                stopAttackAnimationMethod.invoke(entity, 0.0F);
            }
        } catch (ReflectiveOperationException | RuntimeException exception) {
            disabledAfterError = true;
            GyeokbuV2.LOGGER.warn(
                    "Better Combat parry animation interrupt failed. "
                            + "Disabling attack-animation integration for this session.",
                    exception
            );
        }
    }

    private static synchronized boolean ensureInitialized() {
        if (initialized) {
            return true;
        }
        if (disabledAfterError) {
            return false;
        }

        try {
            Class<?> clientApi = Class.forName(
                    "net.bettercombat.api.MinecraftClient_BetterCombat"
            );
            cancelUpswingMethod = clientApi.getMethod("cancelUpswing");

            Class<?> animatableClass = Class.forName(
                    "net.bettercombat.client.animation.PlayerAttackAnimatable"
            );
            stopAttackAnimationMethod = animatableClass.getMethod(
                    "stopAttackAnimation",
                    float.class
            );

            initialized = true;
            return true;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            disabledAfterError = true;
            GyeokbuV2.LOGGER.warn(
                    "Better Combat parry compatibility could not initialize. "
                            + "Disabling attack-animation integration for this session.",
                    exception
            );
            return false;
        }
    }
}
