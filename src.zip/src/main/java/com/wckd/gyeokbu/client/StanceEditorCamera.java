package com.wckd.gyeokbu.client;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

/**
 * Client-only preview camera state for the Gyeokbu Stance Editor.
 *
 * It never changes player yaw/pitch.
 * Mouse-wheel zoom is implemented through a temporary preview FOV.
 */
public final class StanceEditorCamera {

    private static boolean active =
            false;

    private static float yawOffsetDegrees =
            0.0F;

    private static float pitchOffsetDegrees =
            0.0F;

    private static CameraType previousCameraType =
            null;

    private static Integer previousFov =
            null;

    private StanceEditorCamera() {
    }

    public static void begin() {

        Minecraft minecraft =
                Minecraft.getInstance();

        if (!active) {

            previousCameraType =
                    minecraft.options
                            .getCameraType();

            previousFov =
                    minecraft.options
                            .fov()
                            .get();
        }

        active =
                true;

        /*
         * Start in FRONT view automatically.
         */
        yawOffsetDegrees =
                0.0F;

        pitchOffsetDegrees =
                0.0F;

        minecraft.options
                .setCameraType(
                        isAnyEditorFirstPerson()
                                ? CameraType.FIRST_PERSON
                                : CameraType.THIRD_PERSON_FRONT
                );
    }

    public static void useThirdPersonPreview() {

        yawOffsetDegrees =
                0.0F;

        pitchOffsetDegrees =
                0.0F;

        Minecraft.getInstance()
                .options
                .setCameraType(
                        CameraType.THIRD_PERSON_FRONT
                );
    }

    public static void useFirstPersonPreview() {

        Minecraft.getInstance()
                .options
                .setCameraType(
                        CameraType.FIRST_PERSON
                );
    }

    /**
     * Return editor orbit offsets to a level, straight-ahead preview without
     * changing the player's real yaw/pitch.
     */
    public static void resetViewDirection() {
        yawOffsetDegrees = 0.0F;
        pitchOffsetDegrees = 0.0F;
    }

    public static void end() {

        Minecraft minecraft =
                Minecraft.getInstance();

        if (previousCameraType != null) {

            minecraft.options
                    .setCameraType(
                            previousCameraType
                    );
        }

        if (previousFov != null) {

            minecraft.options
                    .fov()
                    .set(
                            previousFov
                    );
        }

        active =
                false;

        yawOffsetDegrees =
                0.0F;

        pitchOffsetDegrees =
                0.0F;

        previousCameraType =
                null;

        previousFov =
                null;
    }

    public static boolean isActive() {

        return active
                && (
                AnimationPoseConfig.isEditorActive()
                        || DualWieldPoseConfig.isEditorActive()
                        || SuccessAnimationConfig.isEditorActive()
        );
    }

    public static float getYawOffsetDegrees() {

        return yawOffsetDegrees;
    }

    public static float getPitchOffsetDegrees() {

        return pitchOffsetDegrees;
    }

    public static void orbit(
            double mouseDeltaX,
            double mouseDeltaY
    ) {

        /*
         * Natural editor drag:
         * drag left  -> camera moves left
         * drag right -> camera moves right
         */
        yawOffsetDegrees =
                wrapDegrees(
                        yawOffsetDegrees
                                + (float) mouseDeltaX
                                * 0.65F
                );

        pitchOffsetDegrees =
                clamp(
                        pitchOffsetDegrees
                                + (float) mouseDeltaY
                                * 0.65F,
                        -80.0F,
                        80.0F
                );
    }

    public static void zoom(
            double scrollAmount
    ) {

        Minecraft minecraft =
                Minecraft.getInstance();

        int current =
                minecraft.options
                        .fov()
                        .get();

        int next =
                current
                        - (int) Math.round(
                                scrollAmount
                                        * 4.0D
                        );

        next =
                Math.max(
                        30,
                        Math.min(
                                110,
                                next
                        )
                );

        minecraft.options
                .fov()
                .set(
                        next
                );
    }

    public static void reset() {

        /*
         * Reset back to the default editor preview:
         * front view + original FOV.
         */
        yawOffsetDegrees =
                0.0F;

        pitchOffsetDegrees =
                0.0F;

        Minecraft minecraft =
                Minecraft.getInstance();

        minecraft.options
                .setCameraType(
                        isAnyEditorFirstPerson()
                                ? CameraType.FIRST_PERSON
                                : CameraType.THIRD_PERSON_FRONT
                );

        if (previousFov != null) {

            minecraft.options
                    .fov()
                    .set(
                            previousFov
                    );
        }
    }


    private static boolean isAnyEditorFirstPerson() {

        return AnimationPoseConfig.isEditorFirstPerson()
                || DualWieldPoseConfig.isEditorFirstPerson()
                || SuccessAnimationConfig.isEditorFirstPerson();
    }

    private static float wrapDegrees(
            float value
    ) {

        float wrapped =
                value % 360.0F;

        if (wrapped > 180.0F) {
            wrapped -= 360.0F;
        }

        if (wrapped < -180.0F) {
            wrapped += 360.0F;
        }

        return wrapped;
    }

    private static float clamp(
            float value,
            float min,
            float max
    ) {

        return Math.max(
                min,
                Math.min(
                        max,
                        value
                )
        );
    }
}
