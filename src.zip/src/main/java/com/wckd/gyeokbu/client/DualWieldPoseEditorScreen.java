package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Modern dual-wield F8 editor.
 *
 * Mirrors the single-weapon Stances/Edit/Parry-Particles workflow while
 * retaining two independent weapon transforms. Saved loadout priority is:
 * exact pair -> main weapon -> default dual stance.
 */
public final class DualWieldPoseEditorScreen extends Screen {

    private static final int ADJUST_WIDTH = 26;
    private static final int ADJUST_HEIGHT = 18;
    private static final int HOLD_DELAY_TICKS = 6;
    private static final int HOLD_REPEAT_TICKS = 1;
    private static final int STYLE_DROPDOWN_WIDTH = 190;
    private static final int STYLE_DROPDOWN_ROW_HEIGHT = 18;
    private static final int STYLE_DROPDOWN_VISIBLE_ROWS = 9;
    private static final int SAVE_NOTICE_TICKS = 80;
    private static final long TOOLTIP_DELAY_NANOS = 300_000_000L;
    private static final int TOOLTIP_PADDING = 5;
    private static final int TOOLTIP_LINE_GAP = 2;

    private ParryStyle style;
    private final ParryStyle naturalStyle;
    private final List<ParryStyle> availableStyles;

    private final List<AdjustHitbox> adjustHitboxes = new ArrayList<>();

    private float step = 0.05F;
    private String status = "";

    private int panelX;
    private int panelY;
    private int previewX;
    private int previewY;
    private int previewWidth = 220;

    private boolean uiHidden = false;
    private boolean focusEdit = false;
    private VisualSection visualSection = VisualSection.STANCES;
    private boolean infoOpen = true;
    private boolean optionsOpen = false;
    private boolean styleDropdownOpen = false;
    private boolean exitConfirmationOpen = false;
    private int styleDropdownOffset = 0;
    private AbstractWidget styleDropdownButton = null;
    private String saveNotice = "";
    private int saveNoticeTicks = 0;
    private String hoveredTooltipKey = "";
    private long tooltipHoverStartNanos = 0L;

    private EditorPage page = EditorPage.ARMS;
    private WeaponHand weaponHand = WeaponHand.MAINHAND;
    private WeaponTransformTab weaponTransformTab = WeaponTransformTab.POSITION;

    private AdjustHitbox heldAdjust = null;
    private int heldTicks = 0;
    private boolean orbitHeld = false;

    private ResetTarget pendingReset = ResetTarget.NONE;
    private boolean pendingPaste = false;
    private boolean pendingRevert = false;
    private boolean pendingDefaultReset = false;

    public DualWieldPoseEditorScreen() {
        this(false);
    }

    /**
     * Compatibility constructor used by the legacy success-editor path.
     * The boolean selects the particles section while preserving the existing
     * dual-wield editor implementation.
     */
    public DualWieldPoseEditorScreen(boolean openParticles) {
        super(Component.literal("Gyeokbu Dual Wield Pose Editor"));

        this.visualSection = openParticles
                ? VisualSection.PARTICLES
                : VisualSection.STANCES;

        Minecraft minecraft = Minecraft.getInstance();
        WeaponProfile main = minecraft.player == null
                ? WeaponClassifier.classifyNatural(ItemStack.EMPTY)
                : WeaponClassifier.classifyNatural(minecraft.player.getMainHandItem());

        naturalStyle = main.parryStyle();
        List<ParryStyle> detected = new ArrayList<>(DualWieldPoseConfig.getAvailableDualStyles());
        if (!detected.contains(naturalStyle) && naturalStyle != null) {
            detected.add(0, naturalStyle);
        }
        availableStyles = List.copyOf(detected);

        DualWieldPoseConfig.beginEditor();
        enforceAvailableDefenseMode();
        style = DualWieldPoseConfig.getEditorStyle();
        if (!availableStyles.isEmpty() && !availableStyles.contains(style)) {
            style = naturalStyle;
            DualWieldPoseConfig.switchEditorStyle(style);
        }
        StanceEditorCamera.begin();
    }

    @Override
    protected void init() {
        clearWidgets();
        adjustHitboxes.clear();
        DeveloperMessageConfig.syncToServer();
        enforceAvailableDefenseMode();

        panelX = F8Layout.panelX(width);
        panelY = F8Layout.panelY();

        if (exitConfirmationOpen) {
            addExitConfirmationButtons();
            return;
        }

        if (focusEdit) {
            addFocusEditor();
            return;
        }

        addRenderableWidget(
                Button.builder(Component.literal(uiHidden ? "Show UI" : "Hide UI"), button -> {
                            uiHidden = !uiHidden;
                            rebuild();
                        })
                        .bounds(panelX, panelY, 96, 20)
                        .build());

        if (uiHidden) {
            return;
        }

        addHeader();
        addVisualModeButtons();
        addDeveloperMessagesToggle();

        if (visualSection == VisualSection.PARTICLES) {
            addParticlePage();
            return;
        }

        if (visualSection == VisualSection.SUCCESS_PARRY) {
            Minecraft.getInstance().setScreen(
                    new SuccessAnimationEditorScreen(SuccessAnimationKind.PARRY, true)
            );
            return;
        }

        addViewSelector();
        addViewPage();
        addToolsArea();
        addInfoToggle();
    }

    private void rebuild() {
        init();
    }

    private int uiPanelWidth() {
        return F8Layout.panelWidth(width, 360);
    }

    private int uiFocusPanelWidth() {
        return F8Layout.focusPanelWidth(width, uiPanelWidth());
    }

    private void addHeader() {
        styleDropdownButton = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128,
                panelY,
                STYLE_DROPDOWN_WIDTH,
                20,
                Component.literal(
                        "[ "
                                + formatStyleName(style)
                                + (styleDropdownOpen ? " ▲ ]" : " ▼ ]")
                ),
                button -> {
                    styleDropdownOpen = !styleDropdownOpen;
                    if (styleDropdownOpen) {
                        ensureSelectedStyleVisible();
                    }
                    rebuild();
                }));

        addRenderableWidget(
                Button.builder(Component.literal("X"), button -> onClose())
                        .bounds(panelX + uiPanelWidth() - 22, panelY, 20, 20)
                        .build());
    }

    private void addVisualModeButtons() {
        int y = panelY + 28;
        addRenderableWidget(Button.builder(Component.literal("• STANCES"), b -> {
            cancelConfirmations();
            visualSection = VisualSection.STANCES;
            optionsOpen = false;
            styleDropdownOpen = false;
            rebuild();
        }).bounds(panelX, y, 112, 20).build());

        addRenderableWidget(Button.builder(Component.literal("SUCCESS PARRY"), b -> {
            cancelConfirmations();
            visualSection = VisualSection.SUCCESS_PARRY;
            optionsOpen = false;
            styleDropdownOpen = false;
            rebuild();
        }).bounds(panelX + 118, y, 124, 20).build());

        addRenderableWidget(Button.builder(Component.literal("PARTICLES"), b -> {
            cancelConfirmations();
            visualSection = VisualSection.PARTICLES;
            optionsOpen = false;
            styleDropdownOpen = false;
            rebuild();
        }).bounds(panelX + 248, y, 116, 20).build());
    }

    private void addPageTabs() {
        int y = panelY + 58;
        addPageButton("VIEW", EditorPage.VIEW, panelX, y, 120);
        addPageButton("ARMS", EditorPage.ARMS, panelX + 130, y, 120);
        addPageButton("WEAPONS", EditorPage.WEAPONS, panelX + 260, y, 120);
    }

    private void addPageButton(String text, EditorPage target, int x, int y, int w) {
        addRenderableWidget(new GyeokbuSmallButton(
                x, y, w, 18,
                Component.literal(text),
                button -> {
                    cancelConfirmations();
                    page = target;
                    rebuild();
                },
                () -> page == target));
    }

    private void addViewSelector() {
        int y = panelY + 58;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 170, 18,
                Component.literal("Edit Third-Person"),
                button -> setFirstPerson(false),
                () -> !DualWieldPoseConfig.isEditorFirstPerson()));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 194, y, 170, 18,
                Component.literal("Edit First-Person"),
                button -> setFirstPerson(true),
                DualWieldPoseConfig::isEditorFirstPerson));
    }

    private void addViewPage() {
        int y = panelY + 116;
        addDefenseModeButtons(y);
        addEditButton(y);

        y += 36;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 178, 18,
                Component.literal("Reset Camera"),
                button -> {
                    cancelConfirmations();
                    StanceEditorCamera.reset();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 178, 18,
                Component.literal("Transition: " + formatTransitionMode()),
                button -> {
                    cancelConfirmations();
                    DefenseTransitionConfig.cycleMode();
                    status = "Stance transition: " + formatTransitionMode() + ".";
                    rebuild();
                }));

        y += 24;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 36, 18,
                Component.literal("-"),
                button -> {
                    DefenseTransitionConfig.adjustDurationTicks(-1);
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 144, y, 94, 18,
                Component.literal("Duration: " + DefenseTransitionConfig.durationTicks() + "t"),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 244, y, 36, 18,
                Component.literal("+"),
                button -> {
                    DefenseTransitionConfig.adjustDurationTicks(1);
                    rebuild();
                }));
    }

    private void addParticlePage() {
        /* Match the single-weapon F8 particle workspace: view selection,
           camera reset, right-click orbit and wheel zoom all behave the same. */
        int y = panelY + 58;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 8, y, 104, 18,
                Component.literal("Third-Person"),
                button -> setFirstPerson(false),
                () -> !DualWieldPoseConfig.isEditorFirstPerson()));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 120, y, 104, 18,
                Component.literal("First-Person"),
                button -> setFirstPerson(true),
                DualWieldPoseConfig::isEditorFirstPerson));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 232, y, 108, 18,
                Component.literal("Reset Camera"),
                button -> {
                    StanceEditorCamera.reset();
                    status = "Particle preview camera reset.";
                    rebuild();
                }));

        y += 28;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 178, 18,
                Component.literal(
                        "Shape: "
                                + ParryParticleTransitionConfig.shape().displayName()
                                + " ↻"
                ),
                button -> {
                    ParryParticleTransitionConfig.cycleShape();
                    status = "Particle shape: "
                            + ParryParticleTransitionConfig.shape().displayName()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 178, 18,
                Component.literal(
                        "Motion: " + ParryParticleTransitionConfig.motion().displayName()
                ),
                button -> {
                    ParryParticleTransitionConfig.cycleMotion();
                    status = "Particle motion: "
                            + ParryParticleTransitionConfig.motion().displayName()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 178, 18,
                Component.literal(
                        "Expansion: "
                                + ParryParticleTransitionConfig.mode().displayName()
                ),
                button -> {
                    ParryParticleTransitionConfig.cycleMode();
                    status = "Particle expansion easing: "
                            + ParryParticleTransitionConfig.mode().displayName()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 36, 18,
                Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustDurationTicks(-1);
                    status = "Particle duration: "
                            + ParryParticleTransitionConfig.durationTicks()
                            + " ticks.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 144, y, 94, 18,
                Component.literal(
                        "Duration: "
                                + ParryParticleTransitionConfig.durationTicks()
                                + "t"
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 244, y, 36, 18,
                Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustDurationTicks(1);
                    status = "Particle duration: "
                            + ParryParticleTransitionConfig.durationTicks()
                            + " ticks.";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 36, 18,
                Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustParticleCount(-1);
                    status = "Particle count: "
                            + ParryParticleTransitionConfig.particleCount()
                            + ".";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 144, y, 94, 18,
                Component.literal(
                        "Count: " + ParryParticleTransitionConfig.particleCount()
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 244, y, 36, 18,
                Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustParticleCount(1);
                    status = "Particle count: "
                            + ParryParticleTransitionConfig.particleCount()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 36, 18, Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustSize(-0.10F);
                    status = "Particle size: " + ParryParticleTransitionConfig.sizePercent() + "%.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 144, y, 94, 18,
                Component.literal("Size: " + ParryParticleTransitionConfig.sizePercent() + "%"),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 244, y, 36, 18, Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustSize(0.10F);
                    status = "Particle size: " + ParryParticleTransitionConfig.sizePercent() + "%.";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 178, 18,
                Component.literal(
                        ParryParticleTransitionConfig.dynamicColors()
                                ? "Dynamic Color: ON"
                                : "Dynamic Color: OFF"
                ),
                button -> {
                    ParryParticleTransitionConfig.toggleDynamicColors();
                    status = ParryParticleTransitionConfig.dynamicColors()
                            ? "Dynamic blade colors enabled."
                            : "Dynamic blade colors disabled.";
                    rebuild();
                },
                ParryParticleTransitionConfig::dynamicColors));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 102, y, 36, 18,
                Component.literal("-5%"),
                button -> {
                    ParryParticleTransitionConfig.adjustOpacity(-0.05F);
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 144, y, 94, 18,
                Component.literal(
                        "Opacity: " + ParryParticleTransitionConfig.opacityPercent() + "%"
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 244, y, 36, 18,
                Component.literal("+5%"),
                button -> {
                    ParryParticleTransitionConfig.adjustOpacity(0.05F);
                    rebuild();
                }));
    }

    private void addArmsPage() {
        int y = panelY + 140;
        addDefenseModeButtons(y);
        addFocusEditButton(y);
    }

    private void addWeaponsPage() {
        int y = panelY + 140;
        addDefenseModeButtons(y);
        addFocusEditButton(y);

        y += 30;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 170, 18,
                Component.literal("Main Weapon"),
                button -> {
                    weaponHand = WeaponHand.MAINHAND;
                    rebuild();
                },
                () -> weaponHand == WeaponHand.MAINHAND));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 194, y, 170, 18,
                Component.literal("Off Weapon"),
                button -> {
                    weaponHand = WeaponHand.OFFHAND;
                    rebuild();
                },
                () -> weaponHand == WeaponHand.OFFHAND));

        y += 30;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 58, y, 116, 18,
                Component.literal("Position"),
                button -> {
                    weaponTransformTab = WeaponTransformTab.POSITION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.POSITION));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 208, y, 116, 18,
                Component.literal("Rotation"),
                button -> {
                    weaponTransformTab = WeaponTransformTab.ROTATION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.ROTATION));
    }

    private void addFocusEditButton(int y) {
        addEditButton(y);
    }

    private void addEditButton(int y) {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 194, y, 170, 18,
                Component.literal("Edit"),
                button -> {
                    cancelConfirmations();
                    focusEdit = true;
                    uiHidden = false;
                    optionsOpen = false;
                    if (page == EditorPage.VIEW) {
                        page = EditorPage.ARMS;
                    }
                    rebuild();
                }));
    }

    private void addFocusEditor() {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX, panelY, 104, 18,
                Component.literal("← Exit Edit"),
                button -> {
                    focusEdit = false;
                    optionsOpen = false;
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 114, panelY, 196, 18,
                Component.literal(DualWieldPoseConfig.isEditorFirstPerson()
                        ? "First-Person ↔"
                        : "Third-Person ↔"),
                button -> setFirstPerson(!DualWieldPoseConfig.isEditorFirstPerson())));

        int modeY = panelY + 38;
        addFocusDefenseModeButtons(modeY);
        addStepCycleButton(panelX + 116, modeY, 82);
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 204, modeY, 102, 18,
                Component.literal(page == EditorPage.ARMS
                        ? "Edit: Arms ↔"
                        : "Edit: Weapons ↔"),
                button -> {
                    page = page == EditorPage.ARMS ? EditorPage.WEAPONS : EditorPage.ARMS;
                    optionsOpen = false;
                    rebuild();
                }));

        if (page == EditorPage.WEAPONS) {
            addFocusWeaponsPage();
        } else {
            page = EditorPage.ARMS;
            addFocusArmsPage();
        }

        addEditToolsArea();
    }

    private void addFocusDefenseModeButtons(int y) {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 50, 18,
                Component.literal("Parry"),
                button -> {
                    DualWieldPoseConfig.setEditorMode(DefenseAnimationSyncPayload.PARRY);
                    rebuild();
                },
                () -> DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY));
        if (canEditBlock()) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 60, y, 50, 18,
                    Component.literal("Block"),
                    button -> {
                        DualWieldPoseConfig.setEditorMode(DefenseAnimationSyncPayload.BLOCK);
                        rebuild();
                    },
                    () -> DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.BLOCK));
        }
    }

    private void addFocusArmsPage() {
        int mainY = panelY + 98;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 198, mainY - 34, 96, 18,
                Component.literal(pendingReset == ResetTarget.MAIN_ARM ? "Are you sure?" : "Reset"),
                button -> requestReset(ResetTarget.MAIN_ARM)));
        addFocusAdjustRow(AdjustKind.ARM, true, 0, mainY);
        addFocusAdjustRow(AdjustKind.ARM, true, 1, mainY + 24);
        addFocusAdjustRow(AdjustKind.ARM, true, 2, mainY + 48);

        int offY = mainY + 100;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 198, offY - 34, 96, 18,
                Component.literal(pendingReset == ResetTarget.OFF_ARM ? "Are you sure?" : "Reset"),
                button -> requestReset(ResetTarget.OFF_ARM)));
        addFocusAdjustRow(AdjustKind.ARM, false, 0, offY);
        addFocusAdjustRow(AdjustKind.ARM, false, 1, offY + 24);
        addFocusAdjustRow(AdjustKind.ARM, false, 2, offY + 48);
    }

    private void addFocusWeaponsPage() {
        int handY = panelY + 72;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 24, handY, 126, 18,
                Component.literal(weaponHand == WeaponHand.MAINHAND
                        ? "Main Weapon ↔"
                        : "Off Weapon ↔"),
                button -> {
                    weaponHand = weaponHand == WeaponHand.MAINHAND
                            ? WeaponHand.OFFHAND : WeaponHand.MAINHAND;
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 164, handY, 64, 18,
                Component.literal("Position"),
                button -> {
                    weaponTransformTab = WeaponTransformTab.POSITION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.POSITION));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 234, handY, 64, 18,
                Component.literal("Rotation"),
                button -> {
                    weaponTransformTab = WeaponTransformTab.ROTATION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.ROTATION));

        int y = panelY + 128;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 198, y - 30, 96, 18,
                Component.literal(pendingReset == ResetTarget.WEAPON ? "Are you sure?" : "Reset"),
                button -> requestReset(ResetTarget.WEAPON)));
        addFocusAdjustRow(AdjustKind.WEAPON, weaponHand == WeaponHand.MAINHAND, 0, y);
        addFocusAdjustRow(AdjustKind.WEAPON, weaponHand == WeaponHand.MAINHAND, 1, y + 24);
        addFocusAdjustRow(AdjustKind.WEAPON, weaponHand == WeaponHand.MAINHAND, 2, y + 48);
    }

    private void addFocusAdjustRow(AdjustKind kind, boolean mainHand, int axis, int y) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 218, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                kind, mainHand, axis, -1));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 266, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                kind, mainHand, axis, 1));
    }

    private void addEditToolsArea() {
        int y = page == EditorPage.ARMS
                ? panelY + 286
                : panelY + 208;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 66, y, 178, 18,
                Component.literal(optionsOpen ? "Edit Options ▲" : "Edit Options ▼"),
                button -> {
                    optionsOpen = !optionsOpen;
                    cancelConfirmations();
                    rebuild();
                }));

        if (!optionsOpen) return;
        y += 26;

        String copyModeText = DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY
                ? "Copy to Block"
                : "Copy to Parry";
        boolean blockEditingAvailable = canEditBlock();
        boolean firstPerson = DualWieldPoseConfig.isEditorFirstPerson();
        String copyLabel = firstPerson ? "Copy → 3P" : "Copy → 1P";
        String mirrorLabel = firstPerson ? "Mirror 3P" : "Mirror 1P";

        if (blockEditingAvailable) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 4, y, 100, 18, Component.literal(copyModeText), button -> copyToOther()));
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 108, y, 100, 18, Component.literal(copyLabel), button -> copyCurrentViewToOther()));
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 212, y, 100, 18, Component.literal(mirrorLabel), button -> copyOtherViewToCurrent()));
        } else {
            int startX = panelX + (uiPanelWidth() - 204) / 2;
            addRenderableWidget(new GyeokbuSmallButton(
                    startX, y, 100, 18, Component.literal(copyLabel), button -> copyCurrentViewToOther()));
            addRenderableWidget(new GyeokbuSmallButton(
                    startX + 104, y, 100, 18, Component.literal(mirrorLabel), button -> copyOtherViewToCurrent()));
        }

        y += 26;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 146, 18, Component.literal("Copy Pose"), button -> {
                    DualWieldPoseConfig.copyEditorStanceToClipboard();
                    rebuild();
                }));
        GyeokbuSmallButton paste = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 156, y, 150, 18,
                Component.literal(pendingPaste ? "Are you sure?" : "Paste Pose"),
                button -> requestPaste()));
        paste.active = DualWieldPoseConfig.hasStanceClipboard();
    }


    private void addDefenseModeButtons(int y) {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 78, 18,
                Component.literal("Parry"),
                button -> {
                    DualWieldPoseConfig.setEditorMode(DefenseAnimationSyncPayload.PARRY);
                    status = "Editing Dual Parry.";
                    rebuild();
                },
                () -> DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY));
        if (canEditBlock()) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 94, y, 78, 18,
                    Component.literal("Block"),
                    button -> {
                        DualWieldPoseConfig.setEditorMode(DefenseAnimationSyncPayload.BLOCK);
                        status = "Editing Dual Block.";
                        rebuild();
                    },
                    () -> DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.BLOCK));
        }
    }

    private void addToolsArea() {
        int y = getToolsY();
        addRenderableWidget(
                Button.builder(Component.literal(optionsOpen ? "Options ▲" : "Options ▼"), button -> {
                            optionsOpen = !optionsOpen;
                            cancelConfirmations();
                            rebuild();
                        })
                        .bounds(panelX + 102, y, 178, 20)
                        .build());

        if (!optionsOpen) return;
        y += 28;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 178, 18,
                Component.literal(pendingRevert ? "Are you sure?" : "Revert Saved"),
                button -> requestRevert()));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 194, y, 178, 18,
                Component.literal(pendingDefaultReset ? "Are you sure?" : "Reset Default"),
                button -> requestDefaultReset()));

        y += 34;
        GyeokbuSmallButton saveDefault = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 118, 18,
                Component.literal("Save as Default"),
                button -> performSave(DualWieldPoseConfig.saveAsDefault())));
        saveDefault.active = naturalStyle != ParryStyle.GENERIC
                && style == naturalStyle;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 132, y, 118, 18,
                Component.literal("Save to Main Weapon"),
                button -> performSave(DualWieldPoseConfig.saveToMainWeapon())));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 254, y, 118, 18,
                Component.literal("Save to This Pair"),
                button -> performSave(DualWieldPoseConfig.saveToThisPair())));

        if (DualWieldPoseConfig.hasMainWeaponSave() || DualWieldPoseConfig.hasPairSave()) {
            y += 26;
            if (DualWieldPoseConfig.hasMainWeaponSave() && DualWieldPoseConfig.hasPairSave()) {
                addRenderableWidget(new GyeokbuSmallButton(
                        panelX + 10, y, 174, 18,
                        Component.literal("Clear Main Weapon Save"),
                        button -> clearSave(DualWieldPoseConfig.clearMainWeaponSave())));
                addRenderableWidget(new GyeokbuSmallButton(
                        panelX + 198, y, 174, 18,
                        Component.literal("Clear Pair Save"),
                        button -> clearSave(DualWieldPoseConfig.clearPairSave())));
            } else if (DualWieldPoseConfig.hasMainWeaponSave()) {
                addRenderableWidget(new GyeokbuSmallButton(
                        panelX + 102, y, 178, 18,
                        Component.literal("Clear Main Weapon Save"),
                        button -> clearSave(DualWieldPoseConfig.clearMainWeaponSave())));
            } else {
                addRenderableWidget(new GyeokbuSmallButton(
                        panelX + 102, y, 178, 18,
                        Component.literal("Clear Pair Save"),
                        button -> clearSave(DualWieldPoseConfig.clearPairSave())));
            }
        }
    }

    private void performSave(AnimationPoseConfig.SaveResult result) {
        cancelConfirmations();
        if (result.success()) showSaveNotice(result.message());
        else status = result.message();
        rebuild();
    }

    private void clearSave(AnimationPoseConfig.SaveResult result) {
        status = result.message();
        if (result.success()) {
            DualWieldPoseConfig.revertToSavedDefault();
            style = DualWieldPoseConfig.getEditorStyle();
        }
        rebuild();
    }

    private int getToolsY() {
        return panelY + 236;
    }

    private int currentPanelHeight() {
        if (visualSection == VisualSection.PARTICLES) {
            return 304;
        }

        int base = (getToolsY() - panelY) + 48;
        if (!optionsOpen) return base;
        int extra = 62;
        if (DualWieldPoseConfig.hasMainWeaponSave() || DualWieldPoseConfig.hasPairSave()) {
            extra += 26;
        }
        return base + extra;
    }

    private int focusPanelHeight() {
        int base = page == EditorPage.ARMS ? 324 : 246;
        return optionsOpen ? base + 52 : base;
    }

    private void addDeveloperMessagesToggle() {
        int x = width - 124;
        int y = height - 30;

        addRenderableWidget(new GyeokbuSmallButton(
                x, y, 112, 18,
                Component.literal(
                        DeveloperMessageConfig.enabled()
                                ? "Dev Msg: ON"
                                : "Dev Msg: OFF"
                ),
                button -> {
                    DeveloperMessageConfig.toggleAndSync();
                    status = DeveloperMessageConfig.enabled()
                            ? "Developer messages enabled."
                            : "Developer messages disabled.";
                    rebuild();
                },
                DeveloperMessageConfig::enabled));
    }

    private void addInfoToggle() {
        previewX = width - previewWidth - 14;
        previewY = 12;
        addRenderableWidget(new GyeokbuSmallButton(
                previewX, previewY, 96, 18,
                Component.literal(infoOpen ? "Hide Info" : "Show Info"),
                button -> {
                    infoOpen = !infoOpen;
                    rebuild();
                }));
    }

    private void setFirstPerson(boolean firstPerson) {
        cancelConfirmations();
        DualWieldPoseConfig.setEditorFirstPerson(firstPerson);
        if (firstPerson) StanceEditorCamera.useFirstPersonPreview();
        else StanceEditorCamera.useThirdPersonPreview();
    }

    private void selectStyle(ParryStyle selectedStyle) {
        if (selectedStyle == null || selectedStyle == style) {
            styleDropdownOpen = false;
            return;
        }
        cancelConfirmations();
        style = selectedStyle;
        styleDropdownOpen = false;
        DualWieldPoseConfig.switchEditorStyle(style);
        status = "Previewing dual " + formatStyleName(style) + " stance.";
        rebuild();
    }

    private void addStepCycleButton(int x, int y, int width) {
        addRenderableWidget(new GyeokbuSmallButton(
                x, y, width, 18,
                Component.literal("Step: " + format(step) + " ↻"),
                button -> {
                    cycleStep();
                    status = "Adjustment step = " + format(step) + ".";
                    rebuild();
                }));
    }

    private void cycleStep() {
        if (Math.abs(step - 0.01F) < 0.0001F) step = 0.05F;
        else if (Math.abs(step - 0.05F) < 0.0001F) step = 0.10F;
        else step = 0.01F;
    }

    private boolean canEditBlock() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return false;
        }
        return GyeokbuEnchantments.hasBlockProvider(
                minecraft.player.level(),
                minecraft.player.getMainHandItem()
        );
    }

    private void enforceAvailableDefenseMode() {
        if (!canEditBlock()
                && DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.BLOCK) {
            DualWieldPoseConfig.setEditorMode(DefenseAnimationSyncPayload.PARRY);
        }
    }

    private void copyToOther() {
        cancelConfirmations();
        if (!canEditBlock()) {
            status = "Block editing requires Block or Perfect Block.";
            rebuild();
            return;
        }
        if (DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY) {
            DualWieldPoseConfig.copyParryToBlock();
            status = "Copied Dual Parry → Block.";
        } else {
            DualWieldPoseConfig.copyBlockToParry();
            status = "Copied Dual Block → Parry.";
        }
        rebuild();
    }

    private void copyCurrentViewToOther() {
        cancelConfirmations();
        if (DualWieldPoseConfig.isEditorFirstPerson()) {
            DualWieldPoseConfig.copyFirstPersonToThirdPerson();
            status = "Copied complete First-Person stance to Third-Person.";
        } else {
            DualWieldPoseConfig.copyThirdPersonToFirstPerson();
            status = "Copied complete Third-Person stance to First-Person.";
        }
        rebuild();
    }

    private void copyOtherViewToCurrent() {
        cancelConfirmations();
        if (DualWieldPoseConfig.isEditorFirstPerson()) {
            DualWieldPoseConfig.copyThirdPersonToFirstPerson();
            status = "Copied complete Third-Person stance to First-Person.";
        } else {
            DualWieldPoseConfig.copyFirstPersonToThirdPerson();
            status = "Copied complete First-Person stance to Third-Person.";
        }
        rebuild();
    }


    private void requestPaste() {
        if (!DualWieldPoseConfig.hasStanceClipboard()) {
            status = "Dual stance clipboard is empty.";
            return;
        }
        if (!pendingPaste) {
            pendingReset = ResetTarget.NONE;
            pendingRevert = false;
            pendingDefaultReset = false;
            pendingPaste = true;
            status = "Click Paste again to confirm.";
            rebuild();
            return;
        }
        AnimationPoseConfig.SaveResult result = DualWieldPoseConfig.pasteClipboardIntoEditor();
        status = result.message();
        pendingPaste = false;
        rebuild();
    }

    private void requestRevert() {
        if (!pendingRevert) {
            pendingReset = ResetTarget.NONE;
            pendingPaste = false;
            pendingDefaultReset = false;
            pendingRevert = true;
            status = "Reload the last saved dual stance? Click again to confirm.";
            rebuild();
            return;
        }
        AnimationPoseConfig.SaveResult result = DualWieldPoseConfig.revertToSavedDefault();
        status = result.message();
        pendingRevert = false;
        rebuild();
    }

    private void requestDefaultReset() {
        if (!pendingDefaultReset) {
            pendingReset = ResetTarget.NONE;
            pendingPaste = false;
            pendingRevert = false;
            pendingDefaultReset = true;
            status = "Reset loads the official shipped dual stance for this loadout/category and view. Click again to confirm.";
            rebuild();
            return;
        }
        AnimationPoseConfig.SaveResult result =
                DualWieldPoseConfig.resetEditorToBundledDefault();
        status = result.message();
        pendingDefaultReset = false;
        rebuild();
    }

    private void requestReset(ResetTarget target) {
        if (pendingReset != target) {
            pendingPaste = false;
            pendingRevert = false;
            pendingDefaultReset = false;
            pendingReset = target;
            status = "Click Are you sure? to confirm reset.";
            rebuild();
            return;
        }

        switch (target) {
            case MAIN_ARM -> DualWieldPoseConfig.resetEditorArm(true);
            case OFF_ARM -> DualWieldPoseConfig.resetEditorArm(false);
            case WEAPON -> DualWieldPoseConfig.resetEditorWeapon(weaponHand == WeaponHand.MAINHAND);
            case NONE -> { }
        }
        pendingReset = ResetTarget.NONE;
        status = "Reset complete.";
        rebuild();
    }

    private void cancelConfirmations() {
        pendingReset = ResetTarget.NONE;
        pendingPaste = false;
        pendingRevert = false;
        pendingDefaultReset = false;
    }

    private String formatTransitionMode() {
        return DefenseTransitionConfig.mode().displayName();
    }

    private void showSaveNotice(String message) {
        saveNotice = message;
        saveNoticeTicks = SAVE_NOTICE_TICKS;
        status = message;
    }

    @Override
    public void tick() {
        super.tick();
        if (saveNoticeTicks > 0 && --saveNoticeTicks == 0) saveNotice = "";
        if (heldAdjust == null) return;
        heldTicks++;
        if (heldTicks >= HOLD_DELAY_TICKS
                && (heldTicks - HOLD_DELAY_TICKS) % HOLD_REPEAT_TICKS == 0) {
            applyAdjustment(heldAdjust);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && styleDropdownOpen) {
            int index = getDropdownStyleIndexAt(mouseX, mouseY);
            if (index >= 0 && index < availableStyles.size()) {
                selectStyle(availableStyles.get(index));
                return true;
            }
            if (styleDropdownButton == null || !styleDropdownButton.isMouseOver(mouseX, mouseY)) {
                styleDropdownOpen = false;
                rebuild();
                return true;
            }
        }

        if (button == 0) {
            for (AdjustHitbox hitbox : adjustHitboxes) {
                if (hitbox.contains(mouseX, mouseY)) {
                    heldAdjust = hitbox;
                    heldTicks = 0;
                    applyAdjustment(hitbox);
                    return true;
                }
            }
        }

        if (button == 1
                && !DualWieldPoseConfig.isEditorFirstPerson()
                && (uiHidden || !isPointerOverInteractiveControl(mouseX, mouseY))) {
            orbitHeld = true;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 1 && orbitHeld) {
            StanceEditorCamera.orbit(dragX, dragY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            heldAdjust = null;
            heldTicks = 0;
        }
        if (button == 1) orbitHeld = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (styleDropdownOpen && isMouseOverStyleDropdown(mouseX, mouseY)) {
            int maxOffset = Math.max(0, availableStyles.size() - STYLE_DROPDOWN_VISIBLE_ROWS);
            if (scrollY < 0.0D) styleDropdownOffset = Math.min(maxOffset, styleDropdownOffset + 1);
            else if (scrollY > 0.0D) styleDropdownOffset = Math.max(0, styleDropdownOffset - 1);
            return true;
        }
        StanceEditorCamera.zoom(scrollY);
        return true;
    }

    private boolean isPointerOverInteractiveControl(double mouseX, double mouseY) {
        for (var child : children()) if (child.isMouseOver(mouseX, mouseY)) return true;
        for (AdjustHitbox hitbox : adjustHitboxes) if (hitbox.contains(mouseX, mouseY)) return true;
        return false;
    }

    private void applyAdjustment(AdjustHitbox hitbox) {
        float amount = hitbox.direction() * step;
        if (hitbox.kind() == AdjustKind.ARM) {
            DualWieldPoseConfig.adjustEditorArm(hitbox.mainHand(), hitbox.axis(), amount);
        } else if (weaponTransformTab == WeaponTransformTab.POSITION) {
            DualWieldPoseConfig.adjustEditorWeaponPosition(hitbox.mainHand(), hitbox.axis(), amount);
        } else {
            DualWieldPoseConfig.adjustEditorWeaponRotation(hitbox.mainHand(), hitbox.axis(), amount);
        }
        status = "Dual-wield preview updated.";
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        if (exitConfirmationOpen) {
            renderExitConfirmation(graphics);
            super.render(graphics, mouseX, mouseY, partialTick);
            return;
        }

        if (focusEdit) {
            renderFocusPanel(graphics);
            renderAdjustButtons(graphics);
        } else if (!uiHidden) {
            renderControlPanel(graphics);
            if (visualSection == VisualSection.STANCES && infoOpen) renderInfoPanel(graphics);
        }

        super.render(graphics, mouseX, mouseY, partialTick);

        if (!focusEdit && !uiHidden && styleDropdownOpen) {
            renderStyleDropdown(graphics, mouseX, mouseY);
        }
        renderSaveNotice(graphics);
        renderDelayedTooltip(graphics, mouseX, mouseY);
    }

    private void renderControlPanel(GuiGraphics graphics) {
        int h = currentPanelHeight();
        graphics.fill(panelX - 4, panelY - 4,
                panelX + uiPanelWidth() + 4, panelY + h, 0xA8121212);
        graphics.fill(panelX, panelY + 52,
                panelX + uiPanelWidth(), panelY + 53, 0x70FFFFFF);

        if (visualSection == VisualSection.STANCES) {
            graphics.fill(panelX, panelY + 108,
                    panelX + uiPanelWidth(), panelY + 109, 0x70FFFFFF);
            renderViewValues(graphics);
            if (optionsOpen) renderSaveDivider(graphics);
        }

        renderStatusBar(graphics, h);
    }

    private void renderViewValues(GuiGraphics graphics) {
        graphics.drawString(font,
                (DualWieldPoseConfig.isEditorFirstPerson() ? "FIRST-PERSON" : "THIRD-PERSON")
                        + " | "
                        + (DualWieldPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY
                        ? "PARRY" : "BLOCK"),
                panelX + 10, panelY + 138, 0xD0D0D0);
    }

    private void renderArmValues(GuiGraphics graphics) {
        AnimationPoseConfig.ArmPose pose = DualWieldPoseConfig.getEditorPose();
        if (pose == null) return;
        int mainY = panelY + 182;
        graphics.drawString(font, "MAINHAND ARM", panelX + 12, mainY - 18, 0xFFFFFF);
        drawAxis(graphics, "X", pose.mainHand().getX(), mainY);
        drawAxis(graphics, "Y", pose.mainHand().getY(), mainY + 20);
        drawAxis(graphics, "Z", pose.mainHand().getZ(), mainY + 40);

        int offY = panelY + 254;
        graphics.drawString(font, "OFFHAND ARM", panelX + 12, offY - 18, 0xFFFFFF);
        drawAxis(graphics, "X", pose.offHand().getX(), offY);
        drawAxis(graphics, "Y", pose.offHand().getY(), offY + 20);
        drawAxis(graphics, "Z", pose.offHand().getZ(), offY + 40);
    }

    private void renderWeaponValues(GuiGraphics graphics) {
        boolean main = weaponHand == WeaponHand.MAINHAND;
        Vec3f value = weaponTransformTab == WeaponTransformTab.POSITION
                ? DualWieldPoseConfig.getEditorWeaponPosition(main)
                : DualWieldPoseConfig.getEditorWeaponRotation(main);
        if (value == null) return;
        int y = panelY + 238;
        graphics.drawString(font,
                (main ? "MAIN WEAPON" : "OFF WEAPON") + " | "
                        + (weaponTransformTab == WeaponTransformTab.POSITION ? "POSITION" : "ROTATION"),
                panelX + 12, y - 18, 0xFFFFFF);
        drawAxis(graphics, "X", value.getX(), y);
        drawAxis(graphics, "Y", value.getY(), y + 20);
        drawAxis(graphics, "Z", value.getZ(), y + 40);
    }

    private void renderFocusPanel(GuiGraphics graphics) {
        int h = focusPanelHeight();
        graphics.fill(panelX - 4, panelY - 4,
                panelX + uiFocusPanelWidth() + 4, panelY + h, 0xB8121212);
        graphics.drawCenteredString(font,
                false ? "LINKED DUAL WORKSPACE" : "DUAL EDIT",
                panelX + uiFocusPanelWidth() / 2, panelY + 23,
                false ? 0xFFF2C14E : 0xFFD0D0D0);

        if (page == EditorPage.ARMS) {
            AnimationPoseConfig.ArmPose pose = DualWieldPoseConfig.getEditorPose();
            if (pose == null) return;
            int mainY = panelY + 98;
            graphics.drawString(font, "MAINHAND ARM", panelX + 12, mainY - 18, 0xFFFFFF);
            drawFocusAxis(graphics, "X", pose.mainHand().getX(), mainY);
            drawFocusAxis(graphics, "Y", pose.mainHand().getY(), mainY + 24);
            drawFocusAxis(graphics, "Z", pose.mainHand().getZ(), mainY + 48);
            int offY = mainY + 100;
            graphics.drawString(font, "OFFHAND ARM", panelX + 12, offY - 18, 0xFFFFFF);
            drawFocusAxis(graphics, "X", pose.offHand().getX(), offY);
            drawFocusAxis(graphics, "Y", pose.offHand().getY(), offY + 24);
            drawFocusAxis(graphics, "Z", pose.offHand().getZ(), offY + 48);
        } else {
            boolean main = weaponHand == WeaponHand.MAINHAND;
            Vec3f value = weaponTransformTab == WeaponTransformTab.POSITION
                    ? DualWieldPoseConfig.getEditorWeaponPosition(main)
                    : DualWieldPoseConfig.getEditorWeaponRotation(main);
            if (value == null) return;
            int y = panelY + 128;
            graphics.drawString(font,
                    (main ? "MAIN WEAPON" : "OFF WEAPON") + " | "
                            + (weaponTransformTab == WeaponTransformTab.POSITION ? "POSITION" : "ROTATION"),
                    panelX + 12, y - 18, 0xFFFFFF);
            drawFocusAxis(graphics, "X", value.getX(), y);
            drawFocusAxis(graphics, "Y", value.getY(), y + 24);
            drawFocusAxis(graphics, "Z", value.getZ(), y + 48);
        }
    }

    private void renderInfoPanel(GuiGraphics graphics) {
        graphics.fill(previewX - 6, previewY + 24,
                previewX + previewWidth + 6, previewY + 142, 0x98121212);
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) return;
        WeaponProfile main = WeaponClassifier.classify(minecraft.player.getMainHandItem());
        WeaponProfile off = WeaponClassifier.classify(minecraft.player.getOffhandItem());
        drawInfo(graphics, "MAIN", main.weaponType().name(), previewY + 34, ChatFormatting.GOLD);
        drawInfo(graphics, "OFF", off.weaponType().name(), previewY + 52, ChatFormatting.AQUA);
        drawInfo(graphics, "STANCE", formatStyleName(style), previewY + 76, ChatFormatting.LIGHT_PURPLE);
        drawInfo(graphics, "LINKED", false ? "ON" : "OFF",
                previewY + 94,
                false ? ChatFormatting.GREEN : ChatFormatting.GRAY);
        drawInfo(graphics, "LOADOUT", DualWieldRules.isDualWield(minecraft.player) ? "VALID" : "INVALID",
                previewY + 112,
                DualWieldRules.isDualWield(minecraft.player) ? ChatFormatting.GREEN : ChatFormatting.RED);
    }

    private void drawInfo(GuiGraphics graphics, String label, String value, int y, ChatFormatting color) {
        graphics.drawString(font, Component.literal(label + ":").withStyle(ChatFormatting.DARK_GRAY),
                previewX, y, 0xFFFFFF);
        graphics.drawString(font, Component.literal(value).withStyle(ChatFormatting.BOLD, color),
                previewX + 66, y, 0xFFFFFF);
    }

    private void renderSaveDivider(GuiGraphics graphics) {
        int y = getToolsY() + 56;
        String label = "SAVE";
        int labelWidth = font.width(label);
        int center = panelX + uiPanelWidth() / 2;
        graphics.fill(panelX + 10, y, center - labelWidth / 2 - 8, y + 1, 0x50FFFFFF);
        graphics.fill(center + labelWidth / 2 + 8, y, panelX + uiPanelWidth() - 10, y + 1, 0x50FFFFFF);
        graphics.drawCenteredString(font, label, center, y - 4, 0xFFB8B8B8);
    }

    private void renderStatusBar(GuiGraphics graphics, int panelHeight) {
        int dividerY = panelY + panelHeight - 24;
        graphics.fill(panelX + 6, dividerY,
                panelX + uiPanelWidth() - 6, dividerY + 1, 0x40FFFFFF);
        String message = status.isEmpty()
                ? (visualSection == VisualSection.PARTICLES
                ? "Parry particle expansion"
                : "Editing: Dual " + formatStyleName(style) + " stance")
                : status;
        graphics.drawString(font, fitTextToWidth(message, uiPanelWidth() - 18),
                panelX + 8, dividerY + 7, 0xD0D0D0);
    }

    private void renderAdjustButtons(GuiGraphics graphics) {
        for (AdjustHitbox hitbox : adjustHitboxes) {
            graphics.fill(hitbox.x(), hitbox.y(),
                    hitbox.x() + hitbox.width(), hitbox.y() + hitbox.height(), 0xD0404040);
            graphics.drawCenteredString(font,
                    hitbox.direction() < 0 ? "-" : "+",
                    hitbox.x() + hitbox.width() / 2,
                    hitbox.y() + 5,
                    0xFFFFFF);
        }
    }

    private void drawAxis(GuiGraphics graphics, String axis, float value, int y) {
        graphics.drawString(font, axis, panelX + 18, y, 0xD0D0D0);
        graphics.drawString(font, format(value), panelX + 154, y, 0xFFFFFF);
    }

    private void drawFocusAxis(GuiGraphics graphics, String axis, float value, int y) {
        graphics.drawString(font, axis, panelX + 18, y, 0xD0D0D0);
        graphics.drawString(font, format(value), panelX + 156, y, 0xFFFFFF);
    }

    private void renderStyleDropdown(GuiGraphics graphics, int mouseX, int mouseY) {
        int x = getStyleDropdownX();
        int y = getStyleDropdownMenuY();
        int visible = Math.min(STYLE_DROPDOWN_VISIBLE_ROWS, availableStyles.size() - styleDropdownOffset);
        if (visible <= 0) return;
        int menuHeight = visible * STYLE_DROPDOWN_ROW_HEIGHT;

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 300.0F);
        graphics.fill(x - 2, y - 2, x + STYLE_DROPDOWN_WIDTH + 2, y + menuHeight + 2, 0xE8000000);
        graphics.fill(x - 1, y - 1, x + STYLE_DROPDOWN_WIDTH + 1, y + menuHeight + 1, 0xE84A4A4A);
        graphics.fill(x, y, x + STYLE_DROPDOWN_WIDTH, y + menuHeight, 0xE8121212);

        graphics.enableScissor(x, y, x + STYLE_DROPDOWN_WIDTH, y + menuHeight);
        for (int row = 0; row < visible; row++) {
            int index = styleDropdownOffset + row;
            ParryStyle option = availableStyles.get(index);
            int rowY = y + row * STYLE_DROPDOWN_ROW_HEIGHT;
            boolean hovered = mouseX >= x && mouseX < x + STYLE_DROPDOWN_WIDTH
                    && mouseY >= rowY && mouseY < rowY + STYLE_DROPDOWN_ROW_HEIGHT;
            if (hovered || option == style) {
                graphics.fill(x + 1, rowY + 1,
                        x + STYLE_DROPDOWN_WIDTH - 1, rowY + STYLE_DROPDOWN_ROW_HEIGHT - 1,
                        hovered ? 0xE83A3A3A : 0xFF303030);
            }
            graphics.drawString(font,
                    (option == style ? "• " : "  ") + formatStyleName(option),
                    x + 8, rowY + 5,
                    option == style ? 0xFFF2C14E : 0xFFFFFFFF,
                    false);
        }
        graphics.disableScissor();

        if (availableStyles.size() > STYLE_DROPDOWN_VISIBLE_ROWS) {
            int trackLeft = x + STYLE_DROPDOWN_WIDTH - 8;
            int trackRight = x + STYLE_DROPDOWN_WIDTH - 3;
            graphics.fill(trackLeft, y + 2, trackRight, y + menuHeight - 2, 0xFF1E1E1E);
            int maxOffset = Math.max(1, availableStyles.size() - visible);
            int thumbHeight = Math.max(14,
                    (int) Math.floor((menuHeight - 4) * (visible / (double) availableStyles.size())));
            int usable = Math.max(1, (menuHeight - 4) - thumbHeight);
            int thumbTop = y + 2 + (int) Math.round(usable * (styleDropdownOffset / (double) maxOffset));
            graphics.fill(trackLeft, thumbTop, trackRight, thumbTop + thumbHeight, 0xFF8A8A8A);
        }

        graphics.pose().popPose();
    }

    private int getStyleDropdownX() { return panelX + 128; }
    private int getStyleDropdownMenuY() { return panelY + 22; }

    private boolean isMouseOverStyleDropdown(double mouseX, double mouseY) {
        int visible = Math.min(STYLE_DROPDOWN_VISIBLE_ROWS, availableStyles.size() - styleDropdownOffset);
        return mouseX >= getStyleDropdownX()
                && mouseX < getStyleDropdownX() + STYLE_DROPDOWN_WIDTH
                && mouseY >= getStyleDropdownMenuY()
                && mouseY < getStyleDropdownMenuY() + visible * STYLE_DROPDOWN_ROW_HEIGHT;
    }

    private int getDropdownStyleIndexAt(double mouseX, double mouseY) {
        if (!isMouseOverStyleDropdown(mouseX, mouseY)) return -1;
        int row = (int) ((mouseY - getStyleDropdownMenuY()) / STYLE_DROPDOWN_ROW_HEIGHT);
        return styleDropdownOffset + row;
    }

    private void ensureSelectedStyleVisible() {
        int index = availableStyles.indexOf(style);
        if (index < 0) return;
        if (index < styleDropdownOffset) styleDropdownOffset = index;
        else if (index >= styleDropdownOffset + STYLE_DROPDOWN_VISIBLE_ROWS) {
            styleDropdownOffset = Math.max(0, index - STYLE_DROPDOWN_VISIBLE_ROWS + 1);
        }
    }

    private void renderSaveNotice(GuiGraphics graphics) {
        if (saveNotice.isEmpty() || saveNoticeTicks <= 0) return;
        int textWidth = font.width(saveNotice);
        int x = width / 2 - textWidth / 2;
        int y = 10;
        graphics.fill(x - 7, y - 5, x + textWidth + 7, y + 14, 0xE0101010);
        graphics.drawString(font,
                Component.literal(saveNotice).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                x, y, 0xFFFFFFFF);
    }

    private void renderDelayedTooltip(GuiGraphics graphics, int mouseX, int mouseY) {
        TooltipContent tooltip = findTooltipAt(mouseX, mouseY);
        if (tooltip == null) {
            hoveredTooltipKey = "";
            tooltipHoverStartNanos = 0L;
            return;
        }
        long now = System.nanoTime();
        if (!tooltip.key().equals(hoveredTooltipKey)) {
            hoveredTooltipKey = tooltip.key();
            tooltipHoverStartNanos = now;
            return;
        }
        if (now - tooltipHoverStartNanos < TOOLTIP_DELAY_NANOS) return;
        renderTooltipBox(graphics, mouseX, mouseY, tooltip.lines());
    }

    private TooltipContent findTooltipAt(double mouseX, double mouseY) {
        if (!uiHidden && styleDropdownOpen && isMouseOverStyleDropdown(mouseX, mouseY)) {
            int index = getDropdownStyleIndexAt(mouseX, mouseY);
            if (index >= 0 && index < availableStyles.size()) {
                ParryStyle option = availableStyles.get(index);
                return tip("style:" + option.name(),
                        "Preview the Dual " + formatStyleName(option) + " stance.",
                        "Use a weapon-specific save to borrow it.");
            }
        }

        for (AdjustHitbox hitbox : adjustHitboxes) {
            if (hitbox.contains(mouseX, mouseY)) {
                String axis = hitbox.axis() == 0 ? "X" : hitbox.axis() == 1 ? "Y" : "Z";
                String direction = hitbox.direction() < 0 ? "Decrease" : "Increase";
                String target = hitbox.kind() == AdjustKind.ARM
                        ? (hitbox.mainHand() ? "main-hand arm" : "off-hand arm")
                        : (hitbox.mainHand() ? "main weapon" : "off weapon");
                return tip("adjust:" + hitbox, direction + " " + target + " " + axis + ".",
                        "Uses the selected step size.");
            }
        }

        for (var child : children()) {
            if (child instanceof AbstractWidget widget && widget.isMouseOver(mouseX, mouseY)) {
                TooltipContent tooltip = tooltipForWidget(widget);
                if (tooltip != null) return tooltip;
            }
        }
        return null;
    }

    private TooltipContent tooltipForWidget(AbstractWidget widget) {
        String t = widget.getMessage().getString().trim();
        if (t.startsWith("[ ")) return tip("stance-selector", "Choose a detected dual-wield stance to preview.");
        if (t.equals("• STANCES")) return tip("stances-heading", "Edit defensive stances. Click to open Parry Particles.");
        if (t.equals("• PARRY PARTICLES")) return tip("particles-heading", "Edit successful-Parry particle motion. Click to return to Stances.");
        if (t.equals("VIEW")) return tip("view", "Preview the stance and transition settings.");
        if (t.equals("ARMS")) return tip("arms", "Inspect both arm poses. Use Edit to adjust them.");
        if (t.equals("WEAPONS")) return tip("weapons", "Inspect both weapon transforms. Use Edit to adjust them.");
        if (t.equals("Edit Third-Person")) return tip("3p", "Edit the stance seen from outside your character.", "Other players see this view too.");
        if (t.equals("Edit First-Person")) return tip("1p", "Edit the stance seen through your own camera.");
        if (t.equals("Edit")) return tip("focus", "Open a clear +/- editing view.");
        if (t.equals("← Exit Edit")) return tip("exit-focus", "Return to the full F8 controls.");
        if (t.equals("Third-Person ↔") || t.equals("First-Person ↔")) return tip("view-cycle", "Switch between First- and Third-Person preview.");
        if (t.equals("Edit: Arms ↔") || t.equals("Edit: Weapons ↔")) return tip("target-cycle", "Switch Edit between arms and weapons.");
        if (t.equals("Main Weapon ↔") || t.equals("Off Weapon ↔")) return tip("weapon-cycle", "Switch which held weapon you are adjusting.");
        if (t.equals("Main Weapon")) return tip("main-weapon", "Inspect the main-hand weapon transform.");
        if (t.equals("Off Weapon")) return tip("off-weapon", "Inspect the off-hand weapon transform.");
        if (t.equals("Parry")) return tip("parry", "Edit the pose used during the Parry window.");
        if (t.equals("Block")) return tip("block", "Edit the pose used while Blocking.");
        if (t.startsWith("Step:")) return tip("step", "Cycle how much each +/- press changes a value.", "0.01 = fine, 0.10 = large.");
        if (t.equals("Position")) return tip("position", "Move the selected weapon without rotating it.");
        if (t.equals("Rotation")) return tip("rotation", "Rotate the selected weapon without moving it.");
        if (t.equals("Reset Camera")) return tip("camera", "Return the preview camera to its default view.");
        if (t.startsWith("Transition:")) return tip("transition", "Choose how smoothly the stance moves in and out.");
        if (t.startsWith("Shape:")) return tip("particle-shape", "Cycle the outward shape of the Parry spark burst.");
        if (t.startsWith("Motion:")) return tip("particle-motion", "Choose whether Parry sparks expand, fall with gravity, or do both.");
        if (t.startsWith("Expansion:")) return tip("particle-expansion", "Choose the easing curve used when sparks expand.");
        if (t.startsWith("Dynamic Color:")) return tip("particle-dynamic-color", "Use sampled blade colors from the held weapon.", "Dark and brown handle-like colors are filtered out.");
        if (t.startsWith("Count:")) return tip("particle-count", "Set the number of sparks created on a successful Parry.", "Range: 1-32; placement logic is unchanged.");
        if (t.startsWith("Opacity:")) return tip("particle-opacity", "Set the constant opacity of successful-Parry sparks.");
        if (t.equals("-5%")) return tip("particle-opacity-minus", "Reduce particle opacity by 5%.");
        if (t.equals("+5%")) return tip("particle-opacity-plus", "Increase particle opacity by 5%.");
        if (t.startsWith("Duration:")) return visualSection == VisualSection.PARTICLES
                ? tip("particle-duration", "How long the Parry particle animation lasts.", "1 tick = 0.05 seconds.")
                : tip("duration", "How long the stance transition takes.", "1 tick = 0.05 seconds.");
        if (t.equals("-") && visualSection == VisualSection.PARTICLES) {
            return widget.getY() == panelY + 180
                    ? tip("particle-count-minus", "Use one fewer spark on successful Parry.")
                    : tip("particle-duration-minus", "Shorten the particle animation by 1 tick.");
        }
        if (t.equals("+") && visualSection == VisualSection.PARTICLES) {
            return widget.getY() == panelY + 180
                    ? tip("particle-count-plus", "Use one more spark on successful Parry.")
                    : tip("particle-duration-plus", "Lengthen the particle animation by 1 tick.");
        }
        if (t.startsWith("Options")) return tip("options", "Open save and restore tools.");
        if (t.startsWith("Edit Options")) return tip("edit-options", "Open copy and pose-editing tools.");
        if (t.equals("Copy to Block")) return tip("copy-block", "Copy the current Parry pose into Block.");
        if (t.equals("Copy to Parry")) return tip("copy-parry", "Copy the current Block pose into Parry.");
        if (t.equals("Copy to First-Person")) return tip("copy-1p", "Copy both arm poses into First-Person.", "First-Person weapon transforms reset to neutral.");
        if (t.equals("Copy to Third-Person")) return tip("copy-3p", "Copy both arm poses into Third-Person.", "Third-Person weapon transforms reset to neutral.");
        if (t.equals("Copy Pose")) return tip("copy-pose", "Copy the complete dual stance for pasting elsewhere.");
        if (t.equals("Paste Pose")) return tip("paste", "Paste the copied dual stance into this workspace.");
        if (t.equals("Revert Saved")) return tip("revert", "Discard edits and reload the last saved stance for this loadout.");
        if (t.equals("Reset Default")) return tip("reset-default", "Load the official stance bundled inside Gyeokbu.", "Saved files are unchanged until you choose a Save action.");
        if (t.equals("Save as Default")) {
            if (!widget.active) return tip("default-disabled", "This is not the main weapon's natural stance.", "Use Main Weapon or This Pair instead.");
            return tip("save-default", "Use this stance for this dual-wield style by default.");
        }
        if (t.equals("Save to Main Weapon")) return tip("save-main", "Use this stance whenever this main-hand weapon is dual wielded.");
        if (t.equals("Save to This Pair")) return tip("save-pair", "Use this stance only with this exact two-weapon combination.", "Pair saves override Main Weapon and Default saves.");
        if (t.equals("Clear Main Weapon Save")) return tip("clear-main", "Remove the dual stance saved to this main weapon.");
        if (t.equals("Clear Pair Save")) return tip("clear-pair", "Remove the dual stance saved to this exact weapon pair.");
        if (t.equals("Reset")) return tip("reset", "Reset this section to neutral values.");
        if (t.equals("Are you sure?")) return tip("confirm", "Click again to confirm.");
        if (t.equals("Hide Info")) return tip("hide-info", "Hide the detected dual-wield information panel.");
        if (t.equals("Show Info")) return tip("show-info", "Show the detected dual-wield information panel.");
        if (t.equals("X")) return tip("close", "Close the F8 editor.");
        return null;
    }

    private TooltipContent tip(String key, String... lines) {
        return new TooltipContent(key, List.of(lines));
    }

    private void renderTooltipBox(GuiGraphics graphics, int mouseX, int mouseY, List<String> lines) {
        if (lines == null || lines.isEmpty()) return;
        int maxWidth = 0;
        for (String line : lines) maxWidth = Math.max(maxWidth, font.width(line));
        int boxWidth = maxWidth + TOOLTIP_PADDING * 2;
        int lineHeight = font.lineHeight;
        int boxHeight = TOOLTIP_PADDING * 2
                + lines.size() * lineHeight
                + Math.max(0, lines.size() - 1) * TOOLTIP_LINE_GAP;

        boolean left = mouseX + boxWidth > width;
        boolean above = mouseY + boxHeight > height;
        int x = left ? mouseX - boxWidth : mouseX;
        int y = above ? mouseY - boxHeight : mouseY;
        x = Math.max(0, Math.min(width - boxWidth, x));
        y = Math.max(0, Math.min(height - boxHeight, y));

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 400.0F);
        graphics.fill(x, y, x + boxWidth, y + boxHeight, 0xF0181818);
        graphics.fill(x, y, x + boxWidth, y + 1, 0xFF707070);
        graphics.fill(x, y + boxHeight - 1, x + boxWidth, y + boxHeight, 0xFF707070);
        graphics.fill(x, y, x + 1, y + boxHeight, 0xFF707070);
        graphics.fill(x + boxWidth - 1, y, x + boxWidth, y + boxHeight, 0xFF707070);
        int textY = y + TOOLTIP_PADDING;
        for (String line : lines) {
            graphics.drawString(font, line, x + TOOLTIP_PADDING, textY, 0xFFFFFFFF, false);
            textY += lineHeight + TOOLTIP_LINE_GAP;
        }
        graphics.pose().popPose();
    }

    private void addExitConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;
        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126, centerY + 24, 118, 20,
                Component.literal("Yes, Leave"),
                button -> closeEditorImmediately()));
        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8, centerY + 24, 118, 20,
                Component.literal("No, Stay"),
                button -> {
                    exitConfirmationOpen = false;
                    rebuild();
                }));
    }

    private void renderExitConfirmation(GuiGraphics graphics) {
        int centerX = width / 2;
        int centerY = height / 2;
        int boxWidth = 286;
        int left = centerX - boxWidth / 2;
        int top = centerY - 42;
        graphics.fill(left, top, left + boxWidth, centerY + 54, 0xF0181818);
        graphics.drawCenteredString(font, "Unsaved changes", centerX, top + 13, 0xFFFFD76A);
        graphics.drawCenteredString(font, "Leave F8 without saving them?", centerX, top + 29, 0xFFFFFFFF);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (exitConfirmationOpen) {
            exitConfirmationOpen = false;
            rebuild();
            return;
        }
        if (DualWieldPoseConfig.hasUnsavedEditorChanges()) {
            exitConfirmationOpen = true;
            orbitHeld = false;
            heldAdjust = null;
            init();
            return;
        }
        closeEditorImmediately();
    }

    private void closeEditorImmediately() {
        exitConfirmationOpen = false;
        orbitHeld = false;
        heldAdjust = null;
        StanceEditorCamera.end();
        DualWieldPoseConfig.endEditor();
        super.onClose();
    }

    @Override
    public void removed() {
        orbitHeld = false;
        heldAdjust = null;
        StanceEditorCamera.end();
        DualWieldPoseConfig.endEditor();
        super.removed();
    }

    private String fitTextToWidth(String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        String ellipsis = "...";
        int allowed = maxWidth - font.width(ellipsis);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            if (font.width(out.toString() + text.charAt(i)) > allowed) break;
            out.append(text.charAt(i));
        }
        return out + ellipsis;
    }

    private static String formatStyleName(ParryStyle value) {
        if (value == null || value == ParryStyle.GENERIC) return "Fallback";
        String[] words = value.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (!result.isEmpty()) result.append(' ');
            result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return result.toString();
    }

    private static String format(float value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private enum VisualSection { STANCES, SUCCESS_PARRY, PARTICLES }

    private enum EditorPage { VIEW, ARMS, WEAPONS }
    private enum WeaponHand { MAINHAND, OFFHAND }
    private enum WeaponTransformTab { POSITION, ROTATION }
    private enum AdjustKind { ARM, WEAPON }
    private enum ResetTarget { NONE, MAIN_ARM, OFF_ARM, WEAPON }

    private record TooltipContent(String key, List<String> lines) { }

    private record AdjustHitbox(
            int x,
            int y,
            int width,
            int height,
            AdjustKind kind,
            boolean mainHand,
            int axis,
            int direction
    ) {
        private boolean contains(double mouseX, double mouseY) {
            return mouseX >= x && mouseX < x + width
                    && mouseY >= y && mouseY < y + height;
        }
    }
}
