package com.wckd.gyeokbu.client;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;

/**
 * Client-only one-frame presentation freeze for a local Successful Parry.
 *
 * The game world and Successful Parry runtime continue progressing normally.
 * The just-rendered start frame is captured once and displayed over the next
 * frame for exactly one-and-a-half client ticks (75 ms). This creates a hit-stop-like
 * impact without pausing simulation, animation time, or networking.
 */
@EventBusSubscriber(
        modid = com.wckd.gyeokbu.GyeokbuV2.MODID,
        value = Dist.CLIENT
)
public final class ClientSuccessImpactFreeze {

    private static final double FREEZE_TICKS = 1.5D;
    private static final long NANOS_PER_TICK = 50_000_000L;
    private static final long FREEZE_NANOS = Math.round(FREEZE_TICKS * NANOS_PER_TICK);

    private static boolean capturePending;
    private static long activeUntilNanos;
    private static ResourceLocation textureLocation;
    private static DynamicTexture texture;
    private static int textureWidth;
    private static int textureHeight;

    private ClientSuccessImpactFreeze() {
    }

    /** Request a one-and-a-half-tick freeze for the local player's next rendered Success start frame. */
    public static void request() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null
                || minecraft.level == null
                || minecraft.screen != null) {
            return;
        }

        capturePending = true;
    }

    @SubscribeEvent
    public static void onRenderFramePost(RenderFrameEvent.Post event) {
        if (!capturePending) {
            return;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null
                || minecraft.level == null
                || minecraft.screen != null) {
            capturePending = false;
            return;
        }

        capturePending = false;
        replaceCapturedFrame(minecraft);
        if (textureLocation != null) {
            activeUntilNanos = System.nanoTime() + FREEZE_NANOS;
        }
    }

    @SubscribeEvent
    public static void onRenderGuiPost(RenderGuiEvent.Post event) {
        if (textureLocation == null) {
            return;
        }

        if (System.nanoTime() >= activeUntilNanos) {
            clear();
            return;
        }

        GuiGraphics graphics = event.getGuiGraphics();
        graphics.blit(
                textureLocation,
                0,
                0,
                graphics.guiWidth(),
                graphics.guiHeight(),
                0.0F,
                0.0F,
                textureWidth,
                textureHeight,
                textureWidth,
                textureHeight
        );
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (textureLocation != null
                && System.nanoTime() >= activeUntilNanos) {
            clear();
        }
    }

    public static void clear() {
        capturePending = false;
        activeUntilNanos = 0L;

        Minecraft minecraft = Minecraft.getInstance();
        TextureManager textureManager = minecraft.getTextureManager();
        if (textureLocation != null) {
            textureManager.release(textureLocation);
        }

        textureLocation = null;
        texture = null;
        textureWidth = 0;
        textureHeight = 0;
    }

    private static void replaceCapturedFrame(Minecraft minecraft) {
        clearCapturedTexture(minecraft);

        NativeImage image = Screenshot.takeScreenshot(
                minecraft.getMainRenderTarget()
        );
        if (image == null) {
            return;
        }

        textureWidth = image.getWidth();
        textureHeight = image.getHeight();
        texture = new DynamicTexture(image);
        textureLocation = minecraft.getTextureManager().register(
                "gyeokbu_success_parry_hitstop",
                texture
        );
    }

    private static void clearCapturedTexture(Minecraft minecraft) {
        if (textureLocation != null) {
            minecraft.getTextureManager().release(textureLocation);
        }
        textureLocation = null;
        texture = null;
        textureWidth = 0;
        textureHeight = 0;
    }
}
