package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import com.wckd.gyeokbu.compat.BetterCombatWeaponMetadata;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.HandStyle;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.network.FallbackWeaponSyncPayload;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import com.wckd.gyeokbu.weapon.WeaponProfileCatalog;
import com.wckd.gyeokbu.weapon.WeaponProfileKey;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Compact single-weapon F8 editor.
 *
 * Normal mode handles view/transition/save management. The dedicated Edit
 * mode owns arm/weapon +/- work so the character preview stays uncluttered.
 * The top mode bar switches between stance controls and Parry-particle motion.
 */
public final class PoseEditorScreen extends Screen {

    private static final int BUTTON_HEIGHT = 20;
    private static final int ADJUST_WIDTH = 26;
    private static final int ADJUST_HEIGHT = 18;
    private static final int HOLD_DELAY_TICKS = 6;
    private static final int HOLD_REPEAT_TICKS = 1;
    private static final int STYLE_DROPDOWN_WIDTH = 190;
    private static final int STYLE_DROPDOWN_ROW_HEIGHT = 18;
    private static final int STYLE_DROPDOWN_VISIBLE_ROWS = 9;
    private static final int SAVE_NOTICE_TICKS = 80;
    private static final long TOOLTIP_DELAY_NANOS = 300_000_000L;
    private static final int TOOLTIP_PADDING = 5;
    private static final int TOOLTIP_LINE_GAP = 2;

    private ParryStyle style;
    private final ResourceLocation heldItemId;
    private final WeaponProfile heldWeaponProfile;
    private final List<ParryStyle> availableStyles;
    private final List<WeaponProfileKey> availableWeaponProfiles;

    private final List<AdjustHitbox> adjustHitboxes = new ArrayList<>();

    private float step = 0.05F;
    private String status = "";

    private int panelX;
    private int panelY;
    private int previewX;
    private int previewY;
    private int previewWidth = 220;

    private boolean uiHidden = false;
    private boolean focusEdit = false;
    private boolean successEditMode = false;
    private VisualSection visualSection = VisualSection.STANCES;
    private boolean infoOpen = true;
    private boolean optionsOpen = false;
    private boolean styleDropdownOpen = false;
    private boolean successStartDropdownOpen = false;
    private boolean successEndDropdownOpen = false;
    private boolean successPlayDropdownOpen = false;
    private boolean exitConfirmationOpen = false;
    private boolean successRemoveConfirmationOpen = false;
    private boolean successResetConfirmationOpen = false;
    private boolean successRevertConfirmationOpen = false;
    private boolean successClearHeldConfirmationOpen = false;
    // Shared layout anchors for the Successful Parry overview. Widgets and section labels use the same geometry.
    private int successStartSectionY = -1;
    private int successEndSectionY = -1;
    private int successTransitionsSectionY = -1;
    private int successToolsSectionY = -1;
    private int successSaveSectionY = -1;
    private int successOptionsY = -1;
    private int successContentBottomY = -1;
    private int successPlaySelection = -1;
    private int successEndDropdownOffset = 0;
    private int successPlayDropdownOffset = 0;
    private boolean successCopyStartPose = false;
    private SuccessAnimationChannel.Group successEditorGroup = SuccessAnimationChannel.Group.ARMS;
    private int styleDropdownOffset = 0;
    private AbstractWidget styleDropdownButton = null;
    private AbstractWidget successEndDropdownButton = null;
    private AbstractWidget successPlayDropdownButton = null;
    private String saveNotice = "";
    private int saveNoticeTicks = 0;
    private String hoveredTooltipKey = "";
    private long tooltipHoverStartNanos = 0L;
    private EditorPage page = EditorPage.ARMS;
    private WeaponTransformTab weaponTransformTab = WeaponTransformTab.POSITION;

    private AdjustHitbox heldAdjust = null;
    private int heldTicks = 0;
    private boolean orbitHeld = false;

    private ResetTarget pendingReset = ResetTarget.NONE;
    private ResetTarget pendingSuccessReset = ResetTarget.NONE;
    private boolean pendingPaste = false;
    private boolean pendingRevert = false;
    private boolean pendingDefaultReset = false;

    public PoseEditorScreen(ParryStyle naturalStyle) {
        this(naturalStyle, false);
    }

    /**
     * Compatibility constructor used by the legacy dual/success editor path.
     * The boolean selects the particles section without creating a second
     * screen implementation or changing the normal constructor behavior.
     */
    public PoseEditorScreen(ParryStyle naturalStyle, boolean openParticles) {
        super(Component.literal("Gyeokbu Pose Editor"));

        this.visualSection = openParticles
                ? VisualSection.PARTICLES
                : VisualSection.STANCES;

        Minecraft minecraft = Minecraft.getInstance();
        ItemStack main = minecraft.player == null
                ? ItemStack.EMPTY
                : minecraft.player.getMainHandItem();

        heldItemId = main.isEmpty()
                ? null
                : BuiltInRegistries.ITEM.getKey(main.getItem());

        /*
         * Keep the true classifier profile separate from any F8 fallback.
         * This is what decides whether Save Default is legitimate.
         */
        heldWeaponProfile = WeaponClassifier.classifyNatural(main);

        List<WeaponProfileKey> detectedWeaponProfiles = new ArrayList<>();
        List<ParryStyle> detectedStyles;
        boolean betterCombatAvailable = BetterCombatWeaponMetadata.isAvailable();

        if (betterCombatAvailable) {
            /* The BC catalog performs the registry scan once and is then reused
             * for both the profile list and the style list. */
            detectedWeaponProfiles.addAll(WeaponProfileCatalog.getDetectedProfiles());
            detectedStyles = new ArrayList<>(WeaponProfileCatalog.getDetectedStyles());
        } else {
            detectedStyles = new ArrayList<>(WeaponClassifier.getDetectedParryStyles());
            for (ParryStyle detectedStyle : detectedStyles) {
                detectedWeaponProfiles.add(
                        new WeaponProfileKey(detectedStyle, HandStyle.ONE_HANDED)
                );
            }
        }

        /*
         * Fallback is not a normal catalog entry. It only appears while the
         * editor is actually holding an unrecognized item.
         */
        if (!heldWeaponProfile.isSupported()) {
            detectedStyles.remove(ParryStyle.GENERIC);
            detectedStyles.add(0, ParryStyle.GENERIC);
        }

        availableStyles = List.copyOf(detectedStyles);
        if (!heldWeaponProfile.isSupported()) {
            detectedWeaponProfiles.removeIf(key -> key.style() == ParryStyle.GENERIC);
            detectedWeaponProfiles.add(0,
                    new WeaponProfileKey(ParryStyle.GENERIC, HandStyle.ONE_HANDED));
        }
        availableWeaponProfiles = List.copyOf(detectedWeaponProfiles);

        ParryStyle naturalEditorStyle = heldWeaponProfile.isSupported()
                ? heldWeaponProfile.parryStyle()
                : ParryStyle.GENERIC;

        /* Open the normal independent First-/Third-Person workspace. */
        this.style = AnimationPoseConfig.getAssignedItemStyle(
                heldItemId,
                naturalEditorStyle
        );

        if (!availableStyles.contains(this.style)) {
            this.style = naturalEditorStyle;
        }

        AnimationPoseConfig.beginEditor(this.style, heldItemId);
        enforceAvailableDefenseMode();
        this.style = AnimationPoseConfig.getEditorStyle();
        StanceEditorCamera.begin();
    }

    @Override
    protected void init() {
        clearWidgets();
        adjustHitboxes.clear();
        styleDropdownButton = null;
        successEndDropdownButton = null;
        successPlayDropdownButton = null;
        DeveloperMessageConfig.syncToServer();
        enforceAvailableDefenseMode();

        panelX = F8Layout.panelX(width);
        panelY = F8Layout.panelY();
        previewWidth = F8Layout.previewWidth(width, uiPanelWidth());

        if (exitConfirmationOpen) {
            addExitConfirmationButtons();
            return;
        }

        if (successRemoveConfirmationOpen) {
            addSuccessRemoveConfirmationButtons();
            return;
        }

        if (focusEdit) {
            if (visualSection == VisualSection.SUCCESS_PARRY) {
                addSuccessFocusEditor();
            } else {
                addFocusEditor();
            }
            return;
        }

        addRenderableWidget(
                Button.builder(Component.literal(uiHidden ? "Show UI" : "Hide UI"), button -> {
                            uiHidden = !uiHidden;
                            rebuild();
                        })
                        .bounds(panelX, panelY, 76, 20)
                        .build());

        if (uiHidden) {
            return;
        }

        addHeader();
        addVisualModeButtons();
        addDeveloperMessagesToggle();

        if (visualSection == VisualSection.PARTICLES) {
            addParticlePage();
            return;
        }

        if (visualSection == VisualSection.SUCCESS_PARRY) {
            ensureSuccessEditorActive();
            addSuccessPage();
            return;
        }

        addViewSelector();
        addViewPage();
        addToolsArea();
        addInfoToggle();
    }

    private void rebuild() {
        init();
    }

    private void addHeader() {
        int titleWidth = 190;
        int titleX = panelX + (uiPanelWidth() - titleWidth) / 2;

        styleDropdownButton = addRenderableWidget(new GyeokbuSmallButton(
                titleX,
                panelY,
                titleWidth,
                20,
                Component.literal(
                        "[ "
                                + (visualSection == VisualSection.SUCCESS_PARRY
                                ? SuccessAnimationConfig.editorProfileLabel()
                                : (BetterCombatWeaponMetadata.isAvailable()
                                && AnimationPoseConfig.isEditorHandVariantActive()
                                && style != ParryStyle.GENERIC
                                ? (AnimationPoseConfig.getEditorHandStyle() == com.wckd.gyeokbu.weapon.HandStyle.TWO_HANDED ? "2H " : "1H ") + formatStyleName(style)
                                : formatStyleName(style)))
                                + (styleDropdownOpen ? " ▲ ]" : " ▼ ]")
                ),
                button -> {
                    styleDropdownOpen = !styleDropdownOpen;
                    if (styleDropdownOpen) {
                        ensureSelectedStyleVisible();
                    }
                    successPlayDropdownOpen = false;
                    successEndDropdownOpen = false;
                    rebuild();
                }
        ));

        // Playback controls are screen-level controls, intentionally outside the left editor panel.
        int closeX = width - 24;
        if (visualSection == VisualSection.SUCCESS_PARRY) {
            int playWidth = 64;
            int arrowWidth = 24;
            int playX = F8Layout.rightOfPanel(panelX, uiPanelWidth(), width, playWidth + arrowWidth + 4);

            addRenderableWidget(new GyeokbuSmallButton(
                    playX, panelY, playWidth, 20,
                    Component.literal("Play"),
                    button -> {
                        SuccessAnimationRuntime.startEditorPreview(successPlaySelection);
                        if (successPlaySelection < 0) {
                            status = "Playing Random End Pose.";
                        } else {
                            List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
                            int poseNumber = successPlaySelection >= 0 && successPlaySelection < existing.size()
                                    ? existing.get(successPlaySelection) + 1
                                    : successPlaySelection + 1;
                            status = "Playing End Pose " + poseNumber + ".";
                        }
                    }
            ));

            successPlayDropdownButton = addRenderableWidget(new GyeokbuSmallButton(
                    playX + playWidth + 4, panelY, arrowWidth, 20,
                    Component.literal(successPlayDropdownOpen ? "▲" : "▼"),
                    button -> {
                        successPlayDropdownOpen = !successPlayDropdownOpen;
                        successEndDropdownOpen = false;
                        styleDropdownOpen = false;
                        rebuild();
                    }
            ));
        }

        addRenderableWidget(
                Button.builder(Component.literal("X"), button -> onClose())
                        .bounds(closeX, panelY, 20, 20)
                        .build());
    }

    private void addVisualModeButtons() {
        int y = panelY + 30;
        int gap = 6;
        int w = (uiPanelWidth() - gap * 2) / 3;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX,
                y,
                w,
                20,
                Component.literal(visualSection == VisualSection.STANCES ? "• STANCES" : "STANCES"),
                button -> switchVisualSection(VisualSection.STANCES),
                () -> visualSection == VisualSection.STANCES));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + w + gap,
                y,
                w,
                20,
                Component.literal(visualSection == VisualSection.SUCCESS_PARRY ? "• SUCCESS PARRY" : "SUCCESS PARRY"),
                button -> switchVisualSection(VisualSection.SUCCESS_PARRY),
                () -> visualSection == VisualSection.SUCCESS_PARRY));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + (w + gap) * 2,
                y,
                w,
                20,
                Component.literal(visualSection == VisualSection.PARTICLES ? "• PARTICLES" : "PARTICLES"),
                button -> switchVisualSection(VisualSection.PARTICLES),
                () -> visualSection == VisualSection.PARTICLES));
    }

    private void switchVisualSection(VisualSection target) {
        cancelConfirmations();
        successStartDropdownOpen = false;
        successEndDropdownOpen = false;
        successPlayDropdownOpen = false;
        styleDropdownOpen = false;

        if (target == VisualSection.SUCCESS_PARRY) {
            if (focusEdit) {
                focusEdit = false;
            }
            ensureSuccessEditorActive();
            SuccessAnimationConfig.setEditorFirstPerson(
                    AnimationPoseConfig.isEditorFirstPerson()
            );
            if (AnimationPoseConfig.isEditorFirstPerson()) {
                StanceEditorCamera.useFirstPersonPreview();
            } else {
                StanceEditorCamera.useThirdPersonPreview();
            }
            visualSection = target;
            status = "Successful Parry animation controls.";
        } else {
            SuccessAnimationRuntime.cancelEditorPreview();
            SuccessAnimationConfig.endEditor();
            successEditMode = false;
            if (target == VisualSection.STANCES) {
                AnimationPoseConfig.setEditorFirstPerson(
                        AnimationPoseConfig.isEditorFirstPerson()
                );
                if (AnimationPoseConfig.isEditorFirstPerson()) {
                    StanceEditorCamera.useFirstPersonPreview();
                } else {
                    StanceEditorCamera.useThirdPersonPreview();
                }
                status = "Stance controls.";
            } else {
                status = "Parry particle controls.";
            }
            visualSection = target;
        }

        optionsOpen = false;
        rebuild();
    }

    private void ensureSuccessEditorActive() {
        if (!SuccessAnimationConfig.isEditorActive()) {
            if (SuccessAnimationConfig.isDefaultEnabled(false)) {
                SuccessAnimationConfig.beginDefaultEditor(
                        SuccessAnimationKind.PARRY,
                        false
                );
            } else {
                SuccessAnimationConfig.beginEditor(
                        SuccessAnimationKind.PARRY,
                        false
                );
            }

            SuccessAnimationConfig.setEditorFirstPerson(
                    AnimationPoseConfig.isEditorFirstPerson()
            );
        }
    }

    private void addPageTabs() {
        int y = panelY + 58;
        addPageButton("VIEW", EditorPage.VIEW, panelX, y, 110);
        addPageButton("ARMS", EditorPage.ARMS, panelX + 120, y, 110);
        addPageButton("WEAPON", EditorPage.WEAPON, panelX + 240, y, 108);
    }

    private void addPageButton(String text, EditorPage target, int x, int y, int w) {
        addRenderableWidget(new GyeokbuSmallButton(
                x, y, w, 18,
                Component.literal(text),
                button -> {
                    cancelConfirmations();
                    page = target;
                    rebuild();
                },
                () -> page == target));
    }

    private void addSuccessPage() {
        int contentX = F8Layout.contentX(panelX);
        int contentW = F8Layout.contentWidth(uiPanelWidth());
        int halfW = F8Layout.halfWidth(contentW);

        successToolsSectionY = -1;
        successSaveSectionY = -1;
        successContentBottomY = -1;

        F8Layout.Cursor cursor = new F8Layout.Cursor(panelY + 62);

        // VIEW & SYNC
        int y = cursor.row();
        addRenderableWidget(new GyeokbuSmallButton(
                contentX, y, halfW, F8Layout.ROW_H,
                Component.literal("Third-Person"),
                button -> setSuccessFirstPerson(false),
                () -> !SuccessAnimationConfig.isEditorFirstPerson()));
        addRenderableWidget(new GyeokbuSmallButton(
                contentX + halfW + F8Layout.GAP, y, halfW, F8Layout.ROW_H,
                Component.literal("First-Person"),
                button -> setSuccessFirstPerson(true),
                SuccessAnimationConfig::isEditorFirstPerson));

        y = cursor.row();
        addRenderableWidget(new GyeokbuSmallButton(
                contentX + 68, y, contentW - 136, F8Layout.ROW_H,
                Component.literal("Use Default: "
                        + (SuccessAnimationConfig.isDefaultEnabled(false) ? "YES" : "NO")),
                button -> {
                    cancelConfirmations();
                    boolean enabled = !SuccessAnimationConfig.isDefaultEnabled(false);
                    SuccessAnimationConfig.setDefaultEnabled(false, enabled);
                    SuccessAnimationRuntime.cancelEditorPreview();
                    if (enabled) {
                        selectSuccessDefaultProfile();
                    } else if (SuccessAnimationConfig.hasItemOverrideForCurrentItem()
                            && SuccessAnimationConfig.selectEditorItemOverride()) {
                        status = "Editing ITEM OVERRIDE Successful Parry.";
                        rebuild();
                    } else {
                        selectSuccessNaturalProfile();
                    }
                    rebuild();
                }, SuccessAnimationConfig::isDefaultEnabled));

        cursor.gap(14);
        successStartSectionY = cursor.sectionHeader();
        cursor.gap(2);
        y = cursor.row();

        addRenderableWidget(new GyeokbuSmallButton(
                contentX, y, contentW - 92, F8Layout.ROW_H,
                Component.literal("Start Pose: " + SuccessAnimationConfig.getPointAMode().displayName()),
                button -> {
                    successCopyStartPose = true;
                    SuccessAnimationConfig.cyclePointAMode();
                    SuccessAnimationRuntime.cancelEditorPreview();
                    rebuild();
                }));
        GyeokbuSmallButton editStart = addRenderableWidget(new GyeokbuSmallButton(
                contentX + contentW - 84, y, 84, F8Layout.ROW_H,
                Component.literal("Edit"),
                button -> enterSuccessEdit(true)));
        editStart.active = SuccessAnimationConfig.isEditorPointACustom();

        cursor.gap(8);
        successEndSectionY = cursor.sectionHeader();
        cursor.gap(2);
        y = cursor.row();

        int navGap = 6;
        int editW = 76;
        int navW = 28;
        int selectorW = Math.max(100, contentW - editW - navW * 2 - navGap * 3);
        int selectorX = contentX;
        int nav1X = selectorX + selectorW + navGap;
        int nav2X = nav1X + navW + navGap;
        int editX = contentX + contentW - editW;

        successEndDropdownButton = addRenderableWidget(new GyeokbuSmallButton(
                selectorX, y, selectorW, F8Layout.ROW_H,
                Component.literal("End Pose: " + (SuccessAnimationConfig.getSelectedEndPose() + 1) + " ▼"),
                button -> {
                    successEndDropdownOpen = !successEndDropdownOpen;
                    if (successEndDropdownOpen) {
                        int visibleRows = Math.max(1, successEndDropdownRect().height() / STYLE_DROPDOWN_ROW_HEIGHT);
                        successEndDropdownOffset = Math.min(
                                Math.max(0, SuccessAnimationConfig.getExistingEndPoseIndices().indexOf(
                                        SuccessAnimationConfig.getSelectedEndPose())),
                                Math.max(0, SuccessAnimationConfig.getExistingEndPoseCount() - visibleRows));
                    }
                    successPlayDropdownOpen = false;
                    styleDropdownOpen = false;
                    successEndDropdownOffset = Math.min(
                            successEndDropdownOffset,
                            Math.max(0, SuccessAnimationConfig.getExistingEndPoseCount() - STYLE_DROPDOWN_VISIBLE_ROWS));
                    rebuild();
                }));
        GyeokbuSmallButton remove = addRenderableWidget(new GyeokbuSmallButton(
                nav1X, y, navW, F8Layout.ROW_H, Component.literal("−"),
                button -> requestDeleteEndPose()));
        remove.active = SuccessAnimationConfig.canRemovePointB();
        GyeokbuSmallButton add = addRenderableWidget(new GyeokbuSmallButton(
                nav2X, y, navW, F8Layout.ROW_H, Component.literal("+"), button -> {
                    if (SuccessAnimationConfig.getExistingEndPoseCount() < 8) {
                        SuccessAnimationConfig.addPointBSmart();
                    }
                    rebuild();
                }));
        add.active = SuccessAnimationConfig.getExistingEndPoseCount() < 8;
        addRenderableWidget(new GyeokbuSmallButton(
                editX, y, editW, F8Layout.ROW_H, Component.literal("Edit"),
                button -> enterSuccessEdit(false)));

        cursor.gap(8);
        successTransitionsSectionY = cursor.sectionHeader();
        cursor.gap(2);
        y = cursor.row();
        addSuccessTransitionRow(y);

        cursor.gap(8);
        successOptionsY = cursor.y();
        addRenderableWidget(new GyeokbuSmallButton(
                contentX, successOptionsY, contentW, F8Layout.ROW_H,
                Component.literal(optionsOpen ? "Options ▲" : "Options ▼"),
                button -> {
                    optionsOpen = !optionsOpen;
                    cancelConfirmations();
                    rebuild();
                }));

        cursor.gap(10);
        if (optionsOpen) {
            successToolsSectionY = cursor.sectionHeader();
            cursor.gap(2);
            y = cursor.row();
            addSuccessCopyPasteRow(y);

            cursor.gap(8);
            successSaveSectionY = cursor.sectionHeader();
            cursor.gap(2);
            y = cursor.row();
            addSuccessNormalSaveRow(y);

            cursor.gap(8);
            y = cursor.row();
            addRenderableWidget(new GyeokbuSmallButton(
                    contentX, y, halfW, F8Layout.ROW_H,
                    Component.literal(successRevertConfirmationOpen ? "Are you sure?" : "Revert Saved"),
                    button -> {
                        if (!successRevertConfirmationOpen) {
                            successRevertConfirmationOpen = true;
                            rebuild();
                            return;
                        }
                        status = SuccessAnimationConfig.revertDefault().message();
                        successRevertConfirmationOpen = false;
                        SuccessAnimationRuntime.cancelEditorPreview();
                        rebuild();
                    }));
            addRenderableWidget(new GyeokbuSmallButton(
                    contentX + halfW + F8Layout.GAP, y, halfW, F8Layout.ROW_H,
                    Component.literal(successResetConfirmationOpen ? "Are you sure?" : "Reset Default"),
                    button -> {
                        if (!successResetConfirmationOpen) {
                            successResetConfirmationOpen = true;
                            rebuild();
                            return;
                        }
                        SuccessAnimationConfig.resetToBundledDefault();
                        successResetConfirmationOpen = false;
                        SuccessAnimationRuntime.cancelEditorPreview();
                        status = "Reset Successful Parry to bundled default.";
                        rebuild();
                    }));

            if (SuccessAnimationConfig.hasItemOverride()) {
                cursor.gap(2);
                y = cursor.row();
                addRenderableWidget(new GyeokbuSmallButton(
                        contentX, y, contentW, F8Layout.ROW_H,
                        Component.literal(successClearHeldConfirmationOpen ? "Are you sure?" : "Clear Held Save"),
                        button -> {
                            if (!successClearHeldConfirmationOpen) {
                                successClearHeldConfirmationOpen = true;
                                rebuild();
                                return;
                            }
                            status = SuccessAnimationConfig.clearItemOverride().message();
                            successClearHeldConfirmationOpen = false;
                            rebuild();
                        }));
            }
        }

        successContentBottomY = cursor.finish();
    }

    private void addSuccessNormalSaveRow(int y) {
        int contentX = F8Layout.contentX(panelX);
        int contentW = F8Layout.contentWidth(uiPanelWidth());
        int gap = 8;
        int halfW = (contentW - gap) / 2;

        GyeokbuSmallButton saveDefault = addRenderableWidget(new GyeokbuSmallButton(
                contentX, y, halfW, 20,
                Component.literal(successPrimarySaveLabel()),
                button -> saveSuccessPrimary()));
        saveDefault.active = SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE;

        GyeokbuSmallButton saveHeld = addRenderableWidget(new GyeokbuSmallButton(
                contentX + halfW + gap, y, halfW, 20,
                Component.literal("Save Held"),
                button -> saveSuccessHeld()));
        saveHeld.active = SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.DEFAULT
                && SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.FALLBACK
                && SuccessAnimationConfig.getEditorItemId() != null;
    }

    private String successPrimarySaveLabel() {
        return switch (SuccessAnimationConfig.getEditorProfileSource()) {
            case DEFAULT -> "Save Default";
            case FALLBACK -> "Save Fallback";
            case STYLE -> "Save Profile";
            case ITEM_OVERRIDE -> "Save Profile";
        };
    }

    private void saveSuccessPrimary() {
        cancelConfirmations();
        AnimationPoseConfig.SaveResult result = switch (SuccessAnimationConfig.getEditorProfileSource()) {
            case DEFAULT, STYLE -> SuccessAnimationConfig.saveDefault();
            case FALLBACK -> SuccessAnimationConfig.saveFallback();
            case ITEM_OVERRIDE -> new AnimationPoseConfig.SaveResult(
                    false,
                    "Select Save Held while editing ITEM OVERRIDE."
            );
        };
        status = result.message();
        if (result.success()) {
            showSaveNotice(result.message());
        }
        rebuild();
    }

    private void saveSuccessDefault() {
        cancelConfirmations();
        AnimationPoseConfig.SaveResult result = SuccessAnimationConfig.saveDefault();
        status = result.message();
        if (result.success()) {
            showSaveNotice("Saved Successful Parry default profile.");
        }
        rebuild();
    }

    private void saveSuccessHeld() {
        cancelConfirmations();
        AnimationPoseConfig.SaveResult result = SuccessAnimationConfig.saveHeld();
        status = result.message();
        if (result.success()) {
            showSaveNotice("Saved Successful Parry for held item.");
        }
        rebuild();
    }

    private void requestDeleteEndPose() {
        if (!SuccessAnimationConfig.canRemovePointB()) {
            status = "At least one End Pose is required.";
            return;
        }
        successRemoveConfirmationOpen = true;
        successEndDropdownOpen = false;
        successPlayDropdownOpen = false;
        rebuild();
    }

    private void addSuccessEndPoseOverview(int y) {
        List<Integer> existingEndPoses = SuccessAnimationConfig.getExistingEndPoseIndices();
        SuccessAnimationConfig.setSelectedEndPose(SuccessAnimationConfig.getSelectedEndPose());
        if (successPlaySelection >= existingEndPoses.size()) {
            successPlaySelection = -1;
        }

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 150, 18,
                Component.literal("End Pose: " + (SuccessAnimationConfig.getSelectedEndPose() + 1) + " ▼"),
                button -> {
                    cancelConfirmations();
                    successCopyStartPose = false;
                    successEndDropdownOpen = !successEndDropdownOpen;
                    successPlayDropdownOpen = false;
                    styleDropdownOpen = false;
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 168, y, 36, 18,
                Component.literal("-"),
                button -> {
                    if (!SuccessAnimationConfig.canRemovePointB()) {
                        status = "At least one End Pose is required.";
                        return;
                    }
                    successRemoveConfirmationOpen = true;
                    successEndDropdownOpen = false;
                    successPlayDropdownOpen = false;
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 210, y, 36, 18,
                Component.literal("+"),
                button -> {
                    if (SuccessAnimationConfig.getExistingEndPoseCount() >= 8) {
                        status = "Maximum of 8 End Poses reached.";
                        return;
                    }
                    if (SuccessAnimationConfig.addPointBSmart()) {
                        successCopyStartPose = false;
                        successPlaySelection = -1;
                        successEndDropdownOffset = 0;
                        status = "Added End Pose " + (SuccessAnimationConfig.getSelectedEndPose() + 1)
                                + "; copied from the other view when available.";
                    }
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 254, y, 84, 18,
                Component.literal("Edit"),
                button -> enterSuccessEdit(false)));
    }


    private void addSuccessTransitionRow(int y) {
        SuccessTransitionMode mode = SuccessAnimationConfig.getTransitionMode();
        int totalTicks = SuccessAnimationConfig.getTotalDurationTicks();
        int x = panelX + 10;

        addRenderableWidget(new GyeokbuSmallButton(
                x, y, 28, 18,
                Component.literal(
                        SuccessAnimationConfig.isTransitionLinkEnabled()
                                ? "[✓]"
                                : "[ ]"
                ),
                button -> {
                    SuccessAnimationConfig.toggleTransitionLink();
                    status = SuccessAnimationConfig.isTransitionLinkEnabled()
                            ? "Linked first- and third-person transition settings."
                            : "Restored each view's previous transition settings.";
                    rebuild();
                },
                SuccessAnimationConfig::isTransitionLinkEnabled));

        addRenderableWidget(new GyeokbuSmallButton(
                x + 34, y, 170, 18,
                Component.literal("Transition: " + mode.displayName()),
                button -> {
                    SuccessAnimationConfig.cycleTransitionMode();
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                x + 210, y, 28, 18,
                Component.literal("-"),
                button -> {
                    SuccessAnimationConfig.adjustTotalDurationTicks(-1);
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                x + 242, y, 54, 18,
                Component.literal(totalTicks + "t"),
                button -> { }));

        addRenderableWidget(new GyeokbuSmallButton(
                x + 300, y, 28, 18,
                Component.literal("+"),
                button -> {
                    SuccessAnimationConfig.adjustTotalDurationTicks(1);
                    rebuild();
                }));
    }

    private void addSuccessCopyPasteRow(int y) {
        GyeokbuSmallButton copy = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 158, 18,
                Component.literal("Copy Pose"),
                button -> {
                    AnimationPoseConfig.SaveResult result = SuccessAnimationConfig.copyOverviewPose(
                            successCopyStartPose
                    );
                    status = result.message();
                    rebuild();
                }));
        copy.active = SuccessAnimationConfig.canCopyOverviewPose(successCopyStartPose);

        GyeokbuSmallButton paste = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 180, y, 158, 18,
                Component.literal("Paste Pose"),
                button -> {
                    AnimationPoseConfig.SaveResult result = SuccessAnimationConfig.pasteOverviewPose(
                            successCopyStartPose
                    );
                    status = result.message();
                    SuccessAnimationRuntime.cancelEditorPreview();
                    rebuild();
                }));
        paste.active = SuccessAnimationConfig.canPasteOverviewPose(successCopyStartPose);
    }

    private void drawSuccessSectionDividerPlaceholder(String label) {
        /* The actual separator line is rendered in renderControlPanel. */
    }

    private void setSuccessFirstPerson(boolean firstPerson) {
        cancelConfirmations();
        SuccessAnimationRuntime.cancelEditorPreview();
        SuccessAnimationConfig.setEditorFirstPerson(firstPerson);
        if (firstPerson) {
            StanceEditorCamera.useFirstPersonPreview();
        } else {
            StanceEditorCamera.useThirdPersonPreview();
        }
        StanceEditorCamera.resetViewDirection();
        rebuild();
    }

    private void enterSuccessEdit(boolean startPose) {
        ensureSuccessEditorActive();
        SuccessAnimationRuntime.cancelEditorPreview();

        if (startPose) {
            if (!SuccessAnimationConfig.isEditorPointACustom()) {
                status = "Current Pose is live data and does not need editing.";
                return;
            }
            SuccessAnimationConfig.selectStartPoseForEditing();
            successCopyStartPose = true;
        } else {
            SuccessAnimationConfig.selectEndPoseForEditing(SuccessAnimationConfig.getSelectedEndPose());
            successCopyStartPose = false;
        }

        focusEdit = true;
        successEditMode = true;
        optionsOpen = false;
        successStartDropdownOpen = false;
        successEndDropdownOpen = false;
        successPlayDropdownOpen = false;
        successRevertConfirmationOpen = false;
        successResetConfirmationOpen = false;
        successClearHeldConfirmationOpen = false;
        rebuild();
    }

    private void addSuccessFocusEditor() {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX, panelY, 104, 20,
                Component.literal("← Exit Edit"),
                button -> {
                    SuccessAnimationConfig.leavePoseEditMode();
                    focusEdit = false;
                    successEditMode = false;
                    optionsOpen = false;
                    SuccessAnimationRuntime.cancelEditorPreview();
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 112, panelY, 132, 20,
                Component.literal(SuccessAnimationConfig.isEditorFirstPerson()
                        ? "First-Person ↔" : "Third-Person ↔"),
                button -> setSuccessFirstPerson(!SuccessAnimationConfig.isEditorFirstPerson())));

        if (SuccessAnimationConfig.isEditorDefaultProfile() && BetterCombatWeaponMetadata.isAvailable()) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 250, panelY, 110, 20,
                    Component.literal(SuccessAnimationConfig.getEditorDefaultHandedness() == SuccessAnimationConfig.DefaultHandedness.ONE_HANDED
                            ? "Default: 1H ↔" : "Default: 2H ↔"),
                    button -> {
                        cancelConfirmations();
                        SuccessAnimationRuntime.cancelEditorPreview();
                        SuccessAnimationConfig.cycleEditorDefaultHandedness();
                        status = "Editing " + SuccessAnimationConfig.editorProfileLabel() + ".";
                        rebuild();
                    }));
        }

        int y = panelY + 42;
        int point = SuccessAnimationConfig.getEditorPoint();
        addRenderableWidget(new GyeokbuSmallButton(
                panelX, y, 150, 20,
                Component.literal(point < 0 ? "START POSE" : "END POSE " + (point + 1) + " ↻"),
                button -> {
                    if (SuccessAnimationConfig.getEditorPoint() >= 0) {
                        SuccessAnimationConfig.cycleSelectedEndPoseForEditing();
                        SuccessAnimationRuntime.cancelEditorPreview();
                        status = "Editing End Pose " + (SuccessAnimationConfig.getEditorPoint() + 1) + ".";
                        rebuild();
                    }
                }, () -> point >= 0));
        addStepCycleButton(panelX + 162, y, 86);
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 260, y, 120, 20,
                Component.literal(successEditorGroup == SuccessAnimationChannel.Group.ARMS
                        ? "Edit: Arms ↔" : "Edit: Weapon ↔"),
                button -> {
                    successEditorGroup = successEditorGroup == SuccessAnimationChannel.Group.ARMS
                            ? SuccessAnimationChannel.Group.MAIN_WEAPON
                            : SuccessAnimationChannel.Group.ARMS;
                    optionsOpen = false;
                    rebuild();
                }));

        y += 36;
        addEditorSectionRule(successEditorGroup == SuccessAnimationChannel.Group.ARMS ? "ARMS" : "WEAPON", y);
        if (successEditorGroup == SuccessAnimationChannel.Group.ARMS) addSuccessFocusArmsPage();
        else addSuccessFocusWeaponPage();
        addSuccessEditToolsArea();
    }

    private void addSuccessFocusArmsPage() {
        int resetX = panelX + 282;
        int mainY = panelY + 104;

        addEditorSubheading("MAINHAND ARM", mainY - 20);
        addRenderableWidget(new GyeokbuSmallButton(
                resetX, mainY - 28, 90, 18,
                Component.literal(pendingSuccessReset == ResetTarget.MAINHAND ? "Confirm" : "Reset"),
                button -> requestSuccessReset(ResetTarget.MAINHAND)));
        addSuccessArmAdjustRow(true, 0, mainY);
        addSuccessArmAdjustRow(true, 1, mainY + 26);
        addSuccessArmAdjustRow(true, 2, mainY + 52);

        int offY = mainY + 100;
        addEditorSubheading("OFFHAND ARM", offY - 20);
        addRenderableWidget(new GyeokbuSmallButton(
                resetX, offY - 28, 90, 18,
                Component.literal(pendingSuccessReset == ResetTarget.OFFHAND ? "Confirm" : "Reset"),
                button -> requestSuccessReset(ResetTarget.OFFHAND)));
        addSuccessArmAdjustRow(false, 0, offY);
        addSuccessArmAdjustRow(false, 1, offY + 26);
        addSuccessArmAdjustRow(false, 2, offY + 52);
    }

    private void addSuccessFocusWeaponPage() {
        int tabsY = panelY + 76;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 20, tabsY, 112, 18,
                Component.literal("Position"),
                button -> {
                    cancelConfirmations();
                    weaponTransformTab = WeaponTransformTab.POSITION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.POSITION));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 150, tabsY, 112, 18,
                Component.literal("Rotation"),
                button -> {
                    cancelConfirmations();
                    weaponTransformTab = WeaponTransformTab.ROTATION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.ROTATION));

        int y = panelY + 138;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 176, y - 34, 92, 18,
                Component.literal(
                        pendingReset == ResetTarget.WEAPON
                                ? "Are you sure?"
                                : "Reset"
                ),
                button -> {
                    if (pendingReset == ResetTarget.WEAPON) {
                        pendingReset = ResetTarget.NONE;
                        SuccessAnimationConfig.resetEditorWeapon(true);
                        rebuild();
                    } else {
                        pendingReset = ResetTarget.WEAPON;
                        rebuild();
                    }
                }));

        addSuccessWeaponAdjustRow(0, y);
        addSuccessWeaponAdjustRow(1, y + 24);
        addSuccessWeaponAdjustRow(2, y + 48);
    }

    private void addEditorSectionRule(String label, int y) {
        // Rendered as a small section title during panel rendering; this method intentionally owns no widgets.
    }

    private void addEditorSubheading(String label, int y) {
        // Rendered in renderFocusPanel/renderSuccessFocusPanel to keep labels aligned with the controls.
    }

    private void addSuccessArmAdjustRow(
            boolean mainHand,
            int axis,
            int y
    ) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 286, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.SUCCESS, mainHand, axis, -1,
                axis == 0
                        ? (mainHand
                        ? SuccessAnimationChannel.MAIN_ARM_X
                        : SuccessAnimationChannel.OFF_ARM_X)
                        : axis == 1
                        ? (mainHand
                        ? SuccessAnimationChannel.MAIN_ARM_Y
                        : SuccessAnimationChannel.OFF_ARM_Y)
                        : (mainHand
                        ? SuccessAnimationChannel.MAIN_ARM_Z
                        : SuccessAnimationChannel.OFF_ARM_Z)
        ));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 328, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.SUCCESS, mainHand, axis, 1,
                axis == 0
                        ? (mainHand
                        ? SuccessAnimationChannel.MAIN_ARM_X
                        : SuccessAnimationChannel.OFF_ARM_X)
                        : axis == 1
                        ? (mainHand
                        ? SuccessAnimationChannel.MAIN_ARM_Y
                        : SuccessAnimationChannel.OFF_ARM_Y)
                        : (mainHand
                        ? SuccessAnimationChannel.MAIN_ARM_Z
                        : SuccessAnimationChannel.OFF_ARM_Z)
        ));
    }

    private void addSuccessWeaponAdjustRow(int axis, int y) {
        SuccessAnimationChannel channel = weaponTransformTab == WeaponTransformTab.POSITION
                ? switch (axis) {
                    case 0 -> SuccessAnimationChannel.MAIN_WEAPON_POS_X;
                    case 1 -> SuccessAnimationChannel.MAIN_WEAPON_POS_Y;
                    default -> SuccessAnimationChannel.MAIN_WEAPON_POS_Z;
                }
                : switch (axis) {
                    case 0 -> SuccessAnimationChannel.MAIN_WEAPON_ROT_X;
                    case 1 -> SuccessAnimationChannel.MAIN_WEAPON_ROT_Y;
                    default -> SuccessAnimationChannel.MAIN_WEAPON_ROT_Z;
                };

        adjustHitboxes.add(new AdjustHitbox(
                panelX + 286, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.SUCCESS, true, axis, -1, channel
        ));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 328, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.SUCCESS, true, axis, 1, channel
        ));
    }

    private void addSuccessEditToolsArea() {
        int y = successEditorGroup == SuccessAnimationChannel.Group.ARMS
                ? panelY + 286
                : panelY + 218;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 52, y, 178, 18,
                Component.literal(optionsOpen ? "Edit Options ▲" : "Edit Options ▼"),
                button -> {
                    optionsOpen = !optionsOpen;
                    cancelConfirmations();
                    rebuild();
                }));

        if (!optionsOpen) {
            return;
        }

        y += 26;
        boolean firstPerson = SuccessAnimationConfig.isEditorFirstPerson();
        String copyLabel = firstPerson ? "Copy → 3P" : "Copy → 1P";
        String mirrorLabel = firstPerson ? "Mirror 3P" : "Mirror 1P";

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 132, 18,
                Component.literal(copyLabel),
                button -> {
                    if (SuccessAnimationConfig.isEditorFirstPerson()) {
                        SuccessAnimationConfig.copy1pTo3p();
                    } else {
                        SuccessAnimationConfig.copy3pTo1p();
                    }
                    SuccessAnimationRuntime.cancelEditorPreview();
                    status = "Copied complete Successful Parry profile to the other view.";
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 142, y, 132, 18,
                Component.literal(mirrorLabel),
                button -> {
                    if (SuccessAnimationConfig.isEditorFirstPerson()) {
                        SuccessAnimationConfig.copy3pTo1p();
                    } else {
                        SuccessAnimationConfig.copy1pTo3p();
                    }
                    SuccessAnimationRuntime.cancelEditorPreview();
                    status = "Replaced current Successful Parry profile with the other view.";
                    rebuild();
                }));

        y += 26;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 132, 18,
                Component.literal("Copy Pose"),
                button -> {
                    cancelConfirmations();
                    AnimationPoseConfig.SaveResult result =
                            SuccessAnimationConfig.copySelectedPose();
                    status = result.message();
                    rebuild();
                }));

        GyeokbuSmallButton paste = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 142, y, 136, 18,
                Component.literal(pendingPaste ? "Are you sure?" : "Paste Pose"),
                button -> requestSuccessPaste()));
        paste.active = SuccessAnimationConfig.canPasteSelectedPose();
    }


    private void addSuccessAxisControls(int y) {
        SuccessAnimationChannel[] channels = switch (successEditorGroup) {
            case ARMS -> DualWieldRules.isDualWield(Minecraft.getInstance().player)
                    ? new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_ARM_X,
                    SuccessAnimationChannel.MAIN_ARM_Y,
                    SuccessAnimationChannel.MAIN_ARM_Z,
                    SuccessAnimationChannel.OFF_ARM_X,
                    SuccessAnimationChannel.OFF_ARM_Y,
                    SuccessAnimationChannel.OFF_ARM_Z
            }
                    : new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_ARM_X,
                    SuccessAnimationChannel.MAIN_ARM_Y,
                    SuccessAnimationChannel.MAIN_ARM_Z
            };
            case MAIN_WEAPON -> weaponTransformTab == WeaponTransformTab.POSITION
                    ? new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_WEAPON_POS_X,
                    SuccessAnimationChannel.MAIN_WEAPON_POS_Y,
                    SuccessAnimationChannel.MAIN_WEAPON_POS_Z
            }
                    : new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_X,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_Y,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_Z
            };
            case OFF_WEAPON -> weaponTransformTab == WeaponTransformTab.POSITION
                    ? new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.OFF_WEAPON_POS_X,
                    SuccessAnimationChannel.OFF_WEAPON_POS_Y,
                    SuccessAnimationChannel.OFF_WEAPON_POS_Z
            }
                    : new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.OFF_WEAPON_ROT_X,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_Y,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_Z
            };
        };

        int row = y;
        for (SuccessAnimationChannel channel : channels) {
            addSuccessAdjustRow(channel, row);
            row += 24;
        }
    }

    private void addSuccessAdjustRow(SuccessAnimationChannel channel, int y) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 194, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.SUCCESS, true, 0, -1, channel
        ));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 244, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.SUCCESS, true, 0, 1, channel
        ));
    }

    private void addSuccessSaveTools(int y) {
        GyeokbuSmallButton saveDefault = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 132, 18,
                Component.literal(successPrimarySaveLabel()),
                button -> {
                    cancelConfirmations();
                    saveSuccessPrimary();
                }));
        saveDefault.active = SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE;

        GyeokbuSmallButton saveHeld = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 140, y, 132, 18,
                Component.literal("Save Held"),
                button -> {
                    cancelConfirmations();
                    saveSuccessHeld();
                }));
        saveHeld.active = SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.DEFAULT
                && SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.FALLBACK
                && SuccessAnimationConfig.getEditorItemId() != null;

        y += 24;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 132, 18,
                Component.literal(successRevertConfirmationOpen
                        ? "Are you sure?"
                        : "Revert Saved"),
                button -> {
                    if (!successRevertConfirmationOpen) {
                        successRevertConfirmationOpen = true;
                        successResetConfirmationOpen = false;
                        successClearHeldConfirmationOpen = false;
                        rebuild();
                        return;
                    }
                    AnimationPoseConfig.SaveResult result = SuccessAnimationConfig.revertDefault();
                    successRevertConfirmationOpen = false;
                    status = result.message();
                    SuccessAnimationRuntime.cancelEditorPreview();
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 140, y, 132, 18,
                Component.literal(successResetConfirmationOpen
                        ? "Are you sure?"
                        : "Reset Default"),
                button -> {
                    if (!successResetConfirmationOpen) {
                        successResetConfirmationOpen = true;
                        successRevertConfirmationOpen = false;
                        successClearHeldConfirmationOpen = false;
                        rebuild();
                        return;
                    }
                    SuccessAnimationConfig.resetToBundledDefault();
                    successResetConfirmationOpen = false;
                    status = "Reset Successful Parry to bundled default.";
                    SuccessAnimationRuntime.cancelEditorPreview();
                    rebuild();
                }));

        if (SuccessAnimationConfig.hasItemOverride()) {
            y += 24;
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 4, y, 268, 18,
                    Component.literal(successClearHeldConfirmationOpen
                            ? "Are you sure?"
                            : "Clear Held Save"),
                    button -> {
                        if (!successClearHeldConfirmationOpen) {
                            successClearHeldConfirmationOpen = true;
                            successRevertConfirmationOpen = false;
                            successResetConfirmationOpen = false;
                            rebuild();
                            return;
                        }
                        AnimationPoseConfig.SaveResult result =
                                SuccessAnimationConfig.clearItemOverride();
                        successClearHeldConfirmationOpen = false;
                        status = result.message();
                        SuccessAnimationRuntime.cancelEditorPreview();
                        rebuild();
                    }));
        }
    }

    private static String successAxisName(SuccessAnimationChannel c) {
        return c.jsonName()
                .replace("main_arm_", "Main Arm ")
                .replace("off_arm_", "Off Arm ")
                .replace("main_weapon_pos_", "Weapon Pos ")
                .replace("main_weapon_rot_", "Weapon Rot ")
                .replace("off_weapon_pos_", "Off Weapon Pos ")
                .replace("off_weapon_rot_", "Off Weapon Rot ");
    }

    private void addSuccessRemoveConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;
        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126, centerY + 24, 118, 20,
                Component.literal("Yes, Remove"),
                button -> {
                    SuccessAnimationConfig.removePointB(SuccessAnimationConfig.getSelectedEndPose());
                    successRemoveConfirmationOpen = false;
                    successEndDropdownOpen = false;
                    status = "End Pose removed.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8, centerY + 24, 118, 20,
                Component.literal("No, Keep"),
                button -> {
                    successRemoveConfirmationOpen = false;
                    rebuild();
                }));
    }

    private void addViewSelector() {
        int y = panelY + 58;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 156, 18,
                Component.literal("Edit Third-Person"),
                button -> setFirstPerson(false),
                () -> !AnimationPoseConfig.isEditorFirstPerson()));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 182, y, 156, 18,
                Component.literal("Edit First-Person"),
                button -> setFirstPerson(true),
                AnimationPoseConfig::isEditorFirstPerson));
    }

    private void addViewPage() {
        int y = panelY + 116;

        addDefenseModeButtons(y);
        addEditButton(y);

        y += 36;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 178, 18,
                Component.literal("Reset Camera"),
                button -> {
                    cancelConfirmations();
                    StanceEditorCamera.reset();
                }));

        y += 28;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 178, 18,
                Component.literal("Transition: " + formatTransitionMode()),
                button -> {
                    cancelConfirmations();
                    DefenseTransitionConfig.cycleMode();
                    status = "Stance transition: " + formatTransitionMode() + ".";
                    rebuild();
                }));

        y += 24;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 36, 18,
                Component.literal("-"),
                button -> {
                    cancelConfirmations();
                    DefenseTransitionConfig.adjustDurationTicks(-1);
                    status = "Transition duration: "
                            + DefenseTransitionConfig.durationTicks()
                            + " ticks.";
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128, y, 94, 18,
                Component.literal("Duration: " + DefenseTransitionConfig.durationTicks() + "t"),
                button -> { }));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 228, y, 36, 18,
                Component.literal("+"),
                button -> {
                    cancelConfirmations();
                    DefenseTransitionConfig.adjustDurationTicks(1);
                    status = "Transition duration: "
                            + DefenseTransitionConfig.durationTicks()
                            + " ticks.";
                    rebuild();
                }));
    }

    private void addParticlePage() {
        /*
         * Particles are a world preview, so they use the same First-/Third-
         * Person camera controls as Stances. Right-click orbit and wheel zoom
         * are already handled by the shared F8 camera input path.
         */
        int y = panelY + 58;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 8, y, 104, 18,
                Component.literal("Third-Person"),
                button -> setFirstPerson(false),
                () -> !AnimationPoseConfig.isEditorFirstPerson()));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 120, y, 104, 18,
                Component.literal("First-Person"),
                button -> setFirstPerson(true),
                AnimationPoseConfig::isEditorFirstPerson));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 232, y, 108, 18,
                Component.literal("Reset Camera"),
                button -> {
                    cancelConfirmations();
                    StanceEditorCamera.reset();
                    status = "Particle preview camera reset.";
                    rebuild();
                }));

        y += 28;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 178, 18,
                Component.literal(
                        "Shape: "
                                + ParryParticleTransitionConfig.shape().displayName()
                                + " ↻"
                ),
                button -> {
                    ParryParticleTransitionConfig.cycleShape();
                    status = "Particle shape: "
                            + ParryParticleTransitionConfig.shape().displayName()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 178, 18,
                Component.literal(
                        "Motion: " + ParryParticleTransitionConfig.motion().displayName()
                ),
                button -> {
                    ParryParticleTransitionConfig.cycleMotion();
                    status = "Particle motion: "
                            + ParryParticleTransitionConfig.motion().displayName()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 178, 18,
                Component.literal(
                        "Expansion: "
                                + ParryParticleTransitionConfig.mode().displayName()
                ),
                button -> {
                    ParryParticleTransitionConfig.cycleMode();
                    status = "Particle expansion easing: "
                            + ParryParticleTransitionConfig.mode().displayName()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 36, 18,
                Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustDurationTicks(-1);
                    status = "Particle duration: "
                            + ParryParticleTransitionConfig.durationTicks()
                            + " ticks.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128, y, 94, 18,
                Component.literal(
                        "Duration: "
                                + ParryParticleTransitionConfig.durationTicks()
                                + "t"
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 228, y, 36, 18,
                Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustDurationTicks(1);
                    status = "Particle duration: "
                            + ParryParticleTransitionConfig.durationTicks()
                            + " ticks.";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 36, 18,
                Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustTurnDelayTicks(-1);
                    status = "Particle turn delay: "
                            + ParryParticleTransitionConfig.turnDelayTicks()
                            + " ticks.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128, y, 94, 18,
                Component.literal(
                        "Turn Delay: "
                                + ParryParticleTransitionConfig.turnDelayTicks()
                                + "t"
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 228, y, 36, 18,
                Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustTurnDelayTicks(1);
                    status = "Particle turn delay: "
                            + ParryParticleTransitionConfig.turnDelayTicks()
                            + " ticks.";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 36, 18,
                Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustParticleCount(-1);
                    status = "Particle count: "
                            + ParryParticleTransitionConfig.particleCount()
                            + ".";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128, y, 94, 18,
                Component.literal(
                        "Count: " + ParryParticleTransitionConfig.particleCount()
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 228, y, 36, 18,
                Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustParticleCount(1);
                    status = "Particle count: "
                            + ParryParticleTransitionConfig.particleCount()
                            + ".";
                    rebuild();
                }));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 36, 18, Component.literal("-"),
                button -> {
                    ParryParticleTransitionConfig.adjustSize(-0.10F);
                    status = "Particle size: " + ParryParticleTransitionConfig.sizePercent() + "%.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128, y, 94, 18,
                Component.literal("Size: " + ParryParticleTransitionConfig.sizePercent() + "%"),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 228, y, 36, 18, Component.literal("+"),
                button -> {
                    ParryParticleTransitionConfig.adjustSize(0.10F);
                    status = "Particle size: " + ParryParticleTransitionConfig.sizePercent() + "%.";
                    rebuild();
                }));

        /* Keep Dynamic Color in the main control block, above the status
         * divider, just like the other particle settings. */
        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 178, 18,
                Component.literal(
                        ParryParticleTransitionConfig.dynamicColors()
                                ? "Dynamic Color: ON"
                                : "Dynamic Color: OFF"
                ),
                button -> {
                    ParryParticleTransitionConfig.toggleDynamicColors();
                    status = ParryParticleTransitionConfig.dynamicColors()
                            ? "Dynamic blade colors enabled."
                            : "Dynamic blade colors disabled.";
                    rebuild();
                },
                ParryParticleTransitionConfig::dynamicColors));

        y += 28;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 86, y, 36, 18,
                Component.literal("-5%"),
                button -> {
                    ParryParticleTransitionConfig.adjustOpacity(-0.05F);
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 128, y, 94, 18,
                Component.literal(
                        "Opacity: " + ParryParticleTransitionConfig.opacityPercent() + "%"
                ),
                button -> { }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 228, y, 36, 18,
                Component.literal("+5%"),
                button -> {
                    ParryParticleTransitionConfig.adjustOpacity(0.05F);
                    rebuild();
                }));
    }

    private void addArmsPage() {
        int y = panelY + 140;
        addDefenseModeButtons(y);
        addFocusEditButton(y);

        /* Normal mode is intentionally read-only/clean. +/- editing lives in Edit. */
    }

    private void addWeaponPage() {
        int y = panelY + 140;
        addDefenseModeButtons(y);
        addFocusEditButton(y);

        y += 30;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 48, y, 116, 18,
                Component.literal("Position"),
                button -> {
                    cancelConfirmations();
                    weaponTransformTab = WeaponTransformTab.POSITION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.POSITION));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 186, y, 116, 18,
                Component.literal("Rotation"),
                button -> {
                    cancelConfirmations();
                    weaponTransformTab = WeaponTransformTab.ROTATION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.ROTATION));
    }

    private void addFocusEditButton(
            int y
    ) {
        addEditButton(y);
    }

    private void addEditButton(int y) {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 182, y, 156, 18,
                Component.literal("Edit"),
                button -> {
                    cancelConfirmations();
                    focusEdit = true;
                    uiHidden = false;
                    optionsOpen = false;
                    if (page == EditorPage.VIEW) {
                        page = EditorPage.ARMS;
                    }
                    rebuild();
                }));
    }

    private void addFocusEditor() {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX, panelY, 104, 20, Component.literal("← Exit Edit"),
                button -> { focusEdit = false; optionsOpen = false; rebuild(); }));
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 112, panelY, 168, 20,
                Component.literal(AnimationPoseConfig.isEditorFirstPerson()
                        ? "First-Person ↔" : "Third-Person ↔"),
                button -> setFirstPerson(!AnimationPoseConfig.isEditorFirstPerson())));

        int y = panelY + 42;
        addFocusDefenseModeButtons(y);
        addStepCycleButton(panelX + 116, y, 74);
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 198, y, 92, 20,
                Component.literal(page == EditorPage.ARMS ? "Edit: Arms ↔" : "Edit: Weapon ↔"),
                button -> { page = page == EditorPage.ARMS ? EditorPage.WEAPON : EditorPage.ARMS; optionsOpen = false; rebuild(); }));

        y += 36;
        addEditorSectionRule("EDITING", y);
        if (page == EditorPage.WEAPON) addFocusWeaponPage();
        else { page = EditorPage.ARMS; addFocusArmsPage(); }
        addEditToolsArea();
    }

    private void addFocusDefenseModeButtons(
            int y
    ) {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 50, 18,
                Component.literal("Parry"),
                button -> {
                    cancelConfirmations();
                    AnimationPoseConfig.setEditorMode(
                            DefenseAnimationSyncPayload.PARRY
                    );
                    status = "Editing Parry.";
                    rebuild();
                },
                () -> AnimationPoseConfig.getEditorMode()
                        == DefenseAnimationSyncPayload.PARRY));

        if (canEditBlock()) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 60, y, 50, 18,
                    Component.literal("Block"),
                    button -> {
                        cancelConfirmations();
                        AnimationPoseConfig.setEditorMode(
                                DefenseAnimationSyncPayload.BLOCK
                        );
                        status = "Editing Block.";
                        rebuild();
                    },
                    () -> AnimationPoseConfig.getEditorMode()
                            == DefenseAnimationSyncPayload.BLOCK));
        }
    }

    private void addFocusArmsPage() {
        int mainY = panelY + 92;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 176, mainY - 34, 92, 18,
                Component.literal(pendingReset == ResetTarget.MAINHAND
                        ? "Are you sure?"
                        : "Reset"),
                button -> requestReset(ResetTarget.MAINHAND)));

        addFocusArmAdjustRow(true, 0, mainY);
        addFocusArmAdjustRow(true, 1, mainY + 24);
        addFocusArmAdjustRow(true, 2, mainY + 48);

        int offY = mainY + 96;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 176, offY - 34, 92, 18,
                Component.literal(pendingReset == ResetTarget.OFFHAND
                        ? "Are you sure?"
                        : "Reset"),
                button -> requestReset(ResetTarget.OFFHAND)));

        addFocusArmAdjustRow(false, 0, offY);
        addFocusArmAdjustRow(false, 1, offY + 24);
        addFocusArmAdjustRow(false, 2, offY + 48);
    }

    private void addFocusWeaponPage() {
        int tabsY = panelY + 76;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 20, tabsY, 112, 18,
                Component.literal("Position"),
                button -> {
                    cancelConfirmations();
                    weaponTransformTab = WeaponTransformTab.POSITION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.POSITION));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 150, tabsY, 112, 18,
                Component.literal("Rotation"),
                button -> {
                    cancelConfirmations();
                    weaponTransformTab = WeaponTransformTab.ROTATION;
                    rebuild();
                },
                () -> weaponTransformTab == WeaponTransformTab.ROTATION));

        int y = panelY + 138;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 176, y - 34, 92, 18,
                Component.literal(pendingReset == ResetTarget.WEAPON
                        ? "Are you sure?"
                        : "Reset"),
                button -> requestReset(ResetTarget.WEAPON)));

        addFocusWeaponAdjustRow(0, y);
        addFocusWeaponAdjustRow(1, y + 24);
        addFocusWeaponAdjustRow(2, y + 48);
    }

    private void addFocusArmAdjustRow(
            boolean mainHand,
            int axis,
            int y
    ) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 190, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.ARM, mainHand, axis, -1));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 234, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.ARM, mainHand, axis, 1));
    }

    private void addFocusWeaponAdjustRow(
            int axis,
            int y
    ) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 190, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.WEAPON, true, axis, -1));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 234, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.WEAPON, true, axis, 1));
    }

    private void addEditToolsArea() {
        int y = page == EditorPage.ARMS
                ? panelY + 258
                : panelY + 208;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 52, y, 178, 18,
                Component.literal(optionsOpen ? "Edit Options ▲" : "Edit Options ▼"),
                button -> {
                    optionsOpen = !optionsOpen;
                    cancelConfirmations();
                    rebuild();
                }));

        if (!optionsOpen) {
            return;
        }

        y += 26;

        String copyModeText =
                AnimationPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY
                        ? "Copy to Block"
                        : "Copy to Parry";
        boolean blockEditingAvailable = canEditBlock();
        boolean firstPerson = AnimationPoseConfig.isEditorFirstPerson();
        String copyLabel = firstPerson ? "Copy → 3P" : "Copy → 1P";
        String mirrorLabel = firstPerson ? "Mirror 3P" : "Mirror 1P";

        if (blockEditingAvailable) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 4, y, 112, 18,
                    Component.literal(copyModeText),
                    button -> copyToOther()));
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 122, y, 112, 18,
                    Component.literal(copyLabel),
                    button -> copyCurrentViewToOther()));
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 240, y, 112, 18,
                    Component.literal(mirrorLabel),
                    button -> copyOtherViewToCurrent()));
        } else {
            int startX = panelX + (uiPanelWidth() - 230) / 2;
            addRenderableWidget(new GyeokbuSmallButton(
                    startX, y, 112, 18,
                    Component.literal(copyLabel),
                    button -> copyCurrentViewToOther()));
            addRenderableWidget(new GyeokbuSmallButton(
                    startX + 118, y, 112, 18,
                    Component.literal(mirrorLabel),
                    button -> copyOtherViewToCurrent()));
        }

        y += 26;
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 4, y, 132, 18,
                Component.literal("Copy Pose"),
                button -> {
                    cancelConfirmations();
                    AnimationPoseConfig.SaveResult result =
                            AnimationPoseConfig.copyEditorStanceToClipboard();
                    status = result.message();
                    rebuild();
                }));

        GyeokbuSmallButton paste = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 142, y, 136, 18,
                Component.literal(pendingPaste ? "Are you sure?" : "Paste Pose"),
                button -> requestPaste()));
        paste.active = AnimationPoseConfig.hasStanceClipboard();
    }


    private void addDefenseModeButtons(
            int y
    ) {
        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 76, 18,
                Component.literal("Parry"),
                button -> {
                    cancelConfirmations();
                    AnimationPoseConfig.setEditorMode(
                            DefenseAnimationSyncPayload.PARRY
                    );
                    status = "Editing Parry.";
                    rebuild();
                },
                () -> AnimationPoseConfig.getEditorMode()
                        == DefenseAnimationSyncPayload.PARRY));

        if (canEditBlock()) {
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 92, y, 76, 18,
                    Component.literal("Block"),
                    button -> {
                        cancelConfirmations();
                        AnimationPoseConfig.setEditorMode(
                                DefenseAnimationSyncPayload.BLOCK
                        );
                        status = "Editing Block.";
                        rebuild();
                    },
                    () -> AnimationPoseConfig.getEditorMode()
                            == DefenseAnimationSyncPayload.BLOCK));
        }
    }

    /** Saving and persistence stay outside Edit mode. */
    private void addToolsArea() {
        int y = getToolsY();

        addRenderableWidget(
                Button.builder(
                                Component.literal(optionsOpen ? "Options ▲" : "Options ▼"),
                                button -> {
                                    optionsOpen = !optionsOpen;
                                    cancelConfirmations();
                                    rebuild();
                                })
                        .bounds(panelX + 86, y, 178, 20)
                        .build());

        if (!optionsOpen) {
            return;
        }

        y += 28;

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 158, 18,
                Component.literal(pendingRevert ? "Are you sure?" : "Revert Saved"),
                button -> requestRevert()));

        addRenderableWidget(new GyeokbuSmallButton(
                panelX + 180, y, 158, 18,
                Component.literal(pendingDefaultReset ? "Are you sure?" : "Reset Default"),
                button -> requestDefaultReset()));

        y += 34;

        GyeokbuSmallButton saveDefault = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 10, y, 158, 18,
                Component.literal("Save Default"),
                button -> {
                    cancelConfirmations();
                    AnimationPoseConfig.SaveResult result =
                            AnimationPoseConfig.saveEditorAsDefault();

                    if (result.success()) {
                        showSaveNotice(
                                "Saved to default "
                                        + formatStyleName(style)
                                        + " stance"
                        );
                    } else {
                        status = result.message();
                    }
                }));
        saveDefault.active = canSaveDefault();

        GyeokbuSmallButton saveHeld = addRenderableWidget(new GyeokbuSmallButton(
                panelX + 180, y, 158, 18,
                Component.literal("Save Held"),
                button -> {
                    cancelConfirmations();
                    ParryStyle storedAssignment =
                            AnimationPoseConfig.getEditorStoredItemStyleAssignment(heldItemId);

                    ParryStyle previouslyAssigned = storedAssignment != null
                            ? storedAssignment
                            : AnimationPoseConfig.getEditorAssignedItemStyle(
                                    heldItemId,
                                    heldWeaponProfile.parryStyle()
                            );

                    if (style != previouslyAssigned) {
                        AnimationPoseConfig.SaveResult rebase =
                                AnimationPoseConfig.rebaseItemOverrideToEditorStyle(heldItemId);
                        if (!rebase.success()) {
                            status = rebase.message();
                            return;
                        }
                    }

                    AnimationPoseConfig.SaveResult result =
                            AnimationPoseConfig.saveEditorForItem(heldItemId);
                    if (!result.success()) {
                        status = result.message();
                        return;
                    }

                    AnimationPoseConfig.SaveResult assignment =
                            AnimationPoseConfig.assignEditorItemStyle(heldItemId, style);
                    if (!assignment.success()) {
                        status = assignment.message();
                        return;
                    }

                    enableFallbackForHeldIfNeeded();
                    showSaveNotice(
                            "Saved to held "
                                    + formatStyleName(style)
                                    + " stance"
                    );
                }));
        saveHeld.active = heldItemId != null;

        if (AnimationPoseConfig.hasEditorItemOverride(heldItemId)) {
            y += 26;
            addRenderableWidget(new GyeokbuSmallButton(
                    panelX + 86, y, 178, 18,
                    Component.literal("Clear Held Save"),
                    button -> {
                        cancelConfirmations();
                        AnimationPoseConfig.SaveResult result =
                                AnimationPoseConfig.clearEditorItemOverride(heldItemId);

                        if (result.success()) {
                            AnimationPoseConfig.clearEditorItemStyleAssignment(heldItemId);
                            syncFallbackForHeldWorkspace();
                            style = AnimationPoseConfig.getEditorStyle();
                        }

                        status = result.message();
                        rebuild();
                    }));
        }
    }

    private void copyCurrentViewToOther() {
        cancelConfirmations();
        if (AnimationPoseConfig.isEditorFirstPerson()) {
            AnimationPoseConfig.copyFirstPersonToThirdPerson();
            status = "Copied complete First-Person stance to Third-Person.";
        } else {
            AnimationPoseConfig.copyThirdPersonToFirstPerson();
            status = "Copied complete Third-Person stance to First-Person.";
        }
        rebuild();
    }

    private void copyOtherViewToCurrent() {
        cancelConfirmations();
        if (AnimationPoseConfig.isEditorFirstPerson()) {
            AnimationPoseConfig.copyThirdPersonToFirstPerson();
            status = "Copied complete Third-Person stance to First-Person.";
        } else {
            AnimationPoseConfig.copyFirstPersonToThirdPerson();
            status = "Copied complete First-Person stance to Third-Person.";
        }
        rebuild();
    }


    private int getToolsY() {
        return panelY + 236;
    }

    private int currentPanelHeight() {
        if (visualSection == VisualSection.PARTICLES) {
            /* Leave a full control row between the final setting and the
             * status-bar divider. */
            return 360;
        }

        if (visualSection == VisualSection.SUCCESS_PARRY) {
            if (successEditMode) {
                return focusPanelHeight();
            }

            if (successContentBottomY > 0) {
                return Math.max(150, successContentBottomY - panelY + 24);
            }
            return 404;
        }

        int base = (getToolsY() - panelY) + 48;
        if (!optionsOpen) {
            return base;
        }

        int extra = 62;
        if (AnimationPoseConfig.hasEditorItemOverride(heldItemId)) {
            extra += 26;
        }
        return base + extra;
    }

    private int uiPanelWidth() {
        return F8Layout.panelWidth(width, 360);
    }

    private int uiFocusPanelWidth() {
        return F8Layout.focusPanelWidth(width, uiPanelWidth());
    }

    private void addDeveloperMessagesToggle() {
        int x = width - 124;
        int y = height - 30;

        addRenderableWidget(new GyeokbuSmallButton(
                x, y, 112, 18,
                Component.literal(
                        DeveloperMessageConfig.enabled()
                                ? "Dev Msg: ON"
                                : "Dev Msg: OFF"
                ),
                button -> {
                    DeveloperMessageConfig.toggleAndSync();
                    status = DeveloperMessageConfig.enabled()
                            ? "Developer messages enabled."
                            : "Developer messages disabled.";
                    rebuild();
                },
                DeveloperMessageConfig::enabled));
    }

    private void addInfoToggle() {
        previewX = width - previewWidth - 14;
        previewY = 12;

        addRenderableWidget(new GyeokbuSmallButton(
                previewX, previewY, 96, 18,
                Component.literal(infoOpen ? "Hide Info" : "Show Info"),
                button -> {
                    infoOpen = !infoOpen;
                    rebuild();
                }));
    }

    private void setFirstPerson(boolean firstPerson) {
        cancelConfirmations();
        AnimationPoseConfig.setEditorFirstPerson(firstPerson);
        if (firstPerson) {
            StanceEditorCamera.useFirstPersonPreview();
        } else {
            StanceEditorCamera.useThirdPersonPreview();
        }
        StanceEditorCamera.resetViewDirection();
        rebuild();
    }

    private void selectSuccessDefaultProfile() {
        cancelConfirmations();
        SuccessAnimationRuntime.cancelEditorPreview();
        SuccessAnimationConfig.beginDefaultEditor(
                SuccessAnimationKind.PARRY,
                false
        );
        SuccessAnimationConfig.setEditorFirstPerson(
                AnimationPoseConfig.isEditorFirstPerson()
        );
        successCopyStartPose = false;
        styleDropdownOpen = false;
        status = "Editing DEFAULT Successful Parry profile.";
        rebuild();
    }

    private void selectSuccessFallbackProfile() {
        cancelConfirmations();
        SuccessAnimationRuntime.cancelEditorPreview();
        SuccessAnimationConfig.selectEditorFallback();
        style = ParryStyle.GENERIC;
        SuccessAnimationConfig.setEditorFirstPerson(
                AnimationPoseConfig.isEditorFirstPerson()
        );
        successCopyStartPose = false;
        styleDropdownOpen = false;
        status = "Editing FALLBACK Successful Parry.";
        rebuild();
    }

    private void selectSuccessNaturalProfile() {
        Minecraft mc = Minecraft.getInstance();
        ItemStack stack = mc.player == null
                ? ItemStack.EMPTY
                : mc.player.getMainHandItem();
        WeaponProfile natural = WeaponClassifier.classifyNatural(stack);
        if (!natural.isSupported() || natural.parryStyle() == ParryStyle.GENERIC) {
            selectSuccessFallbackProfile();
            return;
        }
        selectSuccessStyle(new WeaponProfileKey(
                natural.parryStyle(),
                BetterCombatWeaponMetadata.isAvailable()
                        ? natural.handStyle()
                        : com.wckd.gyeokbu.weapon.HandStyle.ONE_HANDED
        ));
    }

    private void selectSuccessStyle(ParryStyle selectedStyle) {
        if (selectedStyle == null || selectedStyle == ParryStyle.GENERIC) {
            return;
        }
        selectSuccessStyle(new WeaponProfileKey(
                selectedStyle,
                BetterCombatWeaponMetadata.isAvailable()
                        ? SuccessAnimationConfig.detectStyleHandednessForUi(selectedStyle)
                        : com.wckd.gyeokbu.weapon.HandStyle.ONE_HANDED
        ));
    }

    private void selectSuccessStyle(WeaponProfileKey selectedProfile) {
        if (selectedProfile == null || selectedProfile.style() == ParryStyle.GENERIC) return;
        cancelConfirmations();
        SuccessAnimationRuntime.cancelEditorPreview();
        SuccessAnimationConfig.selectEditorStyle(
                selectedProfile.style(),
                selectedProfile.handStyle()
        );
        SuccessAnimationConfig.setEditorFirstPerson(
                AnimationPoseConfig.isEditorFirstPerson()
        );
        style = selectedProfile.style();
        successCopyStartPose = false;
        styleDropdownOpen = false;
        status = "Editing " + selectedProfile.displayName(BetterCombatWeaponMetadata.isAvailable()) + " Successful Parry.";
        rebuild();
    }

    private void selectStyle(WeaponProfileKey selectedProfile) {
        if (selectedProfile == null) {
            styleDropdownOpen = false;
            return;
        }

        cancelConfirmations();
        style = selectedProfile.style();
        styleDropdownOpen = false;
        SuccessAnimationRuntime.cancelEditorPreview();
        AnimationPoseConfig.switchEditorStyle(
                style,
                selectedProfile.handStyle()
        );
        status = selectedProfile.style() == ParryStyle.GENERIC
                ? "Editing Stance Fallback."
                : "Previewing " + selectedProfile.displayName(BetterCombatWeaponMetadata.isAvailable()) + " stance.";
        rebuild();
    }

    private boolean canSaveDefault() {
        return heldWeaponProfile.isSupported()
                && style == heldWeaponProfile.parryStyle();
    }

    private void showSaveNotice(String message) {
        saveNotice = message;
        saveNoticeTicks = SAVE_NOTICE_TICKS;
        status = message;
    }

    private void enableFallbackForHeldIfNeeded() {
        if (heldItemId == null
                || heldWeaponProfile.isSupported()) {
            return;
        }

        WeaponClassifier.setUserFallback(
                heldItemId,
                style
        );

        PacketDistributor.sendToServer(
                new FallbackWeaponSyncPayload(
                        heldItemId.toString(),
                        style.name(),
                        true
                )
        );
    }

    private void syncFallbackForHeldWorkspace() {
        if (heldItemId == null
                || heldWeaponProfile.isSupported()) {
            return;
        }

        if (AnimationPoseConfig.hasEditorItemOverride(heldItemId)) {
            WeaponClassifier.setUserFallback(
                    heldItemId,
                    style
            );
            PacketDistributor.sendToServer(
                    new FallbackWeaponSyncPayload(
                            heldItemId.toString(),
                            style.name(),
                            true
                    )
            );
        } else {
            WeaponClassifier.removeUserFallback(
                    heldItemId
            );
            PacketDistributor.sendToServer(
                    new FallbackWeaponSyncPayload(
                            heldItemId.toString(),
                            ParryStyle.GENERIC.name(),
                            false
                    )
            );
        }
    }

    private boolean canEditBlock() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null) {
            return false;
        }
        return GyeokbuEnchantments.hasBlockProvider(
                minecraft.player.level(),
                minecraft.player.getMainHandItem()
        );
    }

    private void enforceAvailableDefenseMode() {
        if (!canEditBlock()
                && AnimationPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.BLOCK) {
            AnimationPoseConfig.setEditorMode(DefenseAnimationSyncPayload.PARRY);
        }
    }

    private void copyToOther() {
        cancelConfirmations();
        if (!canEditBlock()) {
            status = "Block editing requires Block or Perfect Block.";
            rebuild();
            return;
        }
        if (AnimationPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY) {
            AnimationPoseConfig.copyParryToBlock();
            status = "Copied Parry → Block.";
        } else {
            AnimationPoseConfig.copyBlockToParry();
            status = "Copied Block → Parry.";
        }
    }

    private void requestSuccessPaste() {
        if (!SuccessAnimationConfig.canPasteSelectedPose()) {
            status = "Successful Parry clipboard is empty or cannot be pasted here.";
            return;
        }

        if (!pendingPaste) {
            pendingReset = ResetTarget.NONE;
            pendingSuccessReset = ResetTarget.NONE;
            pendingRevert = false;
            pendingDefaultReset = false;
            pendingPaste = true;
            status = "Click Paste again to confirm.";
            rebuild();
            return;
        }

        AnimationPoseConfig.SaveResult result =
                SuccessAnimationConfig.pasteSelectedPose();
        status = result.message();
        pendingPaste = false;
        SuccessAnimationRuntime.cancelEditorPreview();
        rebuild();
    }

    private void requestPaste() {
        if (!AnimationPoseConfig.hasStanceClipboard()) {
            status = "Stance clipboard is empty.";
            return;
        }

        if (!pendingPaste) {
            pendingReset = ResetTarget.NONE;
            pendingRevert = false;
            pendingDefaultReset = false;
            pendingPaste = true;
            status = "Click Paste again to confirm.";
            rebuild();
            return;
        }

        AnimationPoseConfig.SaveResult result =
                AnimationPoseConfig.pasteClipboardIntoEditor();
        status = result.message();
        pendingPaste = false;
        rebuild();
    }

    private void requestRevert() {
        if (!pendingRevert) {
            pendingReset = ResetTarget.NONE;
            pendingPaste = false;
            pendingDefaultReset = false;
            pendingRevert = true;
            status = "Revert reloads the last saved Third- + First-Person default. Click again to confirm.";
            rebuild();
            return;
        }

        AnimationPoseConfig.SaveResult result =
                AnimationPoseConfig.revertEditorToSavedDefault();
        status = result.message();
        pendingRevert = false;
        rebuild();
    }

    private void requestDefaultReset() {
        if (!pendingDefaultReset) {
            pendingReset = ResetTarget.NONE;
            pendingPaste = false;
            pendingRevert = false;
            pendingDefaultReset = true;
            status = "Reset loads the official shipped stance for this item/category and view. Click again to confirm.";
            rebuild();
            return;
        }

        AnimationPoseConfig.SaveResult result =
                AnimationPoseConfig.resetEditorToDefault();
        status = result.message();
        pendingDefaultReset = false;
        rebuild();
    }

    private void requestReset(ResetTarget target) {
        if (pendingReset != target) {
            pendingPaste = false;
            pendingRevert = false;
            pendingDefaultReset = false;
            pendingReset = target;
            status = "Click Are you sure? to confirm reset.";
            rebuild();
            return;
        }

        switch (target) {
            case MAINHAND -> AnimationPoseConfig.resetEditorArmToVanilla(true);
            case OFFHAND -> AnimationPoseConfig.resetEditorArmToVanilla(false);
            case WEAPON -> AnimationPoseConfig.resetEditorWeaponToVanilla();
            case NONE -> { }
        }

        pendingReset = ResetTarget.NONE;
        status = "Reset complete. Revert Default can restore your saved stance.";
        rebuild();
    }

    private void requestSuccessReset(ResetTarget target) {
        if (pendingSuccessReset != target) {
            pendingReset = ResetTarget.NONE;
            pendingPaste = false;
            pendingRevert = false;
            pendingDefaultReset = false;
            pendingSuccessReset = target;
            status = "Click Are you sure? to confirm Successful Parry reset.";
            rebuild();
            return;
        }

        switch (target) {
            case MAINHAND -> SuccessAnimationConfig.resetEditorArm(true);
            case OFFHAND -> SuccessAnimationConfig.resetEditorArm(false);
            case WEAPON -> SuccessAnimationConfig.resetEditorWeapon(true);
            case NONE -> { }
        }

        pendingSuccessReset = ResetTarget.NONE;
        status = "Successful Parry reset complete.";
        SuccessAnimationRuntime.cancelEditorPreview();
        rebuild();
    }

    private String formatTransitionMode() {
        return DefenseTransitionConfig.mode().displayName();
    }

    private void cancelConfirmations() {
        successRevertConfirmationOpen = false;
        successResetConfirmationOpen = false;
        successClearHeldConfirmationOpen = false;
        successRemoveConfirmationOpen = false;
        pendingReset = ResetTarget.NONE;
        pendingSuccessReset = ResetTarget.NONE;
        pendingPaste = false;
        pendingRevert = false;
        pendingDefaultReset = false;
    }

    private void addStepCycleButton(
            int x,
            int y,
            int width
    ) {
        addRenderableWidget(new GyeokbuSmallButton(
                x, y, width, 18,
                Component.literal("Step: " + format(step) + " ↻"),
                button -> {
                    cancelConfirmations();
                    cycleStep();
                    status = "Adjustment step = " + format(step) + ".";
                    rebuild();
                }));
    }

    private void cycleStep() {
        if (Math.abs(step - 0.01F) < 0.0001F) {
            step = 0.05F;
        } else if (Math.abs(step - 0.05F) < 0.0001F) {
            step = 0.10F;
        } else {
            step = 0.01F;
        }
    }

    private void addArmAdjustRow(boolean mainHand, int axis, int y) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 238, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.ARM, mainHand, axis, -1));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 286, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.ARM, mainHand, axis, 1));
    }

    private void addWeaponAdjustRow(int axis, int y) {
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 238, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.WEAPON, true, axis, -1));
        adjustHitboxes.add(new AdjustHitbox(
                panelX + 286, y - 5, ADJUST_WIDTH, ADJUST_HEIGHT,
                AdjustKind.WEAPON, true, axis, 1));
    }

    @Override
    public void tick() {
        super.tick();

        if (saveNoticeTicks > 0) {
            saveNoticeTicks--;
            if (saveNoticeTicks == 0) {
                saveNotice = "";
            }
        }

        if (heldAdjust == null) {
            return;
        }
        heldTicks++;
        if (heldTicks >= HOLD_DELAY_TICKS
                && (heldTicks - HOLD_DELAY_TICKS) % HOLD_REPEAT_TICKS == 0) {
            applyAdjustment(heldAdjust);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0
                && styleDropdownOpen) {

            int clickedIndex =
                    getDropdownStyleIndexAt(
                            mouseX,
                            mouseY
                    );

            if (clickedIndex >= 0) {
                if (visualSection == VisualSection.SUCCESS_PARRY) {
                    int itemRow = successItemOverrideDropdownRow();
                    int optionCount = successStyleDropdownTotal();
                    if (clickedIndex < optionCount) {
                        if (clickedIndex == 0) {
                            selectSuccessDefaultProfile();
                        } else if (clickedIndex == 1) {
                            selectSuccessFallbackProfile();
                        } else if (clickedIndex == itemRow) {
                            if (SuccessAnimationConfig.selectEditorItemOverride()) {
                                cancelConfirmations();
                                SuccessAnimationRuntime.cancelEditorPreview();
                                successCopyStartPose = false;
                                styleDropdownOpen = false;
                                status = "Editing ITEM OVERRIDE Successful Parry.";
                                rebuild();
                            }
                        } else {
                            WeaponProfileKey selectedProfile = successProfileForDropdown(clickedIndex);
                            if (selectedProfile != null) {
                                selectSuccessStyle(selectedProfile);
                            }
                        }
                        return true;
                    }
                } else if (clickedIndex < getStanceProfileDropdownTotal()) {
                    selectStyle(
                            getStanceProfileDropdownOption(clickedIndex)
                    );
                    return true;
                }
            }

            if (styleDropdownButton == null
                    || !styleDropdownButton.isMouseOver(mouseX, mouseY)) {
                styleDropdownOpen = false;
                rebuild();
                return true;
            }
        }

        if (successRemoveConfirmationOpen) {
            return super.mouseClicked(mouseX, mouseY, button);
        }

        if (button == 0 && visualSection == VisualSection.SUCCESS_PARRY && !uiHidden && !successEditMode) {
            if (successEndDropdownOpen) {
                int endIndex = getSuccessEndDropdownIndexAt(mouseX, mouseY);
                if (endIndex >= 0) {
                    List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
                    if (endIndex >= existing.size()) {
                        successEndDropdownOpen = false;
                        rebuild();
                        return true;
                    }
                    int poseIndex = existing.get(endIndex);
                    SuccessAnimationRuntime.cancelEditorPreview();
                    SuccessAnimationConfig.setSelectedEndPose(poseIndex);
                    successCopyStartPose = false;
                    successEndDropdownOpen = false;
                    status = "Selected End Pose " + (poseIndex + 1) + ".";
                    rebuild();
                    return true;
                }
                successEndDropdownOpen = false;
                rebuild();
                return true;
            }

            if (successPlayDropdownOpen) {
                int playOption = getSuccessPlayOptionAt(mouseX, mouseY);
                if (playOption != Integer.MIN_VALUE) {
                    successPlaySelection = playOption;
                    successPlayDropdownOpen = false;
                    status = playOption < 0
                            ? "Play target: Random."
                            : "Play target: End Pose " + (playOption + 1) + ".";
                    rebuild();
                    return true;
                }
                successPlayDropdownOpen = false;
                rebuild();
                return true;
            }
        }

        if (button == 0) {
            for (AdjustHitbox hitbox : adjustHitboxes) {
                if (hitbox.contains(mouseX, mouseY)) {
                    heldAdjust = hitbox;
                    heldTicks = 0;
                    applyAdjustment(hitbox);
                    return true;
                }
            }
        }

        if (button == 1
                && !isActiveF8FirstPerson()
                && (uiHidden || !isPointerOverInteractiveControl(mouseX, mouseY))) {
            orbitHeld = true;
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean isActiveF8FirstPerson() {
        if (visualSection == VisualSection.SUCCESS_PARRY) {
            return SuccessAnimationConfig.isEditorFirstPerson();
        }
        return AnimationPoseConfig.isEditorFirstPerson();
    }

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double dragX,
            double dragY
    ) {
        if (button == 1 && orbitHeld) {
            StanceEditorCamera.orbit(dragX, dragY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            heldAdjust = null;
            heldTicks = 0;
        }
        if (button == 1) {
            orbitHeld = false;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double scrollX,
            double scrollY
    ) {
        if (successStartDropdownOpen) {
            return true;
        }

        if (successEndDropdownOpen) {
            if (!isMouseOverSuccessEndDropdown(mouseX, mouseY)) {
                return true;
            }
            int visibleRows = Math.max(1, successEndDropdownRect().height() / STYLE_DROPDOWN_ROW_HEIGHT);
            int maxOffset = Math.max(0, SuccessAnimationConfig.getExistingEndPoseCount() - visibleRows);
            if (scrollY < 0.0D) {
                successEndDropdownOffset = Math.min(maxOffset, successEndDropdownOffset + 1);
            } else if (scrollY > 0.0D) {
                successEndDropdownOffset = Math.max(0, successEndDropdownOffset - 1);
            }
            return true;
        }

        if (successPlayDropdownOpen) {
            if (!isMouseOverSuccessPlayDropdown(mouseX, mouseY)) {
                return true;
            }
            int visibleRows = Math.max(1, successPlayDropdownRect().height() / STYLE_DROPDOWN_ROW_HEIGHT);
            int maxOffset = Math.max(0, SuccessAnimationConfig.getExistingEndPoseCount() + 1 - visibleRows);
            if (scrollY < 0.0D) {
                successPlayDropdownOffset = Math.min(maxOffset, successPlayDropdownOffset + 1);
            } else if (scrollY > 0.0D) {
                successPlayDropdownOffset = Math.max(0, successPlayDropdownOffset - 1);
            }
            return true;
        }

        if (styleDropdownOpen
                && isMouseOverStyleDropdown(mouseX, mouseY)) {

            int total = visualSection == VisualSection.SUCCESS_PARRY
                    ? successStyleDropdownTotal()
                    : stanceProfileDropdownTotal();
            int visibleRows = Math.max(1, styleDropdownRect().height() / STYLE_DROPDOWN_ROW_HEIGHT);
            int maxOffset = Math.max(
                    0,
                    total - visibleRows
            );

            if (scrollY < 0.0D) {
                styleDropdownOffset = Math.min(
                        maxOffset,
                        styleDropdownOffset + 1
                );
            } else if (scrollY > 0.0D) {
                styleDropdownOffset = Math.max(
                        0,
                        styleDropdownOffset - 1
                );
            }

            return true;
        }

        StanceEditorCamera.zoom(scrollY);
        return true;
    }

    private boolean isPointerOverInteractiveControl(double mouseX, double mouseY) {
        for (var child : children()) {
            if (child.isMouseOver(mouseX, mouseY)) {
                return true;
            }
        }

        for (AdjustHitbox hitbox : adjustHitboxes) {
            if (hitbox.contains(mouseX, mouseY)) {
                return true;
            }
        }

        return false;
    }

    private void applyAdjustment(AdjustHitbox hitbox) {
        float amount = hitbox.direction() * step;

        if (visualSection == VisualSection.SUCCESS_PARRY && successEditMode) {
            SuccessAnimationChannel channel = successChannelForHitbox(hitbox);
            if (channel != null) {
                SuccessAnimationConfig.adjustEditorValue(channel, amount);
                status = "Preview updated.";
            }
            return;
        }

        if (hitbox.kind() == AdjustKind.SUCCESS) {
            SuccessAnimationConfig.adjustEditorValue(
                    hitbox.successChannel(),
                    amount
            );
            status = "Preview updated.";
            return;
        }

        if (hitbox.kind() == AdjustKind.ARM) {
            AnimationPoseConfig.adjustEditorArmValue(
                    hitbox.mainHand(),
                    hitbox.axis(),
                    amount
            );
        } else if (weaponTransformTab == WeaponTransformTab.POSITION) {
            AnimationPoseConfig.adjustEditorWeaponPositionValue(hitbox.axis(), amount);
        } else {
            AnimationPoseConfig.adjustEditorWeaponValue(hitbox.axis(), amount);
        }

        status = "Preview updated.";
    }

    @Override
    public void renderBackground(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        if (focusEdit) {
            if (visualSection == VisualSection.SUCCESS_PARRY) {
                renderSuccessFocusPanel(graphics);
            } else {
                renderFocusPanel(graphics);
            }
            renderAdjustButtons(graphics);
        } else if (!uiHidden) {
            renderControlPanel(graphics);
            if (visualSection == VisualSection.STANCES && infoOpen) {
                renderInfoPanel(graphics);
            }
            renderAdjustButtons(graphics);
        }

        super.render(graphics, mouseX, mouseY, partialTick);

        if (exitConfirmationOpen) {
            renderExitConfirmation(graphics);
            return;
        }

        if (!focusEdit
                && !uiHidden
                && styleDropdownOpen) {
            renderStyleDropdown(graphics, mouseX, mouseY);
        }

        if (!uiHidden && visualSection == VisualSection.SUCCESS_PARRY) {
            if (successEndDropdownOpen && !focusEdit) {
                renderSuccessEndDropdown(graphics, mouseX, mouseY);
            }
            if (successPlayDropdownOpen && !focusEdit) {
                renderSuccessPlayDropdown(graphics, mouseX, mouseY);
            }
        }

        if (successRemoveConfirmationOpen) {
            renderSuccessRemoveConfirmation(graphics);
        }

        renderSaveNotice(graphics);
        renderDelayedTooltip(graphics, mouseX, mouseY);
    }

    private void renderStyleDropdown(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        int total = visualSection == VisualSection.SUCCESS_PARRY
                ? successStyleDropdownTotal()
                : stanceProfileDropdownTotal();
        F8Layout.Rect rect = styleDropdownRect();
        int dropdownWidth = rect.width();
        int x = rect.x();
        int y = rect.y();
        int menuHeight = styleDropdownRect().height();
        int visible = Math.min(
                STYLE_DROPDOWN_VISIBLE_ROWS,
                Math.min(total - styleDropdownOffset, menuHeight / STYLE_DROPDOWN_ROW_HEIGHT)
        );

        if (visible <= 0) return;

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 300.0F);

        /* Exact visual treatment used by the Stance category dropdown. */
        graphics.fill(
                x - 2,
                y - 2,
                x + dropdownWidth + 2,
                y + menuHeight + 2,
                0xE8000000
        );
        graphics.fill(
                x - 1,
                y - 1,
                x + dropdownWidth + 1,
                y + menuHeight + 1,
                0xE84A4A4A
        );
        graphics.fill(
                x,
                y,
                x + dropdownWidth,
                y + menuHeight,
                0xE8121212
        );

        graphics.enableScissor(
                x,
                y,
                x + dropdownWidth,
                y + menuHeight
        );

        for (int row = 0; row < visible; row++) {
            int index = styleDropdownOffset + row;
            boolean successPage = visualSection == VisualSection.SUCCESS_PARRY;
            int itemRow = successPage ? successItemOverrideDropdownRow() : -1;
            boolean isDefault = successPage && index == 0;
            boolean isItemOverride = successPage && index == itemRow;
            WeaponProfileKey profileOption = successPage
                    ? successProfileForDropdown(index)
                    : getStanceProfileDropdownOption(index);
            ParryStyle option = profileOption == null
                    ? ParryStyle.GENERIC
                    : profileOption.style();
            boolean isFallback = successPage && index == 1;
            boolean selected = successPage
                    ? (isDefault && SuccessAnimationConfig.isEditorDefaultProfile())
                    || (isFallback && SuccessAnimationConfig.isEditorFallbackProfile())
                    || (isItemOverride && SuccessAnimationConfig.getEditorProfileSource() == SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE)
                    || (profileOption != null && !SuccessAnimationConfig.isEditorDefaultProfile()
                    && !SuccessAnimationConfig.isEditorFallbackProfile()
                    && SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE
                    && option == style
                    && (!BetterCombatWeaponMetadata.isAvailable()
                    || profileOption.handStyle() == SuccessAnimationConfig.getEditorStyleHandedness()))
                    : profileOption != null
                    && profileOption.style() == style
                    && (!BetterCombatWeaponMetadata.isAvailable()
                    || profileOption.handStyle() == AnimationPoseConfig.getEditorHandStyle());
            int rowY = y + row * STYLE_DROPDOWN_ROW_HEIGHT;
            boolean hovered = mouseX >= x
                    && mouseX < x + dropdownWidth
                    && mouseY >= rowY
                    && mouseY < rowY + STYLE_DROPDOWN_ROW_HEIGHT;

            if (hovered || selected) {
                graphics.fill(
                        x + 1,
                        rowY + 1,
                        x + dropdownWidth - 1,
                        rowY + STYLE_DROPDOWN_ROW_HEIGHT - 1,
                        hovered ? 0xE83A3A3A : 0xFF303030
                );
            }

            boolean isStanceFallback = !successPage
                    && profileOption != null
                    && profileOption.style() == ParryStyle.GENERIC;
            String label = isDefault
                    ? "DEFAULT"
                    : isFallback || isStanceFallback
                    ? "FALLBACK"
                    : isItemOverride
                    ? "ITEM OVERRIDE"
                    : profileOption == null
                    ? formatStyleName(option)
                    : profileOption.displayName(BetterCombatWeaponMetadata.isAvailable());
            graphics.drawString(
                    font,
                    (selected ? "• " : "  ") + label,
                    x + 8,
                    rowY + 5,
                    selected ? 0xFFF2C14E : 0xFFFFFFFF
            );
        }

        graphics.disableScissor();

        if (total > STYLE_DROPDOWN_VISIBLE_ROWS) {
            int trackLeft = x + dropdownWidth - 7;
            int trackRight = x + dropdownWidth - 3;
            graphics.fill(
                    trackLeft,
                    y + 2,
                    trackRight,
                    y + menuHeight - 2,
                    0xFF242424
            );
            int maxOffset = Math.max(1, total - visible);
            int thumbHeight = Math.max(
                    12,
                    (int) Math.floor(
                            (menuHeight - 4)
                                    * (visible / (double) total)
                    )
            );
            int usable = Math.max(1, (menuHeight - 4) - thumbHeight);
            int thumbTop = y + 2
                    + (int) Math.round(
                    usable
                            * (styleDropdownOffset / (double) maxOffset)
            );
            graphics.fill(
                    trackLeft,
                    thumbTop,
                    trackRight,
                    thumbTop + thumbHeight,
                    0xFF8A8A8A
            );
        }

        graphics.pose().popPose();
    }

    private int successStyleDropdownStyleStart() {
        return 2 + (successItemOverrideDropdownRow() >= 0 ? 1 : 0);
    }

    private int successItemOverrideDropdownRow() {
        return visualSection == VisualSection.SUCCESS_PARRY
                && !SuccessAnimationConfig.isDefaultEnabled(SuccessAnimationConfig.isEditorDual())
                && SuccessAnimationConfig.hasItemOverrideForCurrentItem()
                ? 2
                : -1;
    }

    private List<WeaponProfileKey> getSuccessWeaponProfiles() {
        if (BetterCombatWeaponMetadata.isAvailable()) {
            return availableWeaponProfiles.stream()
                    .filter(key -> key.style() != ParryStyle.GENERIC)
                    .toList();
        }
        List<WeaponProfileKey> profiles = new ArrayList<>();
        for (ParryStyle option : availableStyles) {
            if (option != ParryStyle.GENERIC) {
                profiles.add(new WeaponProfileKey(
                        option,
                        com.wckd.gyeokbu.weapon.HandStyle.ONE_HANDED
                ));
            }
        }
        return profiles;
    }

    private int stanceProfileDropdownTotal() {
        return availableWeaponProfiles.size();
    }

    private int getStanceProfileDropdownTotal() {
        return stanceProfileDropdownTotal();
    }

    private WeaponProfileKey getStanceProfileDropdownOption(int index) {
        return index >= 0 && index < availableWeaponProfiles.size()
                ? availableWeaponProfiles.get(index)
                : null;
    }

    private int successStyleDropdownTotal() {
        return getSuccessWeaponProfiles().size() + successStyleDropdownStyleStart();
    }

    private WeaponProfileKey successProfileForDropdown(int index) {
        int styleIndex = index - successStyleDropdownStyleStart();
        List<WeaponProfileKey> profiles = getSuccessWeaponProfiles();
        return styleIndex >= 0 && styleIndex < profiles.size()
                ? profiles.get(styleIndex)
                : null;
    }

    private int successStyleIndexForDropdown(int index) {
        if (visualSection != VisualSection.SUCCESS_PARRY) {
            return index;
        }
        if (index == 0 || index == 1 || index == successItemOverrideDropdownRow()) {
            return -1;
        }
        return index - successStyleDropdownStyleStart();
    }

    private F8Layout.Rect styleDropdownRect() {
        if (styleDropdownButton == null) {
            return new F8Layout.Rect(F8Layout.SCREEN_MARGIN, panelY + 22, STYLE_DROPDOWN_WIDTH,
                    STYLE_DROPDOWN_VISIBLE_ROWS * STYLE_DROPDOWN_ROW_HEIGHT);
        }
        int total = visualSection == VisualSection.SUCCESS_PARRY
                ? successStyleDropdownTotal()
                : stanceProfileDropdownTotal();
        int visible = Math.min(STYLE_DROPDOWN_VISIBLE_ROWS, total - styleDropdownOffset);
        return F8Layout.placeDropdown(
                width,
                height,
                new F8Layout.Rect(styleDropdownButton.getX(), styleDropdownButton.getY(), styleDropdownButton.getWidth(), styleDropdownButton.getHeight()),
                STYLE_DROPDOWN_WIDTH,
                Math.max(STYLE_DROPDOWN_ROW_HEIGHT, visible * STYLE_DROPDOWN_ROW_HEIGHT),
                List.of(),
                F8Layout.GAP
        );
    }

    private boolean isMouseOverStyleDropdown(double mouseX, double mouseY) {
        int total = visualSection == VisualSection.SUCCESS_PARRY
                ? successStyleDropdownTotal()
                : stanceProfileDropdownTotal();
        int visible = Math.min(STYLE_DROPDOWN_VISIBLE_ROWS, total - styleDropdownOffset);
        if (visible <= 0) return false;
        return styleDropdownRect().contains(mouseX, mouseY);
    }

    private int getDropdownStyleIndexAt(double mouseX, double mouseY) {
        F8Layout.Rect rect = styleDropdownRect();
        if (!isMouseOverStyleDropdown(mouseX, mouseY)) return -1;
        int row = (int) ((mouseY - rect.y()) / STYLE_DROPDOWN_ROW_HEIGHT);
        return styleDropdownOffset + row;
    }

    private void ensureSelectedStyleVisible() {
        int index;
        int total = visualSection == VisualSection.SUCCESS_PARRY
                ? successStyleDropdownTotal()
                : stanceProfileDropdownTotal();

        if (visualSection == VisualSection.SUCCESS_PARRY) {
            if (SuccessAnimationConfig.isEditorDefaultProfile()) {
                index = 0;
            } else if (SuccessAnimationConfig.isEditorFallbackProfile()) {
                index = 1;
            } else if (SuccessAnimationConfig.getEditorProfileSource() == SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE
                    && successItemOverrideDropdownRow() >= 0) {
                index = successItemOverrideDropdownRow();
            } else {
                WeaponProfileKey current = new WeaponProfileKey(
                        style,
                        SuccessAnimationConfig.getEditorStyleHandedness()
                );
                index = successStyleDropdownStyleStart()
                        + getSuccessWeaponProfiles().indexOf(current);
            }
        } else {
            WeaponProfileKey current = new WeaponProfileKey(
                    style,
                    AnimationPoseConfig.getEditorHandStyle()
            );
            index = availableWeaponProfiles.indexOf(current);
            if (index < 0 && style == ParryStyle.GENERIC) {
                index = 0;
            }
        }

        if (index < 0) {
            styleDropdownOffset = 0;
            return;
        }

        if (index < styleDropdownOffset) {
            styleDropdownOffset = index;
        } else if (index >= styleDropdownOffset + STYLE_DROPDOWN_VISIBLE_ROWS) {
            styleDropdownOffset = Math.max(0, index - STYLE_DROPDOWN_VISIBLE_ROWS + 1);
        }

        styleDropdownOffset = Math.min(
                styleDropdownOffset,
                Math.max(0, total - STYLE_DROPDOWN_VISIBLE_ROWS)
        );
    }

    private void renderDelayedTooltip(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        TooltipContent tooltip =
                findTooltipAt(mouseX, mouseY);

        if (tooltip == null) {
            hoveredTooltipKey = "";
            tooltipHoverStartNanos = 0L;
            return;
        }

        long now = System.nanoTime();

        if (!tooltip.key().equals(hoveredTooltipKey)) {
            hoveredTooltipKey = tooltip.key();
            tooltipHoverStartNanos = now;
            return;
        }

        if (now - tooltipHoverStartNanos < TOOLTIP_DELAY_NANOS) {
            return;
        }

        renderTooltipBox(
                graphics,
                mouseX,
                mouseY,
                tooltip.lines()
        );
    }

    private TooltipContent findTooltipAt(
            double mouseX,
            double mouseY
    ) {
        if (!uiHidden
                && styleDropdownOpen
                && isMouseOverStyleDropdown(mouseX, mouseY)) {
            int index = getDropdownStyleIndexAt(mouseX, mouseY);
            int total = visualSection == VisualSection.SUCCESS_PARRY
                    ? successStyleDropdownTotal()
                    : stanceProfileDropdownTotal();
            if (index >= 0 && index < total) {
                boolean isDefault = visualSection == VisualSection.SUCCESS_PARRY && index == 0;
                boolean isFallback = visualSection == VisualSection.SUCCESS_PARRY && index == 1;
                if (isDefault) {
                    return new TooltipContent(
                            "style:default",
                            List.of("Use the default Successful Parry animation.")
                    );
                }
                if (isFallback) {
                    return new TooltipContent(
                            "style:fallback",
                            List.of("Use the Successful Parry fallback for unclassified weapons.")
                    );
                }
                WeaponProfileKey profileOption = visualSection == VisualSection.SUCCESS_PARRY
                        ? successProfileForDropdown(index)
                        : getStanceProfileDropdownOption(index);
                if (profileOption == null) {
                    return null;
                }
                if (visualSection != VisualSection.SUCCESS_PARRY && profileOption.style() == ParryStyle.GENERIC) {
                    return new TooltipContent(
                            "stance:fallback",
                            List.of(
                                    "Edit the Stance Fallback for an unclassified weapon.",
                                    "Save Held can tie this fallback to the current weapon."
                            )
                    );
                }
                String name = profileOption.displayName(BetterCombatWeaponMetadata.isAvailable());
                return new TooltipContent(
                        "style:" + profileOption.style().name() + ":" + profileOption.handStyle().name(),
                        List.of(
                                "Preview the " + name + " stance/profile.",
                                "Save Held to use it on this weapon."
                        )
                );
            }
        }

        if (!uiHidden) {
            for (AdjustHitbox hitbox : adjustHitboxes) {
                if (hitbox.contains(mouseX, mouseY)) {
                    String axis = switch (hitbox.axis()) {
                        case 0 -> "X";
                        case 1 -> "Y";
                        default -> "Z";
                    };
                    String direction = hitbox.direction() < 0
                            ? "Decrease"
                            : "Increase";

                    if (hitbox.kind() == AdjustKind.ARM) {
                        String hand = hitbox.mainHand()
                                ? "main-hand arm"
                                : "off-hand arm";
                        return new TooltipContent(
                                "adjust:arm:" + hitbox.mainHand() + ":" + axis + ":" + hitbox.direction(),
                                List.of(
                                        direction + " " + hand + " " + axis + ".",
                                        "Uses the selected step size."
                                )
                        );
                    }

                    String transform = weaponTransformTab == WeaponTransformTab.POSITION
                            ? "weapon position"
                            : "weapon rotation";
                    return new TooltipContent(
                            "adjust:weapon:" + weaponTransformTab + ":" + axis + ":" + hitbox.direction(),
                            List.of(
                                    direction + " " + transform + " " + axis + ".",
                                    "Uses the selected step size."
                            )
                    );
                }
            }
        }

        for (var child : children()) {
            if (child instanceof AbstractWidget widget
                    && widget.isMouseOver(mouseX, mouseY)) {
                TooltipContent tooltip = tooltipForWidget(widget);
                if (tooltip != null) {
                    return tooltip;
                }
            }
        }

        return null;
    }

    private TooltipContent tooltipForWidget(
            AbstractWidget widget
    ) {
        String label = widget.getMessage().getString();
        String normalized = label.trim();

        if (normalized.startsWith("[ ") && normalized.endsWith(" ]")) {
            return tip(
                    "stance-selector",
                    "Choose a detected weapon stance to preview.",
                    "Borrowed stances can only be saved to Held."
            );
        }

        if (normalized.equals("Hide UI")) {
            return tip("hide-ui", "Hide the F8 controls for a clear preview.");
        }
        if (normalized.equals("Show UI")) {
            return tip("show-ui", "Show the F8 editing controls again.");
        }
        if (normalized.equals("X")) {
            return tip("close", "Close the F8 stance editor.");
        }
        if (normalized.equals("• STANCES")) {
            return tip(
                    "stance-heading",
                    "Edit defensive stances. Click to open Parry Particles."
            );
        }
        if (normalized.equals("• PARRY PARTICLES")) {
            return tip(
                    "particle-heading",
                    "Edit successful-Parry particle motion. Click to return to Stances."
            );
        }
        if (normalized.equals("VIEW")) {
            return tip("page-view", "Preview stance and transition settings.");
        }
        if (normalized.equals("ARMS")) {
            return tip("page-arms", "Adjust the main-hand and off-hand arm poses.");
        }
        if (normalized.equals("WEAPON")) {
            return tip("page-weapon", "Adjust the held weapon position and rotation.");
        }
        if (normalized.equals("Edit Third-Person")) {
            return tip(
                    "view-3p",
                    "Edit the stance seen from outside your character.",
                    "This is also what other players see."
            );
        }
        if (normalized.equals("Edit First-Person")) {
            return tip(
                    "view-1p",
                    "Edit the stance seen through your own camera."
            );
        }
        if (normalized.equals("Third-Person") || normalized.equals("First-Person")) {
            return tip(
                    "particle-view",
                    "Switch the Successful Parry particle preview camera."
            );
        }
        if (normalized.equals("Play")) {
            return tip("success-play", "Play the configured Successful Parry animation preview.");
        }
        if (normalized.equals("Random ▼") || normalized.startsWith("End Pose ") && normalized.endsWith(" ▼")) {
            return tip("success-play-target", "Choose which End Pose Play previews.", "Random gives every End Pose an equal chance.");
        }
        if (normalized.startsWith("Start Pose:")) {
            return tip("success-start-mode", "Cycle between Current Pose and Custom Pose.");
        }
        if (normalized.startsWith("End Pose:")) {
            return tip("success-end-selector", "Choose which End Pose to edit.");
        }
        if (normalized.equals("Copy Pose")) {
            return tip("success-copy-pose", "Copy the selected Custom Start Pose or End Pose.");
        }
        if (normalized.equals("Paste Pose")) {
            return tip("success-paste-pose", "Paste the copied pose into the selected Successful Parry pose.");
        }
        if (normalized.equals("Save Held")) {
            return tip("success-save-held", "Save this Successful Parry profile for the held item.");
        }
        if (normalized.equals("Save Default")) {
            return tip("success-save-default", "Save this Successful Parry profile as the selected category/default profile.");
        }
        if (normalized.equals("Revert Saved")) {
            return tip("success-revert", "Reload the last saved Successful Parry profile.");
        }
        if (normalized.equals("Reset Default")) {
            return tip("success-reset", "Restore the bundled Successful Parry profile without saving it.");
        }
        if (normalized.equals("Clear Held Save")) {
            return tip("success-clear-held", "Remove this item's Successful Parry override.");
        }
        if (normalized.startsWith("Use Default:")) {
            return tip("success-default", "Use the independent Successful Parry DEFAULT profile for all weapon categories.");
        }
        if (normalized.startsWith("Editing: Start Pose") || normalized.startsWith("Editing: End Pose")) {
            return tip("success-edit-target", "Shows exactly which Successful Parry pose is being edited.");
        }

        if (normalized.equals("Third-Person ↔")
                || normalized.equals("First-Person ↔")) {
            return tip(
                    "focus-view-cycle",
                    "Switch between First- and Third-Person preview."
            );
        }
        if (normalized.equals("Edit")) {
            return tip(
                    "focus-edit",
                    "Open a clear pose-editing view with +/- controls."
            );
        }
        if (normalized.equals("← Exit Edit")) {
            return tip(
                    "exit-focus",
                    "Return to the full F8 controls."
            );
        }
        if (normalized.equals("Parry")) {
            return tip("mode-parry", "Edit the pose used during the Parry window.");
        }
        if (normalized.equals("Block")) {
            return tip("mode-block", "Edit the pose used while Blocking.");
        }
        if (normalized.startsWith("Step:")) {
            return tip(
                    "step-cycle",
                    "Cycle how much each +/- press changes a value.",
                    "0.01 = fine, 0.10 = large."
            );
        }
        if (normalized.equals("Edit: Arms ↔")
                || normalized.equals("Edit: Weapon ↔")) {
            return tip(
                    "focus-target-cycle",
                    "Switch Edit between arm and weapon adjustments."
            );
        }
        if (normalized.equals("Reset Camera")) {
            return tip("reset-camera", "Return the preview camera to its default view.");
        }
        if (normalized.equals("[ ]") || normalized.equals("[✓]")) {
            return tip(
                    "transition-link",
                    "Link the First- and Third-Person Successful Parry transition settings.",
                    "Unchecking restores each view's previous settings."
            );
        }
        if (normalized.startsWith("Transition:")) {
            return tip(
                    "transition",
                    "Choose how smoothly the stance moves in and out."
            );
        }
        if (normalized.startsWith("Shape:")) {
            return tip(
                    "particle-shape",
                    "Cycle the outward shape of the Parry spark burst."
            );
        }
        if (normalized.startsWith("Motion:")) {
            return tip(
                    "particle-motion",
                    "Choose whether Parry sparks expand, fall with gravity, or do both."
            );
        }
        if (normalized.startsWith("Expansion:")) {
            return tip(
                    "particle-expansion",
                    "Choose the easing curve used when sparks expand."
            );
        }
        if (normalized.startsWith("Dynamic Color:")) {
            return tip(
                    "particle-dynamic-color",
                    "Use sampled blade colors from the held weapon.",
                    "Dark and brown handle-like colors are filtered out."
            );
        }
        if (normalized.startsWith("Count:")) {
            return tip(
                    "particle-count",
                    "Set how many sparks are created on a successful Parry.",
                    "Range: 1-32. Position and shape logic stay unchanged."
            );
        }
        if (normalized.startsWith("Opacity:")) {
            return tip(
                    "particle-opacity",
                    "Set the constant opacity of successful-Parry sparks."
            );
        }
        if (normalized.equals("-5%")) {
            return tip("particle-opacity-minus", "Reduce particle opacity by 5%.");
        }
        if (normalized.equals("+5%")) {
            return tip("particle-opacity-plus", "Increase particle opacity by 5%.");
        }
        if (normalized.startsWith("Turn Delay:")) {
            return tip(
                    "particle-turn-delay",
                    "How long sparks wait before the next 90° snap.",
                    "1 tick = one turn every tick."
            );
        }
        if (normalized.startsWith("Duration:")) {
            return visualSection == VisualSection.PARTICLES
                    ? tip(
                    "particle-duration",
                    "How long the Parry particle animation lasts.",
                    "1 tick = 0.05 seconds."
            )
                    : tip(
                    "duration",
                    "How long the stance transition takes.",
                    "1 tick = 0.05 seconds."
            );
        }
        if (normalized.equals("-")) {
            if (visualSection == VisualSection.PARTICLES
                    && widget.getY() == panelY + 180) {
                return tip("particle-count-minus", "Use one fewer spark on successful Parry.");
            }
            return visualSection == VisualSection.PARTICLES
                    ? tip("particle-duration-minus", "Shorten the particle animation by 1 tick.")
                    : tip("duration-minus", "Shorten the transition by 1 tick.");
        }
        if (normalized.equals("+")) {
            if (visualSection == VisualSection.PARTICLES
                    && widget.getY() == panelY + 180) {
                return tip("particle-count-plus", "Use one more spark on successful Parry.");
            }
            return visualSection == VisualSection.PARTICLES
                    ? tip("particle-duration-plus", "Lengthen the particle animation by 1 tick.")
                    : tip("duration-plus", "Lengthen the transition by 1 tick.");
        }
        if (normalized.startsWith("Options")) {
            return tip("options", "Open save and restore tools.");
        }
        if (normalized.startsWith("Edit Options")) {
            return tip("edit-options", "Open copy and pose-editing tools.");
        }
        if (normalized.equals("Copy to Block")) {
            return tip(
                    "copy-to-block",
                    "Copy the current Parry pose into Block."
            );
        }
        if (normalized.equals("Copy to Parry")) {
            return tip(
                    "copy-to-parry",
                    "Copy the current Block pose into Parry."
            );
        }
        if (normalized.equals("Copy → 1P")) {
            return tip(
                    "copy-to-first",
                    "Copy the complete Third-Person stance into First-Person.",
                    "The target view is replaced."
            );
        }
        if (normalized.equals("Copy → 3P")) {
            return tip(
                    "copy-to-third",
                    "Copy the complete First-Person stance into Third-Person.",
                    "The target view is replaced."
            );
        }
        if (normalized.equals("Mirror 1P")) {
            return tip(
                    "mirror-first",
                    "Replace the current Third-Person stance with First-Person values.",
                    "This is a full copy, not a geometric mirror."
            );
        }
        if (normalized.equals("Mirror 3P")) {
            return tip(
                    "mirror-third",
                    "Replace the current First-Person stance with Third-Person values.",
                    "This is a full copy, not a geometric mirror."
            );
        }
        if (normalized.equals("Copy Pose")) {
            return tip("copy-pose", "Copy this stance so you can paste it elsewhere.");
        }
        if (normalized.equals("Paste Pose")) {
            return tip("paste-pose", "Paste the copied stance into this editor.");
        }
        if (normalized.equals("Revert Saved")) {
            return tip("revert", "Discard current edits and reload the saved stance.");
        }
        if (normalized.equals("Reset Default")) {
            return tip(
                    "reset-default",
                    "Load the official stance bundled inside Gyeokbu.",
                    "Existing saved files are not overwritten until you choose Save."
            );
        }
        if (normalized.equals("Save Default")) {
            if (!widget.active) {
                return tip(
                        "save-default-disabled",
                        "This is not the weapon's natural stance.",
                        "Use Save Held instead."
                );
            }
            return false
                    ? tip(
                    "save-default-linked",
                    "Save all Linked First-/Third-Person Parry and Block edits",
                    "to the default " + formatStyleName(style) + " stance."
            )
                    : tip(
                    "save-default",
                    "Save all First-/Third-Person Parry and Block edits",
                    "to the default " + formatStyleName(style) + " stance."
            );
        }
        if (normalized.equals("Save Held")) {
            return tip(
                    "save-held",
                    "Save all First-/Third-Person Parry and Block edits",
                    "only to the weapon you are holding."
            );
        }
        if (normalized.equals("Clear Held Save")) {
            return tip("clear-held", "Remove this weapon's custom held stance.");
        }
        if (normalized.equals("Position")) {
            return tip("weapon-position", "Move the weapon without changing its rotation.");
        }
        if (normalized.equals("Rotation")) {
            return tip("weapon-rotation", "Rotate the weapon without moving its position.");
        }
        if (normalized.equals("Reset")) {
            return tip("reset", "Reset this section to vanilla values.");
        }
        if (normalized.equals("Are you sure?")) {
            return tip("confirm", "Click again to confirm this change.");
        }
        if (normalized.equals("Hide Info")) {
            return tip("hide-info", "Hide the detected weapon information panel.");
        }
        if (normalized.equals("Show Info")) {
            return tip("show-info", "Show the detected weapon information panel.");
        }

        return null;
    }

    private TooltipContent tip(
            String key,
            String... lines
    ) {
        return new TooltipContent(
                key,
                List.of(lines)
        );
    }

    private void renderTooltipBox(
            GuiGraphics graphics,
            int mouseX,
            int mouseY,
            List<String> lines
    ) {
        if (lines == null || lines.isEmpty()) {
            return;
        }

        int textWidth = 0;
        for (String line : lines) {
            textWidth = Math.max(textWidth, font.width(line));
        }

        int lineHeight = font.lineHeight + TOOLTIP_LINE_GAP;
        int boxWidth = textWidth + TOOLTIP_PADDING * 2;
        int boxHeight = TOOLTIP_PADDING * 2
                + lines.size() * lineHeight
                - TOOLTIP_LINE_GAP;

        /*
         * The mouse is always exactly one corner of the tooltip rectangle.
         * Flip the box around that corner when it would leave the screen.
         */
        int boxX = mouseX + boxWidth <= width
                ? mouseX
                : mouseX - boxWidth;
        int boxY = mouseY + boxHeight <= height
                ? mouseY
                : mouseY - boxHeight;

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 500.0F);

        graphics.fill(
                boxX,
                boxY,
                boxX + boxWidth,
                boxY + boxHeight,
                0xF0101010
        );
        /* 1px tooltip border using GuiGraphics.fill for 1.21.1 compatibility. */
        graphics.fill(
                boxX,
                boxY,
                boxX + boxWidth,
                boxY + 1,
                0xFF707070
        );
        graphics.fill(
                boxX,
                boxY + boxHeight - 1,
                boxX + boxWidth,
                boxY + boxHeight,
                0xFF707070
        );
        graphics.fill(
                boxX,
                boxY,
                boxX + 1,
                boxY + boxHeight,
                0xFF707070
        );
        graphics.fill(
                boxX + boxWidth - 1,
                boxY,
                boxX + boxWidth,
                boxY + boxHeight,
                0xFF707070
        );

        int textY = boxY + TOOLTIP_PADDING;
        for (String line : lines) {
            graphics.drawString(
                    font,
                    line,
                    boxX + TOOLTIP_PADDING,
                    textY,
                    0xFFFFFFFF,
                    false
            );
            textY += lineHeight;
        }

        graphics.pose().popPose();
    }

    private void renderSaveNotice(GuiGraphics graphics) {
        if (saveNotice.isEmpty()
                || saveNoticeTicks <= 0) {
            return;
        }

        int textWidth = font.width(saveNotice);
        int x = width / 2 - textWidth / 2;
        int y = 10;

        graphics.fill(
                x - 7,
                y - 5,
                x + textWidth + 7,
                y + 14,
                0xD0101010
        );

        graphics.drawString(
                font,
                Component.literal(saveNotice)
                        .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD),
                x,
                y,
                0xFFFFFFFF
        );
    }

    private static String formatStyleName(ParryStyle value) {
        if (value == null) {
            return "Fallback";
        }

        if (value == ParryStyle.GENERIC) {
            return "Fallback";
        }

        String[] words = value.name()
                .toLowerCase(Locale.ROOT)
                .split("_");

        StringBuilder result = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) {
                continue;
            }

            if (!result.isEmpty()) {
                result.append(' ');
            }

            result.append(Character.toUpperCase(word.charAt(0)));
            result.append(word.substring(1));
        }

        return result.toString();
    }

    private void renderControlPanel(GuiGraphics graphics) {
        int h = currentPanelHeight();
        graphics.fill(
                panelX - 4,
                panelY - 4,
                panelX + uiPanelWidth() + 4,
                panelY + h,
                0xA8121212
        );

        /* Divider under the Stances / Parry Particles mode header. */
        graphics.fill(
                panelX,
                panelY + 52,
                panelX + uiPanelWidth(),
                panelY + 53,
                0x70FFFFFF
        );

        if (visualSection == VisualSection.STANCES) {
            /* Separate view/workspace selection from actual stance controls. */
            graphics.fill(
                    panelX,
                    panelY + 108,
                    panelX + uiPanelWidth(),
                    panelY + 109,
                    0x70FFFFFF
            );

            renderViewValues(graphics);

            if (optionsOpen) {
                renderSaveDivider(graphics);
            }
        } else if (visualSection == VisualSection.SUCCESS_PARRY) {
            if (!successEditMode) {
                if (successStartSectionY >= 0) drawSuccessSectionDivider(graphics, "START POSE", successStartSectionY);
                if (successEndSectionY >= 0) drawSuccessSectionDivider(graphics, "END POSE", successEndSectionY);
                if (successTransitionsSectionY >= 0) drawSuccessSectionDivider(graphics, "TRANSITIONS", successTransitionsSectionY);
                if (optionsOpen && successToolsSectionY >= 0) drawSuccessSectionDivider(graphics, "POSE TOOLS", successToolsSectionY);
                if (optionsOpen && successSaveSectionY >= 0) drawSuccessSectionDivider(graphics, "SAVE & MANAGE", successSaveSectionY);
            }
        }

        renderStatusBar(graphics, h);
    }

    private void renderViewValues(GuiGraphics graphics) {
        graphics.drawString(
                font,
                (AnimationPoseConfig.isEditorFirstPerson()
                        ? "FIRST-PERSON"
                        : "THIRD-PERSON")
                        + " | "
                        + (AnimationPoseConfig.getEditorMode() == DefenseAnimationSyncPayload.PARRY
                        ? "PARRY"
                        : "BLOCK"),
                panelX + 10,
                panelY + 138,
                0xD0D0D0
        );
    }

    private void renderArmValues(GuiGraphics graphics) {
        AnimationPoseConfig.ArmPose pose =
                AnimationPoseConfig.getEditorPose();
        if (pose == null) {
            return;
        }

        int mainY = panelY + 182;
        graphics.drawString(
                font,
                "MAINHAND ARM",
                panelX + 12,
                mainY - 18,
                0xFFFFFF
        );
        drawAxis(graphics, "X", pose.mainHand().getX(), mainY);
        drawAxis(graphics, "Y", pose.mainHand().getY(), mainY + 20);
        drawAxis(graphics, "Z", pose.mainHand().getZ(), mainY + 40);

        int offY = panelY + 254;
        graphics.drawString(
                font,
                "OFFHAND ARM",
                panelX + 12,
                offY - 18,
                0xFFFFFF
        );
        drawAxis(graphics, "X", pose.offHand().getX(), offY);
        drawAxis(graphics, "Y", pose.offHand().getY(), offY + 20);
        drawAxis(graphics, "Z", pose.offHand().getZ(), offY + 40);

    }

    private void renderWeaponValues(GuiGraphics graphics) {
        Vec3f value = weaponTransformTab == WeaponTransformTab.POSITION
                ? AnimationPoseConfig.getEditorWeaponPosition()
                : AnimationPoseConfig.getEditorWeaponRotation();

        if (value == null) {
            return;
        }

        int y = panelY + 214;
        graphics.drawString(
                font,
                weaponTransformTab == WeaponTransformTab.POSITION
                        ? "POSITION"
                        : "ROTATION",
                panelX + 12,
                y - 18,
                0xFFFFFF
        );

        drawAxis(graphics, "X", value.getX(), y);
        drawAxis(graphics, "Y", value.getY(), y + 20);
        drawAxis(graphics, "Z", value.getZ(), y + 40);

    }

    private void renderFocusEditHint(
            GuiGraphics graphics
    ) {
        int optionsY = getToolsY();

        graphics.drawCenteredString(
                font,
                "Use Edit for +/- adjustments.",
                panelX + uiPanelWidth() / 2,
                optionsY - 15,
                0xFF9A9A9A
        );
    }

    private void renderSaveDivider(
            GuiGraphics graphics
    ) {
        int y = getToolsY() + 56;
        String label = "SAVE";
        int labelWidth = font.width(label);
        int center = panelX + uiPanelWidth() / 2;

        graphics.fill(
                panelX + 10,
                y,
                center - labelWidth / 2 - 8,
                y + 1,
                0x50FFFFFF
        );
        graphics.fill(
                center + labelWidth / 2 + 8,
                y,
                panelX + uiPanelWidth() - 10,
                y + 1,
                0x50FFFFFF
        );
        graphics.drawCenteredString(
                font,
                label,
                center,
                y - 4,
                0xFFB8B8B8
        );
    }

    private void renderStatusBar(
            GuiGraphics graphics,
            int panelHeight
    ) {
        int dividerY = panelY + panelHeight - 24;
        graphics.fill(
                panelX + 6,
                dividerY,
                panelX + uiPanelWidth() - 6,
                dividerY + 1,
                0x40FFFFFF
        );

        String message = status.isEmpty()
                ? (visualSection == VisualSection.PARTICLES
                ? "Parry particle expansion"
                : visualSection == VisualSection.SUCCESS_PARRY
                ? "Editing: " + SuccessAnimationConfig.editorProfileLabel() + " successful Parry"
                : "Editing: " + formatStyleName(style) + " stance")
                : status;

        graphics.drawString(
                font,
                fitTextToWidth(
                        message,
                        uiPanelWidth() - 18
                ),
                panelX + 8,
                dividerY + 7,
                0xD0D0D0
        );
    }

    private void drawSuccessSectionDivider(
            GuiGraphics graphics,
            String label,
            int y
    ) {
        F8Layout.drawSection(
                graphics,
                font,
                panelX,
                uiPanelWidth(),
                y,
                label
        );
    }

    private void renderSuccessFocusPanel(GuiGraphics graphics) {
        int h = focusPanelHeight();
        graphics.fill(panelX - 4, panelY - 4,
                panelX + uiFocusPanelWidth() + 4, panelY + h,
                0xB8121212);
        graphics.drawCenteredString(font,
                "SUCCESSFUL PARRY",
                panelX + uiFocusPanelWidth() / 2,
                panelY + 24,
                0xFFD0D0D0);
        if (successEditorGroup == SuccessAnimationChannel.Group.ARMS) {
            renderSuccessFocusArmValues(graphics);
        } else {
            renderSuccessFocusWeaponValues(graphics);
        }
    }

    private void renderSuccessFocusArmValues(GuiGraphics graphics) {
        AnimationPoseConfig.ArmPose pose = SuccessAnimationConfig.getEditorArmPose();
        if (pose == null) return;

        int mainY = panelY + 104;
        graphics.drawString(font, "MAINHAND ARM", panelX + 8, mainY - 20, 0xFFFFFFFF);
        drawFocusAxis(graphics, "X", pose.mainHand().getX(), mainY);
        drawFocusAxis(graphics, "Y", pose.mainHand().getY(), mainY + 26);
        drawFocusAxis(graphics, "Z", pose.mainHand().getZ(), mainY + 52);

        int offY = mainY + 100;
        graphics.drawString(font, "OFFHAND ARM", panelX + 8, offY - 20, 0xFFFFFFFF);
        drawFocusAxis(graphics, "X", pose.offHand().getX(), offY);
        drawFocusAxis(graphics, "Y", pose.offHand().getY(), offY + 26);
        drawFocusAxis(graphics, "Z", pose.offHand().getZ(), offY + 52);
    }

    private void renderSuccessFocusWeaponValues(GuiGraphics graphics) {
        Vec3f value = weaponTransformTab == WeaponTransformTab.POSITION
                ? SuccessAnimationConfig.getEditorWeaponPosition(true)
                : SuccessAnimationConfig.getEditorWeaponRotation(true);
        if (value == null) {
            return;
        }

        int y = panelY + 138;
        graphics.drawString(
                font,
                weaponTransformTab == WeaponTransformTab.POSITION
                        ? "WEAPON POSITION"
                        : "WEAPON ROTATION",
                panelX + 8,
                y - 18,
                0xFFFFFFFF
        );
        drawFocusAxis(graphics, "X", value.getX(), y);
        drawFocusAxis(graphics, "Y", value.getY(), y + 24);
        drawFocusAxis(graphics, "Z", value.getZ(), y + 48);
    }

    private void renderSuccessArmValues(GuiGraphics graphics) {
        AnimationPoseConfig.ArmPose pose = SuccessAnimationConfig.getEditorArmPose();
        if (pose == null) {
            return;
        }

        int y = panelY + 92;
        graphics.drawString(font, "MAINHAND ARM", panelX + 8, y - 18, 0xFFFFFFFF);
        renderSuccessAxisValue(graphics, "X", pose.mainHand().getX(), y);
        renderSuccessAxisValue(graphics, "Y", pose.mainHand().getY(), y + 24);
        renderSuccessAxisValue(graphics, "Z", pose.mainHand().getZ(), y + 48);

        int offY = y + 96;
        graphics.drawString(font, "OFFHAND ARM", panelX + 8, offY - 18, 0xFFFFFFFF);
        renderSuccessAxisValue(graphics, "X", pose.offHand().getX(), offY);
        renderSuccessAxisValue(graphics, "Y", pose.offHand().getY(), offY + 24);
        renderSuccessAxisValue(graphics, "Z", pose.offHand().getZ(), offY + 48);
    }

    private void renderSuccessWeaponValues(GuiGraphics graphics) {
        boolean main = successEditorGroup == SuccessAnimationChannel.Group.MAIN_WEAPON;
        Vec3f value = weaponTransformTab == WeaponTransformTab.POSITION
                ? SuccessAnimationConfig.getEditorWeaponPosition(main)
                : SuccessAnimationConfig.getEditorWeaponRotation(main);
        if (value == null) {
            return;
        }

        String prefix = main ? "Main Weapon " : "Off Weapon ";
        graphics.drawString(
                font,
                weaponTransformTab == WeaponTransformTab.POSITION ? "POSITION" : "ROTATION",
                panelX + 14,
                panelY + 88,
                0xFFB8B8B8
        );
        int y = panelY + 112;
        renderSuccessAxisValue(graphics, prefix + "X", value.getX(), y);
        renderSuccessAxisValue(graphics, prefix + "Y", value.getY(), y + 24);
        renderSuccessAxisValue(graphics, prefix + "Z", value.getZ(), y + 48);
    }

    private void renderSuccessAxisValue(
            GuiGraphics graphics,
            String label,
            float value,
            int y
    ) {
        graphics.drawString(font, label, panelX + 12, y, 0xFFD0D0D0);
        graphics.drawString(font, format(value), panelX + 104, y, 0xFFFFFFFF);
    }

    private F8Layout.Rect successEndDropdownRect() {
        int total = SuccessAnimationConfig.getExistingEndPoseCount();
        int visible = Math.min(STYLE_DROPDOWN_VISIBLE_ROWS, total - successEndDropdownOffset);
        if (successEndDropdownButton == null || visible <= 0) {
            return new F8Layout.Rect(F8Layout.SCREEN_MARGIN, panelY, 154, STYLE_DROPDOWN_ROW_HEIGHT);
        }
        return F8Layout.placeDropdown(
                width,
                height,
                new F8Layout.Rect(successEndDropdownButton.getX(), successEndDropdownButton.getY(),
                        successEndDropdownButton.getWidth(), successEndDropdownButton.getHeight()),
                154,
                visible * STYLE_DROPDOWN_ROW_HEIGHT,
                List.of(),
                F8Layout.GAP
        );
    }

    private void renderSuccessEndDropdown(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        F8Layout.Rect rect = successEndDropdownRect();
        int x = rect.x();
        int y = rect.y();
        int width = rect.width();
        int menuHeight = rect.height();

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 300.0F);
        graphics.fill(x - 2, y - 2, x + width + 2, y + menuHeight + 2, 0xE8000000);
        graphics.fill(x - 1, y - 1, x + width + 1, y + menuHeight + 1, 0xE84A4A4A);
        graphics.fill(x, y, x + width, y + menuHeight, 0xE8121212);

        int visible = menuHeight / STYLE_DROPDOWN_ROW_HEIGHT;
        for (int row = 0; row < visible; row++) {
            int index = successEndDropdownOffset + row;
            int rowY = y + row * STYLE_DROPDOWN_ROW_HEIGHT;
            boolean hovered = new F8Layout.Rect(x, rowY, width, STYLE_DROPDOWN_ROW_HEIGHT).contains(mouseX, mouseY);
            List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
            int poseIndex = index < existing.size() ? existing.get(index) : -1;
            boolean selected = poseIndex == SuccessAnimationConfig.getSelectedEndPose();
            if (hovered || selected) {
                graphics.fill(x + 1, rowY + 1, x + width - 1,
                        rowY + STYLE_DROPDOWN_ROW_HEIGHT - 1,
                        hovered ? 0xE83A3A3A : 0xFF303030);
            }
            graphics.drawString(
                    font,
                    F8Layout.fit(font, (selected ? "• " : "  ") + "END POSE " + (poseIndex + 1), width - 16),
                    x + 8,
                    rowY + 5,
                    selected ? 0xFFF2C14E : 0xFFFFFFFF
            );
        }
        graphics.pose().popPose();
    }

    private boolean isMouseOverSuccessEndDropdown(double mouseX, double mouseY) {
        return successEndDropdownRect().contains(mouseX, mouseY);
    }

    private int getSuccessEndDropdownIndexAt(double mouseX, double mouseY) {
        F8Layout.Rect rect = successEndDropdownRect();
        if (!rect.contains(mouseX, mouseY)) return -1;
        int row = (int) ((mouseY - rect.y()) / STYLE_DROPDOWN_ROW_HEIGHT);
        int index = successEndDropdownOffset + row;
        return index < SuccessAnimationConfig.getExistingEndPoseCount() ? index : -1;
    }

    private F8Layout.Rect successPlayDropdownRect() {
        int total = SuccessAnimationConfig.getExistingEndPoseCount() + 1;
        int visible = Math.min(STYLE_DROPDOWN_VISIBLE_ROWS, total - successPlayDropdownOffset);
        if (successPlayDropdownButton == null || visible <= 0) {
            return new F8Layout.Rect(Math.max(F8Layout.SCREEN_MARGIN, width - 140), panelY + 22, 118, STYLE_DROPDOWN_ROW_HEIGHT);
        }
        return F8Layout.placeDropdown(
                width,
                height,
                new F8Layout.Rect(successPlayDropdownButton.getX(), successPlayDropdownButton.getY(),
                        successPlayDropdownButton.getWidth(), successPlayDropdownButton.getHeight()),
                118,
                visible * STYLE_DROPDOWN_ROW_HEIGHT,
                List.of(),
                F8Layout.GAP
        );
    }

    private void renderSuccessPlayDropdown(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        F8Layout.Rect rect = successPlayDropdownRect();
        int x = rect.x();
        int y = rect.y();
        int width = rect.width();
        int menuHeight = rect.height();

        graphics.pose().pushPose();
        graphics.pose().translate(0.0F, 0.0F, 300.0F);
        graphics.fill(x - 2, y - 2, x + width + 2, y + menuHeight + 2, 0xE8000000);
        graphics.fill(x - 1, y - 1, x + width + 1, y + menuHeight + 1, 0xE84A4A4A);
        graphics.fill(x, y, x + width, y + menuHeight, 0xE8121212);

        int visible = menuHeight / STYLE_DROPDOWN_ROW_HEIGHT;
        for (int row = 0; row < visible; row++) {
            int option = successPlayDropdownOffset + row;
            int selection = option == 0 ? -1 : option - 1;
            boolean selected = selection == successPlaySelection;
            int rowY = y + row * STYLE_DROPDOWN_ROW_HEIGHT;
            boolean hovered = new F8Layout.Rect(x, rowY, width, STYLE_DROPDOWN_ROW_HEIGHT).contains(mouseX, mouseY);
            if (hovered || selected) {
                graphics.fill(x + 1, rowY + 1, x + width - 1,
                        rowY + STYLE_DROPDOWN_ROW_HEIGHT - 1,
                        hovered ? 0xE83A3A3A : 0xFF303030);
            }
            List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
            String label = option == 0
                    ? "Random"
                    : option - 1 < existing.size() ? "End Pose " + (existing.get(option - 1) + 1) : "End Pose";
            graphics.drawString(
                    font,
                    F8Layout.fit(font, (selected ? "• " : "  ") + label, width - 12),
                    x + 6,
                    rowY + 5,
                    selected ? 0xFFF2C14E : 0xFFFFFFFF
            );
        }
        graphics.pose().popPose();
    }

    private boolean isMouseOverSuccessPlayDropdown(double mouseX, double mouseY) {
        return successPlayDropdownRect().contains(mouseX, mouseY);
    }

    private int getSuccessPlayOptionAt(double mouseX, double mouseY) {
        F8Layout.Rect rect = successPlayDropdownRect();
        if (!rect.contains(mouseX, mouseY)) {
            return Integer.MIN_VALUE;
        }
        int row = (int) ((mouseY - rect.y()) / STYLE_DROPDOWN_ROW_HEIGHT);
        int option = successPlayDropdownOffset + row;
        return option < SuccessAnimationConfig.getExistingEndPoseCount() + 1
                ? (option == 0 ? -1 : option - 1)
                : Integer.MIN_VALUE;
    }

    private void renderSuccessRemoveConfirmation(GuiGraphics graphics) {
        int centerX = width / 2;
        int centerY = height / 2;
        int boxWidth = 286;
        int left = centerX - boxWidth / 2;
        int top = centerY - 42;

        graphics.fill(left, top, left + boxWidth, centerY + 54, 0xF0181818);
        graphics.fill(left, top, left + boxWidth, top + 1, 0xFF808080);
        graphics.fill(left, centerY + 53, left + boxWidth, centerY + 54, 0xFF808080);
        graphics.drawCenteredString(
                font,
                "Are you sure?",
                centerX,
                top + 13,
                0xFFFFD76A
        );
        int point = SuccessAnimationConfig.getSelectedEndPose() + 1;
        graphics.drawCenteredString(
                font,
                "Remove End Pose " + point + "?",
                centerX,
                top + 29,
                0xFFFFFFFF
        );
    }

    private SuccessAnimationChannel successChannelForHitbox(AdjustHitbox hitbox) {
        return hitbox.kind() == AdjustKind.SUCCESS
                ? hitbox.successChannel()
                : null;
    }

    private void renderFocusPanel(GuiGraphics graphics) {
        int h = focusPanelHeight();
        graphics.fill(panelX - 4, panelY - 4,
                panelX + uiFocusPanelWidth() + 4, panelY + h,
                0xB8121212);

        graphics.drawCenteredString(font,
                "EDIT",
                panelX + uiFocusPanelWidth() / 2,
                panelY + 24,
                0xFFD0D0D0);

        if (page == EditorPage.ARMS) renderFocusArmValues(graphics);
        else renderFocusWeaponValues(graphics);
    }

    private int focusPanelHeight() {
        if (visualSection == VisualSection.SUCCESS_PARRY && successEditMode) {
            int bottom = successEditorGroup == SuccessAnimationChannel.Group.ARMS
                    ? panelY + (optionsOpen ? 356 : 304)
                    : panelY + (optionsOpen ? 288 : 236);
            return Math.max(220, bottom - panelY + 24);
        }

        int bottom = page == EditorPage.ARMS
                ? panelY + (optionsOpen ? 328 : 276)
                : panelY + (optionsOpen ? 278 : 226);
        return Math.max(220, bottom - panelY + 24);
    }

    private void renderFocusArmValues(
            GuiGraphics graphics
    ) {
        AnimationPoseConfig.ArmPose pose =
                AnimationPoseConfig.getEditorPose();
        if (pose == null) {
            return;
        }

        int mainY = panelY + 92;
        graphics.drawString(
                font,
                "MAINHAND ARM",
                panelX + 8,
                mainY - 18,
                0xFFFFFFFF
        );
        drawFocusAxis(graphics, "X", pose.mainHand().getX(), mainY);
        drawFocusAxis(graphics, "Y", pose.mainHand().getY(), mainY + 24);
        drawFocusAxis(graphics, "Z", pose.mainHand().getZ(), mainY + 48);

        int offY = mainY + 96;
        graphics.drawString(
                font,
                "OFFHAND ARM",
                panelX + 8,
                offY - 18,
                0xFFFFFFFF
        );
        drawFocusAxis(graphics, "X", pose.offHand().getX(), offY);
        drawFocusAxis(graphics, "Y", pose.offHand().getY(), offY + 24);
        drawFocusAxis(graphics, "Z", pose.offHand().getZ(), offY + 48);
    }

    private void renderFocusWeaponValues(
            GuiGraphics graphics
    ) {
        Vec3f value = weaponTransformTab == WeaponTransformTab.POSITION
                ? AnimationPoseConfig.getEditorWeaponPosition()
                : AnimationPoseConfig.getEditorWeaponRotation();
        if (value == null) {
            return;
        }

        int y = panelY + 138;
        graphics.drawString(
                font,
                weaponTransformTab == WeaponTransformTab.POSITION
                        ? "WEAPON POSITION"
                        : "WEAPON ROTATION",
                panelX + 8,
                y - 18,
                0xFFFFFFFF
        );
        drawFocusAxis(graphics, "X", value.getX(), y);
        drawFocusAxis(graphics, "Y", value.getY(), y + 24);
        drawFocusAxis(graphics, "Z", value.getZ(), y + 48);
    }

    private void drawFocusAxis(
            GuiGraphics graphics,
            String axis,
            float value,
            int y
    ) {
        graphics.drawString(font, axis, panelX + 12, y, 0xFFD0D0D0);
        graphics.drawString(font, format(value), panelX + 112, y, 0xFFFFFFFF);
    }

    private String fitTextToWidth(
            String value,
            int maxWidth
    ) {
        if (value == null) {
            return "";
        }
        if (font.width(value) <= maxWidth) {
            return value;
        }

        String suffix = "...";
        String trimmed = value;
        while (!trimmed.isEmpty()
                && font.width(trimmed + suffix) > maxWidth) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        return trimmed + suffix;
    }

    private void renderInfoPanel(GuiGraphics graphics) {
        graphics.fill(previewX - 6, previewY + 24,
                previewX + previewWidth + 6, previewY + 150, 0x98121212);

        drawInfo(graphics, "TYPE", heldWeaponProfile.weaponType().name(),
                previewY + 34, ChatFormatting.GOLD);
        drawInfo(graphics, "PARRY", style.name(),
                previewY + 52, ChatFormatting.AQUA);
        drawInfo(graphics, "HAND", heldWeaponProfile.handStyle().name(),
                previewY + 70,
                heldWeaponProfile.isTwoHanded()
                        ? ChatFormatting.LIGHT_PURPLE
                        : ChatFormatting.GREEN);
        drawInfo(graphics, "FAMILY", heldWeaponProfile.defenseFamily().name(),
                previewY + 88, ChatFormatting.YELLOW);
        drawInfo(graphics, "PROFILE",
                heldWeaponProfile.hasSpecialTraits() ? "SPECIAL" : "BASELINE",
                previewY + 106,
                heldWeaponProfile.hasSpecialTraits()
                        ? ChatFormatting.LIGHT_PURPLE
                        : ChatFormatting.GRAY);
        drawInfo(graphics, "CLIP",
                AnimationPoseConfig.getStanceClipboardSourceName(),
                previewY + 124,
                AnimationPoseConfig.hasStanceClipboard()
                        ? ChatFormatting.AQUA
                        : ChatFormatting.DARK_GRAY);
    }

    private void drawInfo(
            GuiGraphics graphics,
            String label,
            String value,
            int y,
            ChatFormatting color
    ) {
        graphics.drawString(
                font,
                Component.literal(label + ":").withStyle(ChatFormatting.DARK_GRAY),
                previewX,
                y,
                0xFFFFFF
        );

        graphics.drawString(
                font,
                Component.literal(value).withStyle(ChatFormatting.BOLD, color),
                previewX + 66,
                y,
                0xFFFFFF
        );
    }

    private void renderAdjustButtons(GuiGraphics graphics) {
        for (AdjustHitbox hitbox : adjustHitboxes) {
            graphics.fill(
                    hitbox.x(), hitbox.y(),
                    hitbox.x() + hitbox.width(),
                    hitbox.y() + hitbox.height(),
                    0xD0404040
            );

            graphics.drawCenteredString(
                    font,
                    hitbox.direction() < 0 ? "-" : "+",
                    hitbox.x() + hitbox.width() / 2,
                    hitbox.y() + 5,
                    0xFFFFFF
            );
        }
    }

    private void drawAxis(GuiGraphics graphics, String axis, float value, int y) {
        graphics.drawString(font, axis, panelX + 18, y, 0xD0D0D0);
        graphics.drawString(font, format(value), panelX + 138, y, 0xFFFFFF);
    }

    private static String format(float value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private void addExitConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;

        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126,
                centerY + 24,
                118,
                20,
                Component.literal("Yes, Leave"),
                button -> closeEditorImmediately()));

        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8,
                centerY + 24,
                118,
                20,
                Component.literal("No, Stay"),
                button -> {
                    exitConfirmationOpen = false;
                    rebuild();
                }));
    }

    private void renderExitConfirmation(
            GuiGraphics graphics
    ) {
        int centerX = width / 2;
        int centerY = height / 2;
        int boxWidth = 286;
        int left = centerX - boxWidth / 2;
        int top = centerY - 42;

        graphics.fill(
                left,
                top,
                left + boxWidth,
                centerY + 54,
                0xF0181818
        );
        graphics.fill(
                left,
                top,
                left + boxWidth,
                top + 1,
                0xFF808080
        );
        graphics.fill(
                left,
                centerY + 53,
                left + boxWidth,
                centerY + 54,
                0xFF808080
        );

        graphics.drawCenteredString(
                font,
                "Unsaved changes",
                centerX,
                top + 13,
                0xFFFFD76A
        );
        graphics.drawCenteredString(
                font,
                "Leave F8 without saving them?",
                centerX,
                top + 29,
                0xFFFFFFFF
        );
    }

    @Override
    public void onClose() {
        if (exitConfirmationOpen) {
            exitConfirmationOpen = false;
            rebuild();
            return;
        }

        if (AnimationPoseConfig.hasUnsavedEditorChanges()
                || SuccessAnimationConfig.hasUnsavedEditorChanges()) {
            exitConfirmationOpen = true;
            orbitHeld = false;
            heldAdjust = null;
            init();
            return;
        }

        closeEditorImmediately();
    }

    private void closeEditorImmediately() {
        exitConfirmationOpen = false;
        orbitHeld = false;
        heldAdjust = null;
        SuccessAnimationRuntime.cancelEditorPreview();
        SuccessAnimationConfig.endEditor();
        StanceEditorCamera.end();
        AnimationPoseConfig.endEditor();
        super.onClose();
    }

    @Override
    public void removed() {
        orbitHeld = false;
        heldAdjust = null;
        SuccessAnimationRuntime.cancelEditorPreview();
        SuccessAnimationConfig.endEditor();
        StanceEditorCamera.end();
        AnimationPoseConfig.endEditor();
        super.removed();
    }

    private enum VisualSection {
        STANCES,
        SUCCESS_PARRY,
        PARTICLES
    }

    private enum EditorPage {
        VIEW,
        ARMS,
        WEAPON
    }

    private enum WeaponTransformTab {
        POSITION,
        ROTATION
    }

    private enum AdjustKind {
        ARM,
        WEAPON,
        SUCCESS
    }

    private enum ResetTarget {
        NONE,
        MAINHAND,
        OFFHAND,
        WEAPON
    }

    private record TooltipContent(
            String key,
            List<String> lines
    ) {
    }

    private record AdjustHitbox(
            int x,
            int y,
            int width,
            int height,
            AdjustKind kind,
            boolean mainHand,
            int axis,
            int direction,
            SuccessAnimationChannel successChannel
    ) {
        private AdjustHitbox(
                int x, int y, int width, int height,
                AdjustKind kind, boolean mainHand, int axis, int direction
        ) {
            this(x, y, width, height, kind, mainHand, axis, direction, null);
        }

        private boolean contains(double mouseX, double mouseY) {
            return mouseX >= x
                    && mouseX < x + width
                    && mouseY >= y
                    && mouseY < y + height;
        }
    }
}
