package com.wckd.gyeokbu.client;

public enum SuccessAnimationKind {
    PARRY("success_parry", "Success Parry"),
    BLOCK("success_block", "Success Block");

    private final String folder;
    private final String displayName;

    SuccessAnimationKind(String folder, String displayName) {
        this.folder = folder;
        this.displayName = displayName;
    }

    public String folder() { return folder; }
    public String displayName() { return displayName; }
}
