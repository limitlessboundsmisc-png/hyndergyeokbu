package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.client.SuccessAnimationConfig.PointAMode;
import com.wckd.gyeokbu.compat.BetterCombatWeaponMetadata;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Successful Parry editor.
 *
 * This deliberately mirrors the existing Stance editor rather than becoming a
 * second, unrelated pose-editing UI. Stance and Particles are not modified by
 * this screen; this screen owns only the Successful Parry workspace.
 */
public final class SuccessAnimationEditorScreen extends Screen {

    private static final int PANEL_X = 12;
    private static final int PANEL_Y = 12;
    private static final int ROW_H = 18;

    private static final int DROPDOWN_WIDTH = 190;
    private static final int DROPDOWN_ROW_H = 18;
    private static final int DROPDOWN_VISIBLE_ROWS = 9;

    private static final int PLAY_DROPDOWN_WIDTH = 140;
    private static final int MAX_END_POSE = 8;

    private final SuccessAnimationKind kind;
    private final boolean dual;

    private boolean initialized;
    private boolean editMode;
    private boolean categoryDropdownOpen;
    private int categoryDropdownOffset;
    private boolean endPoseDropdownOpen;
    private boolean playDropdownOpen;
    private int playDropdownOffset;
    private int playVariant = -1; // -1 = Random

    private boolean exitConfirmationOpen;
    private boolean deleteConfirmationOpen;
    private boolean pasteConfirmationOpen;
    private boolean clearHeldConfirmationOpen;
    private boolean crossViewEndPoseConfirmationOpen;
    private boolean pendingCrossViewOverwrite;

    private EditGroup editGroup = EditGroup.MAIN_ARM;
    private float step = 0.05F;

    private String status = "";
    private String hoveredTooltipKey = "";
    private long tooltipHoverStartNanos = 0L;
    private static final long TOOLTIP_DELAY_NANOS = 300_000_000L;
    private boolean orbitHeld;
    private AdjustHitbox heldAdjust;
    private int heldTicks;

    private int uiPanelWidth() {
        return F8Layout.panelWidth(width, 350);
    }

    private int uiContentX() {
        return F8Layout.contentX(PANEL_X);
    }

    private int uiContentWidth() {
        return F8Layout.contentWidth(uiPanelWidth());
    }

    public SuccessAnimationEditorScreen(
            SuccessAnimationKind kind,
            boolean dual
    ) {
        super(Component.literal("Gyeokbu Successful Parry Editor"));
        this.kind = kind;
        this.dual = dual;
    }

    @Override
    protected void init() {
        if (!initialized) {
            if (SuccessAnimationConfig.isDefaultEnabled(dual)) {
                SuccessAnimationConfig.beginDefaultEditor(kind, dual);
            } else {
                SuccessAnimationConfig.beginEditor(kind, dual);
            }
            StanceEditorCamera.begin();
            applyCameraMode();
            initialized = true;
        }

        clearWidgets();

        if (exitConfirmationOpen) {
            addExitConfirmationButtons();
            return;
        }

        if (deleteConfirmationOpen) {
            addDeleteConfirmationButtons();
            return;
        }

        if (clearHeldConfirmationOpen) {
            addClearHeldConfirmationButtons();
            return;
        }

        if (crossViewEndPoseConfirmationOpen) {
            addCrossViewEndPoseConfirmationButtons();
            return;
        }

        if (editMode) {
            addEditModeWidgets();
        } else {
            addOverviewWidgets();
        }
    }

    private void addOverviewWidgets() {
        addHeader();
        addViewSelector();
        addDefaultButton();

        int y = PANEL_Y + 104;

        // Playback is a screen-level action: keep it away from the editing panel.
        int playX = F8Layout.rightOfPanel(PANEL_X, uiPanelWidth(), width, 110);
        addRenderableWidget(new GyeokbuSmallButton(
                playX, PANEL_Y, 74, ROW_H, Component.literal("Play"), button -> {
                    SuccessAnimationRuntime.startEditorPreview(playVariant);
                    status = playVariant < 0
                            ? "Playing Random End Pose."
                            : "Playing End Pose " + selectedPlayPoseNumber() + ".";
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                playX + 78, PANEL_Y, 32, ROW_H,
                Component.literal(playDropdownOpen ? "▲" : "▼"),
                button -> {
                    playDropdownOpen = !playDropdownOpen;
                    categoryDropdownOpen = false;
                    endPoseDropdownOpen = false;
                    if (playDropdownOpen) playDropdownOffset = 0;
                    rebuild();
                },
                () -> playDropdownOpen));

        y += 30;
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y, 230, ROW_H,
                Component.literal("Start Pose: " + SuccessAnimationConfig.getPointAMode().displayName()),
                button -> {
                    SuccessAnimationConfig.cyclePointAMode();
                    status = "Start Pose changed.";
                    rebuild();
                }));
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 238, y, 110, ROW_H, Component.literal("Edit"),
                button -> enterStartPoseEdit()));

        y += 30;
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y, 174, ROW_H,
                Component.literal("End Pose: " + (SuccessAnimationConfig.getSelectedEndPose() + 1)
                        + (endPoseDropdownOpen ? " ▲" : " ▼")),
                button -> {
                    endPoseDropdownOpen = !endPoseDropdownOpen;
                    categoryDropdownOpen = false;
                    playDropdownOpen = false;
                    rebuild();
                }));

        GyeokbuSmallButton remove = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 182, y, 24, ROW_H, Component.literal("−"),
                button -> requestDeleteEndPose()));
        remove.active = SuccessAnimationConfig.canRemovePointB();

        GyeokbuSmallButton add = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 212, y, 24, ROW_H, Component.literal("+"), button -> {
                    if (SuccessAnimationConfig.addPointBSmart()) {
                        playVariant = -1;
                        status = "Added End Pose " + (SuccessAnimationConfig.getSelectedEndPose() + 1)
                                + "; copied from the other view when available.";
                    }
                    rebuild();
                }));
        add.active = SuccessAnimationConfig.getExistingEndPoseCount() < MAX_END_POSE;

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 244, y, 104, ROW_H, Component.literal("Edit"),
                button -> enterEndPoseEdit()));

        y += 32;
        addTransitionOverview(y);

        addSectionSpacerMarker();
        addMainCopyPaste(PANEL_Y + 274);
        addOverviewSaveOptions(PANEL_Y + 314);
    }

    private void addSectionSpacerMarker() {
        // Visual-only section separators are rendered below.
    }

    private String successPrimarySaveLabel() {
        return switch (SuccessAnimationConfig.getEditorProfileSource()) {
            case DEFAULT -> "Save Default";
            case FALLBACK -> "Save Fallback";
            case STYLE -> "Save Profile";
            case ITEM_OVERRIDE -> "Save Profile";
        };
    }

    private AnimationPoseConfig.SaveResult saveSuccessPrimary() {
        return switch (SuccessAnimationConfig.getEditorProfileSource()) {
            case DEFAULT, STYLE -> SuccessAnimationConfig.saveDefault();
            case FALLBACK -> SuccessAnimationConfig.saveFallback();
            case ITEM_OVERRIDE -> new AnimationPoseConfig.SaveResult(false, "Use Save Held for ITEM OVERRIDE.");
        };
    }

    private void addOverviewSaveOptions(int y) {
        GyeokbuSmallButton saveDefault = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y, 112, ROW_H, Component.literal(successPrimarySaveLabel()),
                button -> { status = saveSuccessPrimary().message(); rebuild(); }));
        saveDefault.active = SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE;

        GyeokbuSmallButton saveHeld = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 120, y, 108, ROW_H, Component.literal("Save Held"),
                button -> { status = SuccessAnimationConfig.saveHeld().message(); rebuild(); }));
        saveHeld.active = SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.DEFAULT
                && SuccessAnimationConfig.getEditorProfileSource() != SuccessAnimationConfig.ProfileSource.FALLBACK
                && SuccessAnimationConfig.getEditorItemId() != null;

        GyeokbuSmallButton clear = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 236, y, 112, ROW_H,
                Component.literal(clearHeldConfirmationOpen ? "Are you sure?" : "Clear Held"),
                button -> requestClearHeld()));
        clear.active = !SuccessAnimationConfig.isEditorDefaultProfile()
                && SuccessAnimationConfig.hasItemOverride();

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y + 24, 112, ROW_H, Component.literal("Revert Saved"),
                button -> { status = SuccessAnimationConfig.revertDefault().message(); rebuild(); }));
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 120, y + 24, 112, ROW_H, Component.literal("Reset Default"),
                button -> { status = SuccessAnimationConfig.resetToBundledDefault().message(); rebuild(); }));
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 240, y + 24, 108, ROW_H, Component.literal("Reset Pose"),
                button -> { resetCurrentEditPose(); rebuild(); }));
    }

    private void addHeader() {
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X,
                PANEL_Y,
                92,
                20,
                Component.literal("‹ Stances"),
                button -> requestOpenStances()
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 98,
                PANEL_Y,
                DROPDOWN_WIDTH,
                20,
                Component.literal(
                        "[ "
                                + categoryDisplayName()
                                + (categoryDropdownOpen ? " ▲ ]" : " ▼ ]")
                ),
                button -> {
                    categoryDropdownOpen = !categoryDropdownOpen;
                    endPoseDropdownOpen = false;
                    playDropdownOpen = false;
                    if (categoryDropdownOpen) {
                        ensureCategoryVisible();
                    }
                    rebuild();
                }
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + uiPanelWidth() - 20,
                PANEL_Y,
                20,
                20,
                Component.literal("X"),
                button -> onClose()
        ));
    }

    private void addViewSelector() {
        int y = PANEL_Y + 28;

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X,
                y,
                156,
                ROW_H,
                Component.literal("Edit Third-Person"),
                button -> setFirstPerson(false),
                () -> !SuccessAnimationConfig.isEditorFirstPerson()
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 172,
                y,
                156,
                ROW_H,
                Component.literal("Edit First-Person"),
                button -> setFirstPerson(true),
                SuccessAnimationConfig::isEditorFirstPerson
        ));
    }

    private void addDefaultButton() {
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 86,
                PANEL_Y + 76,
                178,
                ROW_H,
                Component.literal(
                        "Use Default: "
                                + (SuccessAnimationConfig.isDefaultEnabled(dual) ? "YES" : "NO")
                ),
                button -> {
                    boolean enabled = !SuccessAnimationConfig.isDefaultEnabled(dual);
                    SuccessAnimationConfig.setDefaultEnabled(dual, enabled);
                    SuccessAnimationRuntime.cancelEditorPreview();
                    if (enabled) {
                        SuccessAnimationConfig.beginDefaultEditor(kind, dual);
                    } else {
                        SuccessAnimationConfig.beginEditor(kind, dual);
                    }
                    SuccessAnimationConfig.setEditorFirstPerson(
                            AnimationPoseConfig.isEditorFirstPerson()
                    );
                    status = enabled
                            ? "Successful Parry DEFAULT is now used for all weapon categories."
                            : "Successful Parry uses weapon-specific profiles.";
                    rebuild();
                },
                () -> SuccessAnimationConfig.isDefaultEnabled(dual)
        ));

        if (SuccessAnimationConfig.isEditorDefaultProfile()
                && BetterCombatWeaponMetadata.isAvailable()) {
            addRenderableWidget(new GyeokbuSmallButton(
                    PANEL_X + 270,
                    PANEL_Y + 76,
                    78,
                    ROW_H,
                    Component.literal(
                            SuccessAnimationConfig.getEditorDefaultHandedness() == SuccessAnimationConfig.DefaultHandedness.ONE_HANDED
                                    ? "Default: 1H"
                                    : "Default: 2H"
                    ),
                    button -> {
                        SuccessAnimationConfig.cycleEditorDefaultHandedness();
                        status = "Editing " + SuccessAnimationConfig.getEditorDefaultHandedness().displayName() + " Default.";
                        rebuild();
                    }
            ));
        }
    }

    private void addTransitionOverview(int y) {
        int rowY = y + 8;
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X,
                rowY,
                34,
                ROW_H,
                Component.literal(
                        SuccessAnimationConfig.isTransitionLinkEnabled()
                                ? "[✓]"
                                : "[ ]"
                ),
                button -> {
                    SuccessAnimationConfig.toggleTransitionLink();
                    status = SuccessAnimationConfig.isTransitionLinkEnabled()
                            ? "Linked first- and third-person transition ticks/styles."
                            : "Restored each view's previous transition ticks/styles.";
                    rebuild();
                }
        ));
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 42,
                rowY,
                158,
                ROW_H,
                Component.literal("Transition: " + SuccessAnimationConfig.getTransitionMode().displayName()),
                button -> {
                    SuccessAnimationConfig.cycleTransitionMode();
                    status = "Successful Parry transition changed.";
                    rebuild();
                }
        ));
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 208,
                rowY,
                100,
                ROW_H,
                Component.literal("Total: " + SuccessAnimationConfig.getTotalDurationTicks() + "t"),
                button -> {
                    SuccessAnimationConfig.adjustTotalDurationTicks(1);
                    status = "Successful Parry total duration changed.";
                    rebuild();
                }
        ));
    }

    private void addMainCopyPaste(int y) {
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X,
                y,
                132,
                ROW_H,
                Component.literal("Copy Pose"),
                button -> {
                    SuccessAnimationConfig.copyAnimation();
                    status = "Copied Successful Parry pose.";
                }
        ));

        GyeokbuSmallButton paste = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 140,
                y,
                136,
                ROW_H,
                Component.literal(pasteConfirmationOpen ? "Are you sure?" : "Paste Pose"),
                button -> requestPaste()
        ));
        paste.active = SuccessAnimationConfig.hasClipboard();
    }

    private void addEditModeWidgets() {
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, PANEL_Y, 104, ROW_H, Component.literal("← Exit Edit"),
                button -> exitEditMode()));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 114, PANEL_Y, 168, ROW_H,
                Component.literal(SuccessAnimationConfig.isEditorFirstPerson()
                        ? "First-Person ↔" : "Third-Person ↔"),
                button -> setFirstPerson(!SuccessAnimationConfig.isEditorFirstPerson())));

        int targetY = PANEL_Y + 26;
        boolean editingEndPose = SuccessAnimationConfig.getEditorPoint() >= 0;

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, targetY, 100, ROW_H, Component.literal(editTargetName()), button -> { })).active = false;

        /* End Pose is a true edit-mode cycle control.  It is always available
         * so Start Pose and End Pose remain separate targets without making
         * the user leave Edit mode.  Clicking from Start enters End Pose 1;
         * clicking again advances through all End Poses. */
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 106, targetY, 96, ROW_H,
                Component.literal("End " + (SuccessAnimationConfig.getSelectedEndPose() + 1) + " ↻"),
                button -> {
                    SuccessAnimationConfig.cycleSelectedEndPoseForEditing();
                    SuccessAnimationRuntime.cancelEditorPreview();
                    status = "Editing End Pose " + (SuccessAnimationConfig.getEditorPoint() + 1) + ".";
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 208, targetY, 74, ROW_H,
                Component.literal("Step " + format(step)), button -> cycleStep()));
        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 280, targetY, 68, ROW_H, Component.literal("Play"),
                button -> {
                    SuccessAnimationRuntime.startEditorPreview(playVariant);
                    status = playVariant < 0 ? "Playing Random End Pose."
                            : "Playing End Pose " + selectedPlayPoseNumber() + ".";
                }));

        addEditGroupButtons(PANEL_Y + 62);
        addEditControls(PANEL_Y + 90);
        addCrossViewEndPoseTool(PANEL_Y + 212);
        addViewTransferButtons(PANEL_Y + 232);
        addEditSaveOptions();
    }

    private void addEditGroupButtons(int y) {
        int gap = 6;
        int width = (uiPanelWidth() - gap * 3) / 4;

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y, width, ROW_H, Component.literal("MAIN ARM"),
                button -> { editGroup = EditGroup.MAIN_ARM; rebuild(); },
                () -> editGroup == EditGroup.MAIN_ARM));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + width + gap, y, width, ROW_H, Component.literal("OFF ARM"),
                button -> { editGroup = EditGroup.OFF_ARM; rebuild(); },
                () -> editGroup == EditGroup.OFF_ARM));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + (width + gap) * 2, y, width, ROW_H, Component.literal("MAIN WEAPON"),
                button -> { editGroup = EditGroup.MAIN_WEAPON; rebuild(); },
                () -> editGroup == EditGroup.MAIN_WEAPON));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + (width + gap) * 3, y, width, ROW_H, Component.literal("OFF WEAPON"),
                button -> { editGroup = EditGroup.OFF_WEAPON; rebuild(); },
                () -> editGroup == EditGroup.OFF_WEAPON));
    }

    private void addEditControls(int y) {
        SuccessAnimationChannel[] channels = switch (editGroup) {
            case MAIN_ARM -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_ARM_X,
                    SuccessAnimationChannel.MAIN_ARM_Y,
                    SuccessAnimationChannel.MAIN_ARM_Z
            };
            case OFF_ARM -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.OFF_ARM_X,
                    SuccessAnimationChannel.OFF_ARM_Y,
                    SuccessAnimationChannel.OFF_ARM_Z
            };
            case MAIN_WEAPON -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_WEAPON_POS_X,
                    SuccessAnimationChannel.MAIN_WEAPON_POS_Y,
                    SuccessAnimationChannel.MAIN_WEAPON_POS_Z,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_X,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_Y,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_Z
            };
            case OFF_WEAPON -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.OFF_WEAPON_POS_X,
                    SuccessAnimationChannel.OFF_WEAPON_POS_Y,
                    SuccessAnimationChannel.OFF_WEAPON_POS_Z,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_X,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_Y,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_Z
            };
        };

        int rowH = 20;
        for (int i = 0; i < Math.min(6, channels.length); i++) {
            SuccessAnimationChannel channel = channels[i];
            int rowY = y + i * rowH;

            /* Match the Stance editor's readable pattern: label/value are
               centered in the row, while the +/- hitboxes stay small and
               visually separate on the right. */
            addRenderableWidget(new GyeokbuSmallButton(
                    PANEL_X,
                    rowY,
                    240,
                    ROW_H,
                    Component.literal(
                            editorAxisLabel(channel)
                                    + ": "
                                    + format(SuccessAnimationConfig.getEditorValue(channel))
                    ),
                    button -> {
                        /* informational row */
                    }
            ));

            addRenderableWidget(new GyeokbuSmallButton(
                    PANEL_X + 246,
                    rowY,
                    36,
                    ROW_H,
                    Component.literal("−"),
                    button -> {
                        SuccessAnimationConfig.adjustEditorValue(channel, -step);
                        SuccessAnimationRuntime.cancelEditorPreview();
                        rebuild();
                    }
            ));

            addRenderableWidget(new GyeokbuSmallButton(
                    PANEL_X + 300,
                    rowY,
                    36,
                    ROW_H,
                    Component.literal("+"),
                    button -> {
                        SuccessAnimationConfig.adjustEditorValue(channel, step);
                        SuccessAnimationRuntime.cancelEditorPreview();
                        rebuild();
                    }
            ));
        }
    }

    private void addCrossViewEndPoseTool(int y) {
        if (SuccessAnimationConfig.getEditorPoint() < 0) {
            return;
        }

        int pose = SuccessAnimationConfig.getSelectedEndPose() + 1;
        boolean firstPerson = SuccessAnimationConfig.isEditorFirstPerson();
        String target = firstPerson ? "Third Person" : "First Person";
        SuccessAnimationConfig.CrossViewEndPoseTransferState state =
                SuccessAnimationConfig.getCrossViewEndPoseTransferState();

        String action = state == SuccessAnimationConfig.CrossViewEndPoseTransferState.OVERWRITE
                ? "Overwrite End Pose " + pose + " in " + target
                : "Create End Pose " + pose + " in " + target;

        GyeokbuSmallButton transfer = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y, uiPanelWidth() - 12, ROW_H, Component.literal(action),
                button -> requestCrossViewEndPoseTransfer()));
        transfer.active = state != SuccessAnimationConfig.CrossViewEndPoseTransferState.UNAVAILABLE;
    }

    private void addViewTransferButtons(int y) {
        boolean firstPerson = SuccessAnimationConfig.isEditorFirstPerson();
        String copyLabel = firstPerson ? "Copy → 3P" : "Copy → 1P";
        String mirrorLabel = firstPerson ? "Mirror 3P" : "Mirror 1P";

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X, y, 108, ROW_H, Component.literal(copyLabel), button -> {
                    if (firstPerson) SuccessAnimationConfig.copy1pTo3p();
                    else SuccessAnimationConfig.copy3pTo1p();
                    SuccessAnimationRuntime.cancelEditorPreview();
                    status = "Copied complete Successful Parry profile to the other view.";
                    rebuild();
                }));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 114, y, 108, ROW_H, Component.literal(mirrorLabel), button -> {
                    if (firstPerson) SuccessAnimationConfig.copy3pTo1p();
                    else SuccessAnimationConfig.copy1pTo3p();
                    SuccessAnimationRuntime.cancelEditorPreview();
                    status = "Replaced current Successful Parry profile with the other view.";
                    rebuild();
                }));
    }

    private void addEditSaveOptions() {
        int y = PANEL_Y + 256;

        addSectionLine(y - 10, "SAVE");

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X,
                y,
                108,
                ROW_H,
                Component.literal("Revert Saved"),
                button -> {
                    status = SuccessAnimationConfig.revertDefault().message();
                    rebuild();
                }
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 114,
                y,
                108,
                ROW_H,
                Component.literal("Reset Default"),
                button -> {
                    status = SuccessAnimationConfig.resetToBundledDefault().message();
                    rebuild();
                }
        ));

        GyeokbuSmallButton saveDefault = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 228,
                y,
                120,
                ROW_H,
                Component.literal("Save Default"),
                button -> {
                    status = SuccessAnimationConfig.saveDefault().message();
                    rebuild();
                }
        ));
        saveDefault.active = true;

        int secondRow = y + 26;

        GyeokbuSmallButton saveHeld = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X,
                secondRow,
                108,
                ROW_H,
                Component.literal("Save Held"),
                button -> {
                    status = SuccessAnimationConfig.saveHeld().message();
                    rebuild();
                }
        ));
        saveHeld.active = !SuccessAnimationConfig.isEditorDefaultProfile()
                && SuccessAnimationConfig.getEditorItemId() != null;

        GyeokbuSmallButton clear = addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 114,
                secondRow,
                148,
                ROW_H,
                Component.literal(clearHeldConfirmationOpen ? "Are you sure?" : "Clear Held Save"),
                button -> requestClearHeld()
        ));
        clear.active = !SuccessAnimationConfig.isEditorDefaultProfile()
                && SuccessAnimationConfig.hasItemOverride();

        addRenderableWidget(new GyeokbuSmallButton(
                PANEL_X + 268,
                secondRow,
                80,
                ROW_H,
                Component.literal("Reset"),
                button -> {
                    if (SuccessAnimationConfig.getEditorPoint() < 0) {
                        status = "Start Pose is " + SuccessAnimationConfig.getPointAMode().displayName() + ".";
                    } else {
                        status = "Resetting End Pose to the held Parry pose.";
                        resetCurrentEditPose();
                    }
                    rebuild();
                }
        ));
    }

    private void resetCurrentEditPose() {
        if (editGroup == EditGroup.OFF_WEAPON) {
            SuccessAnimationConfig.resetEditorWeapon(false);
        } else if (editGroup == EditGroup.MAIN_WEAPON) {
            SuccessAnimationConfig.resetEditorWeapon(true);
        } else if (editGroup == EditGroup.OFF_ARM) {
            SuccessAnimationConfig.resetEditorArm(false);
        } else {
            SuccessAnimationConfig.resetEditorArm(true);
        }
    }

    private void enterStartPoseEdit() {
        SuccessAnimationConfig.selectStartPoseForEditing();
        editMode = true;
        status = SuccessAnimationConfig.getPointAMode() == PointAMode.CURRENT
                ? "Current Pose Start: editing is unavailable; it follows the current pose."
                : "Editing Start Pose."
        ;
        rebuild();
    }

    private void enterEndPoseEdit() {
        SuccessAnimationConfig.selectEndPoseForEditing(
                SuccessAnimationConfig.getSelectedEndPose()
        );
        editMode = true;
        status = "Editing End Pose " + (SuccessAnimationConfig.getEditorPoint() + 1) + ".";
        rebuild();
    }

    private void exitEditMode() {
        if (SuccessAnimationConfig.hasUnsavedEditorChanges()) {
            status = "Unsaved changes stay in the editor until you Save or leave."
            ;
        }
        editMode = false;
        SuccessAnimationRuntime.cancelEditorPreview();
        rebuild();
    }

    private void setFirstPerson(boolean firstPerson) {
        SuccessAnimationConfig.setEditorFirstPerson(firstPerson);
        applyCameraMode();
        SuccessAnimationRuntime.cancelEditorPreview();
        status = firstPerson
                ? "Successful Parry First-Person preview."
                : "Successful Parry Third-Person preview.";
        rebuild();
    }

    private void applyCameraMode() {
        if (SuccessAnimationConfig.isEditorFirstPerson()) {
            StanceEditorCamera.useFirstPersonPreview();
        } else {
            StanceEditorCamera.useThirdPersonPreview();
            StanceEditorCamera.resetViewDirection();
        }
    }

    private String categoryDisplayName() {
        return SuccessAnimationConfig.editorProfileLabel();
    }

    private List<ParryStyle> availableCategories() {
        List<ParryStyle> result = new ArrayList<>();
        for (ParryStyle style : WeaponClassifier.getDetectedParryStyles()) {
            if (style != null
                    && style != ParryStyle.GENERIC
                    && !result.contains(style)) {
                result.add(style);
            }
        }
        return result;
    }

    private int categoryItemOverrideRow() {
        return !SuccessAnimationConfig.isDefaultEnabled(dual)
                && SuccessAnimationConfig.hasItemOverrideForCurrentItem()
                ? 2
                : -1;
    }

    private int categoryOptionCount() {
        return availableCategories().size()
                + 2
                + (categoryItemOverrideRow() >= 0 ? 1 : 0);
    }

    private int categoryStyleIndex(int optionIndex) {
        if (optionIndex == 0
                || optionIndex == 1
                || optionIndex == categoryItemOverrideRow()) {
            return -1;
        }
        return optionIndex - (categoryItemOverrideRow() >= 0 ? 3 : 2);
    }

    private List<String> categoryLabels() {
        List<String> labels = new ArrayList<>();
        labels.add("DEFAULT");
        labels.add("FALLBACK");
        if (categoryItemOverrideRow() >= 0) {
            labels.add("ITEM OVERRIDE");
        }
        for (ParryStyle style : availableCategories()) {
            labels.add(pretty(style));
        }
        return labels;
    }

    private void selectCategory(int index) {
        if (index < 0 || index >= categoryOptionCount()) {
            return;
        }

        if (index == 0) {
            SuccessAnimationConfig.selectDefaultProfile();
        } else if (index == 1) {
            SuccessAnimationConfig.selectEditorFallback();
        } else if (index == categoryItemOverrideRow()) {
            if (!SuccessAnimationConfig.selectEditorItemOverride()) {
                return;
            }
        } else {
            int styleIndex = categoryStyleIndex(index);
            List<ParryStyle> categories = availableCategories();
            if (styleIndex < 0 || styleIndex >= categories.size()) {
                return;
            }
            ParryStyle selected = categories.get(styleIndex);
            if (selected == ParryStyle.GENERIC) {
                SuccessAnimationConfig.selectDefaultProfile();
            } else {
                SuccessAnimationConfig.selectEditorStyle(selected);
            }
        }

        categoryDropdownOpen = false;
        endPoseDropdownOpen = false;
        playDropdownOpen = false;
        SuccessAnimationRuntime.cancelEditorPreview();
        status = "Editing " + categoryDisplayName() + " Successful Parry.";
        rebuild();
    }

    private void selectEndPose(int optionIndex) {
        List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
        if (optionIndex < 0 || optionIndex >= existing.size()) {
            return;
        }
        int poseIndex = existing.get(optionIndex);
        SuccessAnimationConfig.setSelectedEndPose(poseIndex);
        endPoseDropdownOpen = false;
        status = "Selected End Pose " + (poseIndex + 1) + ".";
        rebuild();
    }

    private void selectPlayVariant(int optionIndex) {
        if (optionIndex == 0) {
            playVariant = -1;
            status = "Play target: Random.";
        } else {
            List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
            int ordinal = optionIndex - 1;
            if (ordinal < 0 || ordinal >= existing.size()) {
                playVariant = -1;
            } else {
                playVariant = ordinal;
                status = "Play target: End Pose " + (existing.get(ordinal) + 1) + ".";
            }
        }
        playDropdownOpen = false;
        rebuild();
    }

    private int selectedPlayPoseNumber() {
        List<Integer> existing = SuccessAnimationConfig.getExistingEndPoseIndices();
        if (playVariant < 0 || playVariant >= existing.size()) {
            return 0;
        }
        return existing.get(playVariant) + 1;
    }

    private String playTargetLabel() {
        return playVariant < 0
                ? "Random"
                : "End " + selectedPlayPoseNumber();
    }

    private String editTargetName() {
        if (SuccessAnimationConfig.getEditorPoint() < 0) {
            return "Start Pose"
                    + (SuccessAnimationConfig.getPointAMode() == PointAMode.CUSTOM ? " (Custom)" : " (Current)");
        }
        return "End Pose " + (SuccessAnimationConfig.getEditorPoint() + 1);
    }

    private void requestDeleteEndPose() {
        if (!SuccessAnimationConfig.canRemovePointB()) {
            status = "At least one End Pose must remain.";
            return;
        }
        deleteConfirmationOpen = true;
        rebuild();
    }

    private void requestPaste() {
        if (!SuccessAnimationConfig.hasClipboard()) {
            status = "Successful Parry clipboard is empty.";
            return;
        }

        if (!pasteConfirmationOpen) {
            pasteConfirmationOpen = true;
            rebuild();
            return;
        }

        SuccessAnimationConfig.pasteAnimation();
        pasteConfirmationOpen = false;
        playVariant = -1;
        status = "Pasted Successful Parry pose.";
        rebuild();
    }

    private void requestClearHeld() {
        if (!SuccessAnimationConfig.hasItemOverride()) {
            return;
        }
        clearHeldConfirmationOpen = true;
        rebuild();
    }

    private void confirmDeleteEndPose() {
        SuccessAnimationConfig.removePointB();
        deleteConfirmationOpen = false;
        playVariant = -1;
        status = "End Pose removed.";
        rebuild();
    }

    private void confirmClearHeld() {
        status = SuccessAnimationConfig.clearItemOverride().message();
        clearHeldConfirmationOpen = false;
        rebuild();
    }

    private void requestCrossViewEndPoseTransfer() {
        SuccessAnimationConfig.CrossViewEndPoseTransferState state =
                SuccessAnimationConfig.getCrossViewEndPoseTransferState();
        if (state == SuccessAnimationConfig.CrossViewEndPoseTransferState.UNAVAILABLE) {
            status = "That End Pose cannot be transferred to the other view.";
            return;
        }

        pendingCrossViewOverwrite = state == SuccessAnimationConfig.CrossViewEndPoseTransferState.OVERWRITE;
        crossViewEndPoseConfirmationOpen = true;
        rebuild();
    }

    private void confirmCrossViewEndPoseTransfer() {
        boolean firstPersonSource = SuccessAnimationConfig.isEditorFirstPerson();
        int pose = SuccessAnimationConfig.getSelectedEndPose() + 1;
        boolean copied = SuccessAnimationConfig.copySelectedEndPoseToOtherView();

        crossViewEndPoseConfirmationOpen = false;
        pendingCrossViewOverwrite = false;

        if (copied) {
            SuccessAnimationRuntime.cancelEditorPreview();
            status = (firstPersonSource ? "Copied End Pose " : "Copied End Pose ") + pose
                    + " to " + (firstPersonSource ? "Third Person." : "First Person.");
        } else {
            status = "End Pose transfer was not available.";
        }
        rebuild();
    }

    private void addCrossViewEndPoseConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;
        String action = pendingCrossViewOverwrite ? "Overwrite" : "Create";

        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126,
                centerY + 24,
                118,
                20,
                Component.literal("Yes, " + action),
                button -> confirmCrossViewEndPoseTransfer()));

        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8,
                centerY + 24,
                118,
                20,
                Component.literal("No, Keep"),
                button -> {
                    crossViewEndPoseConfirmationOpen = false;
                    pendingCrossViewOverwrite = false;
                    rebuild();
                }));
    }

    private void requestOpenStances() {
        if (SuccessAnimationConfig.hasUnsavedEditorChanges()) {
            pendingExitToStances = true;
            exitConfirmationOpen = true;
            rebuild();
            return;
        }
        openStancesImmediately();
    }

    private void openStancesImmediately() {
        ParryStyle style = SuccessAnimationConfig.getEditorStyle();
        boolean openDual = dual;
        SuccessAnimationConfig.endEditor();
        SuccessAnimationRuntime.cancelLocal();
        StanceEditorCamera.end();

        Minecraft mc = Minecraft.getInstance();
        mc.setScreen(
                openDual
                        ? new DualWieldPoseEditorScreen()
                        : new PoseEditorScreen(
                        style == null || style == ParryStyle.GENERIC
                                ? WeaponClassifier.classifyNatural(mc.player.getMainHandItem()).parryStyle()
                                : style
                )
        );
    }

    private void addExitConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;

        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126,
                centerY + 24,
                118,
                20,
                Component.literal("Yes, Leave"),
                button -> {
                    exitConfirmationOpen = false;
                    if (pendingExitToStances) {
                        pendingExitToStances = false;
                        openStancesImmediately();
                    } else {
                        closeEditorImmediately();
                    }
                }
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8,
                centerY + 24,
                118,
                20,
                Component.literal("No, Stay"),
                button -> {
                    exitConfirmationOpen = false;
                    rebuild();
                }
        ));
    }

    private boolean pendingExitToStances;

    private void addDeleteConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;

        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126,
                centerY + 24,
                118,
                20,
                Component.literal("Yes, Remove"),
                button -> confirmDeleteEndPose()
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8,
                centerY + 24,
                118,
                20,
                Component.literal("No, Keep"),
                button -> {
                    deleteConfirmationOpen = false;
                    rebuild();
                }
        ));
    }

    private void addClearHeldConfirmationButtons() {
        int centerX = width / 2;
        int centerY = height / 2;

        addRenderableWidget(new GyeokbuSmallButton(
                centerX - 126,
                centerY + 24,
                118,
                20,
                Component.literal("Yes, Clear"),
                button -> confirmClearHeld()
        ));

        addRenderableWidget(new GyeokbuSmallButton(
                centerX + 8,
                centerY + 24,
                118,
                20,
                Component.literal("No, Keep"),
                button -> {
                    clearHeldConfirmationOpen = false;
                    rebuild();
                }
        ));
    }

    private void renderModal(
            GuiGraphics graphics,
            String title,
            String message
    ) {
        int centerX = width / 2;
        int centerY = height / 2;
        int boxWidth = 286;
        int left = centerX - boxWidth / 2;
        int top = centerY - 42;

        graphics.fill(
                left,
                top,
                left + boxWidth,
                centerY + 54,
                0xF0181818
        );
        graphics.fill(
                left,
                top,
                left + boxWidth,
                top + 1,
                0xFF808080
        );
        graphics.fill(
                left,
                centerY + 53,
                left + boxWidth,
                centerY + 54,
                0xFF808080
        );

        graphics.drawCenteredString(
                font,
                title,
                centerX,
                top + 13,
                0xFFFFD76A
        );
        graphics.drawCenteredString(
                font,
                message,
                centerX,
                top + 29,
                0xFFFFFFFF
        );
    }

    private void renderCategoryDropdown(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        List<String> labels = categoryLabels();
        String selectedName;
        if (SuccessAnimationConfig.isEditorDefaultProfile()) {
            selectedName = "DEFAULT";
        } else if (SuccessAnimationConfig.isEditorFallbackProfile()) {
            selectedName = "FALLBACK";
        } else if (SuccessAnimationConfig.getEditorProfileSource() == SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE) {
            selectedName = "ITEM OVERRIDE";
        } else {
            selectedName = pretty(SuccessAnimationConfig.getEditorStyle());
        }
        renderPopupBackground(
                graphics,
                PANEL_X + 98,
                PANEL_Y + 22,
                DROPDOWN_WIDTH,
                labels.size(),
                categoryDropdownOffset,
                labels,
                mouseX,
                mouseY,
                selectedName
        );
    }

    private void renderEndPoseDropdown(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        List<String> values = new ArrayList<>();
        for (int index : SuccessAnimationConfig.getExistingEndPoseIndices()) {
            values.add("End Pose " + (index + 1));
        }

        renderPopupBackground(
                graphics,
                editMode ? PANEL_X + 118 : PANEL_X,
                editMode ? PANEL_Y + 44 : PANEL_Y + 188,
                174,
                values.size(),
                0,
                values,
                mouseX,
                mouseY,
                "End Pose " + (SuccessAnimationConfig.getEditorPoint() + 1)
        );
    }

    private void renderPlayDropdown(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        List<String> values = new ArrayList<>();
        values.add("Random");
        for (int index : SuccessAnimationConfig.getExistingEndPoseIndices()) {
            values.add("End Pose " + (index + 1));
        }

        renderPopupBackground(
                graphics,
                editMode ? PANEL_X + 254 : PANEL_X + 82,
                editMode ? PANEL_Y + 56 : PANEL_Y + 132,
                PLAY_DROPDOWN_WIDTH,
                values.size(),
                playDropdownOffset,
                values,
                mouseX,
                mouseY,
                playTargetLabel()
        );
    }

    private <T> void renderPopupBackground(
            GuiGraphics graphics,
            int x,
            int y,
            int width,
            int totalRows,
            int offset,
            List<T> values,
            int mouseX,
            int mouseY,
            String selectedName
    ) {
        int visible = Math.min(DROPDOWN_VISIBLE_ROWS, Math.max(0, totalRows - offset));
        if (visible <= 0) {
            return;
        }

        int height = visible * DROPDOWN_ROW_H;

        graphics.pose().pushPose();
        graphics.pose().translate(0F, 0F, 300F);

        graphics.fill(x - 2, y - 2, x + width + 2, y + height + 2, 0xE8000000);
        graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xE84A4A4A);
        graphics.fill(x, y, x + width, y + height, 0xE8121212);

        graphics.enableScissor(x, y, x + width, y + height);
        for (int row = 0; row < visible; row++) {
            int index = offset + row;
            T option = values.get(index);
            String name = option instanceof ParryStyle style
                    ? (style == ParryStyle.GENERIC ? "FALLBACK" : pretty(style))
                    : option.toString();
            int rowY = y + row * DROPDOWN_ROW_H;
            boolean hovered = mouseX >= x
                    && mouseX < x + width
                    && mouseY >= rowY
                    && mouseY < rowY + DROPDOWN_ROW_H;

            if (hovered) {
                graphics.fill(
                        x + 1,
                        rowY + 1,
                        x + width - 1,
                        rowY + DROPDOWN_ROW_H - 1,
                        0xE83A3A3A
                );
            } else if (name.equals(selectedName)) {
                graphics.fill(
                        x + 1,
                        rowY + 1,
                        x + width - 1,
                        rowY + DROPDOWN_ROW_H - 1,
                        0xE82A2A2A
                );
            }

            boolean selected = name.equals(selectedName);
            graphics.drawString(
                    font,
                    (selected ? "• " : "  ") + name,
                    x + 7,
                    rowY + 5,
                    selected ? 0xFFF2C14E : 0xFFFFFFFF
            );
        }
        graphics.disableScissor();

        if (totalRows > DROPDOWN_VISIBLE_ROWS) {
            int trackLeft = x + width - 7;
            int trackRight = x + width - 3;
            int trackHeight = height - 4;
            int thumbHeight = Math.max(
                    12,
                    (int) Math.floor(
                            trackHeight * (DROPDOWN_VISIBLE_ROWS / (double) totalRows)
                    )
            );
            int maxOffset = totalRows - visible;
            int thumbY = y + 2 + (
                    maxOffset <= 0
                            ? 0
                            : (int) Math.floor(
                            (trackHeight - thumbHeight)
                                    * (offset / (double) maxOffset)
                    )
            );

            graphics.fill(
                    trackLeft,
                    y + 2,
                    trackRight,
                    y + height - 2,
                    0xE8242424
            );
            graphics.fill(
                    trackLeft,
                    thumbY,
                    trackRight,
                    thumbY + thumbHeight,
                    0xE88A8A8A
            );
        }

        graphics.pose().popPose();
    }

    private void renderPanel(
            GuiGraphics graphics
    ) {
        int height = editMode ? 360 : 410;
        graphics.fill(
                PANEL_X - 4,
                PANEL_Y - 4,
                PANEL_X + uiPanelWidth() + 4,
                PANEL_Y + height,
                0xA8121212
        );
    }

    private void addSectionLabel(int y, String label) {
        /* Rendered in render(), so only its Y is needed here. */
    }

    private void addSectionLine(int y, String label) {
        /* Rendered in render(), so only its Y is needed here. */
    }

    private void cycleStep() {
        if (Math.abs(step - 0.01F) < 0.0001F) {
            step = 0.05F;
        } else if (Math.abs(step - 0.05F) < 0.0001F) {
            step = 0.10F;
        } else {
            step = 0.01F;
        }
        status = "Adjustment step = " + format(step) + ".";
        rebuild();
    }

    private String editorAxisLabel(SuccessAnimationChannel channel) {
        return switch (channel) {
            case MAIN_ARM_X -> "Main Arm X";
            case MAIN_ARM_Y -> "Main Arm Y";
            case MAIN_ARM_Z -> "Main Arm Z";
            case OFF_ARM_X -> "Off Arm X";
            case OFF_ARM_Y -> "Off Arm Y";
            case OFF_ARM_Z -> "Off Arm Z";
            case MAIN_WEAPON_POS_X -> "Weapon Pos X";
            case MAIN_WEAPON_POS_Y -> "Weapon Pos Y";
            case MAIN_WEAPON_POS_Z -> "Weapon Pos Z";
            case MAIN_WEAPON_ROT_X -> "Weapon Rot X";
            case MAIN_WEAPON_ROT_Y -> "Weapon Rot Y";
            case MAIN_WEAPON_ROT_Z -> "Weapon Rot Z";
            case OFF_WEAPON_POS_X -> "Off Weapon Pos X";
            case OFF_WEAPON_POS_Y -> "Off Weapon Pos Y";
            case OFF_WEAPON_POS_Z -> "Off Weapon Pos Z";
            case OFF_WEAPON_ROT_X -> "Off Weapon Rot X";
            case OFF_WEAPON_ROT_Y -> "Off Weapon Rot Y";
            case OFF_WEAPON_ROT_Z -> "Off Weapon Rot Z";
        };
    }

    private static String pretty(ParryStyle style) {
        if (style == null || style == ParryStyle.GENERIC) {
            return "Default";
        }
        StringBuilder result = new StringBuilder();
        for (String word : style.name().toLowerCase(Locale.ROOT).split("_")) {
            if (word.isEmpty()) {
                continue;
            }
            if (!result.isEmpty()) {
                result.append(' ');
            }
            result.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1));
        }
        return result.toString();
    }

    private static String format(float value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private void ensureCategoryVisible() {
        List<ParryStyle> categories = availableCategories();
        int selected;
        if (SuccessAnimationConfig.isEditorDefaultProfile()) {
            selected = 0;
        } else if (SuccessAnimationConfig.isEditorFallbackProfile()) {
            selected = 1;
        } else if (SuccessAnimationConfig.getEditorProfileSource() == SuccessAnimationConfig.ProfileSource.ITEM_OVERRIDE
                && categoryItemOverrideRow() >= 0) {
            selected = categoryItemOverrideRow();
        } else {
            int styleIndex = categories.indexOf(SuccessAnimationConfig.getEditorStyle());
            selected = Math.max(2, styleIndex + (categoryItemOverrideRow() >= 0 ? 3 : 2));
        }

        if (selected < categoryDropdownOffset) {
            categoryDropdownOffset = selected;
        } else if (selected >= categoryDropdownOffset + DROPDOWN_VISIBLE_ROWS) {
            categoryDropdownOffset = selected - DROPDOWN_VISIBLE_ROWS + 1;
        }

        categoryDropdownOffset = Math.max(0, Math.min(
                categoryDropdownOffset,
                Math.max(0, categoryOptionCount() - 1)
        ));
    }

    private void rebuild() {
        init();
    }

    @Override
    public boolean mouseClicked(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button == 0 && categoryDropdownOpen) {
            int index = dropdownIndexAt(
                    mouseX,
                    mouseY,
                    PANEL_X + 98,
                    PANEL_Y + 22,
                    DROPDOWN_WIDTH,
                    categoryOptionCount(),
                    categoryDropdownOffset
            );
            if (index >= 0) {
                selectCategory(index);
                return true;
            }

            categoryDropdownOpen = false;
            rebuild();
            return true;
        }

        if (button == 0 && endPoseDropdownOpen) {
            int count = SuccessAnimationConfig.getExistingEndPoseCount();
            int index = dropdownIndexAt(
                    mouseX,
                    mouseY,
                    editMode ? PANEL_X + 118 : PANEL_X,
                    editMode ? PANEL_Y + 44 : PANEL_Y + 188,
                    174,
                    count,
                    0
            );
            if (index >= 0) {
                selectEndPose(index);
                return true;
            }

            endPoseDropdownOpen = false;
            rebuild();
            return true;
        }

        if (button == 0 && playDropdownOpen) {
            int total = SuccessAnimationConfig.getExistingEndPoseCount() + 1;
            int index = dropdownIndexAt(
                    mouseX,
                    mouseY,
                    editMode ? PANEL_X + 254 : PANEL_X + 82,
                    editMode ? PANEL_Y + 56 : PANEL_Y + 132,
                    PLAY_DROPDOWN_WIDTH,
                    total,
                    playDropdownOffset
            );
            if (index >= 0) {
                selectPlayVariant(index);
                return true;
            }

            playDropdownOpen = false;
            rebuild();
            return true;
        }

        if (button == 0) {
            AdjustHitbox hit = findAdjustment(mouseX, mouseY);
            if (hit != null && editMode) {
                heldAdjust = hit;
                heldTicks = 0;
                applyAdjustment(hit);
                return true;
            }
        }

        if (button == 1
                && !SuccessAnimationConfig.isEditorFirstPerson()
                && (mouseX > PANEL_X + uiPanelWidth() || mouseY > PANEL_Y + 324)) {
            orbitHeld = true;
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(
            double mouseX,
            double mouseY,
            int button,
            double dragX,
            double dragY
    ) {
        if (button == 1 && orbitHeld) {
            StanceEditorCamera.orbit(dragX, dragY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(
            double mouseX,
            double mouseY,
            int button
    ) {
        if (button == 0) {
            heldAdjust = null;
            heldTicks = 0;
        }
        if (button == 1) {
            orbitHeld = false;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX,
            double mouseY,
            double scrollX,
            double scrollY
    ) {
        if (categoryDropdownOpen) {
            if (scrollY > 0) {
                categoryDropdownOffset = Math.max(0, categoryDropdownOffset - 1);
                rebuild();
                return true;
            }
            if (scrollY < 0) {
                int max = Math.max(
                        0,
                        categoryOptionCount() - DROPDOWN_VISIBLE_ROWS
                );
                categoryDropdownOffset = Math.min(max, categoryDropdownOffset + 1);
                rebuild();
                return true;
            }
        }

        if (playDropdownOpen) {
            if (scrollY > 0) {
                playDropdownOffset = Math.max(0, playDropdownOffset - 1);
                rebuild();
                return true;
            }
            if (scrollY < 0) {
                int total = SuccessAnimationConfig.getExistingEndPoseCount() + 1;
                int max = Math.max(0, total - DROPDOWN_VISIBLE_ROWS);
                playDropdownOffset = Math.min(max, playDropdownOffset + 1);
                rebuild();
                return true;
            }
        }

        if (!SuccessAnimationConfig.isEditorFirstPerson()) {
            StanceEditorCamera.zoom(scrollY);
            return true;
        }

        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void tick() {
        super.tick();

        if (heldAdjust == null || !editMode) {
            return;
        }

        heldTicks++;
        if (heldTicks >= 8 && (heldTicks - 8) % 2 == 0) {
            applyAdjustment(heldAdjust);
        }
    }

    private AdjustHitbox findAdjustment(
            double mouseX,
            double mouseY
    ) {
        if (!editMode) {
            return null;
        }

        SuccessAnimationChannel[] channels = switch (editGroup) {
            case MAIN_ARM -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_ARM_X,
                    SuccessAnimationChannel.MAIN_ARM_Y,
                    SuccessAnimationChannel.MAIN_ARM_Z
            };
            case OFF_ARM -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.OFF_ARM_X,
                    SuccessAnimationChannel.OFF_ARM_Y,
                    SuccessAnimationChannel.OFF_ARM_Z
            };
            case MAIN_WEAPON -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.MAIN_WEAPON_POS_X,
                    SuccessAnimationChannel.MAIN_WEAPON_POS_Y,
                    SuccessAnimationChannel.MAIN_WEAPON_POS_Z,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_X,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_Y,
                    SuccessAnimationChannel.MAIN_WEAPON_ROT_Z
            };
            case OFF_WEAPON -> new SuccessAnimationChannel[]{
                    SuccessAnimationChannel.OFF_WEAPON_POS_X,
                    SuccessAnimationChannel.OFF_WEAPON_POS_Y,
                    SuccessAnimationChannel.OFF_WEAPON_POS_Z,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_X,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_Y,
                    SuccessAnimationChannel.OFF_WEAPON_ROT_Z
            };
        };

        int baseY = PANEL_Y + 90;
        for (int i = 0; i < Math.min(6, channels.length); i++) {
            int rowY = baseY + i * 22;
            if (mouseX >= PANEL_X && mouseX < PANEL_X + 174
                    && mouseY >= rowY && mouseY < rowY + ROW_H) {
                return new AdjustHitbox(channels[i], -1);
            }
            if (mouseX >= PANEL_X + 182 && mouseX < PANEL_X + 348
                    && mouseY >= rowY && mouseY < rowY + ROW_H) {
                return new AdjustHitbox(channels[i], 1);
            }
        }
        return null;
    }

    private void applyAdjustment(AdjustHitbox hit) {
        SuccessAnimationConfig.adjustEditorValue(
                hit.channel,
                hit.direction * step
        );
        SuccessAnimationRuntime.cancelEditorPreview();
    }

    private int dropdownIndexAt(
            double mouseX,
            double mouseY,
            int x,
            int y,
            int width,
            int total,
            int offset
    ) {
        int visible = Math.min(
                DROPDOWN_VISIBLE_ROWS,
                Math.max(0, total - offset)
        );
        if (mouseX < x || mouseX >= x + width
                || mouseY < y || mouseY >= y + visible * DROPDOWN_ROW_H) {
            return -1;
        }

        int row = (int) ((mouseY - y) / DROPDOWN_ROW_H);
        int result = offset + row;
        return result >= 0 && result < total ? result : -1;
    }

    private void addHeaderText(
            GuiGraphics graphics
    ) {
        graphics.drawString(
                font,
                "Successful Parry",
                PANEL_X + 8,
                PANEL_Y + 316,
                0xFFFFFFFF
        );
    }

    @Override
    public void renderBackground(
            GuiGraphics graphics,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        /* Match Stance editor: do not blur or render an extra screen background. */
    }

    @Override
    public void render(
            GuiGraphics graphics,
            int mouseX,
            int mouseY,
            float partialTick
    ) {
        renderPanel(graphics);

        if (!editMode) {
            renderOverviewLabels(graphics);
        } else {
            renderEditLabels(graphics);
        }

        super.render(graphics, mouseX, mouseY, partialTick);

        if (!exitConfirmationOpen
                && !deleteConfirmationOpen
                && !clearHeldConfirmationOpen
                && !crossViewEndPoseConfirmationOpen) {
            renderDelayedTooltip(graphics, mouseX, mouseY);
        }

        if (!exitConfirmationOpen
                && !deleteConfirmationOpen
                && !clearHeldConfirmationOpen
                && !crossViewEndPoseConfirmationOpen) {
            if (categoryDropdownOpen && !editMode) {
                renderCategoryDropdown(graphics, mouseX, mouseY);
            }
            if (endPoseDropdownOpen) {
                renderEndPoseDropdown(graphics, mouseX, mouseY);
            }
            if (playDropdownOpen) {
                renderPlayDropdown(graphics, mouseX, mouseY);
            }
        }

        if (exitConfirmationOpen) {
            renderModal(
                    graphics,
                    "Unsaved changes",
                    "Leave F8 without saving them?"
            );
        } else if (deleteConfirmationOpen) {
            renderModal(
                    graphics,
                    "Are you sure?",
                    "Remove End Pose " + (SuccessAnimationConfig.getSelectedEndPose() + 1) + "?"
            );
        } else if (clearHeldConfirmationOpen) {
            renderModal(
                    graphics,
                    "Are you sure?",
                    "Clear this held Successful Parry?"
            );
        } else if (crossViewEndPoseConfirmationOpen) {
            int pose = SuccessAnimationConfig.getSelectedEndPose() + 1;
            boolean targetFirstPerson = !SuccessAnimationConfig.isEditorFirstPerson();
            String target = targetFirstPerson ? "First Person" : "Third Person";
            String action = pendingCrossViewOverwrite ? "Overwrite" : "Create";
            renderModal(
                    graphics,
                    "Are you sure?",
                    action + " End Pose " + pose + " in " + target + " using the current values?"
            );
        }

        renderStatus(graphics);
    }

    private void renderOverviewLabels(GuiGraphics graphics) {
        drawDivider(graphics, PANEL_Y + 98, "PLAYBACK");
        drawDivider(graphics, PANEL_Y + 128, "START POSE");
        drawDivider(graphics, PANEL_Y + 158, "END POSE");
        drawDivider(graphics, PANEL_Y + 190, "TRANSITIONS");
        drawDivider(graphics, PANEL_Y + 264, "COPY / PASTE");
        drawDivider(graphics, PANEL_Y + 304, "SAVE");
    }

    private void renderEditLabels(GuiGraphics graphics) {
        drawDivider(graphics, PANEL_Y + 54, "POSE EDIT");
        drawDivider(graphics, PANEL_Y + 208, "POSE TOOLS");
        drawDivider(graphics, PANEL_Y + 230, "VIEW TRANSFER");
        drawDivider(graphics, PANEL_Y + 252, "SAVE");
    }

    private void drawDivider(
            GuiGraphics graphics,
            int y,
            String label
    ) {
        int center = PANEL_X + uiPanelWidth() / 2;
        int labelWidth = font.width(label);

        graphics.fill(
                PANEL_X + 8,
                y,
                center - labelWidth / 2 - 8,
                y + 1,
                0x50FFFFFF
        );
        graphics.fill(
                center + labelWidth / 2 + 8,
                y,
                PANEL_X + uiPanelWidth() - 8,
                y + 1,
                0x50FFFFFF
        );
        graphics.drawCenteredString(
                font,
                label,
                center,
                y - 4,
                0xFFB8B8B8
        );
    }

    private void renderDelayedTooltip(
            GuiGraphics graphics,
            int mouseX,
            int mouseY
    ) {
        TooltipContent tooltip = findTooltipAt(mouseX, mouseY);
        if (tooltip == null) {
            hoveredTooltipKey = "";
            tooltipHoverStartNanos = 0L;
            return;
        }

        long now = System.nanoTime();
        if (!tooltip.key().equals(hoveredTooltipKey)) {
            hoveredTooltipKey = tooltip.key();
            tooltipHoverStartNanos = now;
            return;
        }
        if (now - tooltipHoverStartNanos < TOOLTIP_DELAY_NANOS) {
            return;
        }

        int maxWidth = 0;
        for (String line : tooltip.lines()) {
            maxWidth = Math.max(maxWidth, font.width(line));
        }
        int boxWidth = maxWidth + 12;
        int boxHeight = tooltip.lines().size() * font.lineHeight + 10;
        int x = mouseX + boxWidth > width ? mouseX - boxWidth : mouseX;
        int y = mouseY + boxHeight > height ? mouseY - boxHeight : mouseY;
        graphics.fill(x, y, x + boxWidth, y + boxHeight, 0xF0101010);
        graphics.fill(x, y, x + boxWidth, y + 1, 0xFF808080);
        for (int i = 0; i < tooltip.lines().size(); i++) {
            graphics.drawString(font, tooltip.lines().get(i), x + 6, y + 5 + i * font.lineHeight, 0xFFFFFFFF);
        }
    }

    private TooltipContent findTooltipAt(double mouseX, double mouseY) {
        if (endPoseDropdownOpen) {
            int count = SuccessAnimationConfig.getExistingEndPoseCount();
            int index = dropdownIndexAt(
                    mouseX, mouseY,
                    editMode ? PANEL_X + 118 : PANEL_X,
                    editMode ? PANEL_Y + 44 : PANEL_Y + 188,
                    174, count, 0);
            if (index >= 0) {
                return new TooltipContent("end-option:" + index, List.of(
                        "Edit End Pose " + (index + 1) + ".",
                        "Stay in Edit mode while switching."));
            }
        }

        for (var child : children()) {
            if (child instanceof net.minecraft.client.gui.components.AbstractWidget widget
                    && widget.isMouseOver(mouseX, mouseY)) {
                String text = widget.getMessage().getString().trim();
                if (text.startsWith("End ")) {
                    return new TooltipContent("end-selector", List.of(
                            "Choose which End Pose to edit.",
                            "You can switch without leaving Edit mode."));
                }
                if (text.equals("MAIN ARM")) {
                    return new TooltipContent("main-arm", List.of("Edit the main-hand arm rotation."));
                }
                if (text.equals("OFF ARM")) {
                    return new TooltipContent("off-arm", List.of("Edit the off-hand arm rotation."));
                }
                if (text.equals("MAIN WEAPON")) {
                    return new TooltipContent("main-weapon", List.of("Edit the main-hand weapon position and rotation."));
                }
                if (text.equals("OFF WEAPON")) {
                    return new TooltipContent("off-weapon", List.of("Edit the off-hand weapon position and rotation."));
                }
                if (text.startsWith("Default: ")) {
                    return new TooltipContent("default-handedness", List.of(
                            "Edit the one- or two-handed Default variant.",
                            "Used only when Better Combat reports that handedness."));
                }
                if (text.equals("First-Person ↔") || text.equals("Third-Person ↔")) {
                    return new TooltipContent("view", List.of("Switch between First- and Third-Person editing."));
                }
                if (text.startsWith("Step")) {
                    return new TooltipContent("step", List.of("Change how much each + or − press moves."));
                }
                if (text.equals("Play")) {
                    return new TooltipContent("play", List.of("Preview the selected Successful Parry."));
                }
            }
        }
        return null;
    }

    private record TooltipContent(String key, List<String> lines) { }

    private void renderStatus(
            GuiGraphics graphics
    ) {
        int y = editMode ? PANEL_Y + 304 : PANEL_Y + 380;
        graphics.fill(
                PANEL_X + 8,
                y,
                PANEL_X + uiPanelWidth() - 8,
                y + 1,
                0x40FFFFFF
        );

        String message = status.isEmpty()
                ? "Editing: " + categoryDisplayName() + " Successful Parry"
                : status;

        int maxWidth = uiPanelWidth() - 18;
        if (font.width(message) > maxWidth) {
            String trimmed = message;
            while (!trimmed.isEmpty() && font.width(trimmed + "...") > maxWidth) {
                trimmed = trimmed.substring(0, trimmed.length() - 1);
            }
            message = trimmed + "...";
        }

        graphics.drawString(
                font,
                message,
                PANEL_X + 8,
                y + 7,
                0xFFD0D0D0
        );
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        if (exitConfirmationOpen) {
            exitConfirmationOpen = false;
            rebuild();
            return;
        }

        if (deleteConfirmationOpen) {
            deleteConfirmationOpen = false;
            rebuild();
            return;
        }

        if (clearHeldConfirmationOpen) {
            clearHeldConfirmationOpen = false;
            rebuild();
            return;
        }

        if (crossViewEndPoseConfirmationOpen) {
            crossViewEndPoseConfirmationOpen = false;
            pendingCrossViewOverwrite = false;
            rebuild();
            return;
        }

        if (editMode) {
            editMode = false;
            SuccessAnimationRuntime.cancelEditorPreview();
            rebuild();
            return;
        }

        if (SuccessAnimationConfig.hasUnsavedEditorChanges()) {
            pendingExitToStances = false;
            exitConfirmationOpen = true;
            rebuild();
            return;
        }

        closeEditorImmediately();
    }

    private void closeEditorImmediately() {
        SuccessAnimationConfig.endEditor();
        SuccessAnimationRuntime.cancelLocal();
        StanceEditorCamera.end();
        super.onClose();
    }

    @Override
    public void removed() {
        orbitHeld = false;
        heldAdjust = null;
        SuccessAnimationRuntime.cancelEditorPreview();
        StanceEditorCamera.end();
        SuccessAnimationConfig.endEditor();
        super.removed();
    }

    private enum EditGroup {
        MAIN_ARM,
        OFF_ARM,
        MAIN_WEAPON,
        OFF_WEAPON
    }

    private record AdjustHitbox(
            SuccessAnimationChannel channel,
            int direction
    ) {
    }
}
