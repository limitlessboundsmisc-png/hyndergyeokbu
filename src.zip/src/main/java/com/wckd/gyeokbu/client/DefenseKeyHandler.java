package com.wckd.gyeokbu.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.network.DefenseInputPayload;
import com.wckd.gyeokbu.network.FallbackWeaponSyncPayload;
import com.wckd.gyeokbu.compat.ThrowableWeaponCompat;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.settings.KeyConflictContext;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

public final class DefenseKeyHandler {

    public static final KeyMapping DEFENSE_KEY =
            new KeyMapping(
                    "key.gyeokbuv2.defense",
                    KeyConflictContext.IN_GAME,
                    InputConstants.Type.MOUSE,
                    GLFW.GLFW_MOUSE_BUTTON_RIGHT,
                    "key.categories.gyeokbuv2"
            );

    /*
     * Development pose editor.
     *
     * F8 is only the default. It can be changed normally
     * from Minecraft's Controls menu.
     */
    public static final KeyMapping POSE_EDITOR_KEY =
            new KeyMapping(
                    "key.gyeokbuv2.pose_editor",
                    KeyConflictContext.IN_GAME,
                    InputConstants.Type.KEYSYM,
                    GLFW.GLFW_KEY_F8,
                    "key.categories.gyeokbuv2"
            );

    private static boolean wasDown =
            false;

    private static boolean defenseActive =
            false;

    private static ResourceLocation lastFallbackSyncItemId =
            null;

    /*
     * Set by the client game-mode mixin when vanilla successfully consumes
     * this RMB press on a block or entity. The normal world interaction wins;
     * Gyeokbu does not also start a Parry.
     */
    private static boolean vanillaInteractionConsumed =
            false;

    private DefenseKeyHandler() {
    }

    @EventBusSubscriber(
            modid = GyeokbuV2.MODID,
            value = Dist.CLIENT,
            bus = EventBusSubscriber.Bus.MOD
    )
    public static class ModEvents {

        @SubscribeEvent
        public static void registerKeys(
                RegisterKeyMappingsEvent event
        ) {

            event.register(
                    DEFENSE_KEY
            );

            event.register(
                    POSE_EDITOR_KEY
            );
        }
    }

    @EventBusSubscriber(
            modid = GyeokbuV2.MODID,
            value = Dist.CLIENT
    )
    public static class GameEvents {

        /**
         * Vanilla-combat fallback for attack input while Gyeokbu defense is
         * active. Better Combat-compatible attacks use Gyeokbu's existing
         * Better Combat integration instead.
         *
         * PARRY: attacking is not allowed during the live 0.25 s Parry window.
         * BLOCK: the same left click drops Block first, then vanilla continues
         * processing that click as the normal attack. This also works on misses
         * because it reacts to attack input rather than waiting for damage.
         */
        @SubscribeEvent
        public static void onVanillaAttackInput(
                InputEvent.InteractionKeyMappingTriggered event
        ) {
            if (!event.isAttack()) {
                return;
            }

            Minecraft minecraft =
                    Minecraft.getInstance();

            if (minecraft.player == null
                    || minecraft.screen != null) {
                return;
            }

            int defenseMode =
                    ClientCombatSyncState.getDefenseAnimationMode(
                            minecraft.player.getId()
                    );

            if (defenseMode == DefenseAnimationSyncPayload.PARRY) {
                event.setCanceled(true);
                event.setSwingHand(false);
                return;
            }

            if (defenseMode == DefenseAnimationSyncPayload.BLOCK) {
                sendDefenseReleased();
            }
        }

        @SubscribeEvent
        public static void onClientTick(
                ClientTickEvent.Post event
        ) {

            Minecraft minecraft =
                    Minecraft.getInstance();

            if (minecraft.player == null) {

                resetInputState();
                return;
            }

            ClientCombatSyncState.tickParryCooldown();

            syncHeldFallbackIfNeeded(
                    minecraft
            );

            /*
             * Open the editor only from normal gameplay.
             *
             * The held weapon is classified once when the
             * editor opens. The screen then previews that
             * ParryStyle locally without activating combat.
             */
            if (minecraft.screen == null
                    && POSE_EDITOR_KEY.consumeClick()) {

                ItemStack mainHand =
                        minecraft.player
                                .getMainHandItem();

                WeaponProfile profile =
                        WeaponClassifier.classify(
                                mainHand
                        );

                if (mainHand.isEmpty()) {

                    minecraft.player
                            .displayClientMessage(
                                    Component.literal(
                                            "Hold a weapon before opening the Gyeokbu pose editor."
                                    ),
                                    true
                            );

                    return;
                }

                if (!profile.isSupported()) {
                    minecraft.player
                            .displayClientMessage(
                                    Component.literal(
                                            "Hold a Gyeokbu-recognized weapon before opening the pose editor."
                                    ),
                                    true
                            );

                    return;
                }

                if (defenseActive) {

                    sendDefenseReleased();
                }

                wasDown =
                        false;

                if (DualWieldRules
                        .isDualWield(
                                minecraft.player
                        )) {

                    minecraft.setScreen(
                            new DualWieldPoseEditorScreen()
                    );

                } else {

                    minecraft.setScreen(
                            new PoseEditorScreen(
                                    profile.parryStyle()
                            )
                    );
                }

                return;
            }

            if (minecraft.screen != null) {

                if (defenseActive) {
                    sendDefenseReleased();
                }

                wasDown =
                        false;

                vanillaInteractionConsumed =
                        false;

                return;
            }

            ItemStack mainHand =
                    minecraft.player
                            .getMainHandItem();

            boolean nativeThrowWeaponHeld =
                    ThrowableWeaponCompat
                            .hasNativeThrowWeapon(
                                    minecraft.player
                            );

            boolean nativeThrowRequested =
                    nativeThrowWeaponHeld
                            && minecraft.player
                                    .isShiftKeyDown();

            boolean nativeThrowActive =
                    ThrowableWeaponCompat
                            .isThrowActionActive(
                                    minecraft.player
                            );

            boolean isDown =
                    DEFENSE_KEY.isDown();

            boolean interactionConsumed =
                    vanillaInteractionConsumed;

            vanillaInteractionConsumed =
                    false;

            /*
             * Shift + RMB belongs to the native throwable implementation.
             *
             * If Gyeokbu was already active, release it immediately and do
             * not reinterpret the still-held RMB as a future buffered parry.
             */
            if ((nativeThrowRequested
                    || nativeThrowActive)
                    && defenseActive) {

                sendDefenseReleased();
            }

            /*
             * Client input is intentionally permissive. The server owns weapon
             * classification, loadout validation, Better Combat attack-commit
             * rules, and the authoritative missed-Parry cooldown.
             *
             * Keeping those same checks here can silently swallow RMB for
             * modded weapons before DefenseManager ever receives the request.
             */
            boolean canRequestGyeokbu =
                    !mainHand.isEmpty()
                            && !nativeThrowRequested
                            && !nativeThrowActive;

            /*
             * Fresh RMB press only. Holding RMB through a native throw/cancel
             * never becomes a buffered Gyeokbu attempt. During the mirrored
             * missed-Parry cooldown the click is ignored completely: no packet,
             * no predicted defense flag, and therefore no Parry animation.
             */
            if (isDown
                    && !wasDown
                    && !ClientCombatSyncState.isParryCooldownActive()
                    && !ClientCombatSyncState.isLocalParryPredictionActive()) {

                if (!interactionConsumed
                        && canRequestGyeokbu) {

                    int masteryLevel = Math.min(
                            3,
                            com.wckd.gyeokbu.enchantment.GyeokbuEnchantments.getLevel(
                                    minecraft.player.level(),
                                    mainHand,
                                    com.wckd.gyeokbu.enchantment.GyeokbuEnchantments.MASTERY
                            )
                    );

                    /* If a Successful Parry is still visually playing, seed
                     * the normal defense transition from the exact pose on
                     * screen before starting the new Parry. This makes an
                     * interrupted End Pose / recovery flow directly into the
                     * configured Parry stance instead of snapping. */
                    SuccessAnimationRuntime.prepareDefenseInterruption(
                            minecraft.player
                    );

                    ClientCombatSyncState.beginLocalParryPrediction(
                            minecraft.player.getId(),
                            com.wckd.gyeokbu.combat.DefenseManager.PARRY_TICKS + masteryLevel
                    );
                    sendDefensePressed();
                }
            }

            if (defenseActive
                    && !canRequestGyeokbu) {

                sendDefenseReleased();
            }

            if (!isDown
                    && wasDown
                    && defenseActive) {

                sendDefenseReleased();
            }

            wasDown =
                    isDown;
        }
    }

    public static void markVanillaInteractionConsumed() {
        vanillaInteractionConsumed = true;
    }

    private static void syncHeldFallbackIfNeeded(
            Minecraft minecraft
    ) {
        ItemStack mainHand =
                minecraft.player.getMainHandItem();

        if (mainHand.isEmpty()) {
            lastFallbackSyncItemId = null;
            return;
        }

        ResourceLocation itemId =
                BuiltInRegistries.ITEM.getKey(
                        mainHand.getItem()
                );

        var fallbackStyle =
                WeaponClassifier.getUserFallbackStyle(
                        itemId
                );

        if (fallbackStyle == null) {
            lastFallbackSyncItemId = null;
            return;
        }

        if (itemId.equals(lastFallbackSyncItemId)) {
            return;
        }

        PacketDistributor.sendToServer(
                new FallbackWeaponSyncPayload(
                        itemId.toString(),
                        fallbackStyle.name(),
                        true
                )
        );

        lastFallbackSyncItemId =
                itemId;
    }

    private static void sendDefensePressed() {

        Minecraft minecraft =
                Minecraft.getInstance();

        if (minecraft.player != null
                && !minecraft.player.getMainHandItem().isEmpty()) {

            var itemId =
                    BuiltInRegistries.ITEM.getKey(
                            minecraft.player
                                    .getMainHandItem()
                                    .getItem()
                    );

            var fallbackStyle =
                    WeaponClassifier.getUserFallbackStyle(
                            itemId
                    );

            /*
             * Re-send fallback support immediately before defense so a fresh
             * dedicated-server connection is synchronized before the normal
             * server-authoritative DefenseInputPayload reaches it.
             */
            if (fallbackStyle != null) {
                PacketDistributor.sendToServer(
                        new FallbackWeaponSyncPayload(
                                itemId.toString(),
                                fallbackStyle.name(),
                                true
                        )
                );
            }
        }

        /*
         * Clear any stale Better Combat action state before this defense
         * request. If a swing is genuinely still active, the tracker leaves it
         * alone and the server keeps enforcing the normal hit-confirm rule.
         */
        BetterCombatActionTracker.synchronizeBeforeParryRequest();

        PacketDistributor.sendToServer(
                new DefenseInputPayload(
                        true
                )
        );

        defenseActive =
                true;
    }

    private static void sendDefenseReleased() {

        PacketDistributor.sendToServer(
                new DefenseInputPayload(
                        false
                )
        );

        defenseActive =
                false;
    }

    private static void resetInputState() {

        wasDown =
                false;

        defenseActive =
                false;

        lastFallbackSyncItemId =
                null;

        vanillaInteractionConsumed =
                false;
    }
}
