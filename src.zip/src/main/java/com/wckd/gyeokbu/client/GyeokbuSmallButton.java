package com.wckd.gyeokbu.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;

/**
 * Lightweight editor control for low-priority actions/settings.
 * Major navigation remains on normal Minecraft buttons.
 */
public final class GyeokbuSmallButton extends AbstractButton {
    @FunctionalInterface
    public interface OnPress {
        void onPress(GyeokbuSmallButton button);
    }

    private final OnPress onPress;
    private final BooleanSupplier selected;

    public GyeokbuSmallButton(int x, int y, int width, int height,
                              Component message, OnPress onPress) {
        this(x, y, width, height, message, onPress, () -> false);
    }

    public GyeokbuSmallButton(int x, int y, int width, int height,
                              Component message, OnPress onPress,
                              BooleanSupplier selected) {
        super(x, y, width, height, message);
        this.onPress = onPress;
        this.selected = selected;
    }

    @Override
    public void onPress() {
        if (active) onPress.onPress(this);
    }

    @Override
    protected void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        int bg = !active ? 0x60353535 : (isHovered() ? 0xBC575757 : 0x8E2F2F2F);
        graphics.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(), bg);

        if (selected.getAsBoolean()) {
            int c = 0xFFF2F2F2;
            graphics.fill(getX(), getY(), getX() + getWidth(), getY() + 1, c);
            graphics.fill(getX(), getY() + getHeight() - 1, getX() + getWidth(), getY() + getHeight(), c);
            graphics.fill(getX(), getY(), getX() + 1, getY() + getHeight(), c);
            graphics.fill(getX() + getWidth() - 1, getY(), getX() + getWidth(), getY() + getHeight(), c);
        }

        int text = active ? 0xF4F4F4 : 0x909090;
        net.minecraft.client.gui.Font font = net.minecraft.client.Minecraft.getInstance().font;
        int availableWidth = Math.max(1, getWidth() - 8);
        int messageWidth = font.width(getMessage());

        /* Minecraft GUI coordinates are already scaled by the current GUI
         * scale, so fixed-width buttons need to keep their text inside their
         * own bounds instead of assuming the default 6px-ish glyph budget.
         * Only shrink when necessary; normal labels keep their normal size. */
        float scale = messageWidth > availableWidth
                ? Math.max(0.76F, availableWidth / (float) messageWidth)
                : 1.0F;

        graphics.pose().pushPose();
        float centerX = getX() + getWidth() * 0.5F;
        float centerY = getY() + getHeight() * 0.5F;
        graphics.pose().translate(centerX, centerY, 0.0F);
        graphics.pose().scale(scale, scale, 1.0F);
        graphics.drawCenteredString(
                font,
                getMessage(),
                0,
                -4,
                text
        );
        graphics.pose().popPose();
    }

    @Override
    protected void updateWidgetNarration(net.minecraft.client.gui.narration.NarrationElementOutput output) {
        defaultButtonNarrationText(output);
    }
}
