package com.wckd.gyeokbu.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Shared layout primitives for every Gyeokbu F8 editor.
 *
 * The editor screens intentionally use different controls, but they share one
 * geometry system so spacing, columns, panel sizing and text bounds stay
 * consistent as the screen size / GUI scale changes.
 */
public final class F8Layout {
    public static final int SCREEN_MARGIN = 12;
    public static final int INNER = 12;
    public static final int GAP = 8;
    public static final int SECTION_GAP = 8;
    public static final int ROW_H = 20;
    public static final int SMALL_ROW_H = 18;
    public static final int ROW_GAP = 6;
    public static final int DIVIDER_GAP = 7;
    /** Minimum vertical slot reserved for a section heading plus its separation from the next row. */
    public static final int SECTION_HEADER_H = 22;
    public static final int MIN_PANEL_W = 320;
    public static final int MAX_PANEL_W = 380;

    private F8Layout() {}

    public static int panelX(int screenWidth) {
        return SCREEN_MARGIN;
    }

    public static int panelY() {
        return SCREEN_MARGIN;
    }

    public static int panelWidth(int screenWidth, int preferred) {
        int available = Math.max(MIN_PANEL_W, screenWidth - 320 - SCREEN_MARGIN * 3);
        return clamp(preferred, MIN_PANEL_W, Math.min(MAX_PANEL_W, available));
    }

    public static int focusPanelWidth(int screenWidth, int normalPanelWidth) {
        return Math.min(normalPanelWidth, panelWidth(screenWidth, 360));
    }

    public static int previewWidth(int screenWidth, int panelWidth) {
        int remaining = screenWidth - panelWidth - SCREEN_MARGIN * 3;
        return clamp(remaining, 280, 420);
    }

    public static int contentX(int panelX) {
        return panelX + INNER;
    }

    public static int contentWidth(int panelWidth) {
        return Math.max(1, panelWidth - INNER * 2);
    }

    public static int halfWidth(int contentWidth) {
        return Math.max(1, (contentWidth - GAP) / 2);
    }

    public static int thirdWidth(int contentWidth) {
        return Math.max(1, (contentWidth - GAP * 2) / 3);
    }

    public static int fourthWidth(int contentWidth) {
        return Math.max(1, (contentWidth - GAP * 3) / 4);
    }

    public static int columnX(int contentX, int column, int columnWidth) {
        return contentX + column * (columnWidth + GAP);
    }

    public static int rightOfPanel(int panelX, int panelWidth, int screenWidth, int controlWidth) {
        return Math.max(panelX + panelWidth + GAP * 2, screenWidth - controlWidth - SCREEN_MARGIN);
    }

    public static String fit(Font font, String text, int maxWidth) {
        if (text == null || text.isEmpty() || maxWidth <= 0 || font.width(text) <= maxWidth) {
            return text == null ? "" : text;
        }

        String ellipsis = "...";
        int available = Math.max(0, maxWidth - font.width(ellipsis));
        if (available <= 0) {
            return ellipsis;
        }
        return font.plainSubstrByWidth(text, available) + ellipsis;
    }

    public static Component fit(Font font, Component component, int maxWidth) {
        if (component == null || maxWidth <= 0 || font.width(component) <= maxWidth) {
            return component;
        }
        return Component.literal(fit(font, component.getString(), maxWidth));
    }

    public static void drawSection(
            GuiGraphics graphics,
            Font font,
            int panelX,
            int panelWidth,
            int y,
            String label
    ) {
        String safe = fit(font, label, Math.max(24, panelWidth - INNER * 2 - 48));
        int center = panelX + panelWidth / 2;
        int labelWidth = font.width(safe);
        int leftEnd = center - labelWidth / 2 - DIVIDER_GAP;
        int rightStart = center + labelWidth / 2 + DIVIDER_GAP;
        graphics.fill(panelX + INNER, y, Math.max(panelX + INNER, leftEnd), y + 1, 0x50FFFFFF);
        graphics.fill(Math.min(panelX + panelWidth - INNER, rightStart), y,
                panelX + panelWidth - INNER, y + 1, 0x50FFFFFF);
        graphics.drawCenteredString(font, safe, center, y - 5, 0xD8D8D8);
    }

    public static void drawFittedLeft(
            GuiGraphics graphics,
            Font font,
            String text,
            int x,
            int y,
            int maxWidth,
            int color
    ) {
        graphics.drawString(font, fit(font, text, maxWidth), x, y, color, false);
    }

    public static boolean rectsOverlap(
            int ax, int ay, int aw, int ah,
            int bx, int by, int bw, int bh
    ) {
        return ax < bx + bw && ax + aw > bx
                && ay < by + bh && ay + ah > by;
    }

    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }



    /** A screen-space rectangle used for collision-safe overlay placement. */
    public record Rect(int x, int y, int width, int height) {
        public boolean contains(double px, double py) {
            return px >= x && px < x + width
                    && py >= y && py < y + height;
        }

        public boolean overlaps(Rect other) {
            if (other == null) {
                return false;
            }
            return x < other.x + other.width
                    && x + width > other.x
                    && y < other.y + other.height
                    && y + height > other.y;
        }
    }

    /**
     * Places a dropdown around its anchor without intersecting any reserved
     * screen rectangles. Candidates are tried in a deliberate order so menus
     * prefer the open side of the control while remaining on-screen.
     */
    public static Rect placeDropdown(
            int screenWidth,
            int screenHeight,
            Rect anchor,
            int dropdownWidth,
            int desiredHeight,
            List<Rect> reserved,
            int gap
    ) {
        int w = Math.max(1, dropdownWidth);
        int requestedHeight = Math.max(1, desiredHeight);
        int g = Math.max(0, gap);

        /* A dropdown is allowed to show fewer rows when the screen has too
         * little free space. It will scroll rather than ever covering another
         * control. */
        for (int h = requestedHeight; h >= SMALL_ROW_H; h -= SMALL_ROW_H) {
            List<Rect> candidates = new ArrayList<>();
            /* The normal dropdown position is directly below the control.
             * The editor panel itself is not part of the collision set; only
             * reserved interactive/important controls are. */
            addCandidate(candidates, anchor.x, anchor.y + anchor.height + g, w, h);
            addCandidate(candidates, anchor.x, anchor.y - h - g, w, h);
            addCandidate(candidates, anchor.x + anchor.width + g, anchor.y, w, h);
            addCandidate(candidates, anchor.x - w - g, anchor.y, w, h);
            addCandidate(candidates, anchor.x + anchor.width + g, anchor.y + anchor.height - h, w, h);
            addCandidate(candidates, anchor.x - w - g, anchor.y + anchor.height - h, w, h);

            if (reserved != null) {
                for (Rect block : reserved) {
                    addCandidate(candidates, block.x + block.width + g, anchor.y, w, h);
                    addCandidate(candidates, block.x - w - g, anchor.y, w, h);
                    addCandidate(candidates, anchor.x, block.y + block.height + g, w, h);
                    addCandidate(candidates, anchor.x, block.y - h - g, w, h);
                }
            }

            addCandidate(candidates, screenWidth - w - SCREEN_MARGIN, SCREEN_MARGIN, w, h);
            addCandidate(candidates, SCREEN_MARGIN, SCREEN_MARGIN, w, h);
            addCandidate(candidates, screenWidth - w - SCREEN_MARGIN,
                    screenHeight - h - SCREEN_MARGIN, w, h);
            addCandidate(candidates, SCREEN_MARGIN,
                    screenHeight - h - SCREEN_MARGIN, w, h);

            Rect best = null;
            int bestPenalty = Integer.MAX_VALUE;
            for (Rect candidate : candidates) {
                Rect inside = clampInside(candidate, screenWidth, screenHeight, SCREEN_MARGIN);
                boolean collision = false;
                if (reserved != null) {
                    for (Rect other : reserved) {
                        if (inside.overlaps(other)) {
                            collision = true;
                            break;
                        }
                    }
                }
                if (collision) {
                    continue;
                }

                int penalty = Math.abs(inside.x - anchor.x)
                        + Math.abs(inside.y - anchor.y);
                if (penalty < bestPenalty) {
                    bestPenalty = penalty;
                    best = inside;
                }
            }

            if (best != null) {
                return best;
            }
        }

        /* Extremely small/saturated screens can leave no free rectangle even
         * for one row. Keep the popup on-screen as the last-resort fallback. */
        int safeX = clamp(anchor.x, SCREEN_MARGIN,
                Math.max(SCREEN_MARGIN, screenWidth - w - SCREEN_MARGIN));
        int safeY = clamp(anchor.y + anchor.height + g, SCREEN_MARGIN,
                Math.max(SCREEN_MARGIN, screenHeight - SMALL_ROW_H - SCREEN_MARGIN));
        return new Rect(safeX, safeY, w, SMALL_ROW_H);
    }

    private static void addCandidate(
            List<Rect> candidates,
            int x,
            int y,
            int width,
            int height
    ) {
        candidates.add(new Rect(x, y, width, height));
    }

    private static Rect clampInside(
            Rect rect,
            int screenWidth,
            int screenHeight,
            int margin
    ) {
        int maxX = Math.max(margin, screenWidth - rect.width - margin);
        int maxY = Math.max(margin, screenHeight - rect.height - margin);
        return new Rect(
                clamp(rect.x, margin, maxX),
                clamp(rect.y, margin, maxY),
                rect.width,
                rect.height
        );
    }

    public static final class Cursor {
        private int y;

        public Cursor(int top) {
            this.y = top;
        }

        public int y() {
            return y;
        }

        public int row() {
            int current = y;
            y += ROW_H + ROW_GAP;
            return current;
        }

        public int smallRow() {
            int current = y;
            y += SMALL_ROW_H + ROW_GAP;
            return current;
        }

        public int gap(int pixels) {
            y += Math.max(0, pixels);
            return y;
        }

        public int section() {
            y += SECTION_GAP;
            return y;
        }

        /**
         * Reserve a dedicated grid slot for a section label. The returned Y
         * is the divider/label centerline; the cursor advances beyond the
         * label slot so the next control cannot overlap its text or divider.
         */
        public int sectionHeader() {
            int labelY = y + 8;
            y += SECTION_HEADER_H;
            return labelY;
        }

        public int finish() {
            return y;
        }
    }
}
