package com.wckd.gyeokbu.client;

import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import dev.kosmx.playerAnim.api.TransformType;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonConfiguration;
import dev.kosmx.playerAnim.api.firstPerson.FirstPersonMode;
import dev.kosmx.playerAnim.api.layered.IAnimation;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import org.jetbrains.annotations.NotNull;



/**
 * Procedural Gyeokbu third-person defense animation layer.
 *
 * Despite the historical class name, this handles every current
 * ParryStyle through AnimationPoseConfig.
 */
public final class GlaiveParryAnimation implements IAnimation {

    private final AbstractClientPlayer player;

    public GlaiveParryAnimation(
            AbstractClientPlayer player
    ) {

        this.player =
                player;
    }

    @Override
    public boolean isActive() {

        if (isLocalEditorPreview()) {
            return true;
        }

        if (SuccessAnimationRuntime.isActive(
                player,
                isLocalFirstPersonView()
        )) {
            return true;
        }

        boolean firstPerson =
                isLocalFirstPersonView();

        int mode =
                firstPerson
                        ? ClientCombatSyncState
                        .getFirstPersonDefenseVisualMode(
                                player.getId()
                        )
                        : ClientCombatSyncState
                        .getDefenseAnimationMode(
                                player.getId()
                        );

        return DefensePoseTransitionRuntime
                .isVisualActive(
                        player,
                        firstPerson,
                        mode
                );
    }

    @Override
    public @NotNull Vec3f get3DTransform(
            @NotNull String modelName,
            @NotNull TransformType type,
            float tickDelta,
            @NotNull Vec3f value0
    ) {

        /* The editor is itself a first-person PAL presentation.  The old
         * runtime-only helper intentionally returned false while the Success
         * editor was open, which made the editor use third-person semantics
         * (notably zero look pitch).  Treat the actual camera pass as the
         * source of truth here so F8 and the live Parry share the same model
         * transform path. */
        boolean firstPerson = isLocalFirstPersonPresentation();

        /*
         * Successful Parry owns the defensive presentation window. Better Combat
         * can leave a full-body attack layer active on the same PlayerAnimator
         * stack, even after the attack has been logically canceled. If that
         * lower layer is allowed to contribute its body/root rotation, a weapon
         * attack animation can pitch the entire player forward (the
         * head-first "dive" symptom) and can also pull first-person arms away
         * from their authored F8 pose.
         *
         * During live Successful Parry, keep the normal vanilla body/torso
         * orientation and let Gyeokbu own the arm/weapon transforms below.
         * Walking/other lower layers remain available for bones we do not own.
         */
        if (SuccessAnimationRuntime.isRunning(player, firstPerson)
                && isSuccessfulParryRootBone(modelName)) {
            if (type == TransformType.ROTATION
                    || type == TransformType.POSITION) {
                return new Vec3f(0.0F, 0.0F, 0.0F);
            }
        }

        /* Successful Parry already owns the held-item bones while PAL is
         * presenting the third-person model in first person. This is what makes
         * the Success editor's OFF_WEAPON position/rotation values visible in
         * the real first-person presentation instead of only in third person. */
        boolean successItemBone = "right_item".equals(modelName) || "rightItem".equals(modelName)
                || "left_item".equals(modelName) || "leftItem".equals(modelName);
        if (successItemBone && firstPerson && Minecraft.getInstance().player == player) {
            boolean physicalRight = "right_item".equals(modelName) || "rightItem".equals(modelName);
            boolean mainHand = isPhysicalRightModel(physicalRight, player);
            Vec3f rotation;
            Vec3f position;

            if (SuccessAnimationConfig.isEditorActive()) {
                rotation = SuccessAnimationConfig.getEditorWeaponRotation(mainHand);
                position = SuccessAnimationConfig.getEditorWeaponPosition(mainHand);
            } else if (SuccessAnimationRuntime.isActive(player, firstPerson)) {
                rotation = SuccessAnimationRuntime.weaponRotation(player, firstPerson, mainHand);
                position = SuccessAnimationRuntime.weaponPosition(player, firstPerson, mainHand);
            } else {
                rotation = null;
                position = null;
            }

            if (type == TransformType.ROTATION && rotation != null) {
                return rotation;
            }
            if (type == TransformType.POSITION && position != null) {
                return new Vec3f(
                        value0.getX() + position.getX(),
                        value0.getY() + position.getY(),
                        value0.getZ() + position.getZ()
                );
            }
        }

        if (type != TransformType.ROTATION) {
            return value0;
        }

        /*
         * While editing, keep the head facing straight with the body.
         * The camera can orbit freely without making the player stare
         * back at it.
         */
        if (isLocalEditorPreview()
                && ("head".equals(modelName)
                || "head_rotation".equals(modelName))) {

            return new Vec3f(
                    0.0F,
                    0.0F,
                    0.0F
            );
        }

        /*
         * Editor preview is normally a static pose.  Successful Parry's Play
         * button is different: while its preview is running, route the exact
         * sampled animation through the same render path used by the live
         * Successful Parry runtime.  This keeps the editor preview honest.
         */
        if (isLocalEditorPreview()) {

            AnimationPoseConfig.ArmPose editorPose;

            if (SuccessAnimationConfig.isEditorActive()
                    && SuccessAnimationRuntime.isEditorPreviewActive(
                    player,
                    firstPerson
            )) {
                editorPose =
                        SuccessAnimationRuntime.armPose(
                                player,
                                firstPerson
                        );
            } else if (SuccessAnimationConfig.isEditorActive()) {
                editorPose =
                        SuccessAnimationConfig.getEditorArmPose();
            } else {
                editorPose =
                        DualWieldPoseConfig.isEditorActive()
                                ? DualWieldPoseConfig.getEditorPose()
                                : AnimationPoseConfig.getEditorPose();
            }

            if (editorPose == null) {
                return value0;
            }

            float editorLookPitch = firstPerson
                    ? renderLookPitch(player, tickDelta)
                    : 0.0F;
            return getArmRotation(
                    modelName,
                    editorPose.mainHand(),
                    editorPose.offHand(),
                    value0,
                    editorLookPitch,
                    player
            );
        }

        boolean isSuccessArmBone =
                "rightArm".equals(modelName) || "right_arm".equals(modelName)
                        || "leftArm".equals(modelName) || "left_arm".equals(modelName);

        if (isSuccessArmBone && SuccessAnimationRuntime.isActive(
                player,
                firstPerson
        )) {
            boolean physicalRight =
                    "rightArm".equals(modelName)
                            || "right_arm".equals(modelName);
            boolean mainHand =
                    isPhysicalRightModel(
                            physicalRight,
                            player
                    );
            float runtimeLookPitch =
                    renderLookPitch(
                            player,
                            tickDelta
                    );

            /*
             * Runtime owns the entire Successful Parry arm transition,
             * including the configured curve for End -> Current. The lower
             * PlayerAnimator value is supplied as the actual recovery target,
             * so returning control never snaps to a stale or reconstructed
             * pose.
             */
            Vec3f sampled =
                    SuccessAnimationRuntime.sampleArmRotation(
                            player,
                            firstPerson,
                            mainHand,
                            value0,
                            runtimeLookPitch
                    );

            if (sampled != null) {
                return sampled;
            }

            /* During first-person handoff or after the Success layer finishes,
             * keep the real underlying PlayerAnimator pose. */
            return value0;
        }

        int mode =
                firstPerson
                        ? ClientCombatSyncState
                        .getFirstPersonDefenseVisualMode(
                                player.getId()
                        )
                        : ClientCombatSyncState
                        .getDefenseAnimationMode(
                                player.getId()
                        );

        AnimationPoseConfig.ArmPose pose =
                null;

        if (mode != 0) {

            if (DualWieldRules.isDualWield(player)) {

                pose =
                        DualWieldPoseConfig.getRuntimePose(
                                player,
                                mode,
                                firstPerson
                        );

            } else {

                ParryStyle parryStyle =
                        WeaponClassifier
                                .classify(
                                        player.getMainHandItem()
                                )
                                .parryStyle();

                pose =
                        firstPerson
                                ? AnimationPoseConfig.getFirstPersonPoseFor(
                                player.getMainHandItem(),
                                parryStyle,
                                mode
                        )
                                : AnimationPoseConfig.getPoseFor(
                                player.getMainHandItem(),
                                parryStyle,
                                mode
                        );
            }
        }

        String channel;
        Vec3f target;

        switch (modelName) {

            case "rightArm",
                 "right_arm" -> {
                channel =
                        DefensePoseTransitionRuntime.RIGHT_ARM;
                boolean mainHand = isPhysicalRightModel(true, player);
                target =
                        pose == null
                                ? value0
                                : withLookPitch(
                                mainHand ? pose.mainHand() : pose.offHand(),
                                renderLookPitch(player, tickDelta)
                        );
            }

            case "leftArm",
                 "left_arm" -> {
                channel =
                        DefensePoseTransitionRuntime.LEFT_ARM;
                boolean mainHand = isPhysicalRightModel(false, player);
                target =
                        pose == null
                                ? value0
                                : withLookPitch(
                                mainHand ? pose.mainHand() : pose.offHand(),
                                renderLookPitch(player, tickDelta)
                        );
            }

            default -> {
                return value0;
            }
        }

        return DefensePoseTransitionRuntime.sample(
                player,
                firstPerson,
                channel,
                mode,
                target,
                value0
        );
    }

    private static boolean isSuccessfulParryRootBone(String modelName) {
        return "body".equals(modelName)
                || "torso".equals(modelName)
                || "body_rotation".equals(modelName)
                || "torso_rotation".equals(modelName);
    }

    private boolean isLocalEditorPreview() {

        return (AnimationPoseConfig
                .isEditorActive()
                || DualWieldPoseConfig
                .isEditorActive()
                || SuccessAnimationConfig
                .isEditorActive())
                && Minecraft.getInstance()
                .player == player;
    }

    private static Vec3f getArmRotation(
            String modelName,
            Vec3f mainHand,
            Vec3f offHand,
            Vec3f original,
            float runtimeLookPitch,
            AbstractClientPlayer player
    ) {

        return switch (modelName) {

            case "rightArm",
                 "right_arm" ->
                    withLookPitch(
                            isPhysicalRightModel(true, player) ? mainHand : offHand,
                            runtimeLookPitch
                    );

            case "leftArm",
                 "left_arm" ->
                    withLookPitch(
                            isPhysicalRightModel(false, player) ? mainHand : offHand,
                            runtimeLookPitch
                    );

            default ->
                    original;
        };
    }

    /**
     * Applies vertical look direction as a true render-only PARENT rotation.
     *
     * PlayerAnimator applies arm Euler rotations in Z -> Y -> X order. The old
     * implementation simply added look pitch to saved X. That only behaves
     * like a parent pitch while the other saved axes are simple; with a rolled
     * arm (especially non-zero Z), looking up/down no longer keeps the whole
     * stance aligned with the camera.
     *
     * Build the equivalent matrix for:
     *
     *     cameraPitch * saved(Z -> Y -> X)
     *
     * then decompose it back into the Z -> Y -> X Euler values expected by
     * PlayerAnimator. F8's saved X/Y/Z values remain completely unchanged.
     */
    private static Vec3f withLookPitch(
            Vec3f savedPose,
            float runtimeLookPitch
    ) {
        return FirstPersonPoseMath.applyCameraPitch(
                savedPose,
                runtimeLookPitch
        );
    }

    private static double clampUnit(
            double value
    ) {
        return Math.max(
                -1.0D,
                Math.min(
                        1.0D,
                        value
                )
        );
    }

    private static float renderLookPitch(
            AbstractClientPlayer player,
            float tickDelta
    ) {
        /* Match the camera's interpolated pitch instead of sampling the last
         * completed game tick.  This removes the small one-frame mismatch that
         * becomes very noticeable when a custom first-person pose has large
         * arm pitch/roll values. */
        float pitch = player.getViewXRot(tickDelta);
        return (float) Math.toRadians(pitch);
    }

    private static boolean isPhysicalRightModel(
            boolean physicalRight,
            AbstractClientPlayer player
    ) {
        return physicalRight == (player.getMainArm() == net.minecraft.world.entity.HumanoidArm.RIGHT);
    }

    private boolean isLocalFirstPersonPresentation() {
        Minecraft minecraft = Minecraft.getInstance();
        return minecraft.player == player
                && minecraft.options.getCameraType() == CameraType.FIRST_PERSON;
    }

    private boolean isLocalFirstPersonView() {

        Minecraft minecraft =
                Minecraft.getInstance();

        return minecraft.player == player
                && minecraft.options
                .getCameraType()
                == CameraType.FIRST_PERSON
                && !AnimationPoseConfig
                .isEditorActive()
                && !DualWieldPoseConfig
                .isEditorActive()
                && !SuccessAnimationConfig
                .isEditorActive();
    }

    private boolean isLocalFirstPersonEditorPreview() {

        Minecraft minecraft =
                Minecraft.getInstance();

        return minecraft.player == player
                && minecraft.options
                .getCameraType()
                == CameraType.FIRST_PERSON
                && (
                (
                        AnimationPoseConfig
                                .isEditorActive()
                                && AnimationPoseConfig
                                .isEditorFirstPerson()
                )
                        || (
                        DualWieldPoseConfig
                                .isEditorActive()
                                && DualWieldPoseConfig
                                .isEditorFirstPerson()
                )
                        || (
                        SuccessAnimationConfig.isEditorActive()
                                && SuccessAnimationConfig.isEditorFirstPerson()
                )
        );
    }

    /**
     * Gyeokbu only requests a PlayerAnimator first-person presentation while
     * the local defensive visual/editor preview is active. Outside defense,
     * vanilla/other combat rendering remains untouched.
     */
    @Override
    public @NotNull FirstPersonMode getFirstPersonMode(
            float tickDelta
    ) {

        if (!isLocalFirstPersonEditorPreview()) {

            if (!isLocalFirstPersonView()) {
                return FirstPersonMode.NONE;
            }

            int mode =
                    ClientCombatSyncState
                            .getFirstPersonDefenseVisualMode(
                                    player.getId()
                            );

            boolean visualActive =
                    DefensePoseTransitionRuntime
                            .isVisualActive(
                                    player,
                                    true,
                                    mode
                            )
                            || SuccessAnimationRuntime
                            .isActive(
                                    player,
                                    true
                            );

            if (!visualActive) {
                return FirstPersonMode.NONE;
            }
        }

        return getGyeokbuFirstPersonMode();
    }

    @Override
    public @NotNull FirstPersonConfiguration getFirstPersonConfiguration(
            float tickDelta
    ) {

        if (!isLocalFirstPersonEditorPreview()) {

            if (!isLocalFirstPersonView()) {
                return new FirstPersonConfiguration();
            }

            int mode =
                    ClientCombatSyncState
                            .getFirstPersonDefenseVisualMode(
                                    player.getId()
                            );

            boolean visualActive =
                    DefensePoseTransitionRuntime
                            .isVisualActive(
                                    player,
                                    true,
                                    mode
                            )
                            || SuccessAnimationRuntime
                            .isActive(
                                    player,
                                    true
                            );

            if (!visualActive) {
                return new FirstPersonConfiguration();
            }
        }

        return new FirstPersonConfiguration(
                true,
                true,
                true,
                true
        );
    }

    /**
     * Gyeokbu owns first-person rendering only while its synchronized defense
     * visual is active. Better Combat's first-person preference applies to
     * Better Combat attacks/idle rendering, but it must not be allowed to turn
     * an already accepted Gyeokbu PARRY/BLOCK state invisible. Outside defense
     * getFirstPersonMode() still returns NONE above, so vanilla/Better Combat
     * immediately regain control.
     */
    private static FirstPersonMode getGyeokbuFirstPersonMode() {
        return FirstPersonMode.THIRD_PERSON_MODEL;
    }

    @Override
    public void setupAnim(
            float tickDelta
    ) {

        /*
         * Static procedural poses for now.
         */
    }
}