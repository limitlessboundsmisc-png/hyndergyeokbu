package com.wckd.gyeokbu.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Client-only visual transition settings for Gyeokbu stances.
 *
 * Combat state changes remain immediate/server-authoritative. These values
 * only control how the client visually moves toward the new pose.
 */
public final class DefenseTransitionConfig {

    public enum Mode {
        SNAP("Snap"),
        LINEAR("Linear"),
        SMOOTH("Smooth"),
        QUICK("Quick"),
        OVERSHOOT("Overshoot");

        private final String displayName;

        Mode(String displayName) {
            this.displayName = displayName;
        }

        public String displayName() {
            return displayName;
        }

        /**
         * Reads current and legacy serialized names without exposing legacy
         * modes in the editor's cycle order.
         */
        public static Mode fromSerializedName(
                String value,
                Mode fallback
        ) {
            if (value == null) {
                return fallback;
            }

            String normalized = value.trim().toLowerCase(Locale.ROOT);
            return switch (normalized) {
                case "snap" -> SNAP;
                case "linear" -> LINEAR;
                case "smooth" -> SMOOTH;
                case "quick" -> QUICK;
                case "overshoot" -> OVERSHOOT;

                // Legacy profile names. Map to the closest retained behavior.
                case "ease_in" -> SMOOTH;
                case "ease_out", "strong_ease_out" -> QUICK;
                default -> fallback;
            };
        }
    }

    /* Smooth is the general-purpose default for natural defensive motion. */
    private static final Mode DEFAULT_MODE = Mode.SMOOTH;
    private static final int DEFAULT_DURATION_TICKS = 2;
    private static final int MIN_DURATION_TICKS = 1;
    private static final int MAX_DURATION_TICKS = 10;

    private static volatile Mode mode = DEFAULT_MODE;
    private static volatile int durationTicks = DEFAULT_DURATION_TICKS;

    private DefenseTransitionConfig() {
    }

    public static void initialize() {
        reload();
    }

    public static void reload() {
        Path path = getPath();

        try {
            Files.createDirectories(path.getParent());

            if (!Files.exists(path)) {
                write();
                return;
            }

            JsonObject root = JsonParser.parseString(
                    Files.readString(path, StandardCharsets.UTF_8)
            ).getAsJsonObject();

            Mode loadedMode = DEFAULT_MODE;
            if (root.has("mode")) {
                loadedMode = Mode.fromSerializedName(
                        root.get("mode").getAsString(),
                        DEFAULT_MODE
                );
            }

            int loadedDuration = root.has("duration_ticks")
                    ? root.get("duration_ticks").getAsInt()
                    : DEFAULT_DURATION_TICKS;

            mode = loadedMode;
            durationTicks = clampDuration(loadedDuration);

        } catch (Exception exception) {
            mode = DEFAULT_MODE;
            durationTicks = DEFAULT_DURATION_TICKS;

            GyeokbuV2.LOGGER.error(
                    "Failed to load Gyeokbu stance transition config. Using defaults.",
                    exception
            );
        }

        DefensePoseTransitionRuntime.reset();
    }

    public static Mode mode() {
        return mode;
    }

    public static boolean isAnimated() {
        return mode != Mode.SNAP;
    }

    public static int durationTicks() {
        return durationTicks;
    }

    public static long durationNanos() {
        return durationTicks * 50_000_000L;
    }

    public static void cycleMode() {
        Mode[] modes = Mode.values();
        mode = modes[(mode.ordinal() + 1) % modes.length];
        save();
    }

    public static void adjustDurationTicks(
            int delta
    ) {
        durationTicks = clampDuration(durationTicks + delta);
        save();
    }

    private static int clampDuration(
            int value
    ) {
        return Math.max(
                MIN_DURATION_TICKS,
                Math.min(MAX_DURATION_TICKS, value)
        );
    }

    private static void save() {
        try {
            write();
        } catch (IOException exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu stance transition config.",
                    exception
            );
        }

        /* Restart visual interpolation cleanly after changing settings. */
        DefensePoseTransitionRuntime.reset();
    }

    private static void write() throws IOException {
        Path path = getPath();
        Files.createDirectories(path.getParent());

        String json = """
                {
                  "mode": "%s",
                  "duration_ticks": %d
                }
                """.formatted(
                mode.name().toLowerCase(Locale.ROOT),
                durationTicks
        );

        Files.writeString(
                path,
                json,
                StandardCharsets.UTF_8
        );
    }

    private static Path getPath() {
        return Minecraft.getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("stance_transition.json");
    }
}
