package com.wckd.gyeokbu.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.compat.BetterCombatWeaponMetadata;
import com.wckd.gyeokbu.network.ClientCombatSyncState;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.weapon.HandStyle;
import com.wckd.gyeokbu.weapon.ParryStyle;
import com.wckd.gyeokbu.weapon.WeaponProfileKey;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import dev.kosmx.playerAnim.core.util.Vec3f;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Gyeokbu stance pose storage + live editor backing store.
 *
 * Personal/player stance:
 *   config/gyeokbuv2/animations/<style>.json
 *
 * Saved editor default stance:
 *   config/gyeokbuv2/animation_defaults/<style>.json
 *
 * Immutable official defaults ship inside:
 *   assets/gyeokbuv2/shipped_stance_defaults/...
 *
 * Combat behavior stays in Java. These files only contain visual pose values.
 */
public final class AnimationPoseConfig {

    private static volatile Map<ParryStyle, PoseSet> poses =
            createFallbackPoses();

    /**
     * Exact registry-item visual overrides.
     *
     * Key examples:
     * basicweapons:iron_rapier
     * anothermod:longsword
     *
     * Durability, enchantments, custom names and other ItemStack data
     * are intentionally NOT part of the key.
     */
    private static volatile Map<ResourceLocation, PoseSet> itemPoses =
            new HashMap<>();

    /* Runtime priority bookkeeping: untouched seeded files are shipped defaults,
     * while changed/new external files are user overrides. */
    private static volatile Set<ParryStyle> userThirdPersonStyles =
            EnumSet.noneOf(ParryStyle.class);

    private static volatile Set<ResourceLocation> userThirdPersonItems =
            new HashSet<>();

    /*
     * Dedicated first-person stance storage.
     *
     * These use the same PoseSet shape as third person, but live in separate
     * files so third-person tuning never gets destroyed by first-person work.
     */
    private static volatile Map<ParryStyle, PoseSet> firstPersonPoses =
            new EnumMap<>(
                    ParryStyle.class
            );

    private static volatile Map<ResourceLocation, PoseSet> firstPersonItemPoses =
            new HashMap<>();

    private static volatile Set<ParryStyle> userFirstPersonStyles =
            EnumSet.noneOf(ParryStyle.class);

    private static volatile Set<ResourceLocation> userFirstPersonItems =
            new HashSet<>();

    /*
     * Better Combat handedness variants are kept separate from the legacy
     * category maps so installing Better Combat never rewrites the existing
     * no-BC stance files. A variant is created only when the user saves it.
     */
    private static final Map<WeaponProfileKey, PoseSet> handedThirdPersonPoses =
            new ConcurrentHashMap<>();
    private static final Map<WeaponProfileKey, PoseSet> handedFirstPersonPoses =
            new ConcurrentHashMap<>();
    private static final Map<WeaponProfileKey, PoseSet> handedLinkedThirdPersonPoses =
            new ConcurrentHashMap<>();
    private static final Map<WeaponProfileKey, PoseSet> handedLinkedFirstPersonPoses =
            new ConcurrentHashMap<>();


    /*
     * Linked Views is a completely separate visual workspace.
     *
     * Arms are kept identical between the linked Third-Person and First-Person
     * sets, while each view keeps its own weapon position/rotation correction.
     * Nothing here overwrites the normal TPV/FPV pose maps above.
     */
    private static volatile Map<ParryStyle, PoseSet> linkedThirdPersonPoses =
            new EnumMap<>(ParryStyle.class);

    private static volatile Map<ParryStyle, PoseSet> linkedFirstPersonPoses =
            new EnumMap<>(ParryStyle.class);

    private static volatile Map<ResourceLocation, PoseSet> linkedThirdPersonItemPoses =
            new HashMap<>();

    private static volatile Map<ResourceLocation, PoseSet> linkedFirstPersonItemPoses =
            new HashMap<>();

    private static volatile Set<ParryStyle> userLinkedThirdPersonStyles =
            EnumSet.noneOf(ParryStyle.class);

    private static volatile Set<ParryStyle> userLinkedFirstPersonStyles =
            EnumSet.noneOf(ParryStyle.class);

    private static volatile Set<ResourceLocation> userLinkedThirdPersonItems =
            new HashSet<>();

    private static volatile Set<ResourceLocation> userLinkedFirstPersonItems =
            new HashSet<>();

    private static volatile Map<ResourceLocation, ParryStyle> linkedItemAssignedStyles =
            new HashMap<>();

    /*
     * legacy linked-workspace mode is remembered per stance style. Sword can stay linked while
     * Katana, Rapier, etc. remain independent.
     */
    private static volatile Map<ParryStyle, Boolean> linkedViewStates =
            new EnumMap<>(ParryStyle.class);

    /* One-time migration helper for the old global { "enabled": true } file. */
    private static volatile boolean legacyLinkedViewsEnabled =
            false;

    /**
     * The stance family intentionally chosen for an exact held item in F8.
     *
     * This is separate from the pose data so a rapier can remember that its
     * held override was based on the Greatsword stance, and reopen the editor
     * with Greatsword selected.
     */
    private static volatile Map<ResourceLocation, ParryStyle> itemAssignedStyles =
            new HashMap<>();

    private static boolean editorActive =
            false;

    private static ParryStyle editorStyle =
            null;

    private static HandStyle editorHandStyle =
            HandStyle.ONE_HANDED;

    private static boolean editorHandVariantActive =
            false;

    private static int editorMode =
            DefenseAnimationSyncPayload.PARRY;

    private static PoseSet editorOriginal =
            null;

    private static PoseSet editorWorking =
            null;

    private static PoseSet editorFirstPersonOriginal =
            null;

    private static PoseSet editorFirstPersonWorking =
            null;

    private static boolean editorFirstPerson =
            false;

    /*
     * Linked editor workspace. Normal editorWorking/editorFirstPersonWorking
     * remain untouched while this workspace is active, so turning legacy linked-workspace mode
     * OFF restores the exact normal editor state from before it was enabled.
     */
    private static final boolean editorViewsLinked = false;

    private static ResourceLocation editorItemId =
            null;

    private static ParryStyle editorNormalStyle =
            null;

    private static ParryStyle editorLinkedStyle =
            null;

    private static PoseSet editorLinkedThirdPersonOriginal =
            null;

    private static PoseSet editorLinkedThirdPersonWorking =
            null;

    private static PoseSet editorLinkedFirstPersonOriginal =
            null;

    private static PoseSet editorLinkedFirstPersonWorking =
            null;

    /*
     * Session-only stance clipboard.
     *
     * Intentionally survives closing/reopening F8, but is never written to
     * disk automatically. This lets modpackers:
     *
     *   open SPEAR -> Copy Stance -> close F8
     *   open JAVELIN -> Paste Stance -> inspect -> Save
     *
     * Clipboard contains the complete visual package:
     * - Third Person Parry + Block
     * - First Person Parry + Block
     * - arm rotations
     * - weapon position
     * - weapon rotation
     *
     * It does NOT contain combat stats, WeaponType, HandStyle, traits,
     * DefenseFamily or item-registry identity.
     */
    private static PoseSet stanceClipboardThirdPerson =
            null;

    private static PoseSet stanceClipboardFirstPerson =
            null;

    private static ParryStyle stanceClipboardSourceStyle =
            null;

    private AnimationPoseConfig() {
    }

    public static void initialize() {

        BundledStanceDefaults.seedMissingConfigFiles();
        DefenseTransitionConfig.initialize();
        ensureAllFilesExist();
        ensureAllDefaultFilesExist();
        reload();
    }

    public static ReloadResult reload() {

        try {

            BundledStanceDefaults.seedMissingConfigFiles();
            ensureAllFilesExist();
            ensureAllDefaultFilesExist();

            EnumMap<ParryStyle, PoseSet> loaded =
                    new EnumMap<>(
                            ParryStyle.class
                    );

            for (ParryStyle style : ParryStyle.values()) {

                loaded.put(
                        style,
                        readPoseSet(
                                getConfigPath(
                                        style
                                ),
                                defaultEnabled(
                                        style
                                )
                        )
                );
            }

            poses =
                    loaded;
            userThirdPersonStyles =
                    detectUserStyleOverrides(false, false);

            itemPoses =
                    loadItemOverrides();
            userThirdPersonItems =
                    detectUserItemOverrides(
                            itemPoses.keySet(),
                            false,
                            false
                    );

            firstPersonPoses =
                    loadFirstPersonStylePoses(
                            loaded
                    );
            handedThirdPersonPoses.clear();
            handedFirstPersonPoses.clear();
            handedLinkedThirdPersonPoses.clear();
            handedLinkedFirstPersonPoses.clear();
            if (BetterCombatWeaponMetadata.isAvailable()) {
                loadHandedStyleVariants(false);
                loadHandedStyleVariants(true);
            }
            userFirstPersonStyles =
                    detectUserStyleOverrides(true, false);

            firstPersonItemPoses =
                    loadFirstPersonItemOverrides();
            userFirstPersonItems =
                    detectUserItemOverrides(
                            firstPersonItemPoses.keySet(),
                            true,
                            false
                    );

            itemAssignedStyles =
                    loadItemStyleAssignments();
            userThirdPersonItems = addUserAssignmentOverrides(
                    userThirdPersonItems,
                    itemAssignedStyles,
                    "animations/item_stance_assignments.json"
            );
            userFirstPersonItems = addUserAssignmentOverrides(
                    userFirstPersonItems,
                    itemAssignedStyles,
                    "animations/item_stance_assignments.json"
            );

            // Linked Views was retired. Legacy linked configuration is not loaded.
            linkedThirdPersonPoses.clear();
            linkedFirstPersonPoses.clear();
            linkedThirdPersonItemPoses.clear();
            linkedFirstPersonItemPoses.clear();
            userLinkedThirdPersonStyles.clear();
            userLinkedFirstPersonStyles.clear();
            userLinkedThirdPersonItems.clear();
            userLinkedFirstPersonItems.clear();
            linkedItemAssignedStyles.clear();
            linkedViewStates.clear();
            legacyLinkedViewsEnabled = false;

            synchronizeUserFallbacksFromAssignments();

            DualWieldPoseConfig.reload();

            GyeokbuV2.LOGGER.info(
                    "Reloaded Gyeokbu stance poses for {} styles, {} exact-item overrides, {} first-person styles, {} first-person item overrides, and {} held stance assignments.",
                    loaded.size(),
                    itemPoses.size(),
                    firstPersonPoses.size(),
                    firstPersonItemPoses.size(),
                    itemAssignedStyles.size()
            );

            return new ReloadResult(
                    true,
                    "Gyeokbu stances reloaded from "
                            + getAnimationDirectory()
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to reload Gyeokbu stance poses.",
                    exception
            );

            return new ReloadResult(
                    false,
                    "Gyeokbu stance reload failed. Check latest.log."
            );
        }
    }

    public static ArmPose getPose(
            ParryStyle style,
            int mode
    ) {

        PoseSet poseSet =
                getEnabledPoseSet(
                        style
                );

        if (poseSet == null) {
            return null;
        }

        return getArmPoseFromSet(
                poseSet,
                mode
        );
    }

    /**
     * Runtime pose priority:
     *
     * 1. exact registry item override
     * 2. normal ParryStyle pose
     * 3. no Gyeokbu pose
     */
    public static ArmPose getPoseFor(
            ItemStack stack,
            ParryStyle style,
            int mode
    ) {

        PoseSet poseSet =
                getRuntimeThirdPersonPoseSet(
                        stack,
                        style
                );

        if (poseSet == null) {
            return null;
        }

        return getArmPoseFromSet(
                poseSet,
                mode
        );
    }

    /**
     * Dedicated first-person pose lookup.
     *
     * Priority:
     * 1. exact held-item first-person override
     * 2. exact held-item third-person override converted to a FP fallback
     * 3. first-person style stance
     * 4. third-person style stance converted to a FP fallback
     */
    public static ArmPose getFirstPersonPoseFor(
            ItemStack stack,
            ParryStyle style,
            int mode
    ) {

        PoseSet poseSet =
                getFirstPersonPoseSet(
                        stack,
                        style
                );

        if (poseSet == null) {
            return null;
        }

        return getArmPoseFromSet(
                poseSet,
                mode
        );
    }

    /**
     * Third-person held-item translation for the player's MAINHAND item.
     *
     * This is a render-only Gyeokbu offset. The actual ItemStack/entity
     * remains attached to the player and combat reach is unchanged.
     */
    public static Vec3f getWeaponPositionFor(
            LivingEntity entity
    ) {

        if (!(entity instanceof AbstractClientPlayer player)) {
            return null;
        }

        Minecraft minecraft =
                Minecraft.getInstance();

        if (isEditorActive()
                && minecraft.player == player) {

            return getEditorWeaponPosition();
        }

        boolean localFirstPerson =
                minecraft.player == player
                        && minecraft.options
                                .getCameraType()
                                == CameraType.FIRST_PERSON;

        int mode =
                localFirstPerson
                        ? ClientCombatSyncState
                                .getFirstPersonDefenseVisualMode(
                                        player.getId()
                                )
                        : ClientCombatSyncState
                                .getDefenseAnimationMode(
                                        player.getId()
                                );

        if (!DefensePoseTransitionRuntime.isVisualActive(
                player,
                localFirstPerson,
                mode
        )) {
            return null;
        }

        Vec3f target =
                zero();

        if (mode == DefenseAnimationSyncPayload.PARRY
                || mode == DefenseAnimationSyncPayload.BLOCK) {

            ItemStack mainHand =
                    player.getMainHandItem();

            ParryStyle style =
                    WeaponClassifier
                            .classify(
                                    mainHand
                            )
                            .parryStyle();

            PoseSet poseSet =
                    localFirstPerson
                            ? getFirstPersonPoseSet(
                                    mainHand,
                                    style
                            )
                            : getRuntimeThirdPersonPoseSet(
                                    mainHand,
                                    style
                            );

            if (poseSet != null) {
                Vec3f configured =
                        getWeaponPositionFromSet(
                                poseSet,
                                mode
                        );

                if (configured != null) {
                    target = configured;
                }
            }
        }

        return DefensePoseTransitionRuntime.sample(
                player,
                localFirstPerson,
                DefensePoseTransitionRuntime.MAIN_WEAPON_POSITION,
                mode,
                target,
                zero()
        );
    }

    /**
     * Third-person held-item rotation for the player's MAINHAND item.
     *
     * This is rotation-only. Minecraft's normal hand attachment/position
     * remains responsible for the grip point.
     */
    public static Vec3f getWeaponRotationFor(
            LivingEntity entity
    ) {

        if (!(entity instanceof AbstractClientPlayer player)) {
            return null;
        }

        Minecraft minecraft =
                Minecraft.getInstance();

        if (isEditorActive()
                && minecraft.player == player) {

            return getEditorWeaponRotation();
        }

        boolean localFirstPerson =
                minecraft.player == player
                        && minecraft.options
                                .getCameraType()
                                == CameraType.FIRST_PERSON;

        int mode =
                localFirstPerson
                        ? ClientCombatSyncState
                                .getFirstPersonDefenseVisualMode(
                                        player.getId()
                                )
                        : ClientCombatSyncState
                                .getDefenseAnimationMode(
                                        player.getId()
                                );

        if (!DefensePoseTransitionRuntime.isVisualActive(
                player,
                localFirstPerson,
                mode
        )) {
            return null;
        }

        Vec3f target =
                zero();

        if (mode == DefenseAnimationSyncPayload.PARRY
                || mode == DefenseAnimationSyncPayload.BLOCK) {

            ItemStack mainHand =
                    player.getMainHandItem();

            ParryStyle style =
                    WeaponClassifier
                            .classify(
                                    mainHand
                            )
                            .parryStyle();

            PoseSet poseSet =
                    localFirstPerson
                            ? getFirstPersonPoseSet(
                                    mainHand,
                                    style
                            )
                            : getRuntimeThirdPersonPoseSet(
                                    mainHand,
                                    style
                            );

            if (poseSet != null) {
                Vec3f configured =
                        getWeaponRotationFromSet(
                                poseSet,
                                mode
                        );

                if (configured != null) {
                    target = configured;
                }
            }
        }

        return DefensePoseTransitionRuntime.sample(
                player,
                localFirstPerson,
                DefensePoseTransitionRuntime.MAIN_WEAPON_ROTATION,
                mode,
                target,
                zero()
        );
    }

    /**
     * Explicit-mode weapon position lookup used by the camera-relative
     * first-person renderer.
     *
     * This intentionally preserves the normal exact-item -> style priority.
     */
    public static Vec3f getWeaponPositionForMode(
            ItemStack stack,
            ParryStyle style,
            int mode
    ) {

        PoseSet poseSet =
                getItemPoseSet(
                        stack
                );

        if (poseSet == null) {

            poseSet =
                    getEnabledPoseSet(
                            style
                    );
        }

        if (poseSet == null) {
            return null;
        }

        return getWeaponPositionFromSet(
                poseSet,
                mode
        );
    }

    /**
     * Explicit-mode weapon rotation lookup used by the camera-relative
     * first-person renderer.
     */
    public static Vec3f getWeaponRotationForMode(
            ItemStack stack,
            ParryStyle style,
            int mode
    ) {

        PoseSet poseSet =
                getItemPoseSet(
                        stack
                );

        if (poseSet == null) {

            poseSet =
                    getEnabledPoseSet(
                            style
                    );
        }

        if (poseSet == null) {
            return null;
        }

        return getWeaponRotationFromSet(
                poseSet,
                mode
        );
    }

    /**
     * Explicit visual value lookup used by the Success Animation editor.
     * It preserves the existing exact-item -> ParryStyle stance priority and
     * keeps first-person and third-person data separate.
     */
    public static float getVisualValueFor(
            ResourceLocation itemId,
            ParryStyle style,
            int mode,
            boolean firstPerson,
            SuccessAnimationChannel channel
    ) {
        Minecraft minecraft = Minecraft.getInstance();
        ItemStack stack = minecraft.player == null
                ? ItemStack.EMPTY
                : minecraft.player.getMainHandItem();
        return getVisualValueFor(stack, style, mode, firstPerson, channel);
    }

    public static float getVisualValueFor(
            ItemStack stack,
            ParryStyle style,
            int mode,
            boolean firstPerson,
            SuccessAnimationChannel channel
    ) {
        PoseSet set = firstPerson
                ? getFirstPersonPoseSet(stack, style)
                : getRuntimeThirdPersonPoseSet(stack, style);

        if (set == null) {
            return 0.0F;
        }

        ArmPose pose = getArmPoseFromSet(set, mode);
        Vec3f main = pose == null ? new Vec3f(0,0,0) : pose.mainHand();
        Vec3f off = pose == null ? new Vec3f(0,0,0) : pose.offHand();
        Vec3f pos = getWeaponPositionFromSet(set, mode);
        Vec3f rot = getWeaponRotationFromSet(set, mode);
        if (pos == null) pos = new Vec3f(0,0,0);
        if (rot == null) rot = new Vec3f(0,0,0);

        return switch (channel) {
            case MAIN_ARM_X -> main.getX(); case MAIN_ARM_Y -> main.getY(); case MAIN_ARM_Z -> main.getZ();
            case OFF_ARM_X -> off.getX(); case OFF_ARM_Y -> off.getY(); case OFF_ARM_Z -> off.getZ();
            case MAIN_WEAPON_POS_X -> pos.getX(); case MAIN_WEAPON_POS_Y -> pos.getY(); case MAIN_WEAPON_POS_Z -> pos.getZ();
            case MAIN_WEAPON_ROT_X -> rot.getX(); case MAIN_WEAPON_ROT_Y -> rot.getY(); case MAIN_WEAPON_ROT_Z -> rot.getZ();
            default -> 0.0F;
        };
    }

    /*
     * ------------------------------------------------------------
     * STANCE EDITOR
     * ------------------------------------------------------------
     */

    public static boolean beginEditor(
            ParryStyle style
    ) {

        return beginEditor(
                style,
                null
        );
    }

    /**
     * Opens the editor from an exact held item.
     *
     * Existing exact-item override wins as the starting preview.
     * Otherwise the style pose is used, including disabled/neutral styles.
     */
    public static boolean beginEditor(
            ParryStyle style,
            ResourceLocation itemId
    ) {

        if (style == null) {
            return false;
        }

        editorActive =
                true;

        editorStyle =
                style;

        WeaponProfile naturalProfile = itemId == null
                ? WeaponProfile.unknown()
                : WeaponClassifier.classifyNatural(
                        new ItemStack(BuiltInRegistries.ITEM.get(itemId))
                );
        editorHandVariantActive = BetterCombatWeaponMetadata.isAvailable()
                && style != ParryStyle.GENERIC
                && naturalProfile.isSupported()
                && naturalProfile.parryStyle() == style;
        editorHandStyle = editorHandVariantActive
                ? naturalProfile.handStyle()
                : HandStyle.ONE_HANDED;

        /* Resolve the actual editor profile only after the handedness state is
         * established. Otherwise opening F8 could load the legacy category
         * pose even when a saved 1H/2H variant already exists. */
        PoseSet current =
                itemId == null
                        || !isEditorItemAssignmentActive(itemId, style)
                        ? null
                        : itemPoses.get(
                                itemId
                        );

        if (current == null) {

            current = getEditorStylePoseSet(
                    style,
                    false
            );
        }

        if (current == null) {

            current =
                    disabledNeutral();
        }

        editorMode =
                DefenseAnimationSyncPayload.PARRY;

        editorOriginal =
                copyPoseSet(
                        current
                );

        editorWorking =
                copyPoseSet(
                        current
                );

        PoseSet firstPersonCurrent =
                itemId == null
                        || !isEditorItemAssignmentActive(itemId, style)
                        ? null
                        : firstPersonItemPoses.get(
                                itemId
                        );

        if (firstPersonCurrent == null) {

            firstPersonCurrent = getEditorStylePoseSet(
                    style,
                    true
            );
        }

        if (firstPersonCurrent == null) {

            firstPersonCurrent =
                    disabledNeutral();
        }

        editorFirstPersonOriginal =
                copyPoseSet(
                        firstPersonCurrent
                );

        editorFirstPersonWorking =
                copyPoseSet(
                        firstPersonCurrent
                );

        /*
         * F8 opens in the same broad camera mode the player was already using:
         * First Person stays First Person; either Third Person mode opens the
         * editor's normal Third-Person preview. The editor camera itself still
         * levels pitch to straight-ahead for posing.
         */
        editorFirstPerson =
                Minecraft.getInstance()
                        .options
                        .getCameraType()
                        == CameraType.FIRST_PERSON;

        editorItemId =
                itemId;

        editorNormalStyle =
                style;

        // First- and Third-Person are always independent workspaces.
        editorLinkedStyle = null;
        editorLinkedThirdPersonOriginal = null;
        editorLinkedThirdPersonWorking = null;
        editorLinkedFirstPersonOriginal = null;
        editorLinkedFirstPersonWorking = null;

        return true;
    }

    public static ParryStyle getEditorStyle() {

        return editorStyle;
    }

    public static HandStyle getEditorHandStyle() {
        return editorHandStyle;
    }

    public static boolean isEditorHandVariantActive() {
        return editorHandVariantActive;
    }

    /**
     * Lets the editor reach every ParryStyle even when that style has not
     * been enabled/saved yet.
     */
    public static void switchEditorStyle(
            ParryStyle style
    ) {
        switchEditorStyle(style, HandStyle.ONE_HANDED);
    }

    public static void switchEditorStyle(
            ParryStyle style,
            HandStyle handStyle
    ) {
        if (!isEditorActive() || style == null) {
            return;
        }

        editorNormalStyle = style;
        editorStyle = style;
        editorHandVariantActive = BetterCombatWeaponMetadata.isAvailable()
                && style != ParryStyle.GENERIC;
        editorHandStyle = handStyle == null
                ? HandStyle.ONE_HANDED
                : handStyle;

        PoseSet current = getEditorStylePoseSet(style, false);
        PoseSet firstPersonCurrent = getEditorStylePoseSet(style, true);

        if (current == null) {
            current = disabledNeutral();
        }
        if (firstPersonCurrent == null) {
            firstPersonCurrent = disabledNeutral();
        }

        editorWorking = copyPoseSet(current);
        editorOriginal = copyPoseSet(current);
        editorFirstPersonWorking = copyPoseSet(firstPersonCurrent);
        editorFirstPersonOriginal = copyPoseSet(firstPersonCurrent);
        editorLinkedStyle = null;
        editorLinkedThirdPersonOriginal = null;
        editorLinkedThirdPersonWorking = null;
        editorLinkedFirstPersonOriginal = null;
        editorLinkedFirstPersonWorking = null;

        synchronizeUserFallbacksFromAssignments();
    }

    public static boolean isEditorActive() {

        return editorActive
                && editorStyle != null
                && editorWorking != null
                && editorFirstPersonWorking != null;
    }

    public static int getEditorMode() {

        return editorMode;
    }

    public static boolean isEditorFirstPerson() {

        return editorFirstPerson;
    }

    public static void setEditorFirstPerson(
            boolean firstPerson
    ) {

        if (!isEditorActive()) {
            return;
        }

        editorFirstPerson =
                firstPerson;
    }

    public static boolean isLinkedViewsEnabled() {
        return editorViewsLinked;
    }

    public static boolean isLinkedViewsEnabledForStyle(ParryStyle style) {
        return false;
    }

    /**
     * Switches between the normal TPV/FPV workspace and the separate Linked
     * Views workspace. The normal working poses are never overwritten here.
     * The ON/OFF state is remembered for this stance only.
     */

    private static void setLinkedViewState(
            ParryStyle style,
            boolean linked
    ) {
        if (style == null) {
            return;
        }

        Map<ParryStyle, Boolean> updated =
                new EnumMap<>(ParryStyle.class);
        updated.putAll(linkedViewStates);
        updated.put(style, linked);
        linkedViewStates = updated;
    }

    public static void setEditorMode(
            int mode
    ) {

        if (mode
                == DefenseAnimationSyncPayload.PARRY
                || mode
                == DefenseAnimationSyncPayload.BLOCK) {

            editorMode =
                    mode;
        }
    }

    public static ArmPose getEditorPose() {

        if (!isEditorActive()) {
            return null;
        }

        return getArmPoseFromSet(
                getActiveEditorPoseSet(),
                editorMode
        );
    }

    public static Vec3f getEditorWeaponPosition() {

        if (!isEditorActive()) {
            return null;
        }

        return getWeaponPositionFromSet(
                getActiveEditorPoseSet(),
                editorMode
        );
    }

    public static Vec3f getEditorWeaponRotation() {

        if (!isEditorActive()) {
            return null;
        }

        return getWeaponRotationFromSet(
                getActiveEditorPoseSet(),
                editorMode
        );
    }

    public static void adjustEditorArmValue(
            boolean mainHand,
            int axis,
            float delta
    ) {

        if (!isEditorActive()) {
            return;
        }

        PoseSet activeSet =
                getActiveEditorPoseSet();

        ArmPose current =
                getArmPoseFromSet(
                        activeSet,
                        editorMode
                );

        if (current == null) {
            return;
        }

        Vec3f main =
                current.mainHand();

        Vec3f off =
                current.offHand();

        if (mainHand) {

            main =
                    adjustAxis(
                            main,
                            axis,
                            delta
                    );

        } else {

            off =
                    adjustAxis(
                            off,
                            axis,
                            delta
                    );
        }

        setActiveEditorPoseSet(
                replaceArmMode(
                        activeSet,
                        editorMode,
                        main,
                        off
                )
        );

        if (editorViewsLinked) {
            mirrorActiveEditorModeArmsToOtherView(
                    getActiveEditorPoseSet()
            );
        }
    }

    public static void adjustEditorWeaponPositionValue(
            int axis,
            float delta
    ) {

        if (!isEditorActive()) {
            return;
        }

        PoseSet activeSet =
                getActiveEditorPoseSet();

        Vec3f current =
                getWeaponPositionFromSet(
                        activeSet,
                        editorMode
                );

        if (current == null) {
            current = zero();
        }

        Vec3f updated =
                adjustPositionAxis(
                        current,
                        axis,
                        delta
                );

        setActiveEditorPoseSet(
                replaceWeaponPositionMode(
                        activeSet,
                        editorMode,
                        updated
                )
        );
    }

    public static void adjustEditorWeaponValue(
            int axis,
            float delta
    ) {

        if (!isEditorActive()) {
            return;
        }

        PoseSet activeSet =
                getActiveEditorPoseSet();

        Vec3f current =
                getWeaponRotationFromSet(
                        activeSet,
                        editorMode
                );

        if (current == null) {
            current = zero();
        }

        Vec3f updated =
                adjustAxis(
                        current,
                        axis,
                        delta
                );

        setActiveEditorPoseSet(
                replaceWeaponMode(
                        activeSet,
                        editorMode,
                        updated
                )
        );
    }

    /**
     * Reset only the selected hand section for the current Parry/Block pose.
     * Zero removes Gyeokbu's custom rotation for that section.
     */
    public static void resetEditorArmToVanilla(
            boolean mainHand
    ) {

        if (!isEditorActive()) {
            return;
        }

        PoseSet activeSet =
                getActiveEditorPoseSet();

        ArmPose current =
                getArmPoseFromSet(
                        activeSet,
                        editorMode
                );

        if (current == null) {
            return;
        }

        Vec3f main =
                current.mainHand();

        Vec3f off =
                current.offHand();

        if (mainHand) {
            main = zero();
        } else {
            off = zero();
        }

        setActiveEditorPoseSet(
                replaceArmMode(
                        activeSet,
                        editorMode,
                        main,
                        off
                )
        );

        if (editorViewsLinked) {
            mirrorActiveEditorModeArmsToOtherView(
                    getActiveEditorPoseSet()
            );
        }
    }

    /**
     * Reset only Gyeokbu's extra held-weapon rotation.
     * The normal Minecraft grip/held-item transform remains intact.
     */
    public static void resetEditorWeaponToVanilla() {

        if (!isEditorActive()) {
            return;
        }

        PoseSet activeSet =
                getActiveEditorPoseSet();

        activeSet =
                replaceWeaponPositionMode(
                        activeSet,
                        editorMode,
                        zero()
                );

        activeSet =
                replaceWeaponMode(
                        activeSet,
                        editorMode,
                        zero()
                );

        setActiveEditorPoseSet(
                activeSet
        );
    }

    public static void copyParryToBlock() {

        if (!isEditorActive()) {
            return;
        }

        PoseSet source =
                getActiveEditorPoseSet();

        setActiveEditorPoseSet(
                new PoseSet(
                        source.enabled(),
                        copyVec(source.parryMainHand()),
                        copyVec(source.parryOffHand()),
                        copyVec(source.parryWeaponPosition()),
                        copyVec(source.parryWeaponRotation()),
                        copyVec(source.parryMainHand()),
                        copyVec(source.parryOffHand()),
                        copyVec(source.parryWeaponPosition()),
                        copyVec(source.parryWeaponRotation())
                )
        );

        if (editorViewsLinked) {
            mirrorAllEditorArmsToOtherView(
                    getActiveEditorPoseSet()
            );
        }
    }

    public static void copyBlockToParry() {

        if (!isEditorActive()) {
            return;
        }

        PoseSet source =
                getActiveEditorPoseSet();

        setActiveEditorPoseSet(
                new PoseSet(
                        source.enabled(),
                        copyVec(source.blockMainHand()),
                        copyVec(source.blockOffHand()),
                        copyVec(source.blockWeaponPosition()),
                        copyVec(source.blockWeaponRotation()),
                        copyVec(source.blockMainHand()),
                        copyVec(source.blockOffHand()),
                        copyVec(source.blockWeaponPosition()),
                        copyVec(source.blockWeaponRotation())
                )
        );

        if (editorViewsLinked) {
            mirrorAllEditorArmsToOtherView(
                    getActiveEditorPoseSet()
            );
        }
    }

    /**
     * Copies the complete CURRENT editor stance into the session clipboard.
     *
     * Unsaved editor changes are intentionally copied. This is a visual
     * clipboard, not a "copy last saved JSON" operation.
     */
    public static SaveResult copyEditorStanceToClipboard() {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        stanceClipboardThirdPerson =
                copyPoseSet(
                        editorViewsLinked
                                ? editorLinkedThirdPersonWorking
                                : editorWorking
                );

        stanceClipboardFirstPerson =
                copyPoseSet(
                        editorViewsLinked
                                ? editorLinkedFirstPersonWorking
                                : editorFirstPersonWorking
                );

        stanceClipboardSourceStyle =
                editorStyle;

        return new SaveResult(
                true,
                "Copied "
                        + editorStyle.name()
                        + " stance."
        );
    }

    /**
     * Pastes the clipboard into the CURRENT target style's editor working
     * state. Nothing is saved to disk until the user presses one of the
     * normal Save buttons.
     *
     * The copied poses become independent copies immediately.
     */
    public static SaveResult pasteClipboardIntoEditor() {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        if (!hasStanceClipboard()) {

            return new SaveResult(
                    false,
                    "Stance clipboard is empty."
            );
        }

        if (editorViewsLinked) {
            PoseSet armSource = editorFirstPerson
                    ? stanceClipboardFirstPerson
                    : stanceClipboardThirdPerson;

            editorLinkedThirdPersonWorking =
                    copyArmsIntoPoseSet(
                            stanceClipboardThirdPerson,
                            armSource
                    );
            editorLinkedFirstPersonWorking =
                    copyArmsIntoPoseSet(
                            stanceClipboardFirstPerson,
                            armSource
                    );
        } else {
            editorWorking =
                    copyPoseSet(
                            stanceClipboardThirdPerson
                    );

            editorFirstPersonWorking =
                    copyPoseSet(
                            stanceClipboardFirstPerson
                    );
        }

        return new SaveResult(
                true,
                "Pasted "
                        + stanceClipboardSourceStyle.name()
                        + " stance into "
                        + editorStyle.name()
                        + ". Save when ready."
        );
    }

    public static boolean hasStanceClipboard() {

        return stanceClipboardThirdPerson != null
                && stanceClipboardFirstPerson != null
                && stanceClipboardSourceStyle != null;
    }

    public static String getStanceClipboardSourceName() {

        return stanceClipboardSourceStyle == null
                ? "<empty>"
                : stanceClipboardSourceStyle.name();
    }

    /**
     * Explicit bridge from Third Person -> First Person.
     *
     * The views are otherwise STRICTLY independent.
     *
     * The arm rotations are useful as a starting point, so they are copied.
     *
     * Weapon transform is intentionally RESET to neutral:
     * the V13/V16 testing proved there is no reliable generic 3P -> 1P
     * weapon-space conversion. A wrong automatic conversion is worse than
     * starting from a predictable neutral held-item transform.
     */
    public static void copyThirdPersonToFirstPerson() {
        if (!isEditorActive()) {
            return;
        }
        editorFirstPersonWorking = copyPoseSet(editorWorking);
    }


    /**
     * Explicit bridge from First Person -> Third Person.
     * Copies the complete stance value set, including arms and weapon transforms.
     */
    public static void copyFirstPersonToThirdPerson() {
        if (!isEditorActive()) {
            return;
        }
        editorWorking = copyPoseSet(editorFirstPersonWorking);
    }



    public static SaveResult saveEditor() {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        PoseSet saved =
                enabledCopy(
                        editorWorking
                );

        try {

            writePoseSet(
                    getEditorConfigPath(false)
                    ,
                    saved
            );

            replaceLoadedPoseForEditor(
                    saved,
                    false
            );

            editorWorking =
                    copyPoseSet(
                            saved
                    );

            editorOriginal =
                    copyPoseSet(
                            saved
                    );

            return new SaveResult(
                    true,
                    "Saved personal "
                            + editorStyle.name()
                            + " stance."
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu personal stance.",
                    exception
            );

            return new SaveResult(
                    false,
                    "Save failed. Check latest.log."
            );
        }
    }

    /**
     * Saves both Parry and Block poses only for one exact registry item.
     *
     * The item's registry ID is the whole key. ItemStack components such as
     * durability, enchantments and custom names are intentionally ignored.
     */
    /**
     * Returns the stance family assigned to one exact registry item.
     *
     * Items without an explicit assignment fall back to their natural
     * classifier stance.
     */
    public static ParryStyle getAssignedItemStyle(
            ResourceLocation itemId,
            ParryStyle naturalStyle
    ) {
        if (itemId == null) {
            return naturalStyle == null
                    ? ParryStyle.GENERIC
                    : naturalStyle;
        }

        ParryStyle fallback = naturalStyle == null
                ? ParryStyle.GENERIC
                : naturalStyle;

        ParryStyle assigned =
                itemAssignedStyles.get(
                        itemId
                );

        if (assigned == null) {
            return fallback;
        }

        /*
         * Borrowed stance assignments are active only while that stance type
         * exists somewhere in the currently loaded game/modpack. If the mod
         * that supplied the last weapon of that type is removed, use the held
         * weapon's natural stance instead (or GENERIC for an unknown item).
         */
        if (assigned == ParryStyle.GENERIC) {
            return fallback == ParryStyle.GENERIC
                    ? ParryStyle.GENERIC
                    : fallback;
        }

        if (WeaponClassifier.isParryStyleDetected(assigned)) {
            return assigned;
        }

        return fallback;
    }

    /**
     * Initial stance selection for F8. When the old linked-workspace mode was used, the
     * linked held assignment is used; otherwise the normal held assignment is
     * used.
     */
    public static ParryStyle getInitialEditorItemStyle(
            ResourceLocation itemId,
            ParryStyle naturalStyle
    ) {
        return getAssignedItemStyle(itemId, naturalStyle);
    }

    public static ParryStyle getLinkedAssignedItemStyle(
            ResourceLocation itemId,
            ParryStyle naturalStyle
    ) {
        ParryStyle fallback = naturalStyle == null
                ? ParryStyle.GENERIC
                : naturalStyle;

        if (itemId == null) {
            return fallback;
        }

        ParryStyle assigned =
                linkedItemAssignedStyles.get(itemId);

        if (assigned == null) {
            return fallback;
        }

        if (assigned == ParryStyle.GENERIC) {
            return fallback == ParryStyle.GENERIC
                    ? ParryStyle.GENERIC
                    : fallback;
        }

        return WeaponClassifier.isParryStyleDetected(assigned)
                ? assigned
                : fallback;
    }

    public static ParryStyle getEditorAssignedItemStyle(
            ResourceLocation itemId,
            ParryStyle naturalStyle
    ) {
        return getAssignedItemStyle(itemId, naturalStyle);
    }

    static ParryStyle getEditorStoredItemStyleAssignment(
            ResourceLocation itemId
    ) {
        return itemId == null ? null : itemAssignedStyles.get(itemId);
    }

    public static SaveResult assignEditorItemStyle(
            ResourceLocation itemId,
            ParryStyle style
    ) {
        return assignItemStyle(itemId, style);
    }

    public static SaveResult clearEditorItemStyleAssignment(
            ResourceLocation itemId
    ) {
        return clearItemStyleAssignment(itemId);
    }

    private static boolean isLinkedEditorItemAssignmentActive(
            ResourceLocation itemId,
            ParryStyle editorResolvedStyle
    ) {
        if (itemId == null) {
            return false;
        }

        ParryStyle stored =
                linkedItemAssignedStyles.get(itemId);

        return stored == null
                || stored == editorResolvedStyle;
    }

    private static boolean isLinkedRuntimeItemAssignmentActive(
            ResourceLocation itemId,
            ParryStyle naturalStyle
    ) {
        if (itemId == null) {
            return false;
        }

        ParryStyle stored =
                linkedItemAssignedStyles.get(itemId);

        if (stored == null) {
            return true;
        }

        return stored == getLinkedAssignedItemStyle(
                itemId,
                naturalStyle
        );
    }

    private static SaveResult assignLinkedItemStyle(
            ResourceLocation itemId,
            ParryStyle style
    ) {
        if (itemId == null || style == null) {
            return new SaveResult(
                    false,
                    "No held item or linked stance was available to assign."
            );
        }

        try {
            Map<ResourceLocation, ParryStyle> updated =
                    new HashMap<>(linkedItemAssignedStyles);
            updated.put(itemId, style);
            linkedItemAssignedStyles = updated;
            writeLinkedItemStyleAssignments();
            markUserItemOverride(itemId, false, true);
            markUserItemOverride(itemId, true, true);

            return new SaveResult(
                    true,
                    "Assigned linked " + style.name() + " to " + itemId + "."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save linked Gyeokbu held stance assignment for {}.",
                    itemId,
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked held stance assignment failed. Check latest.log."
            );
        }
    }

    private static SaveResult clearLinkedItemStyleAssignment(
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            Map<ResourceLocation, ParryStyle> updated =
                    new HashMap<>(linkedItemAssignedStyles);
            updated.remove(itemId);
            linkedItemAssignedStyles = updated;
            writeLinkedItemStyleAssignments();
            refreshUserItemClassification(itemId, true);

            return new SaveResult(
                    true,
                    "Cleared linked held stance assignment for " + itemId + "."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to clear linked Gyeokbu held stance assignment for {}.",
                    itemId,
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked held stance assignment clear failed. Check latest.log."
            );
        }
    }

    private static boolean isEditorItemAssignmentActive(
            ResourceLocation itemId,
            ParryStyle editorResolvedStyle
    ) {
        if (itemId == null) {
            return false;
        }

        ParryStyle stored = itemAssignedStyles.get(itemId);
        return stored == null
                || stored == editorResolvedStyle;
    }

    private static boolean isRuntimeItemAssignmentActive(
            ResourceLocation itemId,
            ParryStyle naturalStyle
    ) {
        if (itemId == null) {
            return false;
        }

        ParryStyle stored = itemAssignedStyles.get(itemId);
        if (stored == null) {
            return true;
        }

        return stored == getAssignedItemStyle(
                itemId,
                naturalStyle
        );
    }

    static ParryStyle getStoredItemStyleAssignment(
            ResourceLocation itemId
    ) {
        return itemId == null
                ? null
                : itemAssignedStyles.get(itemId);
    }

    public static SaveResult assignItemStyle(
            ResourceLocation itemId,
            ParryStyle style
    ) {
        if (itemId == null
                || style == null) {
            return new SaveResult(
                    false,
                    "No held item or stance was available to assign."
            );
        }

        try {
            Map<ResourceLocation, ParryStyle> updated =
                    new HashMap<>(
                            itemAssignedStyles
                    );

            updated.put(
                    itemId,
                    style
            );

            itemAssignedStyles =
                    updated;

            writeItemStyleAssignments();
            markUserItemOverride(itemId, false, false);
            markUserItemOverride(itemId, true, false);

            return new SaveResult(
                    true,
                    "Assigned " + style.name() + " to " + itemId + "."
            );

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu held stance assignment for {}.",
                    itemId,
                    exception
            );

            return new SaveResult(
                    false,
                    "Held stance assignment failed. Check latest.log."
            );
        }
    }

    public static SaveResult clearItemStyleAssignment(
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            Map<ResourceLocation, ParryStyle> updated =
                    new HashMap<>(
                            itemAssignedStyles
                    );

            updated.remove(
                    itemId
            );

            itemAssignedStyles =
                    updated;

            writeItemStyleAssignments();
            refreshUserItemClassification(itemId, false);

            return new SaveResult(
                    true,
                    "Cleared held stance assignment for " + itemId + "."
            );

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to clear Gyeokbu held stance assignment for {}.",
                    itemId,
                    exception
            );

            return new SaveResult(
                    false,
                    "Held stance assignment clear failed. Check latest.log."
            );
        }
    }

    /**
     * Returns true when this exact registry item currently has its own
     * stance override.
     *
     * The key is only the registry ID. Enchantments, durability, custom
     * names and other ItemStack data are intentionally ignored.
     */
    public static boolean hasItemOverride(
            ResourceLocation itemId
    ) {

        if (itemId == null) {
            return false;
        }

        PoseSet poseSet =
                itemPoses.get(
                        itemId
                );

        PoseSet firstPersonPoseSet =
                firstPersonItemPoses.get(
                        itemId
                );

        return (poseSet != null
                && poseSet.enabled())
                || (firstPersonPoseSet != null
                && firstPersonPoseSet.enabled());
    }

    public static boolean hasEditorItemOverride(
            ResourceLocation itemId
    ) {
        return hasItemOverride(itemId);
    }

    public static SaveResult clearEditorItemOverride(
            ResourceLocation itemId
    ) {
        return clearItemOverride(itemId);
    }

    private static SaveResult clearLinkedItemOverride(
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            Files.deleteIfExists(
                    getLinkedItemConfigPath(itemId, false)
            );
            Files.deleteIfExists(
                    getLinkedItemConfigPath(itemId, true)
            );

            Map<ResourceLocation, PoseSet> thirdUpdated =
                    new HashMap<>(linkedThirdPersonItemPoses);
            thirdUpdated.remove(itemId);
            linkedThirdPersonItemPoses = thirdUpdated;

            Map<ResourceLocation, PoseSet> firstUpdated =
                    new HashMap<>(linkedFirstPersonItemPoses);
            firstUpdated.remove(itemId);
            linkedFirstPersonItemPoses = firstUpdated;
            clearUserItemOverride(itemId, false, true);
            clearUserItemOverride(itemId, true, true);

            clearLinkedItemStyleAssignment(itemId);

            if (isEditorActive() && editorViewsLinked) {
                editorLinkedStyle =
                        getLinkedAssignedItemStyle(
                                itemId,
                                getNaturalStyleForItemId(itemId)
                        );
                editorStyle = editorLinkedStyle;
                prepareLinkedEditorWorkspace(
                        editorLinkedStyle,
                        itemId,
                        editorFirstPerson
                );
            }

            return new SaveResult(
                    true,
                    "Cleared linked item override for " + itemId + "."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to clear linked exact-item Gyeokbu stance for {}.",
                    itemId,
                    exception
            );
            return new SaveResult(
                    false,
                    "Could not clear linked item override. Check latest.log."
            );
        }
    }

    /**
     * Removes only the exact-item override for the supplied registry item.
     *
     * After removal, runtime animation lookup falls back to the item's
     * normal ParryStyle stance.
     */
    public static SaveResult clearItemOverride(
            ResourceLocation itemId
    ) {

        if (itemId == null) {

            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {

            Files.deleteIfExists(
                    getItemConfigPath(
                            itemId
                    )
            );

            Files.deleteIfExists(
                    getFirstPersonItemConfigPath(
                            itemId
                    )
            );

            Map<ResourceLocation, PoseSet> updated =
                    new HashMap<>(
                            itemPoses
                    );

            updated.remove(
                    itemId
            );

            itemPoses =
                    updated;

            Map<ResourceLocation, PoseSet> firstPersonUpdated =
                    new HashMap<>(
                            firstPersonItemPoses
                    );

            firstPersonUpdated.remove(
                    itemId
            );

            firstPersonItemPoses =
                    firstPersonUpdated;
            clearUserItemOverride(itemId, false, false);
            clearUserItemOverride(itemId, true, false);

            /*
             * If the editor is currently open, immediately show the selected
             * style stance after clearing the item override.
             */
            if (isEditorActive()) {
                Minecraft mc = Minecraft.getInstance();
                ItemStack main = mc.player == null
                        ? ItemStack.EMPTY
                        : mc.player.getMainHandItem();
                WeaponProfile natural = WeaponClassifier.classifyNatural(main);
                if (natural.isSupported() && natural.parryStyle() != ParryStyle.GENERIC) {
                    editorStyle = natural.parryStyle();
                    editorHandVariantActive = BetterCombatWeaponMetadata.isAvailable();
                    editorHandStyle = editorHandVariantActive
                            ? natural.handStyle()
                            : HandStyle.ONE_HANDED;
                } else {
                    editorStyle = ParryStyle.GENERIC;
                    editorHandVariantActive = false;
                    editorHandStyle = HandStyle.ONE_HANDED;
                }

                PoseSet fallback = getEditorStylePoseSet(editorStyle, false);
                if (fallback == null) {
                    fallback = disabledNeutral();
                }
                editorWorking = copyPoseSet(fallback);
                editorOriginal = copyPoseSet(fallback);

                PoseSet firstPersonFallback = getEditorStylePoseSet(editorStyle, true);
                if (firstPersonFallback == null) {
                    firstPersonFallback = disabledNeutral();
                }
                editorFirstPersonWorking = copyPoseSet(firstPersonFallback);
                editorFirstPersonOriginal = copyPoseSet(firstPersonFallback);
            }

            return new SaveResult(
                    true,
                    "Cleared item override for "
                            + itemId
                            + "."
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to clear exact-item Gyeokbu stance for {}.",
                    itemId,
                    exception
            );

            return new SaveResult(
                    false,
                    "Could not clear item override. Check latest.log."
            );
        }
    }


    /**
     * Saves only ONE editor slice:
     *
     * current view (3P or 1P)
     * + current mode (Parry or Block)
     * + requested category (Arms or Weapon)
     *
     * Every other saved category is read from disk / current saved runtime data
     * and preserved exactly.
     */
    public static SaveResult saveCurrentCategoryAsDefault(
            boolean armsCategory
    ) {
        if (!isEditorActive()) {
            return new SaveResult(
                    false,
                    "No Gyeokbu pose is being edited."
            );
        }

        if (editorViewsLinked) {
            return saveLinkedCurrentCategoryAsDefault(
                    armsCategory
            );
        }

        try {
            PoseSet working =
                    getActiveEditorPoseSet();

            Path defaultPath = getEditorDefaultConfigPath(editorFirstPerson);

            Path activePath = getEditorConfigPath(editorFirstPerson);

            PoseSet base;

            if (Files.exists(defaultPath)) {
                base = readPoseSet(
                        defaultPath,
                        true
                );
            } else {
                PoseSet loaded =
                        editorFirstPerson
                                ? firstPersonPoses.get(editorStyle)
                                : poses.get(editorStyle);

                base = loaded == null
                        ? disabledNeutral()
                        : copyPoseSet(loaded);
            }

            PoseSet merged =
                    mergeEditorCategory(
                            base,
                            working,
                            armsCategory
                    );

            writePoseSet(
                    defaultPath,
                    merged
            );

            writePoseSet(
                    activePath,
                    merged
            );

            if (editorFirstPerson) {
                replaceLoadedFirstPersonPose(
                        editorStyle,
                        merged
                );
            } else {
                replaceLoadedPose(
                        editorStyle,
                        merged
                );
            }

            return new SaveResult(
                    true,
                    "Saved "
                            + (editorFirstPerson ? "1P " : "3P ")
                            + (editorMode == DefenseAnimationSyncPayload.PARRY
                            ? "Parry "
                            : "Block ")
                            + (armsCategory ? "Arms" : "Weapon")
                            + " as default."
            );

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save one Gyeokbu editor category as default.",
                    exception
            );

            return new SaveResult(
                    false,
                    "Category save failed. Check latest.log."
            );
        }
    }

    /**
     * Re-bases one held item's complete 3P + 1P override onto the currently
     * selected editor stance family.
     *
     * This is used only when the dropdown actually changes stance family, so
     * one Save Held click can switch Rapier -> Greatsword cleanly instead of
     * creating a hybrid from an older held override.
     */
    public static SaveResult rebaseItemOverrideToEditorStyle(
            ResourceLocation itemId
    ) {
        if (!isEditorActive()) {
            return new SaveResult(
                    false,
                    "No Gyeokbu pose is being edited."
            );
        }

        if (editorViewsLinked) {
            return rebaseLinkedItemOverrideToEditorStyle(
                    itemId
            );
        }

        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            PoseSet thirdBase =
                    poses.get(
                            editorStyle
                    );
            if (thirdBase == null) {
                thirdBase = disabledNeutral();
            }

            PoseSet firstBase =
                    firstPersonPoses.get(
                            editorStyle
                    );
            if (firstBase == null) {
                firstBase = disabledNeutral();
            }

            PoseSet savedThird =
                    enabledCopy(
                            thirdBase
                    );
            PoseSet savedFirst =
                    enabledCopy(
                            firstBase
                    );

            writePoseSet(
                    getItemConfigPath(itemId),
                    savedThird
            );
            writePoseSet(
                    getFirstPersonItemConfigPath(itemId),
                    savedFirst
            );

            Map<ResourceLocation, PoseSet> thirdUpdated =
                    new HashMap<>(
                            itemPoses
                    );
            thirdUpdated.put(
                    itemId,
                    copyPoseSet(savedThird)
            );
            itemPoses =
                    thirdUpdated;

            Map<ResourceLocation, PoseSet> firstUpdated =
                    new HashMap<>(
                            firstPersonItemPoses
                    );
            firstUpdated.put(
                    itemId,
                    copyPoseSet(savedFirst)
            );
            firstPersonItemPoses =
                    firstUpdated;
            markUserItemOverride(itemId, false, false);
            markUserItemOverride(itemId, true, false);

            return new SaveResult(
                    true,
                    "Re-based held item to " + editorStyle.name() + "."
            );

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to re-base held Gyeokbu stance for {}.",
                    itemId,
                    exception
            );

            return new SaveResult(
                    false,
                    "Held stance re-base failed. Check latest.log."
            );
        }
    }

    public static SaveResult saveCurrentCategoryForItem(
            ResourceLocation itemId,
            boolean armsCategory
    ) {
        if (!isEditorActive()) {
            return new SaveResult(
                    false,
                    "No Gyeokbu pose is being edited."
            );
        }

        if (editorViewsLinked) {
            return saveLinkedCurrentCategoryForItem(
                    itemId,
                    armsCategory
            );
        }

        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            PoseSet working =
                    getActiveEditorPoseSet();

            Path path =
                    editorFirstPerson
                            ? getFirstPersonItemConfigPath(itemId)
                            : getItemConfigPath(itemId);

            PoseSet base;

            if (Files.exists(path)) {
                base = readPoseSet(
                        path,
                        true
                );
            } else {
                PoseSet loaded =
                        editorFirstPerson
                                ? firstPersonPoses.get(editorStyle)
                                : poses.get(editorStyle);

                base = loaded == null
                        ? disabledNeutral()
                        : copyPoseSet(loaded);
            }

            PoseSet merged =
                    mergeEditorCategory(
                            base,
                            working,
                            armsCategory
                    );

            writePoseSet(
                    path,
                    merged
            );

            if (editorFirstPerson) {
                Map<ResourceLocation, PoseSet> updated =
                        new HashMap<>(
                                firstPersonItemPoses
                        );

                updated.put(
                        itemId,
                        copyPoseSet(merged)
                );

                firstPersonItemPoses =
                        updated;
            } else {
                Map<ResourceLocation, PoseSet> updated =
                        new HashMap<>(
                                itemPoses
                        );

                updated.put(
                        itemId,
                        copyPoseSet(merged)
                );

                itemPoses =
                        updated;
            }
            markUserItemOverride(itemId, editorFirstPerson, false);

            return new SaveResult(
                    true,
                    "Saved held "
                            + (editorFirstPerson ? "1P " : "3P ")
                            + (editorMode == DefenseAnimationSyncPayload.PARRY
                            ? "Parry "
                            : "Block ")
                            + (armsCategory ? "Arms." : "Weapon.")
            );

        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save one exact-item Gyeokbu editor category for {}.",
                    itemId,
                    exception
            );

            return new SaveResult(
                    false,
                    "Held category save failed. Check latest.log."
            );
        }
    }

    private static SaveResult saveLinkedCurrentCategoryAsDefault(
            boolean armsCategory
    ) {
        try {
            PoseSet activeWorking =
                    getActiveEditorPoseSet();

            PoseSet thirdBase =
                    linkedThirdPersonPoses.get(editorStyle);
            PoseSet firstBase =
                    linkedFirstPersonPoses.get(editorStyle);

            if (thirdBase == null) {
                thirdBase = editorLinkedThirdPersonOriginal == null
                        ? editorLinkedThirdPersonWorking
                        : editorLinkedThirdPersonOriginal;
            }
            if (firstBase == null) {
                firstBase = editorLinkedFirstPersonOriginal == null
                        ? editorLinkedFirstPersonWorking
                        : editorLinkedFirstPersonOriginal;
            }

            if (thirdBase == null) thirdBase = disabledNeutral();
            if (firstBase == null) firstBase = disabledNeutral();

            PoseSet savedThird = copyPoseSet(thirdBase);
            PoseSet savedFirst = copyPoseSet(firstBase);

            if (armsCategory) {
                savedThird = mergeEditorCategory(
                        savedThird,
                        activeWorking,
                        true
                );
                savedFirst = mergeEditorCategory(
                        savedFirst,
                        activeWorking,
                        true
                );
            } else if (editorFirstPerson) {
                savedFirst = mergeEditorCategory(
                        savedFirst,
                        activeWorking,
                        false
                );
            } else {
                savedThird = mergeEditorCategory(
                        savedThird,
                        activeWorking,
                        false
                );
            }

            writePoseSet(
                    getEditorLinkedStyleConfigPath(false),
                    enabledCopy(savedThird)
            );
            writePoseSet(
                    getEditorLinkedStyleConfigPath(true),
                    enabledCopy(savedFirst)
            );

            replaceLinkedStylePose(
                    editorStyle,
                    savedThird,
                    false
            );
            replaceLinkedStylePose(
                    editorStyle,
                    savedFirst,
                    true
            );

            return new SaveResult(
                    true,
                    "Saved linked "
                            + (editorMode == DefenseAnimationSyncPayload.PARRY
                            ? "Parry "
                            : "Block ")
                            + (armsCategory ? "Arms" : (editorFirstPerson ? "First-Person Weapon" : "Third-Person Weapon"))
                            + " as default."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save linked Gyeokbu default category.",
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked default save failed. Check latest.log."
            );
        }
    }

    private static SaveResult saveLinkedCurrentCategoryForItem(
            ResourceLocation itemId,
            boolean armsCategory
    ) {
        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            PoseSet activeWorking =
                    getActiveEditorPoseSet();

            PoseSet thirdBase =
                    linkedThirdPersonItemPoses.get(itemId);
            PoseSet firstBase =
                    linkedFirstPersonItemPoses.get(itemId);

            if (thirdBase == null) {
                thirdBase = editorLinkedThirdPersonOriginal == null
                        ? editorLinkedThirdPersonWorking
                        : editorLinkedThirdPersonOriginal;
            }
            if (firstBase == null) {
                firstBase = editorLinkedFirstPersonOriginal == null
                        ? editorLinkedFirstPersonWorking
                        : editorLinkedFirstPersonOriginal;
            }

            if (thirdBase == null) thirdBase = disabledNeutral();
            if (firstBase == null) firstBase = disabledNeutral();

            PoseSet savedThird = copyPoseSet(thirdBase);
            PoseSet savedFirst = copyPoseSet(firstBase);

            if (armsCategory) {
                savedThird = mergeEditorCategory(savedThird, activeWorking, true);
                savedFirst = mergeEditorCategory(savedFirst, activeWorking, true);
            } else if (editorFirstPerson) {
                savedFirst = mergeEditorCategory(savedFirst, activeWorking, false);
            } else {
                savedThird = mergeEditorCategory(savedThird, activeWorking, false);
            }

            writePoseSet(
                    getLinkedItemConfigPath(itemId, false),
                    enabledCopy(savedThird)
            );
            writePoseSet(
                    getLinkedItemConfigPath(itemId, true),
                    enabledCopy(savedFirst)
            );

            Map<ResourceLocation, PoseSet> thirdUpdated =
                    new HashMap<>(linkedThirdPersonItemPoses);
            thirdUpdated.put(itemId, copyPoseSet(savedThird));
            linkedThirdPersonItemPoses = thirdUpdated;

            Map<ResourceLocation, PoseSet> firstUpdated =
                    new HashMap<>(linkedFirstPersonItemPoses);
            firstUpdated.put(itemId, copyPoseSet(savedFirst));
            linkedFirstPersonItemPoses = firstUpdated;

            markUserItemOverride(itemId, false, true);
            markUserItemOverride(itemId, true, true);

            return new SaveResult(
                    true,
                    "Saved linked held "
                            + (editorMode == DefenseAnimationSyncPayload.PARRY
                            ? "Parry "
                            : "Block ")
                            + (armsCategory ? "Arms." : (editorFirstPerson ? "First-Person Weapon." : "Third-Person Weapon."))
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save linked held Gyeokbu category for {}.",
                    itemId,
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked held save failed. Check latest.log."
            );
        }
    }

    private static SaveResult rebaseLinkedItemOverrideToEditorStyle(
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        try {
            PoseSet thirdBase = editorLinkedThirdPersonOriginal == null
                    ? editorLinkedThirdPersonWorking
                    : editorLinkedThirdPersonOriginal;
            PoseSet firstBase = editorLinkedFirstPersonOriginal == null
                    ? editorLinkedFirstPersonWorking
                    : editorLinkedFirstPersonOriginal;

            if (thirdBase == null) thirdBase = disabledNeutral();
            if (firstBase == null) firstBase = disabledNeutral();

            PoseSet savedThird = enabledCopy(thirdBase);
            PoseSet savedFirst = enabledCopy(firstBase);

            writePoseSet(
                    getLinkedItemConfigPath(itemId, false),
                    savedThird
            );
            writePoseSet(
                    getLinkedItemConfigPath(itemId, true),
                    savedFirst
            );

            Map<ResourceLocation, PoseSet> thirdUpdated =
                    new HashMap<>(linkedThirdPersonItemPoses);
            thirdUpdated.put(itemId, copyPoseSet(savedThird));
            linkedThirdPersonItemPoses = thirdUpdated;

            Map<ResourceLocation, PoseSet> firstUpdated =
                    new HashMap<>(linkedFirstPersonItemPoses);
            firstUpdated.put(itemId, copyPoseSet(savedFirst));
            linkedFirstPersonItemPoses = firstUpdated;

            markUserItemOverride(itemId, false, true);
            markUserItemOverride(itemId, true, true);

            return new SaveResult(
                    true,
                    "Re-based linked held item to " + editorStyle.name() + "."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to re-base linked held Gyeokbu stance for {}.",
                    itemId,
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked held stance re-base failed. Check latest.log."
            );
        }
    }

    private static SaveResult saveLinkedEditorAsDefaultWhole() {
        if (editorLinkedThirdPersonWorking == null
                || editorLinkedFirstPersonWorking == null) {
            return new SaveResult(false, "No linked workspace is being edited.");
        }

        PoseSet savedThird = enabledCopy(editorLinkedThirdPersonWorking);
        PoseSet savedFirst = enabledCopy(editorLinkedFirstPersonWorking);

        try {
            writePoseSet(
                    getEditorLinkedStyleConfigPath(false),
                    savedThird
            );
            writePoseSet(
                    getEditorLinkedStyleConfigPath(true),
                    savedFirst
            );

            replaceLinkedStylePose(editorStyle, savedThird, false);
            replaceLinkedStylePose(editorStyle, savedFirst, true);

            editorLinkedThirdPersonWorking = copyPoseSet(savedThird);
            editorLinkedThirdPersonOriginal = copyPoseSet(savedThird);
            editorLinkedFirstPersonWorking = copyPoseSet(savedFirst);
            editorLinkedFirstPersonOriginal = copyPoseSet(savedFirst);

            return new SaveResult(
                    true,
                    "Saved complete linked " + editorStyle.name() + " stance as default."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save complete linked Gyeokbu default stance.",
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked default save failed. Check latest.log."
            );
        }
    }

    private static SaveResult saveLinkedEditorForItemWhole(
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        if (editorLinkedThirdPersonWorking == null
                || editorLinkedFirstPersonWorking == null) {
            return new SaveResult(false, "No linked workspace is being edited.");
        }

        PoseSet savedThird = enabledCopy(editorLinkedThirdPersonWorking);
        PoseSet savedFirst = enabledCopy(editorLinkedFirstPersonWorking);

        try {
            writePoseSet(
                    getLinkedItemConfigPath(itemId, false),
                    savedThird
            );
            writePoseSet(
                    getLinkedItemConfigPath(itemId, true),
                    savedFirst
            );

            Map<ResourceLocation, PoseSet> thirdUpdated =
                    new HashMap<>(linkedThirdPersonItemPoses);
            thirdUpdated.put(itemId, copyPoseSet(savedThird));
            linkedThirdPersonItemPoses = thirdUpdated;

            Map<ResourceLocation, PoseSet> firstUpdated =
                    new HashMap<>(linkedFirstPersonItemPoses);
            firstUpdated.put(itemId, copyPoseSet(savedFirst));
            linkedFirstPersonItemPoses = firstUpdated;

            editorLinkedThirdPersonWorking = copyPoseSet(savedThird);
            editorLinkedThirdPersonOriginal = copyPoseSet(savedThird);
            editorLinkedFirstPersonWorking = copyPoseSet(savedFirst);
            editorLinkedFirstPersonOriginal = copyPoseSet(savedFirst);

            markUserItemOverride(itemId, false, true);
            markUserItemOverride(itemId, true, true);

            return new SaveResult(
                    true,
                    "Saved complete linked stance only for " + itemId + "."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save complete linked held Gyeokbu stance for {}.",
                    itemId,
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked held save failed. Check latest.log."
            );
        }
    }

    private static PoseSet mergeEditorCategory(
            PoseSet base,
            PoseSet working,
            boolean armsCategory
    ) {
        boolean parry =
                editorMode == DefenseAnimationSyncPayload.PARRY;

        Vec3f parryMain =
                copyVec(base.parryMainHand());
        Vec3f parryOff =
                copyVec(base.parryOffHand());
        Vec3f parryPos =
                copyVec(base.parryWeaponPosition());
        Vec3f parryRot =
                copyVec(base.parryWeaponRotation());

        Vec3f blockMain =
                copyVec(base.blockMainHand());
        Vec3f blockOff =
                copyVec(base.blockOffHand());
        Vec3f blockPos =
                copyVec(base.blockWeaponPosition());
        Vec3f blockRot =
                copyVec(base.blockWeaponRotation());

        if (parry) {
            if (armsCategory) {
                parryMain =
                        copyVec(working.parryMainHand());
                parryOff =
                        copyVec(working.parryOffHand());
            } else {
                parryPos =
                        copyVec(working.parryWeaponPosition());
                parryRot =
                        copyVec(working.parryWeaponRotation());
            }
        } else {
            if (armsCategory) {
                blockMain =
                        copyVec(working.blockMainHand());
                blockOff =
                        copyVec(working.blockOffHand());
            } else {
                blockPos =
                        copyVec(working.blockWeaponPosition());
                blockRot =
                        copyVec(working.blockWeaponRotation());
            }
        }

        return new PoseSet(
                true,
                parryMain,
                parryOff,
                parryPos,
                parryRot,
                blockMain,
                blockOff,
                blockPos,
                blockRot
        );
    }

    public static SaveResult saveEditorForItem(
            ResourceLocation itemId
    ) {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        if (itemId == null) {

            return new SaveResult(
                    false,
                    "No held item was captured when the editor opened."
            );
        }

        if (editorViewsLinked) {
            return saveLinkedEditorForItemWhole(itemId);
        }

        PoseSet saved =
                enabledCopy(
                        editorWorking
                );

        PoseSet firstPersonSaved =
                enabledCopy(
                        editorFirstPersonWorking
                );

        try {

            writePoseSet(
                    getItemConfigPath(
                            itemId
                    ),
                    saved
            );

            writePoseSet(
                    getFirstPersonItemConfigPath(
                            itemId
                    ),
                    firstPersonSaved
            );

            Map<ResourceLocation, PoseSet> updated =
                    new HashMap<>(
                            itemPoses
                    );

            updated.put(
                    itemId,
                    copyPoseSet(
                            saved
                    )
            );

            itemPoses =
                    updated;

            Map<ResourceLocation, PoseSet> firstPersonUpdated =
                    new HashMap<>(
                            firstPersonItemPoses
                    );

            firstPersonUpdated.put(
                    itemId,
                    copyPoseSet(
                            firstPersonSaved
                    )
            );

            firstPersonItemPoses =
                    firstPersonUpdated;
            markUserItemOverride(itemId, false, false);
            markUserItemOverride(itemId, true, false);

            editorWorking =
                    copyPoseSet(
                            saved
                    );

            editorOriginal =
                    copyPoseSet(
                            saved
                    );

            editorFirstPersonWorking =
                    copyPoseSet(
                            firstPersonSaved
                    );

            editorFirstPersonOriginal =
                    copyPoseSet(
                            firstPersonSaved
                    );

            return new SaveResult(
                    true,
                    "Saved stance only for "
                            + itemId
                            + "."
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to save exact-item Gyeokbu stance for {}.",
                    itemId,
                    exception
            );

            return new SaveResult(
                    false,
                    "Item stance save failed. Check latest.log."
            );
        }
    }

    public static SaveResult saveEditorAsDefault() {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        if (editorViewsLinked) {
            return saveLinkedEditorAsDefaultWhole();
        }

        PoseSet saved =
                enabledCopy(
                        editorWorking
                );

        PoseSet firstPersonSaved =
                enabledCopy(
                        editorFirstPersonWorking
                );

        try {

            writePoseSet(
                    getEditorDefaultConfigPath(false),
                    saved
            );

            writePoseSet(
                    getEditorConfigPath(false),
                    saved
            );

            writePoseSet(
                    getEditorDefaultConfigPath(true),
                    firstPersonSaved
            );

            writePoseSet(
                    getEditorConfigPath(true),
                    firstPersonSaved
            );

            replaceLoadedPoseForEditor(
                    saved,
                    false
            );

            replaceLoadedPoseForEditor(
                    firstPersonSaved,
                    true
            );

            editorWorking =
                    copyPoseSet(
                            saved
                    );

            editorOriginal =
                    copyPoseSet(
                            saved
                    );

            editorFirstPersonWorking =
                    copyPoseSet(
                            firstPersonSaved
                    );

            editorFirstPersonOriginal =
                    copyPoseSet(
                            firstPersonSaved
                    );

            return new SaveResult(
                    true,
                    "Saved "
                            + editorStyle.name()
                            + " as the default stance."
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to save Gyeokbu default stance.",
                    exception
            );

            return new SaveResult(
                    false,
                    "Default save failed. Check latest.log."
            );
        }
    }

    public static SaveResult resetEditorToDefault() {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        try {

            PoseSet defaultPose =
                    getBundledEditorDefaultPose(
                            editorFirstPerson
                    );

            if (editorViewsLinked) {
                setActiveEditorPoseSet(
                        copyPoseSet(defaultPose)
                );
                mirrorAllEditorArmsToOtherView(
                        defaultPose
                );
            } else if (editorFirstPerson) {
                editorFirstPersonWorking =
                        copyPoseSet(defaultPose);
            } else {
                editorWorking =
                        copyPoseSet(defaultPose);
            }

            return new SaveResult(
                    true,
                    "Loaded official shipped "
                            + editorStyle.name()
                            + (editorFirstPerson
                            ? " first-person default."
                            : " third-person default.")
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to load official bundled Gyeokbu default stance.",
                    exception
            );

            return new SaveResult(
                    false,
                    "Reset to shipped default failed. Check latest.log."
            );
        }
    }

    private static PoseSet getBundledEditorDefaultPose(
            boolean firstPerson
    ) throws IOException {

        String view = firstPerson
                ? "first_person"
                : "third_person";

        if (editorItemId != null) {
            String exactPath;

            if (editorViewsLinked) {
                exactPath =
                        "legacy_linked_views/items/"
                                + view
                                + "/"
                                + editorItemId.getNamespace()
                                + "/"
                                + editorItemId.getPath()
                                + ".json";
            } else {
                exactPath =
                        (firstPerson
                                ? "first_person_item_animations/"
                                : "item_animations/")
                                + editorItemId.getNamespace()
                                + "/"
                                + editorItemId.getPath()
                                + ".json";
            }

            if (BundledStanceDefaults.has(exactPath)) {
                return readBundledPoseSet(
                        exactPath,
                        true
                );
            }
        }

        if (editorViewsLinked) {
            String linkedStylePath =
                    "legacy_linked_views/styles/"
                            + view
                            + "/"
                            + editorStyle.name()
                            .toLowerCase(Locale.ROOT)
                            + ".json";

            if (BundledStanceDefaults.has(linkedStylePath)) {
                return readBundledPoseSet(
                        linkedStylePath,
                        true
                );
            }
        }

        String stylePath =
                (firstPerson
                        ? "first_person_animation_defaults/"
                        : "animation_defaults/")
                        + editorStyle.name()
                        .toLowerCase(Locale.ROOT)
                        + ".json";

        if (BundledStanceDefaults.has(stylePath)) {
            return readBundledPoseSet(
                    stylePath,
                    defaultEnabled(editorStyle)
            );
        }

        return disabledNeutral();
    }

    /**
     * Recovery action for accidental editor changes.
     *
     * Reloads BOTH Third Person and First Person from the last saved style
     * defaults. Nothing is written to disk.
     */
    public static SaveResult revertEditorToSavedDefault() {

        if (!isEditorActive()) {

            return new SaveResult(
                    false,
                    "No Gyeokbu stance is being edited."
            );
        }

        if (editorViewsLinked) {
            return revertLinkedEditorToSaved();
        }

        try {

            Path editorDefaultPath = getEditorDefaultConfigPath(false);
            Path editorFirstDefaultPath = getEditorDefaultConfigPath(true);

            ensureDefaultFileExists(
                    editorStyle
            );

            PoseSet thirdDefault;
            if (Files.exists(editorDefaultPath)) {
                thirdDefault = readPoseSet(
                        editorDefaultPath,
                        defaultEnabled(editorStyle)
                );
            } else {
                Path legacyDefaultPath = getDefaultConfigPath(editorStyle);
                thirdDefault = readPoseSet(
                        legacyDefaultPath,
                        defaultEnabled(editorStyle)
                );
            }

            Path firstDefaultPath = editorFirstDefaultPath;

            PoseSet firstDefault;

            if (Files.exists(firstDefaultPath)) {
                firstDefault = readPoseSet(firstDefaultPath, true);
            } else if (editorHandVariantActive) {
                Path legacyFirstDefaultPath = getFirstPersonDefaultConfigPath(editorStyle);
                firstDefault = Files.exists(legacyFirstDefaultPath)
                        ? readPoseSet(legacyFirstDefaultPath, true)
                        : firstPersonPoses.get(editorStyle);
                if (firstDefault == null) {
                    firstDefault = disabledNeutral();
                }
            } else {
                firstDefault = firstPersonPoses.get(editorStyle);
                if (firstDefault == null) {
                    firstDefault = disabledNeutral();
                }
            }

            editorWorking =
                    copyPoseSet(
                            thirdDefault
                    );

            editorFirstPersonWorking =
                    copyPoseSet(
                            firstDefault
                    );

            return new SaveResult(
                    true,
                    "Reverted "
                            + editorStyle.name()
                            + " 3P + 1P to the last saved default."
            );

        } catch (Exception exception) {

            GyeokbuV2.LOGGER.error(
                    "Failed to revert Gyeokbu stance to saved default.",
                    exception
            );

            return new SaveResult(
                    false,
                    "Revert to saved default failed. Check latest.log."
            );
        }
    }

    private static SaveResult revertLinkedEditorToSaved() {
        try {
            PoseSet savedThird =
                    getLinkedEditorSavedPose(
                            editorStyle,
                            editorItemId,
                            false
                    );
            PoseSet savedFirst =
                    getLinkedEditorSavedPose(
                            editorStyle,
                            editorItemId,
                            true
                    );

            if (savedThird == null && savedFirst == null) {
                savedThird = editorLinkedThirdPersonOriginal;
                savedFirst = editorLinkedFirstPersonOriginal;
            }

            if (savedThird == null) {
                savedThird = editorLinkedThirdPersonOriginal == null
                        ? disabledNeutral()
                        : editorLinkedThirdPersonOriginal;
            }
            if (savedFirst == null) {
                savedFirst = editorLinkedFirstPersonOriginal == null
                        ? disabledNeutral()
                        : editorLinkedFirstPersonOriginal;
            }

            PoseSet armSource = editorFirstPerson
                    ? savedFirst
                    : savedThird;

            editorLinkedThirdPersonWorking =
                    copyArmsIntoPoseSet(
                            savedThird,
                            armSource
                    );
            editorLinkedFirstPersonWorking =
                    copyArmsIntoPoseSet(
                            savedFirst,
                            armSource
                    );

            return new SaveResult(
                    true,
                    "Reverted linked "
                            + editorStyle.name()
                            + " workspace to its last saved state."
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to revert linked Gyeokbu stance.",
                    exception
            );
            return new SaveResult(
                    false,
                    "Linked revert failed. Check latest.log."
            );
        }
    }

    public static boolean hasUnsavedEditorChanges() {
        if (!isEditorActive()) {
            return false;
        }

        return !poseSetsEqual(editorWorking, editorOriginal)
                || !poseSetsEqual(editorFirstPersonWorking, editorFirstPersonOriginal)
                || !poseSetsEqual(editorLinkedThirdPersonWorking, editorLinkedThirdPersonOriginal)
                || !poseSetsEqual(editorLinkedFirstPersonWorking, editorLinkedFirstPersonOriginal);
    }

    private static boolean poseSetsEqual(
            PoseSet first,
            PoseSet second
    ) {
        if (first == second) {
            return true;
        }
        if (first == null || second == null) {
            return false;
        }

        return first.enabled() == second.enabled()
                && vecEquals(first.parryMainHand(), second.parryMainHand())
                && vecEquals(first.parryOffHand(), second.parryOffHand())
                && vecEquals(first.parryWeaponPosition(), second.parryWeaponPosition())
                && vecEquals(first.parryWeaponRotation(), second.parryWeaponRotation())
                && vecEquals(first.blockMainHand(), second.blockMainHand())
                && vecEquals(first.blockOffHand(), second.blockOffHand())
                && vecEquals(first.blockWeaponPosition(), second.blockWeaponPosition())
                && vecEquals(first.blockWeaponRotation(), second.blockWeaponRotation());
    }

    private static boolean vecEquals(
            Vec3f first,
            Vec3f second
    ) {
        if (first == second) {
            return true;
        }
        if (first == null || second == null) {
            return false;
        }

        return Float.compare(first.getX(), second.getX()) == 0
                && Float.compare(first.getY(), second.getY()) == 0
                && Float.compare(first.getZ(), second.getZ()) == 0;
    }

    public static void endEditor() {

        editorActive =
                false;

        editorStyle =
                null;

        editorOriginal =
                null;

        editorWorking =
                null;

        editorFirstPersonOriginal =
                null;

        editorFirstPersonWorking =
                null;

        editorFirstPerson =
                false;
        editorItemId =
                null;
        editorNormalStyle =
                null;
        editorLinkedStyle =
                null;
        editorLinkedThirdPersonOriginal =
                null;
        editorLinkedThirdPersonWorking =
                null;
        editorLinkedFirstPersonOriginal =
                null;
        editorLinkedFirstPersonWorking =
                null;

        editorMode =
                DefenseAnimationSyncPayload.PARRY;
    }

    private static Set<ParryStyle> detectUserStyleOverrides(
            boolean firstPerson,
            boolean linked
    ) throws IOException {
        EnumSet<ParryStyle> result =
                EnumSet.noneOf(ParryStyle.class);

        for (ParryStyle style : ParryStyle.values()) {
            Path path = linked
                    ? getLinkedStyleConfigPath(style, firstPerson)
                    : (firstPerson
                    ? getFirstPersonConfigPath(style)
                    : getConfigPath(style));

            if (BundledStanceDefaults.isUserOverride(
                    path,
                    styleRelativePath(style, firstPerson, linked)
            )) {
                result.add(style);
            }
        }

        return result;
    }

    private static Set<ResourceLocation> detectUserItemOverrides(
            Set<ResourceLocation> itemIds,
            boolean firstPerson,
            boolean linked
    ) throws IOException {
        Set<ResourceLocation> result =
                new HashSet<>();

        for (ResourceLocation itemId : itemIds) {
            Path path = linked
                    ? getLinkedItemConfigPath(itemId, firstPerson)
                    : (firstPerson
                    ? getFirstPersonItemConfigPath(itemId)
                    : getItemConfigPath(itemId));

            if (BundledStanceDefaults.isUserOverride(
                    path,
                    itemRelativePath(itemId, firstPerson, linked)
            )) {
                result.add(itemId);
            }
        }

        return result;
    }

    private static String styleRelativePath(
            ParryStyle style,
            boolean firstPerson,
            boolean linked
    ) {
        String file =
                style.name().toLowerCase(Locale.ROOT) + ".json";

        if (linked) {
            return "legacy_linked_views/styles/"
                    + (firstPerson ? "first_person/" : "third_person/")
                    + file;
        }

        return (firstPerson
                ? "first_person_animations/"
                : "animations/")
                + file;
    }

    private static String itemRelativePath(
            ResourceLocation itemId,
            boolean firstPerson,
            boolean linked
    ) {
        if (linked) {
            return "legacy_linked_views/items/"
                    + (firstPerson ? "first_person/" : "third_person/")
                    + itemId.getNamespace()
                    + "/"
                    + itemId.getPath()
                    + ".json";
        }

        return (firstPerson
                ? "first_person_item_animations/"
                : "item_animations/")
                + itemId.getNamespace()
                + "/"
                + itemId.getPath()
                + ".json";
    }

    private static Set<ResourceLocation> addUserAssignmentOverrides(
            Set<ResourceLocation> base,
            Map<ResourceLocation, ParryStyle> assignments,
            String bundledRelativePath
    ) throws IOException {
        Set<ResourceLocation> updated = new HashSet<>(base);
        JsonObject bundled = null;

        if (BundledStanceDefaults.has(bundledRelativePath)) {
            bundled = JsonParser.parseString(
                    BundledStanceDefaults.readText(bundledRelativePath)
            ).getAsJsonObject();
        }

        for (Map.Entry<ResourceLocation, ParryStyle> entry : assignments.entrySet()) {
            String key = entry.getKey().toString();
            String value = entry.getValue().name();
            if (bundled == null
                    || !bundled.has(key)
                    || !value.equals(bundled.get(key).getAsString())) {
                updated.add(entry.getKey());
            }
        }

        return updated;
    }

    private static void refreshUserItemClassification(
            ResourceLocation itemId,
            boolean linked
    ) throws IOException {
        Path thirdPath = linked
                ? getLinkedItemConfigPath(itemId, false)
                : getItemConfigPath(itemId);
        Path firstPath = linked
                ? getLinkedItemConfigPath(itemId, true)
                : getFirstPersonItemConfigPath(itemId);

        if (BundledStanceDefaults.isUserOverride(
                thirdPath, itemRelativePath(itemId, false, linked))) {
            markUserItemOverride(itemId, false, linked);
        } else {
            clearUserItemOverride(itemId, false, linked);
        }

        if (BundledStanceDefaults.isUserOverride(
                firstPath, itemRelativePath(itemId, true, linked))) {
            markUserItemOverride(itemId, true, linked);
        } else {
            clearUserItemOverride(itemId, true, linked);
        }
    }

    private static void markUserStyleOverride(
            ParryStyle style,
            boolean firstPerson,
            boolean linked
    ) {
        Set<ParryStyle> current = linked
                ? (firstPerson
                ? userLinkedFirstPersonStyles
                : userLinkedThirdPersonStyles)
                : (firstPerson
                ? userFirstPersonStyles
                : userThirdPersonStyles);

        EnumSet<ParryStyle> updated =
                EnumSet.noneOf(ParryStyle.class);
        updated.addAll(current);
        updated.add(style);

        if (linked) {
            if (firstPerson) {
                userLinkedFirstPersonStyles = updated;
            } else {
                userLinkedThirdPersonStyles = updated;
            }
        } else if (firstPerson) {
            userFirstPersonStyles = updated;
        } else {
            userThirdPersonStyles = updated;
        }
    }

    private static void markUserItemOverride(
            ResourceLocation itemId,
            boolean firstPerson,
            boolean linked
    ) {
        Set<ResourceLocation> current = linked
                ? (firstPerson
                ? userLinkedFirstPersonItems
                : userLinkedThirdPersonItems)
                : (firstPerson
                ? userFirstPersonItems
                : userThirdPersonItems);

        Set<ResourceLocation> updated =
                new HashSet<>(current);
        updated.add(itemId);

        if (linked) {
            if (firstPerson) {
                userLinkedFirstPersonItems = updated;
            } else {
                userLinkedThirdPersonItems = updated;
            }
        } else if (firstPerson) {
            userFirstPersonItems = updated;
        } else {
            userThirdPersonItems = updated;
        }
    }

    private static void clearUserItemOverride(
            ResourceLocation itemId,
            boolean firstPerson,
            boolean linked
    ) {
        Set<ResourceLocation> current = linked
                ? (firstPerson
                ? userLinkedFirstPersonItems
                : userLinkedThirdPersonItems)
                : (firstPerson
                ? userFirstPersonItems
                : userThirdPersonItems);

        Set<ResourceLocation> updated =
                new HashSet<>(current);
        updated.remove(itemId);

        if (linked) {
            if (firstPerson) {
                userLinkedFirstPersonItems = updated;
            } else {
                userLinkedThirdPersonItems = updated;
            }
        } else if (firstPerson) {
            userFirstPersonItems = updated;
        } else {
            userThirdPersonItems = updated;
        }
    }

    /*
     * ------------------------------------------------------------
     * FILE PATHS
     * ------------------------------------------------------------
     */

    public static Path getAnimationDirectory() {

        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("animations");
    }

    public static Path getDefaultAnimationDirectory() {

        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("animation_defaults");
    }

    public static Path getItemAnimationDirectory() {

        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("item_animations");
    }

    public static Path getFirstPersonAnimationDirectory() {

        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("first_person_animations");
    }

    public static Path getFirstPersonDefaultAnimationDirectory() {

        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("first_person_animation_defaults");
    }

    public static Path getFirstPersonItemAnimationDirectory() {

        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("first_person_item_animations");
    }

    public static Path getLinkedViewDirectory() {
        return Minecraft
                .getInstance()
                .gameDirectory
                .toPath()
                .resolve("config")
                .resolve(GyeokbuV2.MODID)
                .resolve("legacy_linked_views");
    }

    private static Path getLinkedStyleAnimationDirectory(
            boolean firstPerson
    ) {
        return getLinkedViewDirectory()
                .resolve("styles")
                .resolve(firstPerson ? "first_person" : "third_person");
    }

    private static Path getLinkedItemAnimationDirectory(
            boolean firstPerson
    ) {
        return getLinkedViewDirectory()
                .resolve("items")
                .resolve(firstPerson ? "first_person" : "third_person");
    }

    private static Path getLinkedStyleConfigPath(
            ParryStyle style,
            boolean firstPerson
    ) {
        return getLinkedStyleAnimationDirectory(firstPerson)
                .resolve(
                        style.name()
                                .toLowerCase(Locale.ROOT)
                                + ".json"
                );
    }

    private static Path getLinkedItemConfigPath(
            ResourceLocation itemId,
            boolean firstPerson
    ) {
        return getLinkedItemAnimationDirectory(firstPerson)
                .resolve(itemId.getNamespace())
                .resolve(itemId.getPath() + ".json");
    }

    private static Path getLinkedItemStyleAssignmentsPath() {
        return getLinkedViewDirectory()
                .resolve("item_stance_assignments.json");
    }

    private static Path getLinkedSettingsPath() {
        return getLinkedViewDirectory()
                .resolve("settings.json");
    }

    public static Path getFirstPersonConfigPath(
            ParryStyle style
    ) {

        return getFirstPersonAnimationDirectory()
                .resolve(
                        style.name()
                                .toLowerCase(
                                        Locale.ROOT
                                )
                                + ".json"
                );
    }

    public static Path getFirstPersonDefaultConfigPath(
            ParryStyle style
    ) {

        return getFirstPersonDefaultAnimationDirectory()
                .resolve(
                        style.name()
                                .toLowerCase(
                                        Locale.ROOT
                                )
                                + ".json"
                );
    }

    public static Path getFirstPersonItemConfigPath(
            ResourceLocation itemId
    ) {

        return getFirstPersonItemAnimationDirectory()
                .resolve(
                        itemId.getNamespace()
                )
                .resolve(
                        itemId.getPath()
                                + ".json"
                );
    }

    public static Path getConfigPath(
            ParryStyle style
    ) {

        return getAnimationDirectory()
                .resolve(
                        style.name()
                                .toLowerCase(
                                        Locale.ROOT
                                )
                                + ".json"
                );
    }

    public static Path getDefaultConfigPath(
            ParryStyle style
    ) {

        return getDefaultAnimationDirectory()
                .resolve(
                        style.name()
                                .toLowerCase(
                                        Locale.ROOT
                                )
                                + ".json"
                );
    }

    public static Path getItemConfigPath(
            ResourceLocation itemId
    ) {

        return getItemAnimationDirectory()
                .resolve(
                        itemId.getNamespace()
                )
                .resolve(
                        itemId.getPath()
                                + ".json"
                );
    }

    private static Path getItemStyleAssignmentsPath() {
        return getAnimationDirectory()
                .resolve(
                        "item_stance_assignments.json"
                );
    }

    private static void ensureAllFilesExist() {

        for (ParryStyle style : ParryStyle.values()) {

            Path path =
                    getConfigPath(
                            style
                    );

            if (Files.exists(
                    path
            )) {
                continue;
            }

            try {

                Files.createDirectories(
                        path.getParent()
                );

                Files.writeString(
                        path,
                        defaultFileContent(
                                style
                        ),
                        StandardCharsets.UTF_8
                );

            } catch (IOException exception) {

                throw new IllegalStateException(
                        "Could not create Gyeokbu stance config: "
                                + path,
                        exception
                );
            }
        }
    }

    private static void ensureAllDefaultFilesExist() {

        for (ParryStyle style : ParryStyle.values()) {

            ensureDefaultFileExists(
                    style
            );
        }
    }

    private static void ensureDefaultFileExists(
            ParryStyle style
    ) {

        Path defaultPath =
                getDefaultConfigPath(
                        style
                );

        if (Files.exists(
                defaultPath
        )) {
            return;
        }

        Path currentPath =
                getConfigPath(
                        style
                );

        try {

            Files.createDirectories(
                    defaultPath.getParent()
            );

            if (Files.exists(
                    currentPath
            )) {

                Files.copy(
                        currentPath,
                        defaultPath
                );

            } else {

                Files.writeString(
                        defaultPath,
                        defaultFileContent(
                                style
                        ),
                        StandardCharsets.UTF_8
                );
            }

        } catch (IOException exception) {

            throw new IllegalStateException(
                    "Could not create Gyeokbu default stance config: "
                            + defaultPath,
                    exception
            );
        }
    }

    private static String defaultFileContent(
            ParryStyle style
    ) {

        if (style == ParryStyle.GLAIVE) {

            return """
                    {
                      "enabled": true,
                      "parry": {
                        "mainhand": [-1.28, 0.08, -1.18],
                        "offhand": [-0.92, -0.18, 0.78],
                        "weapon_rotation": [0.0, 0.0, 0.0]
                      },
                      "block": {
                        "mainhand": [-1.18, 0.12, -1.05],
                        "offhand": [-1.02, -0.20, 0.88],
                        "weapon_rotation": [0.0, 0.0, 0.0]
                      }
                    }
                    """;
        }

        if (style == ParryStyle.RAPIER) {

            return """
                    {
                      "enabled": true,
                      "parry": {
                        "mainhand": [-1.20, -0.10, 1.45],
                        "offhand": [-0.55, 0.35, -0.30],
                        "weapon_rotation": [0.0, 0.0, 0.0]
                      },
                      "block": {
                        "mainhand": [-1.05, -0.05, 1.25],
                        "offhand": [-0.70, 0.25, -0.15],
                        "weapon_rotation": [0.0, 0.0, 0.0]
                      }
                    }
                    """;
        }

        return """
                {
                  "enabled": false,
                  "parry": {
                    "mainhand": [0.0, 0.0, 0.0],
                    "offhand": [0.0, 0.0, 0.0],
                    "weapon_rotation": [0.0, 0.0, 0.0]
                  },
                  "block": {
                    "mainhand": [0.0, 0.0, 0.0],
                    "offhand": [0.0, 0.0, 0.0],
                    "weapon_rotation": [0.0, 0.0, 0.0]
                  }
                }
                """;
    }

    private static boolean defaultEnabled(
            ParryStyle style
    ) {

        return style == ParryStyle.GLAIVE
                || style == ParryStyle.RAPIER;
    }

    /*
     * ------------------------------------------------------------
     * JSON / POSE HELPERS
     * ------------------------------------------------------------
     */

    private static PoseSet getEditorStylePoseSet(
            ParryStyle style,
            boolean firstPerson
    ) {
        if (editorHandVariantActive && style != ParryStyle.GENERIC) {
            WeaponProfileKey key = new WeaponProfileKey(style, editorHandStyle);
            PoseSet variant = (firstPerson
                    ? handedFirstPersonPoses
                    : handedThirdPersonPoses).get(key);
            if (variant != null && variant.enabled()) {
                return copyPoseSet(variant);
            }
        }

        PoseSet base = firstPerson
                ? firstPersonPoses.get(style)
                : poses.get(style);
        return base == null ? null : copyPoseSet(base);
    }

    private static void replaceLoadedPoseForEditor(
            PoseSet pose,
            boolean firstPerson
    ) {
        if (editorHandVariantActive && editorStyle != ParryStyle.GENERIC) {
            WeaponProfileKey key = new WeaponProfileKey(editorStyle, editorHandStyle);
            if (firstPerson) {
                handedFirstPersonPoses.put(key, copyPoseSet(pose));
            } else {
                handedThirdPersonPoses.put(key, copyPoseSet(pose));
            }
            return;
        }

        if (firstPerson) {
            replaceLoadedFirstPersonPose(editorStyle, pose);
        } else {
            replaceLoadedPose(editorStyle, pose);
        }
    }

    private static Path getEditorConfigPath(boolean firstPerson) {
        if (editorHandVariantActive && editorStyle != ParryStyle.GENERIC) {
            return getHandedConfigPath(editorStyle, editorHandStyle, firstPerson, false);
        }
        return firstPerson
                ? getFirstPersonConfigPath(editorStyle)
                : getConfigPath(editorStyle);
    }

    private static Path getEditorDefaultConfigPath(boolean firstPerson) {
        if (editorHandVariantActive && editorStyle != ParryStyle.GENERIC) {
            return getHandedConfigPath(editorStyle, editorHandStyle, firstPerson, true);
        }
        return firstPerson
                ? getFirstPersonDefaultConfigPath(editorStyle)
                : getDefaultConfigPath(editorStyle);
    }

    private static Path getHandedConfigPath(
            ParryStyle style,
            HandStyle handStyle,
            boolean firstPerson,
            boolean defaultDirectory
    ) {
        String suffix = handStyle == HandStyle.TWO_HANDED
                ? "two_handed"
                : "one_handed";
        Path directory;
        if (defaultDirectory) {
            directory = firstPerson
                    ? getFirstPersonDefaultAnimationDirectory()
                    : getDefaultAnimationDirectory();
        } else {
            directory = firstPerson
                    ? getFirstPersonAnimationDirectory()
                    : getAnimationDirectory();
        }
        return directory.resolve(
                style.name().toLowerCase(Locale.ROOT)
                        + "_" + suffix + ".json"
        );
    }

    private static void loadHandedStyleVariants(boolean firstPerson) throws IOException {
        Path directory = firstPerson
                ? getFirstPersonAnimationDirectory()
                : getAnimationDirectory();
        Files.createDirectories(directory);

        Map<WeaponProfileKey, PoseSet> target = firstPerson
                ? handedFirstPersonPoses
                : handedThirdPersonPoses;
        for (ParryStyle style : ParryStyle.values()) {
            if (style == ParryStyle.GENERIC) {
                continue;
            }
            for (HandStyle hand : HandStyle.values()) {
                WeaponProfileKey key = new WeaponProfileKey(style, hand);
                Path path = getHandedConfigPath(style, hand, firstPerson, false);
                if (!Files.exists(path)) {
                    continue;
                }
                try {
                    PoseSet pose = readPoseSet(path, true);
                    if (pose.enabled()) {
                        target.put(key, pose);
                    }
                } catch (Exception exception) {
                    GyeokbuV2.LOGGER.error(
                            "Failed to load Gyeokbu handed stance variant {}.",
                            path,
                            exception
                    );
                }
            }
        }
    }

    private static Path getHandedLinkedConfigPath(
            ParryStyle style,
            HandStyle handStyle,
            boolean firstPerson
    ) {
        String suffix = handStyle == HandStyle.TWO_HANDED
                ? "two_handed"
                : "one_handed";
        return getLinkedStyleAnimationDirectory(firstPerson).resolve(
                style.name().toLowerCase(Locale.ROOT)
                        + "_" + suffix + ".json"
        );
    }

    private static void loadHandedLinkedStyleVariants(boolean firstPerson) throws IOException {
        Map<WeaponProfileKey, PoseSet> target = firstPerson
                ? handedLinkedFirstPersonPoses
                : handedLinkedThirdPersonPoses;
        Files.createDirectories(getLinkedStyleAnimationDirectory(firstPerson));
        for (ParryStyle style : ParryStyle.values()) {
            if (style == ParryStyle.GENERIC) {
                continue;
            }
            for (HandStyle hand : HandStyle.values()) {
                WeaponProfileKey key = new WeaponProfileKey(style, hand);
                Path path = getHandedLinkedConfigPath(style, hand, firstPerson);
                if (!Files.exists(path)) {
                    continue;
                }
                try {
                    PoseSet pose = readPoseSet(path, true);
                    if (pose.enabled()) {
                        target.put(key, pose);
                    }
                } catch (Exception exception) {
                    GyeokbuV2.LOGGER.error(
                            "Failed to load Gyeokbu linked handed stance variant {}.",
                            path,
                            exception
                    );
                }
            }
        }
    }

    private static Path getEditorLinkedStyleConfigPath(boolean firstPerson) {
        if (editorHandVariantActive && editorStyle != ParryStyle.GENERIC) {
            return getHandedLinkedConfigPath(editorStyle, editorHandStyle, firstPerson);
        }
        return getLinkedStyleConfigPath(editorStyle, firstPerson);
    }

    private static PoseSet getItemPoseSet(
            ItemStack stack
    ) {

        if (stack == null
                || stack.isEmpty()) {

            return null;
        }

        ResourceLocation itemId =
                BuiltInRegistries.ITEM
                        .getKey(
                                stack.getItem()
                        );

        ParryStyle naturalStyle =
                WeaponClassifier.classifyNatural(stack)
                        .parryStyle();

        if (!isRuntimeItemAssignmentActive(
                itemId,
                naturalStyle
        )) {
            return null;
        }

        PoseSet poseSet =
                itemPoses.get(
                        itemId
                );

        if (poseSet == null
                || !poseSet.enabled()) {

            return null;
        }

        return poseSet;
    }

    private static PoseSet getItemPoseSet(
            ItemStack stack,
            boolean userOnly
    ) {
        if (stack == null || stack.isEmpty()) {
            return null;
        }

        ResourceLocation itemId =
                BuiltInRegistries.ITEM.getKey(stack.getItem());

        if (userThirdPersonItems.contains(itemId) != userOnly) {
            return null;
        }

        return getItemPoseSet(stack);
    }

    private static PoseSet getStylePoseSet(
            ParryStyle style,
            boolean firstPerson,
            boolean userOnly
    ) {
        if (style == null) {
            return null;
        }

        Set<ParryStyle> userStyles = firstPerson
                ? userFirstPersonStyles
                : userThirdPersonStyles;

        if (userStyles.contains(style) != userOnly) {
            return null;
        }

        PoseSet poseSet = firstPerson
                ? firstPersonPoses.get(style)
                : poses.get(style);

        return poseSet != null && poseSet.enabled()
                ? poseSet
                : null;
    }


    private static PoseSet getStylePoseSet(
            ItemStack stack,
            ParryStyle style,
            boolean firstPerson,
            boolean userOnly
    ) {
        if (stack != null
                && !stack.isEmpty()
                && BetterCombatWeaponMetadata.isAvailable()
                && style != null
                && style != ParryStyle.GENERIC) {
            WeaponProfile profile = WeaponClassifier.classifyNatural(stack);
            BetterCombatWeaponMetadata.Metadata metadata = BetterCombatWeaponMetadata.get(stack);
            if (metadata.present()
                    && profile.isSupported()
                    && profile.parryStyle() == style) {
                WeaponProfileKey key = new WeaponProfileKey(style, profile.handStyle());
                PoseSet variant = (firstPerson
                        ? handedFirstPersonPoses
                        : handedThirdPersonPoses).get(key);
                if (variant != null && variant.enabled()) {
                    return variant;
                }
            }
        }

        return getStylePoseSet(style, firstPerson, userOnly);
    }

    private static Map<ResourceLocation, ParryStyle> loadItemStyleAssignments()
            throws IOException {

        Map<ResourceLocation, ParryStyle> loaded =
                new HashMap<>();

        Path path =
                getItemStyleAssignmentsPath();

        if (!Files.exists(path)) {
            return loaded;
        }

        JsonObject root =
                JsonParser.parseString(
                        Files.readString(
                                path,
                                StandardCharsets.UTF_8
                        )
                ).getAsJsonObject();

        for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
            try {
                ResourceLocation itemId =
                        ResourceLocation.parse(
                                entry.getKey()
                        );

                if (!BuiltInRegistries.ITEM.containsKey(itemId)) {
                    continue;
                }

                ParryStyle style =
                        ParryStyle.valueOf(
                                entry.getValue()
                                        .getAsString()
                                        .toUpperCase(
                                                Locale.ROOT
                                        )
                        );

                loaded.put(
                        itemId,
                        style
                );

            } catch (Exception exception) {
                GyeokbuV2.LOGGER.warn(
                        "Ignoring invalid Gyeokbu held stance assignment {} = {}.",
                        entry.getKey(),
                        entry.getValue()
                );
            }
        }

        return loaded;
    }

    private static void writeItemStyleAssignments()
            throws IOException {

        Path path =
                getItemStyleAssignmentsPath();

        Files.createDirectories(
                path.getParent()
        );

        StringBuilder json =
                new StringBuilder(
                        "{\n"
                );

        int index = 0;
        for (Map.Entry<ResourceLocation, ParryStyle> entry
                : itemAssignedStyles.entrySet()) {

            if (index > 0) {
                json.append(
                        ",\n"
                );
            }

            json.append(
                    "  \""
            );
            json.append(
                    entry.getKey()
            );
            json.append(
                    "\": \""
            );
            json.append(
                    entry.getValue().name()
            );
            json.append(
                    "\""
            );

            index++;
        }

        json.append(
                "\n}\n"
        );

        Files.writeString(
                path,
                json.toString(),
                StandardCharsets.UTF_8
        );
    }

    private static void synchronizeUserFallbacksFromAssignments() {
        WeaponClassifier.clearUserFallbacks();

        Map<ResourceLocation, ParryStyle> candidates = new HashMap<>(itemAssignedStyles);

        for (ResourceLocation itemId : candidates.keySet()) {
            if (!BuiltInRegistries.ITEM.containsKey(itemId)) {
                continue;
            }

            ItemStack probe =
                    new ItemStack(BuiltInRegistries.ITEM.get(itemId));

            if (WeaponClassifier.classifyNatural(probe).isSupported()) {
                continue;
            }

            ParryStyle natural = ParryStyle.GENERIC;
            ParryStyle normalStyle =
                    getAssignedItemStyle(itemId, natural);
            boolean hasPose = itemPoses.containsKey(itemId)
                    || firstPersonItemPoses.containsKey(itemId);

            if (!hasPose) {
                continue;
            }

            WeaponClassifier.setUserFallback(itemId, normalStyle);
        }
    }

    /** Refreshes client-side fallback classification after legacy linked-workspace mode changes. */
    public static void refreshUserFallbacksForCurrentWorkspace() {
        synchronizeUserFallbacksFromAssignments();
    }

    private static Map<ResourceLocation, PoseSet> loadItemOverrides()
            throws IOException {

        Map<ResourceLocation, PoseSet> loaded =
                new HashMap<>();

        Path root =
                getItemAnimationDirectory();

        if (!Files.exists(
                root
        )) {

            Files.createDirectories(
                    root
            );

            return loaded;
        }

        try (var paths = Files.walk(
                root
        )) {

            paths.filter(
                            Files::isRegularFile
                    )
                    .filter(
                            path ->
                                    path.getFileName()
                                            .toString()
                                            .endsWith(
                                                    ".json"
                                            )
                    )
                    .forEach(
                            path -> {

                                try {

                                    Path relative =
                                            root.relativize(
                                                    path
                                            );

                                    if (relative.getNameCount() < 2) {
                                        return;
                                    }

                                    String namespace =
                                            relative
                                                    .getName(0)
                                                    .toString();

                                    StringBuilder itemPath =
                                            new StringBuilder();

                                    for (int i = 1;
                                         i < relative.getNameCount();
                                         i++) {

                                        if (itemPath.length() > 0) {
                                            itemPath.append('/');
                                        }

                                        itemPath.append(
                                                relative
                                                        .getName(i)
                                                        .toString()
                                        );
                                    }

                                    String itemPathString =
                                            itemPath.toString();

                                    itemPathString =
                                            itemPathString.substring(
                                                    0,
                                                    itemPathString.length()
                                                            - ".json".length()
                                            );

                                    ResourceLocation itemId =
                                            ResourceLocation
                                                    .fromNamespaceAndPath(
                                                            namespace,
                                                            itemPathString
                                                    );

                                    if (!BuiltInRegistries.ITEM
                                            .containsKey(
                                                    itemId
                                            )) {

                                        GyeokbuV2.LOGGER.warn(
                                                "Ignoring Gyeokbu item stance for missing item {} at {}",
                                                itemId,
                                                path
                                        );

                                        return;
                                    }

                                    PoseSet pose =
                                            readPoseSet(
                                                    path,
                                                    true
                                            );

                                    if (pose.enabled()) {

                                        loaded.put(
                                                itemId,
                                                pose
                                        );
                                    }

                                } catch (Exception exception) {

                                    GyeokbuV2.LOGGER.error(
                                            "Failed to load Gyeokbu exact-item stance from {}",
                                            path,
                                            exception
                                    );
                                }
                            }
                    );
        }

        return loaded;
    }

    private static PoseSet getRuntimeThirdPersonPoseSet(
            ItemStack stack,
            ParryStyle style
    ) {
        if (shouldUseLinkedRuntime(stack, style)) {
            PoseSet linked =
                    getLinkedRuntimePoseSet(
                            stack,
                            style,
                            false
                    );
            if (linked != null) {
                return linked;
            }
        }

        // User exact item -> user category -> shipped exact item -> shipped category.
        PoseSet poseSet = getItemPoseSet(stack, true);
        if (poseSet != null) {
            return poseSet;
        }

        poseSet = getStylePoseSet(stack, style, false, true);
        if (poseSet != null) {
            return poseSet;
        }

        poseSet = getItemPoseSet(stack, false);
        if (poseSet != null) {
            return poseSet;
        }

        poseSet = getStylePoseSet(stack, style, false, false);
        if (poseSet != null) {
            return poseSet;
        }

        return getGenericRuntimeFallbackPoseSet(
                stack,
                style,
                false
        );
    }

    private static PoseSet getFirstPersonPoseSet(
            ItemStack stack,
            ParryStyle style
    ) {
        if (shouldUseLinkedRuntime(stack, style)) {
            PoseSet linked =
                    getLinkedRuntimePoseSet(
                            stack,
                            style,
                            true
                    );
            if (linked != null) {
                return linked;
            }
        }

        // STRICT VIEW SEPARATION with the same user-before-shipped hierarchy.
        if (stack != null && !stack.isEmpty()) {
            ResourceLocation itemId =
                    BuiltInRegistries.ITEM.getKey(stack.getItem());
            ParryStyle naturalStyle =
                    WeaponClassifier.classifyNatural(stack).parryStyle();

            if (isRuntimeItemAssignmentActive(itemId, naturalStyle)) {
                PoseSet itemPose = firstPersonItemPoses.get(itemId);
                if (userFirstPersonItems.contains(itemId)
                        && itemPose != null
                        && itemPose.enabled()) {
                    return itemPose;
                }
            }
        }

        PoseSet stylePose = getStylePoseSet(stack, style, true, true);
        if (stylePose != null) {
            return stylePose;
        }

        if (stack != null && !stack.isEmpty()) {
            ResourceLocation itemId =
                    BuiltInRegistries.ITEM.getKey(stack.getItem());
            ParryStyle naturalStyle =
                    WeaponClassifier.classifyNatural(stack).parryStyle();

            if (isRuntimeItemAssignmentActive(itemId, naturalStyle)) {
                PoseSet itemPose = firstPersonItemPoses.get(itemId);
                if (!userFirstPersonItems.contains(itemId)
                        && itemPose != null
                        && itemPose.enabled()) {
                    return itemPose;
                }
            }
        }

        PoseSet shippedStyle = getStylePoseSet(stack, style, true, false);
        if (shippedStyle != null) {
            return shippedStyle;
        }

        return getGenericRuntimeFallbackPoseSet(
                stack,
                style,
                true
        );
    }

    /**
     * A mechanically recognized GENERIC weapon must still have a visible
     * Gyeokbu stance. Existing exact-item/category GENERIC files keep priority;
     * this is only the final emergency visual fallback when GENERIC itself is
     * missing or disabled.
     *
     * One-handed unknowns borrow Sword, two-handed unknowns borrow Greatsword.
     */
    private static PoseSet getGenericRuntimeFallbackPoseSet(
            ItemStack stack,
            ParryStyle style,
            boolean firstPerson
    ) {
        if (style != ParryStyle.GENERIC
                || stack == null
                || stack.isEmpty()) {
            return null;
        }

        WeaponProfile profile = WeaponClassifier.classify(stack);
        ParryStyle fallbackStyle = profile.isTwoHanded()
                ? ParryStyle.GREATSWORD
                : ParryStyle.SWORD;

        PoseSet pose = getStylePoseSet(
                fallbackStyle,
                firstPerson,
                true
        );
        if (pose == null) {
            pose = getStylePoseSet(
                    fallbackStyle,
                    firstPerson,
                    false
            );
        }
        if (pose != null) {
            return pose;
        }

        /*
         * Some authored categories intentionally have no dedicated first-person
         * file. Sword is the final visible fallback rather than returning null.
         */
        if (fallbackStyle != ParryStyle.SWORD) {
            pose = getStylePoseSet(
                    ParryStyle.SWORD,
                    firstPerson,
                    true
            );
            if (pose == null) {
                pose = getStylePoseSet(
                        ParryStyle.SWORD,
                        firstPerson,
                        false
                );
            }
        }

        return pose;
    }

    private static boolean shouldUseLinkedRuntime(
            ItemStack stack,
            ParryStyle runtimeStyle
    ) {
        return false;
    }


    private static PoseSet getLinkedRuntimePoseSet(
            ItemStack stack,
            ParryStyle naturalOrRuntimeStyle,
            boolean firstPerson
    ) {
        ResourceLocation itemId = null;
        ParryStyle activeLinkedStyle = naturalOrRuntimeStyle;
        boolean itemAssignmentActive = false;

        if (stack != null && !stack.isEmpty()) {
            itemId = BuiltInRegistries.ITEM.getKey(stack.getItem());
            ParryStyle naturalStyle =
                    WeaponClassifier.classifyNatural(stack).parryStyle();
            ParryStyle normalStyle =
                    getAssignedItemStyle(itemId, naturalStyle);
            ParryStyle linkedStyle =
                    getLinkedAssignedItemStyle(itemId, normalStyle);

            activeLinkedStyle = isLinkedViewsEnabledForStyle(linkedStyle)
                    ? linkedStyle
                    : normalStyle;
            itemAssignmentActive =
                    isLinkedRuntimeItemAssignmentActive(itemId, naturalStyle);
        }

        Set<ResourceLocation> userItems = firstPerson
                ? userLinkedFirstPersonItems
                : userLinkedThirdPersonItems;
        Set<ParryStyle> userStyles = firstPerson
                ? userLinkedFirstPersonStyles
                : userLinkedThirdPersonStyles;
        Map<ResourceLocation, PoseSet> itemMap = firstPerson
                ? linkedFirstPersonItemPoses
                : linkedThirdPersonItemPoses;
        Map<ParryStyle, PoseSet> styleMap = firstPerson
                ? linkedFirstPersonPoses
                : linkedThirdPersonPoses;

        // User exact item.
        if (itemId != null && itemAssignmentActive && userItems.contains(itemId)) {
            PoseSet pose = itemMap.get(itemId);
            if (pose != null && pose.enabled()) {
                return pose;
            }
        }

        // User category, with a separate Better Combat handedness variant when available.
        if (stack != null && !stack.isEmpty()
                && BetterCombatWeaponMetadata.isAvailable()
                && activeLinkedStyle != null
                && activeLinkedStyle != ParryStyle.GENERIC) {
            WeaponProfile natural = WeaponClassifier.classifyNatural(stack);
            BetterCombatWeaponMetadata.Metadata metadata = BetterCombatWeaponMetadata.get(stack);
            if (metadata.present() && natural.isSupported()
                    && natural.parryStyle() == activeLinkedStyle) {
                WeaponProfileKey key = new WeaponProfileKey(activeLinkedStyle, natural.handStyle());
                PoseSet handedPose = (firstPerson
                        ? handedLinkedFirstPersonPoses
                        : handedLinkedThirdPersonPoses).get(key);
                if (handedPose != null && handedPose.enabled()) {
                    return handedPose;
                }
            }
        }

        if (activeLinkedStyle != null && userStyles.contains(activeLinkedStyle)) {
            PoseSet pose = styleMap.get(activeLinkedStyle);
            if (pose != null && pose.enabled()) {
                return pose;
            }
        }

        // Shipped exact item.
        if (itemId != null && itemAssignmentActive && !userItems.contains(itemId)) {
            PoseSet pose = itemMap.get(itemId);
            if (pose != null && pose.enabled()) {
                return pose;
            }
        }

        // Shipped category for the resolved linked style.
        if (activeLinkedStyle != null && !userStyles.contains(activeLinkedStyle)) {
            PoseSet pose = styleMap.get(activeLinkedStyle);
            if (pose != null && pose.enabled()) {
                return pose;
            }
        }

        // Last linked-style fallback for callers that supplied a different runtime style.
        if (naturalOrRuntimeStyle != null
                && naturalOrRuntimeStyle != activeLinkedStyle) {
            PoseSet pose = styleMap.get(naturalOrRuntimeStyle);
            if (pose != null && pose.enabled()) {
                return pose;
            }
        }

        return null;
    }

    private static void prepareLinkedEditorWorkspace(
            ParryStyle style,
            ResourceLocation itemId,
            boolean sourceFirstPerson
    ) {
        PoseSet savedThird =
                getLinkedEditorSavedPose(
                        style,
                        itemId,
                        false
                );
        PoseSet savedFirst =
                getLinkedEditorSavedPose(
                        style,
                        itemId,
                        true
                );

        PoseSet normalThird =
                getNormalEditorBasePose(
                        style,
                        itemId,
                        false
                );
        PoseSet normalFirst =
                getNormalEditorBasePose(
                        style,
                        itemId,
                        true
                );

        if (normalThird == null) {
            normalThird = disabledNeutral();
        }
        if (normalFirst == null) {
            normalFirst = disabledNeutral();
        }

        boolean hasSaved =
                savedThird != null
                        || savedFirst != null;

        PoseSet third = savedThird == null
                ? copyPoseSet(normalThird)
                : copyPoseSet(savedThird);
        PoseSet first = savedFirst == null
                ? copyPoseSet(normalFirst)
                : copyPoseSet(savedFirst);

        PoseSet armSource;
        if (!hasSaved) {
            /*
             * First-ever Linked workspace: choice A from the design pass.
             * Shared arms start from whichever normal view the player is
             * currently editing, while each view keeps its own existing weapon
             * transform as the initial correction.
             */
            armSource = sourceFirstPerson
                    ? normalFirst
                    : normalThird;
        } else if (sourceFirstPerson && savedFirst != null) {
            armSource = savedFirst;
        } else if (!sourceFirstPerson && savedThird != null) {
            armSource = savedThird;
        } else {
            armSource = savedThird != null
                    ? savedThird
                    : savedFirst;
        }

        third = copyArmsIntoPoseSet(third, armSource);
        first = copyArmsIntoPoseSet(first, armSource);

        editorLinkedThirdPersonOriginal =
                copyPoseSet(third);
        editorLinkedThirdPersonWorking =
                copyPoseSet(third);
        editorLinkedFirstPersonOriginal =
                copyPoseSet(first);
        editorLinkedFirstPersonWorking =
                copyPoseSet(first);
    }

    private static PoseSet getNormalEditorBasePose(
            ParryStyle style,
            ResourceLocation itemId,
            boolean firstPerson
    ) {
        /* Preserve unsaved normal edits when Linked Views is entered. */
        if (style == editorNormalStyle) {
            PoseSet current = firstPerson
                    ? editorFirstPersonWorking
                    : editorWorking;
            if (current != null) {
                return copyPoseSet(current);
            }
        }

        if (itemId != null) {
            ParryStyle naturalStyle =
                    getNaturalStyleForItemId(itemId);
            ParryStyle assigned =
                    getAssignedItemStyle(
                            itemId,
                            naturalStyle
                    );

            if (assigned == style) {
                PoseSet itemPose = firstPerson
                        ? firstPersonItemPoses.get(itemId)
                        : itemPoses.get(itemId);
                if (itemPose != null && itemPose.enabled()) {
                    return copyPoseSet(itemPose);
                }
            }
        }

        PoseSet stylePose;
        if (editorHandVariantActive && style != ParryStyle.GENERIC) {
            WeaponProfileKey key = new WeaponProfileKey(style, editorHandStyle);
            stylePose = firstPerson
                    ? handedFirstPersonPoses.get(key)
                    : handedThirdPersonPoses.get(key);
            if (stylePose != null) {
                return copyPoseSet(stylePose);
            }
        }

        stylePose = firstPerson
                ? firstPersonPoses.get(style)
                : poses.get(style);

        return stylePose == null
                ? disabledNeutral()
                : copyPoseSet(stylePose);
    }

    private static PoseSet getLinkedEditorSavedPose(
            ParryStyle style,
            ResourceLocation itemId,
            boolean firstPerson
    ) {
        if (itemId != null
                && isLinkedEditorItemAssignmentActive(itemId, style)) {
            PoseSet itemPose = firstPerson
                    ? linkedFirstPersonItemPoses.get(itemId)
                    : linkedThirdPersonItemPoses.get(itemId);
            if (itemPose != null && itemPose.enabled()) {
                return copyPoseSet(itemPose);
            }
        }

        if (editorHandVariantActive && style != ParryStyle.GENERIC) {
            WeaponProfileKey key = new WeaponProfileKey(style, editorHandStyle);
            PoseSet variant = firstPerson
                    ? handedLinkedFirstPersonPoses.get(key)
                    : handedLinkedThirdPersonPoses.get(key);
            if (variant != null && variant.enabled()) {
                return copyPoseSet(variant);
            }
        }

        PoseSet stylePose = firstPerson
                ? linkedFirstPersonPoses.get(style)
                : linkedThirdPersonPoses.get(style);

        return stylePose != null && stylePose.enabled()
                ? copyPoseSet(stylePose)
                : null;
    }

    private static PoseSet copyArmsIntoPoseSet(
            PoseSet target,
            PoseSet armSource
    ) {
        PoseSet safeTarget = target == null
                ? disabledNeutral()
                : target;
        PoseSet safeSource = armSource == null
                ? disabledNeutral()
                : armSource;

        return new PoseSet(
                true,
                copyVec(safeSource.parryMainHand()),
                copyVec(safeSource.parryOffHand()),
                copyVec(safeTarget.parryWeaponPosition()),
                copyVec(safeTarget.parryWeaponRotation()),
                copyVec(safeSource.blockMainHand()),
                copyVec(safeSource.blockOffHand()),
                copyVec(safeTarget.blockWeaponPosition()),
                copyVec(safeTarget.blockWeaponRotation())
        );
    }

    private static ParryStyle getNaturalStyleForItemId(
            ResourceLocation itemId
    ) {
        if (itemId == null
                || !BuiltInRegistries.ITEM.containsKey(itemId)) {
            return ParryStyle.GENERIC;
        }

        ItemStack probe =
                new ItemStack(
                        BuiltInRegistries.ITEM.get(itemId)
                );

        return WeaponClassifier.classifyNatural(probe)
                .parryStyle();
    }

    private static PoseSet getActiveEditorPoseSet() {
        if (editorViewsLinked) {
            return editorFirstPerson
                    ? editorLinkedFirstPersonWorking
                    : editorLinkedThirdPersonWorking;
        }

        return editorFirstPerson
                ? editorFirstPersonWorking
                : editorWorking;
    }

    private static void setActiveEditorPoseSet(
            PoseSet poseSet
    ) {
        if (editorViewsLinked) {
            if (editorFirstPerson) {
                editorLinkedFirstPersonWorking = poseSet;
            } else {
                editorLinkedThirdPersonWorking = poseSet;
            }
            return;
        }

        if (editorFirstPerson) {
            editorFirstPersonWorking = poseSet;
        } else {
            editorWorking = poseSet;
        }
    }

    private static void mirrorActiveEditorModeArmsToOtherView(
            PoseSet source
    ) {
        if (!isEditorActive()
                || source == null
                || !editorViewsLinked) {
            return;
        }

        ArmPose sourceArms =
                getArmPoseFromSet(
                        source,
                        editorMode
                );

        if (sourceArms == null) {
            return;
        }

        if (editorFirstPerson) {
            editorLinkedThirdPersonWorking =
                    replaceArmMode(
                            editorLinkedThirdPersonWorking,
                            editorMode,
                            copyVec(sourceArms.mainHand()),
                            copyVec(sourceArms.offHand())
                    );
        } else {
            editorLinkedFirstPersonWorking =
                    replaceArmMode(
                            editorLinkedFirstPersonWorking,
                            editorMode,
                            copyVec(sourceArms.mainHand()),
                            copyVec(sourceArms.offHand())
                    );
        }
    }

    private static void mirrorAllEditorArmsToOtherView(
            PoseSet source
    ) {
        if (!isEditorActive()
                || source == null
                || !editorViewsLinked) {
            return;
        }

        PoseSet target = editorFirstPerson
                ? editorLinkedThirdPersonWorking
                : editorLinkedFirstPersonWorking;

        if (target == null) {
            return;
        }

        PoseSet mirrored =
                new PoseSet(
                        true,
                        copyVec(source.parryMainHand()),
                        copyVec(source.parryOffHand()),
                        copyVec(target.parryWeaponPosition()),
                        copyVec(target.parryWeaponRotation()),
                        copyVec(source.blockMainHand()),
                        copyVec(source.blockOffHand()),
                        copyVec(target.blockWeaponPosition()),
                        copyVec(target.blockWeaponRotation())
                );

        if (editorFirstPerson) {
            editorLinkedThirdPersonWorking = mirrored;
        } else {
            editorLinkedFirstPersonWorking = mirrored;
        }
    }

    private static Map<ParryStyle, PoseSet> loadLinkedStylePoses(
            boolean firstPerson
    ) throws IOException {
        EnumMap<ParryStyle, PoseSet> loaded =
                new EnumMap<>(ParryStyle.class);

        Path root =
                getLinkedStyleAnimationDirectory(firstPerson);
        Files.createDirectories(root);

        for (ParryStyle style : ParryStyle.values()) {
            Path path =
                    getLinkedStyleConfigPath(style, firstPerson);
            if (!Files.exists(path)) {
                continue;
            }

            PoseSet pose =
                    readPoseSet(path, true);
            if (pose.enabled()) {
                loaded.put(style, pose);
            }
        }

        return loaded;
    }

    private static Map<ResourceLocation, PoseSet> loadLinkedItemOverrides(
            boolean firstPerson
    ) throws IOException {
        Map<ResourceLocation, PoseSet> loaded =
                new HashMap<>();

        Path root =
                getLinkedItemAnimationDirectory(firstPerson);
        Files.createDirectories(root);

        try (var paths = Files.walk(root)) {
            paths.filter(Files::isRegularFile)
                    .filter(path -> path.getFileName()
                            .toString()
                            .endsWith(".json"))
                    .forEach(path -> {
                        try {
                            Path relative = root.relativize(path);
                            if (relative.getNameCount() < 2) {
                                return;
                            }

                            String namespace =
                                    relative.getName(0).toString();
                            StringBuilder itemPath =
                                    new StringBuilder();

                            for (int i = 1; i < relative.getNameCount(); i++) {
                                if (itemPath.length() > 0) {
                                    itemPath.append('/');
                                }
                                itemPath.append(relative.getName(i));
                            }

                            String itemPathString =
                                    itemPath.toString();
                            itemPathString =
                                    itemPathString.substring(
                                            0,
                                            itemPathString.length() - ".json".length()
                                    );

                            ResourceLocation itemId =
                                    ResourceLocation.fromNamespaceAndPath(
                                            namespace,
                                            itemPathString
                                    );

                            if (!BuiltInRegistries.ITEM.containsKey(itemId)) {
                                GyeokbuV2.LOGGER.warn(
                                        "Ignoring linked Gyeokbu item stance for missing item {} at {}",
                                        itemId,
                                        path
                                );
                                return;
                            }

                            PoseSet pose =
                                    readPoseSet(path, true);
                            if (pose.enabled()) {
                                loaded.put(itemId, pose);
                            }
                        } catch (Exception exception) {
                            GyeokbuV2.LOGGER.error(
                                    "Failed to load linked Gyeokbu exact-item stance from {}",
                                    path,
                                    exception
                            );
                        }
                    });
        }

        return loaded;
    }

    private static Map<ResourceLocation, ParryStyle> loadLinkedItemStyleAssignments()
            throws IOException {
        Map<ResourceLocation, ParryStyle> loaded =
                new HashMap<>();

        Path path =
                getLinkedItemStyleAssignmentsPath();
        if (!Files.exists(path)) {
            return loaded;
        }

        JsonObject root =
                JsonParser.parseString(
                        Files.readString(path, StandardCharsets.UTF_8)
                ).getAsJsonObject();

        for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
            try {
                ResourceLocation itemId =
                        ResourceLocation.parse(entry.getKey());
                if (!BuiltInRegistries.ITEM.containsKey(itemId)) {
                    continue;
                }

                ParryStyle style =
                        ParryStyle.valueOf(
                                entry.getValue()
                                        .getAsString()
                                        .toUpperCase(Locale.ROOT)
                        );
                loaded.put(itemId, style);
            } catch (Exception exception) {
                GyeokbuV2.LOGGER.warn(
                        "Ignoring invalid linked Gyeokbu held stance assignment {} = {}.",
                        entry.getKey(),
                        entry.getValue()
                );
            }
        }

        return loaded;
    }

    private static Map<ParryStyle, Boolean> readLinkedViewStates() {
        Map<ParryStyle, Boolean> loaded =
                new EnumMap<>(ParryStyle.class);
        Path path = getLinkedSettingsPath();
        if (!Files.exists(path)) {
            return loaded;
        }

        try {
            JsonObject root =
                    JsonParser.parseString(
                            Files.readString(path, StandardCharsets.UTF_8)
                    ).getAsJsonObject();

            JsonObject states = root.has("states")
                    && root.get("states").isJsonObject()
                    ? root.getAsJsonObject("states")
                    : null;

            if (states == null) {
                return loaded;
            }

            for (Map.Entry<String, JsonElement> entry : states.entrySet()) {
                try {
                    ParryStyle style =
                            ParryStyle.valueOf(entry.getKey().toUpperCase(Locale.ROOT));
                    loaded.put(style, entry.getValue().getAsBoolean());
                } catch (Exception ignored) {
                    /* Ignore stale/invalid stance names. */
                }
            }
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.warn(
                    "Could not read per-stance Linked Views settings; using OFF.",
                    exception
            );
        }

        return loaded;
    }

    private static boolean readLegacyLinkedViewsEnabled() {
        Path path = getLinkedSettingsPath();
        if (!Files.exists(path)) {
            return false;
        }

        try {
            JsonObject root =
                    JsonParser.parseString(
                            Files.readString(path, StandardCharsets.UTF_8)
                    ).getAsJsonObject();
            return !root.has("states")
                    && readOptionalBoolean(root, "enabled", false);
        } catch (Exception ignored) {
            return false;
        }
    }

    private static void writeLinkedViewStatesQuietly() {
        try {
            Path path = getLinkedSettingsPath();
            Files.createDirectories(path.getParent());

            StringBuilder json = new StringBuilder();
            json.append("{\n  \"states\": {\n");

            int index = 0;
            for (ParryStyle style : ParryStyle.values()) {
                if (!linkedViewStates.containsKey(style)) {
                    continue;
                }

                if (index > 0) {
                    json.append(",\n");
                }

                json.append("    \"")
                        .append(style.name())
                        .append("\": ")
                        .append(Boolean.TRUE.equals(linkedViewStates.get(style)));
                index++;
            }

            json.append("\n  }\n}\n");

            Files.writeString(
                    path,
                    json.toString(),
                    StandardCharsets.UTF_8
            );
        } catch (Exception exception) {
            GyeokbuV2.LOGGER.error(
                    "Failed to save per-stance Linked Views settings.",
                    exception
            );
        }
    }

    private static void writeLinkedItemStyleAssignments()
            throws IOException {
        Path path = getLinkedItemStyleAssignmentsPath();
        Files.createDirectories(path.getParent());

        StringBuilder json = new StringBuilder("{\n");
        int index = 0;
        for (Map.Entry<ResourceLocation, ParryStyle> entry
                : linkedItemAssignedStyles.entrySet()) {
            if (index > 0) {
                json.append(",\n");
            }
            json.append("  \"")
                    .append(entry.getKey())
                    .append("\": \"")
                    .append(entry.getValue().name())
                    .append("\"");
            index++;
        }
        json.append("\n}\n");

        Files.writeString(
                path,
                json.toString(),
                StandardCharsets.UTF_8
        );
    }

    private static void replaceLinkedStylePose(
            ParryStyle style,
            PoseSet pose,
            boolean firstPerson
    ) {
        EnumMap<ParryStyle, PoseSet> updated =
                new EnumMap<>(ParryStyle.class);
        updated.putAll(
                firstPerson
                        ? linkedFirstPersonPoses
                        : linkedThirdPersonPoses
        );
        updated.put(style, copyPoseSet(pose));

        if (firstPerson) {
            linkedFirstPersonPoses = updated;
        } else {
            linkedThirdPersonPoses = updated;
        }

        if (editorHandVariantActive && style != ParryStyle.GENERIC) {
            WeaponProfileKey key = new WeaponProfileKey(style, editorHandStyle);
            Map<WeaponProfileKey, PoseSet> handedMap = firstPerson
                    ? handedLinkedFirstPersonPoses
                    : handedLinkedThirdPersonPoses;
            handedMap.put(key, copyPoseSet(pose));
        }

        markUserStyleOverride(style, firstPerson, true);
    }

    private static Map<ParryStyle, PoseSet> loadFirstPersonStylePoses(
            Map<ParryStyle, PoseSet> thirdPersonLoaded
    ) throws IOException {

        EnumMap<ParryStyle, PoseSet> loaded =
                new EnumMap<>(
                        ParryStyle.class
                );

        Files.createDirectories(
                getFirstPersonAnimationDirectory()
        );

        Files.createDirectories(
                getFirstPersonDefaultAnimationDirectory()
        );

        for (ParryStyle style : ParryStyle.values()) {

            Path path =
                    getFirstPersonConfigPath(
                            style
                    );

            PoseSet pose;

            if (Files.exists(
                    path
            )) {

                pose =
                        readPoseSet(
                                path,
                                defaultEnabled(
                                        style
                                )
                        );

            } else {

                /*
                 * Strict independence:
                 * missing first-person data starts neutral.
                 *
                 * The ONLY way to bring 3P values into 1P is the explicit
                 * "Copy 3P -> 1P" editor button.
                 */
                pose =
                        disabledNeutral();
            }

            loaded.put(
                    style,
                    pose
            );
        }

        return loaded;
    }

    private static Map<ResourceLocation, PoseSet> loadFirstPersonItemOverrides()
            throws IOException {

        Map<ResourceLocation, PoseSet> loaded =
                new HashMap<>();

        Path root =
                getFirstPersonItemAnimationDirectory();

        Files.createDirectories(
                root
        );

        try (var paths = Files.walk(
                root
        )) {

            paths.filter(
                            Files::isRegularFile
                    )
                    .filter(
                            path ->
                                    path.getFileName()
                                            .toString()
                                            .endsWith(
                                                    ".json"
                                            )
                    )
                    .forEach(
                            path -> {

                                try {

                                    Path relative =
                                            root.relativize(
                                                    path
                                            );

                                    if (relative.getNameCount() < 2) {
                                        return;
                                    }

                                    String namespace =
                                            relative
                                                    .getName(0)
                                                    .toString();

                                    StringBuilder itemPath =
                                            new StringBuilder();

                                    for (int i = 1;
                                         i < relative.getNameCount();
                                         i++) {

                                        if (itemPath.length() > 0) {
                                            itemPath.append('/');
                                        }

                                        itemPath.append(
                                                relative
                                                        .getName(i)
                                                        .toString()
                                        );
                                    }

                                    String itemPathString =
                                            itemPath.toString();

                                    itemPathString =
                                            itemPathString.substring(
                                                    0,
                                                    itemPathString.length()
                                                            - ".json".length()
                                            );

                                    ResourceLocation itemId =
                                            ResourceLocation
                                                    .fromNamespaceAndPath(
                                                            namespace,
                                                            itemPathString
                                                    );

                                    PoseSet pose =
                                            readPoseSet(
                                                    path,
                                                    true
                                            );

                                    if (pose.enabled()) {

                                        loaded.put(
                                                itemId,
                                                pose
                                        );
                                    }

                                } catch (Exception exception) {

                                    GyeokbuV2.LOGGER.error(
                                            "Failed to load Gyeokbu first-person exact-item stance from {}",
                                            path,
                                            exception
                                    );
                                }
                            }
                    );
        }

        return loaded;
    }

    private static void replaceLoadedFirstPersonPose(
            ParryStyle style,
            PoseSet pose
    ) {

        EnumMap<ParryStyle, PoseSet> updated =
                new EnumMap<>(
                        ParryStyle.class
                );

        updated.putAll(
                firstPersonPoses
        );

        updated.put(
                style,
                copyPoseSet(
                        pose
                )
        );

        firstPersonPoses =
                updated;
        markUserStyleOverride(style, true, false);
    }

    private static PoseSet getEnabledPoseSet(
            ParryStyle style
    ) {

        if (style == null) {
            return null;
        }

        PoseSet poseSet =
                poses.get(
                        style
                );

        if (poseSet == null
                || !poseSet.enabled()) {

            return null;
        }

        return poseSet;
    }

    /**
     * Backward-compatible reader:
     *
     * Older files used right_arm / left_arm and had no
     * weapon_rotation. They continue to load automatically.
     *
     * The next Save rewrites them using the new
     * mainhand / offhand naming.
     */
    private static PoseSet readPoseSet(
            Path path,
            boolean fallbackEnabled
    ) throws IOException {

        String text =
                Files.readString(
                        path,
                        StandardCharsets.UTF_8
                );

        return readPoseSetText(
                text,
                fallbackEnabled
        );
    }

    private static PoseSet readBundledPoseSet(
            String relativePath,
            boolean fallbackEnabled
    ) throws IOException {

        return readPoseSetText(
                BundledStanceDefaults.readText(relativePath),
                fallbackEnabled
        );
    }

    private static PoseSet readPoseSetText(
            String text,
            boolean fallbackEnabled
    ) {

        JsonObject root =
                JsonParser
                        .parseString(
                                text
                        )
                        .getAsJsonObject();

        boolean enabled =
                readOptionalBoolean(
                        root,
                        "enabled",
                        fallbackEnabled
                );

        JsonObject parry =
                requireObject(
                        root,
                        "parry"
                );

        JsonObject block =
                requireObject(
                        root,
                        "block"
                );

        return new PoseSet(
                enabled,
                readVec3Either(
                        parry,
                        "mainhand",
                        "right_arm"
                ),
                readVec3Either(
                        parry,
                        "offhand",
                        "left_arm"
                ),
                readOptionalVec3(
                        parry,
                        "weapon_position"
                ),
                readOptionalVec3(
                        parry,
                        "weapon_rotation"
                ),
                readVec3Either(
                        block,
                        "mainhand",
                        "right_arm"
                ),
                readVec3Either(
                        block,
                        "offhand",
                        "left_arm"
                ),
                readOptionalVec3(
                        block,
                        "weapon_position"
                ),
                readOptionalVec3(
                        block,
                        "weapon_rotation"
                )
        );
    }

    private static void writePoseSet(
            Path path,
            PoseSet pose
    ) throws IOException {

        Files.createDirectories(
                path.getParent()
        );

        Files.writeString(
                path,
                toJson(
                        pose
                ),
                StandardCharsets.UTF_8
        );
    }

    private static void replaceLoadedPose(
            ParryStyle style,
            PoseSet pose
    ) {

        EnumMap<ParryStyle, PoseSet> updated =
                new EnumMap<>(
                        ParryStyle.class
                );

        updated.putAll(
                poses
        );

        updated.put(
                style,
                copyPoseSet(
                        pose
                )
        );

        poses =
                updated;
        markUserStyleOverride(style, false, false);
    }

    private static PoseSet enabledCopy(
            PoseSet source
    ) {

        return new PoseSet(
                true,
                copyVec(source.parryMainHand()),
                copyVec(source.parryOffHand()),
                copyVec(source.parryWeaponPosition()),
                copyVec(source.parryWeaponRotation()),
                copyVec(source.blockMainHand()),
                copyVec(source.blockOffHand()),
                copyVec(source.blockWeaponPosition()),
                copyVec(source.blockWeaponRotation())
        );
    }

    private static String toJson(
            PoseSet pose
    ) {

        return """
                {
                  "enabled": %s,
                  "parry": {
                    "mainhand": [%s, %s, %s],
                    "offhand": [%s, %s, %s],
                    "weapon_position": [%s, %s, %s],
                    "weapon_rotation": [%s, %s, %s]
                  },
                  "block": {
                    "mainhand": [%s, %s, %s],
                    "offhand": [%s, %s, %s],
                    "weapon_position": [%s, %s, %s],
                    "weapon_rotation": [%s, %s, %s]
                  }
                }
                """.formatted(
                pose.enabled(),
                number(pose.parryMainHand().getX()),
                number(pose.parryMainHand().getY()),
                number(pose.parryMainHand().getZ()),
                number(pose.parryOffHand().getX()),
                number(pose.parryOffHand().getY()),
                number(pose.parryOffHand().getZ()),
                number(pose.parryWeaponPosition().getX()),
                number(pose.parryWeaponPosition().getY()),
                number(pose.parryWeaponPosition().getZ()),
                number(pose.parryWeaponRotation().getX()),
                number(pose.parryWeaponRotation().getY()),
                number(pose.parryWeaponRotation().getZ()),
                number(pose.blockMainHand().getX()),
                number(pose.blockMainHand().getY()),
                number(pose.blockMainHand().getZ()),
                number(pose.blockOffHand().getX()),
                number(pose.blockOffHand().getY()),
                number(pose.blockOffHand().getZ()),
                number(pose.blockWeaponPosition().getX()),
                number(pose.blockWeaponPosition().getY()),
                number(pose.blockWeaponPosition().getZ()),
                number(pose.blockWeaponRotation().getX()),
                number(pose.blockWeaponRotation().getY()),
                number(pose.blockWeaponRotation().getZ())
        );
    }

    private static String number(
            float value
    ) {

        return String.format(
                Locale.ROOT,
                "%.4f",
                value
        );
    }

    private static ArmPose getArmPoseFromSet(
            PoseSet poseSet,
            int mode
    ) {

        if (poseSet == null) {
            return null;
        }

        if (mode
                == DefenseAnimationSyncPayload.PARRY) {

            return new ArmPose(
                    poseSet.parryMainHand(),
                    poseSet.parryOffHand()
            );
        }

        if (mode
                == DefenseAnimationSyncPayload.BLOCK) {

            return new ArmPose(
                    poseSet.blockMainHand(),
                    poseSet.blockOffHand()
            );
        }

        return null;
    }

    private static Vec3f getWeaponPositionFromSet(
            PoseSet poseSet,
            int mode
    ) {

        if (poseSet == null) {
            return null;
        }

        if (mode == DefenseAnimationSyncPayload.PARRY) {
            return poseSet.parryWeaponPosition();
        }

        if (mode == DefenseAnimationSyncPayload.BLOCK) {
            return poseSet.blockWeaponPosition();
        }

        return null;
    }

    private static Vec3f getWeaponRotationFromSet(
            PoseSet poseSet,
            int mode
    ) {

        if (poseSet == null) {
            return null;
        }

        if (mode
                == DefenseAnimationSyncPayload.PARRY) {

            return poseSet.parryWeaponRotation();
        }

        if (mode
                == DefenseAnimationSyncPayload.BLOCK) {

            return poseSet.blockWeaponRotation();
        }

        return null;
    }

    private static PoseSet replaceArmMode(
            PoseSet base,
            int mode,
            Vec3f main,
            Vec3f off
    ) {

        if (mode == DefenseAnimationSyncPayload.PARRY) {
            return new PoseSet(
                    base.enabled(),
                    main,
                    off,
                    base.parryWeaponPosition(),
                    base.parryWeaponRotation(),
                    base.blockMainHand(),
                    base.blockOffHand(),
                    base.blockWeaponPosition(),
                    base.blockWeaponRotation()
            );
        }

        return new PoseSet(
                base.enabled(),
                base.parryMainHand(),
                base.parryOffHand(),
                base.parryWeaponPosition(),
                base.parryWeaponRotation(),
                main,
                off,
                base.blockWeaponPosition(),
                base.blockWeaponRotation()
        );
    }

    private static PoseSet replaceWeaponPositionMode(
            PoseSet base,
            int mode,
            Vec3f weaponPosition
    ) {

        if (mode == DefenseAnimationSyncPayload.PARRY) {
            return new PoseSet(
                    base.enabled(),
                    base.parryMainHand(),
                    base.parryOffHand(),
                    weaponPosition,
                    base.parryWeaponRotation(),
                    base.blockMainHand(),
                    base.blockOffHand(),
                    base.blockWeaponPosition(),
                    base.blockWeaponRotation()
            );
        }

        return new PoseSet(
                base.enabled(),
                base.parryMainHand(),
                base.parryOffHand(),
                base.parryWeaponPosition(),
                base.parryWeaponRotation(),
                base.blockMainHand(),
                base.blockOffHand(),
                weaponPosition,
                base.blockWeaponRotation()
        );
    }

    private static PoseSet replaceWeaponMode(
            PoseSet base,
            int mode,
            Vec3f weaponRotation
    ) {

        if (mode == DefenseAnimationSyncPayload.PARRY) {
            return new PoseSet(
                    base.enabled(),
                    base.parryMainHand(),
                    base.parryOffHand(),
                    base.parryWeaponPosition(),
                    weaponRotation,
                    base.blockMainHand(),
                    base.blockOffHand(),
                    base.blockWeaponPosition(),
                    base.blockWeaponRotation()
            );
        }

        return new PoseSet(
                base.enabled(),
                base.parryMainHand(),
                base.parryOffHand(),
                base.parryWeaponPosition(),
                base.parryWeaponRotation(),
                base.blockMainHand(),
                base.blockOffHand(),
                base.blockWeaponPosition(),
                weaponRotation
        );
    }

    private static Vec3f adjustAxis(
            Vec3f value,
            int axis,
            float delta
    ) {

        float x =
                value.getX();

        float y =
                value.getY();

        float z =
                value.getZ();

        if (axis == 0) {
            x += delta;
        } else if (axis == 1) {
            y += delta;
        } else if (axis == 2) {
            z += delta;
        }

        /*
         * Keep rotations sane without restricting normal creativity.
         * +/- PI radians = full 180-degree range on each axis.
         */
        x = clampRotation(x);
        y = clampRotation(y);
        z = clampRotation(z);

        return new Vec3f(
                x,
                y,
                z
        );
    }

    private static Vec3f adjustPositionAxis(
            Vec3f value,
            int axis,
            float delta
    ) {

        float x = value.getX();
        float y = value.getY();
        float z = value.getZ();

        if (axis == 0) {
            x += delta;
        } else if (axis == 1) {
            y += delta;
        } else if (axis == 2) {
            z += delta;
        }

        /*
         * Generous visual-only safety limit.
         * Allows floating/magical weapon poses while preventing accidental
         * extreme values from pushing the render absurdly far away.
         */
        x = clampPosition(x);
        y = clampPosition(y);
        z = clampPosition(z);

        return new Vec3f(x, y, z);
    }

    private static float clampPosition(
            float value
    ) {

        return Math.max(
                -4.0F,
                Math.min(
                        4.0F,
                        value
                )
        );
    }

    private static float clampRotation(
            float value
    ) {

        float pi =
                (float) Math.PI;

        return Math.max(
                -pi,
                Math.min(
                        pi,
                        value
                )
        );
    }

    private static PoseSet copyPoseSet(
            PoseSet value
    ) {

        return new PoseSet(
                value.enabled(),
                copyVec(value.parryMainHand()),
                copyVec(value.parryOffHand()),
                copyVec(value.parryWeaponPosition()),
                copyVec(value.parryWeaponRotation()),
                copyVec(value.blockMainHand()),
                copyVec(value.blockOffHand()),
                copyVec(value.blockWeaponPosition()),
                copyVec(value.blockWeaponRotation())
        );
    }

    private static Vec3f copyVec(
            Vec3f value
    ) {

        return new Vec3f(
                value.getX(),
                value.getY(),
                value.getZ()
        );
    }

    private static Vec3f zero() {

        return new Vec3f(
                0.0F,
                0.0F,
                0.0F
        );
    }

    private static PoseSet disabledNeutral() {

        return new PoseSet(
                false,
                zero(),
                zero(),
                zero(),
                zero(),
                zero(),
                zero(),
                zero(),
                zero()
        );
    }

    private static Map<ParryStyle, PoseSet>
    createFallbackPoses() {

        EnumMap<ParryStyle, PoseSet> fallback =
                new EnumMap<>(
                        ParryStyle.class
                );

        for (ParryStyle style : ParryStyle.values()) {

            fallback.put(
                    style,
                    disabledNeutral()
            );
        }

        return fallback;
    }

    private static boolean readOptionalBoolean(
            JsonObject parent,
            String key,
            boolean fallback
    ) {

        JsonElement element =
                parent.get(
                        key
                );

        if (element == null) {
            return fallback;
        }

        if (!element.isJsonPrimitive()
                || !element
                        .getAsJsonPrimitive()
                        .isBoolean()) {

            throw new IllegalArgumentException(
                    key
                            + " must be true or false."
            );
        }

        return element.getAsBoolean();
    }

    private static JsonObject requireObject(
            JsonObject parent,
            String key
    ) {

        JsonElement element =
                parent.get(
                        key
                );

        if (element == null
                || !element.isJsonObject()) {

            throw new IllegalArgumentException(
                    "Missing JSON object: "
                            + key
            );
        }

        return element.getAsJsonObject();
    }

    private static Vec3f readVec3Either(
            JsonObject parent,
            String preferred,
            String legacy
    ) {

        if (parent.has(
                preferred
        )) {

            return readVec3(
                    parent,
                    preferred
            );
        }

        return readVec3(
                parent,
                legacy
        );
    }

    private static Vec3f readOptionalVec3(
            JsonObject parent,
            String key
    ) {

        if (!parent.has(
                key
        )) {

            return zero();
        }

        return readVec3(
                parent,
                key
        );
    }

    private static Vec3f readVec3(
            JsonObject parent,
            String key
    ) {

        JsonElement element =
                parent.get(
                        key
                );

        if (element == null
                || !element.isJsonArray()) {

            throw new IllegalArgumentException(
                    "Missing vector array: "
                            + key
            );
        }

        JsonArray array =
                element.getAsJsonArray();

        if (array.size() != 3) {

            throw new IllegalArgumentException(
                    key
                            + " must contain exactly 3 numbers."
            );
        }

        return new Vec3f(
                array.get(0).getAsFloat(),
                array.get(1).getAsFloat(),
                array.get(2).getAsFloat()
        );
    }

    private record PoseSet(
            boolean enabled,
            Vec3f parryMainHand,
            Vec3f parryOffHand,
            Vec3f parryWeaponPosition,
            Vec3f parryWeaponRotation,
            Vec3f blockMainHand,
            Vec3f blockOffHand,
            Vec3f blockWeaponPosition,
            Vec3f blockWeaponRotation
    ) {
    }

    public record ArmPose(
            Vec3f mainHand,
            Vec3f offHand
    ) {
    }

    public record ReloadResult(
            boolean success,
            String message
    ) {
    }

    public record SaveResult(
            boolean success,
            String message
    ) {
    }
}
