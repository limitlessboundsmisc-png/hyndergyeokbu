package com.wckd.gyeokbu.compat;

import com.wckd.gyeokbu.Config;
import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.advancement.GyeokbuAdvancements;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantmentRuntime;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingKnockBackEvent;
import net.neoforged.neoforge.event.entity.living.LivingShieldBlockEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Lightweight compatibility bridge for shields whose owning mod supplies its
 * own Parry window.
 *
 * Pack/mod authors can opt in deterministically through
 * {@code gyeokbuv2:parry_capable_shields}. Gyeokbu can also learn the common
 * external-parry pattern at runtime: a successful shield block followed by
 * knockback on the attacker during the same short window.
 */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class ShieldParryCompat {

    public static final TagKey<Item> PARRY_CAPABLE_SHIELDS = TagKey.create(
            Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath(GyeokbuV2.MODID, "parry_capable_shields")
    );

    private static final int DETECTION_WINDOW_TICKS = 2;

    private static final Map<UUID, PendingShieldBlock> PENDING_BY_ATTACKER =
            new HashMap<>();
    private static final Set<ResourceLocation> LEARNED_PARRY_SHIELDS =
            new HashSet<>();

    private static final ThreadLocal<Boolean> GYEOKBU_PUSHBACK =
            ThreadLocal.withInitial(() -> false);

    private ShieldParryCompat() {
    }

    public static boolean isParryCapableShield(ItemStack stack) {
        if (!GyeokbuEnchantments.isShield(stack)) {
            return false;
        }

        if (stack.is(PARRY_CAPABLE_SHIELDS)) {
            return true;
        }

        ResourceLocation id = BuiltInRegistries.ITEM.getKey(stack.getItem());
        return Config.isConfiguredParryCapableShield(id)
                || LEARNED_PARRY_SHIELDS.contains(id);
    }

    /**
     * Small integration hook for dedicated compat code that can identify an
     * external shield Parry directly. This learns the shield type and applies
     * only Gyeokbu effects that are safe after a successful external Parry.
     */
    public static void reportSuccessfulShieldParry(
            ServerPlayer defender,
            LivingEntity attacker,
            ItemStack shield
    ) {
        if (defender == null
                || attacker == null
                || attacker == defender
                || !GyeokbuEnchantments.isShield(shield)) {
            return;
        }

        LEARNED_PARRY_SHIELDS.add(BuiltInRegistries.ITEM.getKey(shield.getItem()));
        GyeokbuEnchantmentRuntime.onSuccessfulShieldParry(defender, attacker, shield);
        GyeokbuAdvancements.awardFirstDefense(defender);
    }

    /** Used by Gyeokbu's own Pushback so it is never mistaken for external Parry knockback. */
    public static void runGyeokbuShieldPushback(Runnable action) {
        GYEOKBU_PUSHBACK.set(true);
        try {
            action.run();
        } finally {
            GYEOKBU_PUSHBACK.set(false);
        }
    }


    /**
     * Broad first-stage detector for external shield Parry mods. We remember an
     * incoming attack while a shield is actively raised; the attacker must
     * still receive real knockback within the short detection window before
     * Gyeokbu treats it as an external successful Parry.
     *
     * This deliberately does not claim a Parry from damage cancellation alone.
     * The second knockback signal is what keeps ordinary shield blocks from
     * being learned as Parry systems.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onIncomingShieldAttack(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer defender)) {
            return;
        }

        ItemStack shield = defender.getUseItem();
        if (!defender.isUsingItem() || !GyeokbuEnchantments.isShield(shield)) {
            return;
        }

        Entity attackOwner = event.getSource().getEntity();
        if (!(attackOwner instanceof LivingEntity attacker) || attacker == defender) {
            return;
        }

        rememberCandidate(defender, attacker, shield);
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onShieldBlock(LivingShieldBlockEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer defender)
                || event.isCanceled() || !event.getBlocked() || event.getBlockedDamage() <= 0.0F) {
            return;
        }

        ItemStack shield = defender.getUseItem();
        if (!GyeokbuEnchantments.isShield(shield)) {
            return;
        }

        Entity attackOwner = event.getDamageSource().getEntity();
        if (!(attackOwner instanceof LivingEntity attacker) || attacker == defender) {
            return;
        }

        rememberCandidate(defender, attacker, shield);
    }


    private static void rememberCandidate(
            ServerPlayer defender,
            LivingEntity attacker,
            ItemStack shield
    ) {
        long gameTime = defender.serverLevel().getGameTime();
        PENDING_BY_ATTACKER.put(
                attacker.getUUID(),
                new PendingShieldBlock(defender, shield.copy(), gameTime)
        );
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onAttackerKnockback(LivingKnockBackEvent event) {
        if (GYEOKBU_PUSHBACK.get()) {
            return;
        }

        LivingEntity attacker = event.getEntity();
        if (event.getStrength() <= 0.0F) {
            return;
        }

        PendingShieldBlock pending = PENDING_BY_ATTACKER.remove(attacker.getUUID());
        if (pending == null) {
            return;
        }

        ServerPlayer defender = pending.defender();
        if (defender == null || defender.isRemoved() || !defender.isAlive()) {
            return;
        }

        long now = defender.serverLevel().getGameTime();
        if (now - pending.gameTime() < 0L
                || now - pending.gameTime() > DETECTION_WINDOW_TICKS) {
            return;
        }

        ItemStack liveShield = defender.getUseItem();
        if (!GyeokbuEnchantments.isShield(liveShield)
                || liveShield.getItem() != pending.shield().getItem()) {
            return;
        }

        /*
         * External shield mods own their own timing, sounds and particles.
         * Gyeokbu only supplies the enchantment effects here; it deliberately
         * does not spawn Gyeokbu Parry particles for shields.
         */
        reportSuccessfulShieldParry(defender, attacker, liveShield);
    }


    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        if (PENDING_BY_ATTACKER.isEmpty()) {
            return;
        }

        PENDING_BY_ATTACKER.entrySet().removeIf(entry -> {
            PendingShieldBlock pending = entry.getValue();
            ServerPlayer defender = pending.defender();
            if (defender == null || defender.isRemoved() || !defender.isAlive()) {
                return true;
            }

            long age = defender.serverLevel().getGameTime() - pending.gameTime();
            return age < 0L || age > DETECTION_WINDOW_TICKS;
        });
    }

    private record PendingShieldBlock(
            ServerPlayer defender,
            ItemStack shield,
            long gameTime
    ) {
    }
}
