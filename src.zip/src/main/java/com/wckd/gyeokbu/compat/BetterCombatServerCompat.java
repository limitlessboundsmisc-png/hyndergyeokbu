package com.wckd.gyeokbu.compat;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.ModList;

import java.lang.reflect.Method;

public final class BetterCombatServerCompat {

    private static boolean disabledAfterError = false;

    private BetterCombatServerCompat() {
    }

    public static void setAttacksDisabled(
            ServerPlayer player,
            boolean disabled
    ) {

        if (player == null
                || disabledAfterError
                || !ModList.get().isLoaded("bettercombat")) {

            return;
        }

        try {

            /*
             * Better Combat 2.4.0:
             *
             * CombatFlags.setAttacksDisabled(
             *     ServerPlayer,
             *     boolean
             * )
             *
             * Better Combat's server-side
             * C2S_AttackRequest handler checks this
             * before processing attack damage.
             */
            Class<?> combatFlagsClass =
                    Class.forName(
                            "net.bettercombat.api.CombatFlags"
                    );

            Method setAttacksDisabled =
                    combatFlagsClass.getMethod(
                            "setAttacksDisabled",
                            ServerPlayer.class,
                            boolean.class
                    );

            setAttacksDisabled.invoke(
                    null,
                    player,
                    disabled
            );

        } catch (ReflectiveOperationException exception) {

            disabledAfterError = true;

            GyeokbuV2.LOGGER.warn(
                    "Better Combat server compatibility failed. "
                            + "Disabling Better Combat attack-lock integration "
                            + "for this session.",
                    exception
            );
        }
    }
}