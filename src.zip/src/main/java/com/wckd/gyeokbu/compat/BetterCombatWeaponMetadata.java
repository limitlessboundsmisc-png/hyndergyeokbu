package com.wckd.gyeokbu.compat;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;

import java.lang.reflect.Method;

/**
 * Optional, reflection-only reader for Better Combat's resolved weapon
 * attributes.
 *
 * Gyeokbu must remain fully usable without Better Combat on the classpath, so
 * this bridge deliberately has no compile-time Better Combat dependency.
 */
public final class BetterCombatWeaponMetadata {

    private static final Metadata NONE =
            new Metadata(false, false, null, null);

    private static volatile boolean initialized = false;
    private static volatile boolean unavailable = false;

    private static Method getAttributesMethod;
    private static Method isTwoHandedMethod;
    private static Method categoryMethod;
    private static Method poseMethod;

    private BetterCombatWeaponMetadata() {
    }

    /** Returns whether the optional Better Combat bridge can currently be used. */
    public static boolean isAvailable() {
        if (!ModList.get().isLoaded("bettercombat") || unavailable) {
            return false;
        }
        return initialized || initialize();
    }

    public static Metadata get(ItemStack stack) {
        if (stack == null
                || stack.isEmpty()
                || unavailable
                || !ModList.get().isLoaded("bettercombat")) {
            return NONE;
        }

        if (!initialized && !initialize()) {
            return NONE;
        }

        try {
            Object attributes = getAttributesMethod.invoke(null, stack);
            if (attributes == null) {
                return NONE;
            }

            boolean twoHanded = Boolean.TRUE.equals(
                    isTwoHandedMethod.invoke(attributes)
            );

            Object categoryValue = categoryMethod.invoke(attributes);
            Object poseValue = poseMethod.invoke(attributes);

            return new Metadata(
                    true,
                    twoHanded,
                    categoryValue instanceof String value ? value : null,
                    poseValue instanceof String value ? value : null
            );
        } catch (ReflectiveOperationException | RuntimeException exception) {
            disableAfterError(exception);
            return NONE;
        }
    }

    private static synchronized boolean initialize() {
        if (initialized) {
            return true;
        }

        if (unavailable) {
            return false;
        }

        try {
            Class<?> registryClass = Class.forName(
                    "net.bettercombat.logic.WeaponRegistry"
            );
            Class<?> attributesClass = Class.forName(
                    "net.bettercombat.api.WeaponAttributes"
            );

            getAttributesMethod = registryClass.getMethod(
                    "getAttributes",
                    ItemStack.class
            );
            isTwoHandedMethod = attributesClass.getMethod("isTwoHanded");
            categoryMethod = attributesClass.getMethod("category");
            poseMethod = attributesClass.getMethod("pose");

            initialized = true;
            return true;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            disableAfterError(exception);
            return false;
        }
    }

    private static void disableAfterError(Exception exception) {
        if (unavailable) {
            return;
        }

        unavailable = true;
        GyeokbuV2.LOGGER.warn(
                "Better Combat weapon-metadata compatibility failed. "
                        + "Gyeokbu will continue with its normal automatic "
                        + "weapon classifier for this session.",
                exception
        );
    }

    public record Metadata(
            boolean present,
            boolean twoHanded,
            String category,
            String pose
    ) {
    }
}
