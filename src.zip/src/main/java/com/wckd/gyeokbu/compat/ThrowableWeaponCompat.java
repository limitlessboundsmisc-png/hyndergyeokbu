package com.wckd.gyeokbu.compat;

import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;

/**
 * Generic compatibility boundary for Gyeokbu weapons with a native
 * throw / charged-spear right-click action.
 *
 * V20 control rule:
 *
 * Plain RMB
 * -> Gyeokbu Parry / Block
 *
 * Shift + RMB
 * -> native item/mod use is allowed through
 *
 * This works for either hand. That matters for mods such as Spartan where
 * dual throwable weapons may choose the OFFHAND as the actual throwing hand.
 */
public final class ThrowableWeaponCompat {

    private ThrowableWeaponCompat() {
    }

    public static boolean hasNativeThrowUse(
            ItemStack stack,
            LivingEntity user
    ) {

        if (stack == null
                || stack.isEmpty()) {

            return false;
        }

        WeaponProfile profile =
                WeaponClassifier.classify(
                        stack
                );

        if (!profile.isSupported()) {
            return false;
        }

        if (profile.isThrowable()) {
            return true;
        }

        /*
         * Generic charged-throw signal.
         *
         * Keeps the existing melee profile when a mod adds a throwable trait
         * to something such as a Katana or Longsword.
         */
        if (stack.getUseAnimation()
                != UseAnim.SPEAR) {

            return false;
        }

        return user == null
                || stack.getUseDuration(
                        user
                ) > 0;
    }

    public static boolean hasNativeThrowWeapon(
            Player player
    ) {

        if (player == null) {
            return false;
        }

        return hasNativeThrowUse(
                player.getMainHandItem(),
                player
        )
                || hasNativeThrowUse(
                player.getOffhandItem(),
                player
        );
    }

    /**
     * True only while the item the player is ACTUALLY using is one of the
     * held native-throw weapons.
     */
    public static boolean isThrowActionActive(
            Player player
    ) {

        if (player == null
                || !player.isUsingItem()) {

            return false;
        }

        ItemStack useItem =
                player.getUseItem();

        if (useItem.isEmpty()) {
            return false;
        }

        if (!hasNativeThrowUse(
                useItem,
                player
        )) {

            return false;
        }

        ItemStack mainHand =
                player.getMainHandItem();

        ItemStack offHand =
                player.getOffhandItem();

        return useItem.getItem()
                == mainHand.getItem()
                || useItem.getItem()
                == offHand.getItem();
    }

    /**
     * Client-side interaction ownership rule.
     *
     * Plain RMB on a held native-throw Gyeokbu weapon must never reach the
     * item's normal use pipeline; it belongs to Gyeokbu.
     *
     * Sneaking deliberately returns false so Shift + RMB reaches the native
     * mod/item implementation untouched.
     */
    public static boolean shouldBlockNativePlainUse(
            Player player
    ) {

        return player != null
                && !player.isShiftKeyDown()
                && hasNativeThrowWeapon(
                        player
                );
    }
}
