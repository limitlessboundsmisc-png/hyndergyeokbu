package com.wckd.gyeokbu.weapon;

public enum HandStyle {

    ONE_HANDED,
    TWO_HANDED
}