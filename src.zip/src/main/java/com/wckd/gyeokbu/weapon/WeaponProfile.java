package com.wckd.gyeokbu.weapon;

/**
 * One resolved Gyeokbu weapon profile.
 *
 * Core identity:
 *   handStyle
 *
 * Legacy trait fields remain in the record for compatibility, but the current
 * built-in V25.1 classifier assigns every combat weapon to its plain 1H or 2H
 * mechanical baseline. Weapon-specific identities remain available for visuals,
 * classification, and future explicit design work.
 */
public record WeaponProfile(
        WeaponType weaponType,
        HandStyle handStyle,
        DefenseFamily defenseFamily,
        ParryStyle parryStyle,

        TraitStyle perfectParryStyle,
        TraitStyle normalCounterDamageStyle,
        TraitStyle perfectCounterDamageStyle,
        TraitStyle stunStyle,

        boolean reflectOnNormalParry,

        boolean canStun,
        boolean canKnockback,
        float blockDamageMultiplier
) {

    public static WeaponProfile unknown() {
        return unknown(HandStyle.ONE_HANDED);
    }

    public static WeaponProfile unknown(HandStyle handStyle) {

        return new WeaponProfile(
                WeaponType.UNKNOWN,
                handStyle == null ? HandStyle.ONE_HANDED : handStyle,
                DefenseFamily.UNKNOWN,
                ParryStyle.GENERIC,

                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,

                false,

                false,
                false,
                1.0F
        );
    }

    /**
     * Explicit throwable weapon types are now valid Gyeokbu weapons while
     * idle. Input ownership is enforced separately by ThrowableWeaponCompat:
     * their native right-click is never used to start Gyeokbu.
     */
    /** Return a copy with the resolved handedness changed without altering category/traits. */
    public WeaponProfile withHandStyle(HandStyle handStyle) {
        return new WeaponProfile(
                weaponType,
                handStyle == null ? HandStyle.ONE_HANDED : handStyle,
                defenseFamily,
                parryStyle,
                perfectParryStyle,
                normalCounterDamageStyle,
                perfectCounterDamageStyle,
                stunStyle,
                reflectOnNormalParry,
                canStun,
                canKnockback,
                blockDamageMultiplier
        );
    }

    public boolean isSupported() {

        return weaponType != WeaponType.UNKNOWN;
    }

    public boolean isTool() {

        return weaponType == WeaponType.TOOL;
    }

    public boolean isThrowable() {

        return weaponType == WeaponType.THROWING_KNIFE
                || weaponType == WeaponType.TOMAHAWK
                || weaponType == WeaponType.JAVELIN
                || weaponType == WeaponType.BOOMERANG;
    }

    public boolean isTwoHanded() {

        return handStyle == HandStyle.TWO_HANDED;
    }

    public HandStyle resolvePerfectParryStyle() {

        return perfectParryStyle.resolve(
                handStyle
        );
    }

    public HandStyle resolveNormalCounterDamageStyle() {

        return normalCounterDamageStyle.resolve(
                handStyle
        );
    }

    public HandStyle resolvePerfectCounterDamageStyle() {

        return perfectCounterDamageStyle.resolve(
                handStyle
        );
    }

    public HandStyle resolveCounterDamageStyle(
            boolean perfect
    ) {

        return perfect
                ? resolvePerfectCounterDamageStyle()
                : resolveNormalCounterDamageStyle();
    }

    public HandStyle resolveStunStyle() {

        return stunStyle.resolve(
                handStyle
        );
    }

    public boolean hasSpecialTraits() {

        return perfectParryStyle != TraitStyle.INHERIT
                || normalCounterDamageStyle != TraitStyle.INHERIT
                || perfectCounterDamageStyle != TraitStyle.INHERIT
                || stunStyle != TraitStyle.INHERIT
                || reflectOnNormalParry;
    }
}
