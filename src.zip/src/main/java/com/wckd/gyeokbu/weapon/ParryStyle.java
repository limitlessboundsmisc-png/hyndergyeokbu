package com.wckd.gyeokbu.weapon;

public enum ParryStyle {

    SWORD,
    LONGSWORD,
    SABER,

    RAPIER,

    DAGGER,
    PARRYING_DAGGER,

    GREATSWORD,
    KATANA,

    SPEAR,
    LANCE,

    GLAIVE,
    HALBERD,

    AXE,
    BATTLEAXE,

    HAMMER,
    WARHAMMER,
    BATTLE_HAMMER,

    MACE,
    FLANGED_MACE,
    CLUB,

    STAFF,
    QUARTERSTAFF,

    SCYTHE,
    SICKLE,

    CESTUS,

    THROWING_KNIFE,
    TOMAHAWK,
    JAVELIN,
    BOOMERANG,

    TOOL,

    GENERIC
}
