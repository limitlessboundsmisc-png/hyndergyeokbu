package com.wckd.gyeokbu.weapon;

import com.wckd.gyeokbu.compat.BetterCombatWeaponMetadata;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Session-stable catalog of weapon-category + handedness combinations that
 * actually exist in the loaded game. Handedness is only meaningful when the
 * optional Better Combat metadata bridge is available.
 */
public final class WeaponProfileCatalog {

    private static volatile List<WeaponProfileKey> cached;

    private WeaponProfileCatalog() {
    }

    public static List<WeaponProfileKey> getDetectedProfiles() {
        if (!BetterCombatWeaponMetadata.isAvailable()) {
            return List.of();
        }

        List<WeaponProfileKey> value = cached;
        if (value != null) {
            return value;
        }

        synchronized (WeaponProfileCatalog.class) {
            value = cached;
            if (value != null) {
                return value;
            }

            Set<WeaponProfileKey> detected = new LinkedHashSet<>();
            for (Item item : BuiltInRegistries.ITEM) {
                if (item == null || item == Items.AIR) {
                    continue;
                }

                try {
                    WeaponProfile profile = WeaponClassifier.classifyNaturalForCatalog(item);
                    if (!profile.isSupported()
                            || profile.parryStyle() == null
                            || profile.parryStyle() == ParryStyle.GENERIC
                            || profile.weaponType() == WeaponType.UNKNOWN) {
                        continue;
                    }

                    detected.add(new WeaponProfileKey(
                            profile.parryStyle(),
                            profile.handStyle()
                    ));
                } catch (RuntimeException exception) {
                    /* One malformed/unsupported item must not prevent the F8
                     * catalog from showing every other usable weapon profile. */
                    continue;
                }
            }

            List<WeaponProfileKey> ordered = new ArrayList<>(detected);
            ordered.sort(
                    Comparator
                            .comparingInt((WeaponProfileKey key) -> key.style().ordinal())
                            .thenComparingInt(key -> key.handStyle().ordinal())
            );

            cached = List.copyOf(ordered);
            return cached;
        }
    }

    public static List<ParryStyle> getDetectedStyles() {
        if (!BetterCombatWeaponMetadata.isAvailable()) {
            return List.of();
        }

        LinkedHashSet<ParryStyle> styles = new LinkedHashSet<>();
        for (WeaponProfileKey key : getDetectedProfiles()) {
            styles.add(key.style());
        }
        return List.copyOf(styles);
    }

    public static boolean isDetected(WeaponProfileKey key) {
        return key != null && getDetectedProfiles().contains(key);
    }

    public static void invalidate() {
        cached = null;
    }
}
