package com.wckd.gyeokbu.weapon;

/**
 * Broad defensive classification.
 *
 * V17 deliberately does NOT assign numerical bonuses to these families yet.
 * 1H / 2H remains the core Gyeokbu stat identity.
 *
 * Families exist now so future balance work can group related weapons without
 * rewriting the classifier or inventing per-item combat code.
 */
public enum DefenseFamily {

    SWORD,
    THRUSTING,
    POLEARM,
    LIGHT_BLADE,
    BLUNT,
    HEAVY,
    UNARMED,
    THROWABLE,
    TOOL,
    UNKNOWN
}
