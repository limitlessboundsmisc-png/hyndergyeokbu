package com.wckd.gyeokbu.weapon;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

/**
 * Small common/server-safe dual-wield rule helper.
 *
 * V1:
 * - both hands must contain supported Gyeokbu weapons
 * - BOTH weapons must be 1H
 * - mainhand owns all combat mechanics
 * - offhand contributes only visuals + shared block durability
 */
public final class DualWieldRules {

    private DualWieldRules() {
    }

    public static boolean isDualWield(
            LivingEntity entity
    ) {

        if (entity == null) {
            return false;
        }

        return isDualWield(
                entity.getMainHandItem(),
                entity.getOffhandItem()
        );
    }

    public static boolean isDualWield(
            ItemStack mainHand,
            ItemStack offHand
    ) {

        if (mainHand == null
                || mainHand.isEmpty()
                || offHand == null
                || offHand.isEmpty()) {

            return false;
        }

        WeaponProfile mainProfile =
                WeaponClassifier.classify(
                        mainHand
                );

        WeaponProfile offProfile =
                WeaponClassifier.classify(
                        offHand
                );

        return mainProfile.isSupported()
                && offProfile.isSupported()
                && !mainProfile.isTwoHanded()
                && !offProfile.isTwoHanded();
    }

    /**
     * Valid overall Gyeokbu loadout:
     * - supported two-handed mainhand (offhand is ignored, matching Better Combat)
     * - supported single one-handed mainhand + empty offhand
     * - OR valid 1H + 1H dual wield
     */
    public static boolean isValidDefenseLoadout(
            LivingEntity entity
    ) {

        if (entity == null) {
            return false;
        }

        ItemStack mainHand =
                entity.getMainHandItem();

        WeaponProfile mainProfile =
                WeaponClassifier.classify(
                        mainHand
                );

        if (!mainProfile.isSupported()) {
            return false;
        }

        /*
         * Better Combat's two-handed weapons disable/ignore the offhand. Do
         * not make a harmless visible offhand stack prevent Gyeokbu Parry.
         */
        if (mainProfile.isTwoHanded()) {
            return true;
        }

        ItemStack offHand =
                entity.getOffhandItem();

        if (offHand.isEmpty()) {
            return true;
        }

        return isDualWield(
                mainHand,
                offHand
        );
    }
}
