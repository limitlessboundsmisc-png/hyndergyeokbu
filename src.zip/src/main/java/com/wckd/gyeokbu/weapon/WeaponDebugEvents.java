package com.wckd.gyeokbu.weapon;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.combat.CounterStateManager;
import com.wckd.gyeokbu.combat.DefenseData;
import com.wckd.gyeokbu.combat.DefenseManager;
import com.wckd.gyeokbu.combat.DefenseState;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class WeaponDebugEvents {

    private static final int UPDATE_INTERVAL_TICKS =
            20;

    private WeaponDebugEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(
            PlayerTickEvent.Post event
    ) {

        if (!(event.getEntity()
                instanceof ServerPlayer player)) {

            return;
        }

        if (!DefenseManager.areDeveloperMessagesEnabled(player)) {
            return;
        }

        if (player.tickCount
                % UPDATE_INTERVAL_TICKS != 0) {

            return;
        }

        /*
         * LOWEST PRIORITY.
         *
         * Never overwrite:
         *
         * - Perfect Parry
         * - Parry
         * - Group Parry
         * - Block
         * - Cooldown
         * - Counter State
         */
        DefenseData defenseData =
                DefenseManager.get(
                        player
                );

        if (defenseData.getState()
                != DefenseState.NEUTRAL) {

            return;
        }

        if (CounterStateManager
                .hasCounterState(
                        player
                )) {

            return;
        }

        ItemStack stack =
                player.getMainHandItem();

        WeaponProfile profile =
                WeaponClassifier.classify(
                        stack
                );

        if (profile.isThrowable()) {

            player.displayClientMessage(
                    Component.literal(
                            "GYEOKBU • "
                                    + profile.weaponType()
                                    + " THROWABLE"
                    ),
                    true
            );

            return;
        }

        if (!profile.isSupported()) {

            player.displayClientMessage(
                    Component.literal(
                            "GY: UNSUPPORTED"
                    ),
                    true
            );

            return;
        }

        String message =
                "GYEOKBU • "
                        + profile.parryStyle()
                        + " STANCE";

        player.displayClientMessage(
                Component.literal(
                        message
                ),
                true
        );
    }
}