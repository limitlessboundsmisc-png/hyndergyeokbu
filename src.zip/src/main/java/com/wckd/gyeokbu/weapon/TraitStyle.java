package com.wckd.gyeokbu.weapon;

/**
 * A selective borrowed Gyeokbu behavior.
 *
 * INHERIT means:
 * use the weapon's normal 1H / 2H HandStyle.
 */
public enum TraitStyle {

    INHERIT,
    ONE_HANDED,
    TWO_HANDED;

    public HandStyle resolve(
            HandStyle baseStyle
    ) {

        return switch (this) {

            case ONE_HANDED ->
                    HandStyle.ONE_HANDED;

            case TWO_HANDED ->
                    HandStyle.TWO_HANDED;

            case INHERIT ->
                    baseStyle;
        };
    }
}
