package com.wckd.gyeokbu.weapon;

import java.util.Locale;

/**
 * Canonical visual weapon identity used by systems that need to distinguish
 * the same weapon category by Better Combat handedness.
 */
public record WeaponProfileKey(
        ParryStyle style,
        HandStyle handStyle
) {

    public WeaponProfileKey {
        if (style == null) {
            throw new IllegalArgumentException("Weapon profile style cannot be null.");
        }
        if (handStyle == null) {
            throw new IllegalArgumentException("Weapon profile hand style cannot be null.");
        }
    }

    public String fileSuffix() {
        return handStyle == HandStyle.TWO_HANDED
                ? "two_handed"
                : "one_handed";
    }

    public String displayName(boolean includeHandedness) {
        String base = pretty(style);
        if (!includeHandedness) {
            return base;
        }
        return (handStyle == HandStyle.TWO_HANDED ? "2H " : "1H ") + base;
    }

    private static String pretty(ParryStyle value) {
        String[] words = value.name()
                .toLowerCase(Locale.ROOT)
                .split("_");
        StringBuilder out = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) {
                continue;
            }
            if (!out.isEmpty()) {
                out.append(' ');
            }
            out.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1));
        }
        return out.toString();
    }
}
