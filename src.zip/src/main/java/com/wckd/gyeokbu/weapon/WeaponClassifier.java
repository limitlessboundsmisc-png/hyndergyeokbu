package com.wckd.gyeokbu.weapon;

import com.wckd.gyeokbu.Config;
import com.wckd.gyeokbu.compat.BetterCombatWeaponMetadata;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class WeaponClassifier {

    /*
     * Structured weapon metadata checked before the final generic fallback.
     *
     * These are declared by id instead of depending on another mod's Java API.
     * Any mod/datapack can participate simply by putting its item in the normal
     * Minecraft/common tag. Better Combat remains entirely optional.
     */
    private static final TagKey<Item> MINECRAFT_SWORDS =
            itemTag("minecraft", "swords");
    private static final TagKey<Item> MINECRAFT_AXES =
            itemTag("minecraft", "axes");
    private static final TagKey<Item> MINECRAFT_PICKAXES =
            itemTag("minecraft", "pickaxes");
    private static final TagKey<Item> MINECRAFT_SWORD_ENCHANTABLE =
            itemTag("minecraft", "enchantable/sword");
    private static final TagKey<Item> MINECRAFT_TRIDENT_ENCHANTABLE =
            itemTag("minecraft", "enchantable/trident");
    private static final TagKey<Item> MINECRAFT_WEAPON_ENCHANTABLE =
            itemTag("minecraft", "enchantable/weapon");

    private static final TagKey<Item> COMMON_MELEE_WEAPONS =
            itemTag("c", "tools/melee_weapon");
    private static final TagKey<Item> COMMON_SWORDS =
            itemTag("c", "swords");
    private static final TagKey<Item> COMMON_AXES =
            itemTag("c", "axes");
    private static final TagKey<Item> COMMON_DAGGERS =
            itemTag("c", "daggers");
    private static final TagKey<Item> COMMON_RAPIERS =
            itemTag("c", "rapiers");
    private static final TagKey<Item> COMMON_SPEARS =
            itemTag("c", "spears");
    private static final TagKey<Item> COMMON_GLAIVES =
            itemTag("c", "glaives");
    private static final TagKey<Item> COMMON_HALBERDS =
            itemTag("c", "halberds");
    private static final TagKey<Item> COMMON_HAMMERS =
            itemTag("c", "hammers");
    private static final TagKey<Item> COMMON_MACES =
            itemTag("c", "maces");
    private static final TagKey<Item> COMMON_STAVES =
            itemTag("c", "staves");
    private static final TagKey<Item> COMMON_SCYTHES =
            itemTag("c", "scythes");

    private static final Map<ResourceLocation, WeaponProfile> ITEM_OVERRIDES =
            new ConcurrentHashMap<>();

    /**
     * User-enabled fallback weapons created through the F8 held-stance save.
     *
     * These are registry-item scoped, matching exact-item visual stance saves.
     * Recognized weapons never need this map; they keep their normal profile.
     */
    private static final Map<ResourceLocation, ParryStyle> USER_FALLBACK_STYLES =
            new ConcurrentHashMap<>();

    /*
     * Registry-backed list used by the F8 stance dropdown.
     *
     * The item registry is stable during normal gameplay, so this can be
     * cached for the session. Explicit classifier overrides invalidate it.
     */
    private static volatile List<ParryStyle> DETECTED_PARRY_STYLES =
            null;

    private WeaponClassifier() {
    }

    public static WeaponProfile classify(
            ItemStack stack
    ) {

        if (stack == null
                || stack.isEmpty()) {

            return WeaponProfile.unknown();
        }

        WeaponProfile natural =
                classifyNatural(
                        stack
                );

        if (natural.isSupported()) {
            return natural;
        }

        ResourceLocation id =
                BuiltInRegistries.ITEM
                        .getKey(
                                stack.getItem()
                        );

        ParryStyle fallbackStyle =
                USER_FALLBACK_STYLES.get(
                        id
                );

        if (fallbackStyle != null) {
            return fallbackProfile(
                    fallbackStyle
            );
        }

        return natural;
    }

    public static WeaponProfile classify(
            Item item
    ) {

        WeaponProfile natural =
                classifyNatural(
                        item
                );

        if (natural.isSupported()) {
            return natural;
        }

        if (item == null
                || item == Items.AIR) {
            return natural;
        }

        ResourceLocation id =
                BuiltInRegistries.ITEM
                        .getKey(
                                item
                        );

        ParryStyle fallbackStyle =
                USER_FALLBACK_STYLES.get(
                        id
                );

        if (fallbackStyle != null) {
            return fallbackProfile(
                    fallbackStyle
            );
        }

        return natural;
    }

    /**
     * Classifies an item without user-created F8 fallback support.
     *
     * The pose editor uses this to remember the weapon's real recognized
     * stance even after a fallback assignment has been registered.
     */
    public static WeaponProfile classifyNatural(
            ItemStack stack
    ) {
        if (stack == null
                || stack.isEmpty()) {
            return WeaponProfile.unknown();
        }

        return classifyNatural(
                stack.getItem(),
                stack,
                true
        );
    }

    /**
     * Natural classification used by the detected weapon-profile catalog.
     * User-authored exact-item overrides must not manufacture or remove a
     * category from the catalog; the catalog represents the loaded game's
     * natural weapon capabilities only.
     */
    public static WeaponProfile classifyNaturalForCatalog(
            Item item
    ) {
        if (item == null || item == Items.AIR) {
            return WeaponProfile.unknown();
        }

        return classifyNatural(
                item,
                item.getDefaultInstance(),
                false
        );
    }

    public static WeaponProfile classifyNatural(
            Item item
    ) {

        if (item == null
                || item == Items.AIR) {

            return WeaponProfile.unknown();
        }

        return classifyNatural(
                item,
                item.getDefaultInstance(),
                true
        );
    }

    private static WeaponProfile classifyNatural(
            Item item,
            ItemStack stack
    ) {
        return classifyNatural(item, stack, true);
    }

    private static WeaponProfile classifyNatural(
            Item item,
            ItemStack stack,
            boolean allowUserOverrides
    ) {
        ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);

        if (Config.isExplicitWeaponExcluded(id)) {
            return WeaponProfile.unknown();
        }

        if (allowUserOverrides) {
            WeaponProfile override = ITEM_OVERRIDES.get(id);
            if (override != null) {
                return override;
            }
        }

        BetterCombatWeaponMetadata.Metadata metadata =
                BetterCombatWeaponMetadata.get(stack);

        WeaponProfile betterCombatProfile =
                classifyBetterCombatMetadata(metadata);
        if (betterCombatProfile != null) {
            return betterCombatProfile;
        }

        WeaponProfile profile =
                classifyNaturalWithoutBetterCombat(
                        item,
                        stack,
                        allowUserOverrides
                );

        if (metadata.present()) {
            HandStyle detectedHandStyle = metadata.twoHanded()
                    ? HandStyle.TWO_HANDED
                    : HandStyle.ONE_HANDED;
            return profile.withHandStyle(detectedHandStyle);
        }

        return profile;
    }

    private static WeaponProfile classifyNaturalWithoutBetterCombat(
            Item item,
            ItemStack stack,
            boolean allowUserOverrides
    ) {

        ResourceLocation id =
                BuiltInRegistries.ITEM
                        .getKey(
                                item
                        );

        /* Pack-author exclusions have the highest compatibility priority. */
        if (Config.isExplicitWeaponExcluded(id)) {
            return WeaponProfile.unknown();
        }

        if (allowUserOverrides) {
            WeaponProfile override =
                    ITEM_OVERRIDES.get(
                            id
                    );

            if (override != null) {
                return override;
            }
        }

        /* Explicit pack-author inclusion wins over normal automatic detection. */
        if (Config.isExplicitWeaponIncluded(id)) {
            return fallbackProfile(ParryStyle.GENERIC);
        }

        /*
         * Vanilla progression policy: swords, axes, pickaxes and tridents are
         * supported. Shovels, hoes and the vanilla mace remain excluded unless
         * a pack author explicitly includes/overrides them above.
         */
        if ("minecraft".equals(id.getNamespace())) {
            String vanillaPath = id.getPath();
            if (item == Items.MACE
                    || vanillaPath.endsWith("_shovel")
                    || vanillaPath.endsWith("_hoe")) {
                return WeaponProfile.unknown();
            }
        }

        /*
         * Iron's Spells publishes several custom sword item classes and Better
         * Combat presets for its heavy blades. Resolve the concrete known
         * identities before the optional Better Combat metadata bridge so a
         * metadata mismatch cannot turn an otherwise valid Gyeokbu weapon into
         * the wrong loadout/handedness.
         */
        if ("irons_spellbooks".equals(id.getNamespace())) {
            if (containsAny(
                    id.getPath(),
                    "spellbreaker",
                    "claymore",
                    "keeper_flamberge",
                    "legionnaire_flamberge"
            )) {
                return twoHanded(
                        WeaponType.GREATSWORD,
                        DefenseFamily.HEAVY,
                        ParryStyle.GREATSWORD
                );
            }

            if (containsAny(
                    id.getPath(),
                    "hellrazor",
                    "decrepit_scythe"
            )) {
                return twoHanded(
                        WeaponType.SCYTHE,
                        DefenseFamily.POLEARM,
                        ParryStyle.SCYTHE
                );
            }
        }

        /*
         * Strong class-level signals do not depend on the registry/display name.
         * This catches mods that subclass normal Minecraft weapon/tool classes.
         */
        if (item instanceof TridentItem) {
            return twoHanded(
                    WeaponType.SPEAR,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR
            );
        }

        /*
         * Specialized common tags are allowed to provide a precise category.
         * Name heuristics still run afterward for mods that do not publish a
         * specialized tag but do use descriptive registry ids.
         */
        WeaponProfile specializedTagProfile =
                classifySpecializedTags(
                        stack
                );

        if (specializedTagProfile != null) {
            return specializedTagProfile;
        }

        String path =
                id.getPath()
                        .toLowerCase(
                                Locale.ROOT
                        );

        /*
         * ============================================================
         * THROWABLE IDENTITIES
         * ============================================================
         *
         * These MUST be checked before dagger/spear/axe fallbacks.
         *
         * They are recognized for future compatibility but currently return
         * isSupported() == false so native throw controls remain untouched.
         */
        if (containsAny(
                path,
                "throwing_knife",
                "throwingknife"
        )) {

            return throwable(
                    WeaponType.THROWING_KNIFE,
                    ParryStyle.THROWING_KNIFE
            );
        }

        if (containsAny(
                path,
                "tomahawk"
        )) {

            return throwable(
                    WeaponType.TOMAHAWK,
                    ParryStyle.TOMAHAWK
            );
        }

        if (containsAny(
                path,
                "javelin"
        )) {

            return throwable(
                    WeaponType.JAVELIN,
                    ParryStyle.JAVELIN
            );
        }

        if (containsAny(
                path,
                "boomerang"
        )) {

            return throwable(
                    WeaponType.BOOMERANG,
                    ParryStyle.BOOMERANG
            );
        }

        /*
         * ============================================================
         * SPECIFIC MELEE IDENTITIES
         * ============================================================
         *
         * Specific names come before broad names.
         */

        // Spartan / modded parrying dagger: ordinary 1H mechanics.
        if (containsAny(
                path,
                "parrying_dagger",
                "parryingdagger"
        )) {

            return oneHanded(
                    WeaponType.PARRYING_DAGGER,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.PARRYING_DAGGER
            );
        }

        // Longsword is intentionally distinct from broad "sword".
        if (containsAny(
                path,
                "longsword",
                "long_sword"
        )) {

            return oneHanded(
                    WeaponType.LONGSWORD,
                    DefenseFamily.SWORD,
                    ParryStyle.LONGSWORD
            );
        }

        // Saber / sabre family
        if (containsAny(
                path,
                "saber",
                "sabre"
        )) {

            return oneHanded(
                    WeaponType.SABER,
                    DefenseFamily.SWORD,
                    ParryStyle.SABER
            );
        }

        // Rapier / thrusting sword family
        if (containsAny(
                path,
                "rapier",
                "estoc"
        )) {

            return oneHanded(
                    WeaponType.RAPIER,
                    DefenseFamily.THRUSTING,
                    ParryStyle.RAPIER
            );
        }

        /*
         * Dagger keeps its own visual/classification identity but now uses
         * the ordinary one-handed mechanical baseline.
         */
        if (containsAny(
                path,
                "dagger",
                "knife",
                "sai"
        )) {

            return oneHanded(
                    WeaponType.DAGGER,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.DAGGER
            );
        }

        // Cestus / fist weapon
        if (containsAny(
                path,
                "cestus"
        )) {

            return oneHanded(
                    WeaponType.CESTUS,
                    DefenseFamily.UNARMED,
                    ParryStyle.CESTUS
            );
        }

        // Club is distinct from Mace mechanically.
        if (containsAny(
                path,
                "club",
                "baton"
        )) {

            return oneHanded(
                    WeaponType.CLUB,
                    DefenseFamily.BLUNT,
                    ParryStyle.CLUB
            );
        }

        // Greatswords
        if (containsAny(
                path,
                "greatsword",
                "great_sword",
                "claymore",
                "zweihander",
                "flamberge",
                "flamberg",
                "spellbreaker"
        )) {

            return twoHanded(
                    WeaponType.GREATSWORD,
                    DefenseFamily.HEAVY,
                    ParryStyle.GREATSWORD
            );
        }

        /*
         * Katana keeps its KATANA visual/classification identity but now uses
         * the ordinary two-handed mechanical baseline with no borrowed traits.
         */
        if (containsAny(
                path,
                "katana",
                "nodachi"
        )) {

            return twoHanded(
                    WeaponType.KATANA,
                    DefenseFamily.SWORD,
                    ParryStyle.KATANA
            );
        }

        // Pike keeps existing Gyeokbu 2H identity.
        if (containsAny(
                path,
                "pike"
        )) {

            return twoHanded(
                    WeaponType.PIKE,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR
            );
        }

        /*
         * Lance is intentionally 1H per the current Gyeokbu decision.
         * Check before the broad spear family.
         */
        if (containsAny(
                path,
                "lance"
        )) {

            return oneHanded(
                    WeaponType.LANCE,
                    DefenseFamily.THRUSTING,
                    ParryStyle.LANCE
            );
        }

        // Halberd is distinct from Glaive.
        if (containsAny(
                path,
                "halberd"
        )) {

            return twoHanded(
                    WeaponType.HALBERD,
                    DefenseFamily.POLEARM,
                    ParryStyle.HALBERD
            );
        }

        // Glaive / generic cutting polearm
        if (containsAny(
                path,
                "glaive",
                "polearm"
        )) {

            return twoHanded(
                    WeaponType.GLAIVE,
                    DefenseFamily.POLEARM,
                    ParryStyle.GLAIVE
            );
        }

        // Spear family keeps current Gyeokbu 2H baseline.
        if (containsAny(
                path,
                "spear",
                "trident"
        )) {

            return twoHanded(
                    WeaponType.SPEAR,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR
            );
        }

        // Quarterstaff is now a distinct identity.
        if (containsAny(
                path,
                "quarterstaff",
                "quarter_staff"
        )) {

            return twoHanded(
                    WeaponType.QUARTERSTAFF,
                    DefenseFamily.POLEARM,
                    ParryStyle.QUARTERSTAFF
            );
        }

        // Generic staff family
        if (containsAny(
                path,
                "staff"
        )) {

            return twoHanded(
                    WeaponType.STAFF,
                    DefenseFamily.POLEARM,
                    ParryStyle.STAFF
            );
        }

        // Sickle before scythe/tool fallbacks
        if (containsAny(
                path,
                "sickle"
        )) {

            return oneHanded(
                    WeaponType.SICKLE,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.SICKLE
            );
        }

        if (containsAny(
                path,
                "scythe",
                "hellrazor"
        )) {

            return twoHanded(
                    WeaponType.SCYTHE,
                    DefenseFamily.POLEARM,
                    ParryStyle.SCYTHE
            );
        }

        /*
         * Battle Hammer remains ordinary 2H.
         * This is distinct from Warhammer/Hammer for future balancing.
         */
        if (containsAny(
                path,
                "battle_hammer",
                "battlehammer",
                "great_hammer",
                "greathammer"
        )) {

            return twoHanded(
                    WeaponType.BATTLE_HAMMER,
                    DefenseFamily.HEAVY,
                    ParryStyle.BATTLE_HAMMER
            );
        }

        // Warhammer keeps the existing heavy / 2H behavior.
        if (containsAny(
                path,
                "warhammer",
                "war_hammer"
        )) {

            return twoHanded(
                    WeaponType.WARHAMMER,
                    DefenseFamily.HEAVY,
                    ParryStyle.WARHAMMER
            );
        }

        // Normal hammer = ordinary 1H.
        if (containsAny(
                path,
                "hammer"
        )) {

            return oneHanded(
                    WeaponType.HAMMER,
                    DefenseFamily.BLUNT,
                    ParryStyle.HAMMER
            );
        }

        /*
         * Flanged Mace keeps its visual/classification identity but uses the
         * ordinary one-handed mechanical baseline.
         */
        if (containsAny(
                path,
                "flanged_mace",
                "flangedmace"
        )) {

            return oneHanded(
                    WeaponType.FLANGED_MACE,
                    DefenseFamily.BLUNT,
                    ParryStyle.FLANGED_MACE
            );
        }

        /*
         * Mace keeps its visual/classification identity but uses the ordinary
         * one-handed mechanical baseline.
         */
        if (containsAny(
                path,
                "mace",
                "morningstar",
                "morning_star"
        )) {

            return oneHanded(
                    WeaponType.MACE,
                    DefenseFamily.BLUNT,
                    ParryStyle.MACE
            );
        }

        // Battleaxe is now distinct from generic AXE / tools.
        if (containsAny(
                path,
                "battleaxe",
                "battle_axe",
                "great_axe",
                "greataxe"
        )) {

            return twoHanded(
                    WeaponType.BATTLEAXE,
                    DefenseFamily.HEAVY,
                    ParryStyle.BATTLEAXE
            );
        }

        // Other curved sword names still use the ordinary Sword profile.
        if (containsAny(
                path,
                "cutlass",
                "falchion",
                "scimitar"
        )) {

            return oneHanded(
                    WeaponType.SWORD,
                    DefenseFamily.SWORD,
                    ParryStyle.SWORD
            );
        }

        /*
         * Registry-name compatibility for modded weapons whose namespace does
         * not match the mod-specific rules above.  These are strong weapon
         * identities and should never become unsupported merely because a mod
         * uses a different namespace or item class.
         */
        if (containsAny(
                path,
                "flamberge",
                "flamberg",
                "spellbreaker"
        )) {

            return twoHanded(
                    WeaponType.GREATSWORD,
                    DefenseFamily.HEAVY,
                    ParryStyle.GREATSWORD
            );
        }

        // Broad sword fallback
        if (containsAny(
                path,
                "sword",
                "broadsword",
                "blade"
        )) {

            return oneHanded(
                    WeaponType.SWORD,
                    DefenseFamily.SWORD,
                    ParryStyle.SWORD
            );
        }

        /*
         * Preserve the established name-based tool behavior before broad
         * metadata fallbacks. This avoids silently changing ordinary modded
         * axe/pickaxe/shovel/hoe mechanics while expanding weapon support.
         */
        if (isToolName(
                path
        )) {

            return toolProfile();
        }

        /*
         * Broad structured metadata comes after the more precise identities
         * above. A weapon called something opaque such as "spellbreaker" can
         * therefore still resolve from minecraft:swords or c:tools/melee_weapon
         * without sacrificing a precise Rapier/Spear/etc. identity when one was
         * already discoverable.
         */
        WeaponProfile broadMetadataProfile =
                classifyBroadMetadata(
                        item,
                        stack
                );

        if (broadMetadataProfile != null) {
            return broadMetadataProfile;
        }

        /*
         * Last automatic compatibility net: a main-hand ATTACK_DAMAGE modifier
         * is evidence that the item is intended to function as a weapon, but it
         * is still an UNKNOWN category.  Stance Fallback and Successful Parry
         * Fallback must be able to see that unknown result instead of having a
         * generic profile masquerade as a successfully classified weapon.
         */
        if (hasMainHandAttackDamage(stack)) {
            return WeaponProfile.unknown();
        }

        return WeaponProfile.unknown();
    }


    /**
     * Returns only stance types that are actually represented by at least one
     * naturally recognized Gyeokbu weapon in the currently loaded item
     * registry. GENERIC/Fallback is intentionally excluded; the F8 editor adds
     * it only when the held item itself is unrecognized.
     */
    public static List<ParryStyle> getDetectedParryStyles() {
        List<ParryStyle> cached = DETECTED_PARRY_STYLES;
        if (cached != null) {
            return cached;
        }

        synchronized (WeaponClassifier.class) {
            cached = DETECTED_PARRY_STYLES;
            if (cached != null) {
                return cached;
            }

            Set<ParryStyle> detected =
                    EnumSet.noneOf(ParryStyle.class);

            for (Item item : BuiltInRegistries.ITEM) {
                if (item == null || item == Items.AIR) {
                    continue;
                }

                WeaponProfile profile = classifyNatural(item);
                if (!profile.isSupported()) {
                    continue;
                }

                ParryStyle detectedStyle = profile.parryStyle();
                if (detectedStyle != null
                        && detectedStyle != ParryStyle.GENERIC) {
                    detected.add(detectedStyle);
                }
            }

            List<ParryStyle> ordered = new ArrayList<>();
            for (ParryStyle candidate : ParryStyle.values()) {
                if (detected.contains(candidate)) {
                    ordered.add(candidate);
                }
            }

            cached = List.copyOf(ordered);
            DETECTED_PARRY_STYLES = cached;
            return cached;
        }
    }

    public static boolean isParryStyleDetected(
            ParryStyle style
    ) {
        return style != null
                && style != ParryStyle.GENERIC
                && getDetectedParryStyles().contains(style);
    }

    private static void invalidateDetectedParryStyles() {
        DETECTED_PARRY_STYLES = null;
        WeaponProfileCatalog.invalidate();
    }

    public static void setUserFallback(
            ResourceLocation itemId,
            ParryStyle style
    ) {
        if (itemId == null
                || style == null) {
            return;
        }

        USER_FALLBACK_STYLES.put(
                itemId,
                style
        );
    }

    public static void removeUserFallback(
            ResourceLocation itemId
    ) {
        if (itemId == null) {
            return;
        }

        USER_FALLBACK_STYLES.remove(
                itemId
        );
    }

    public static void clearUserFallbacks() {
        USER_FALLBACK_STYLES.clear();
    }

    public static boolean isUserFallback(
            ResourceLocation itemId
    ) {
        return itemId != null
                && USER_FALLBACK_STYLES.containsKey(
                        itemId
                );
    }

    public static ParryStyle getUserFallbackStyle(
            ResourceLocation itemId
    ) {
        return itemId == null
                ? null
                : USER_FALLBACK_STYLES.get(
                        itemId
                );
    }

    private static WeaponProfile fallbackProfile(
            ParryStyle style
    ) {
        return profile(
                WeaponType.GENERIC,
                HandStyle.ONE_HANDED,
                DefenseFamily.UNKNOWN,
                style == null
                        ? ParryStyle.GENERIC
                        : style,

                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,

                false,

                true,
                true,
                0.50F
        );
    }

    public static void setOverride(
            ResourceLocation itemId,
            WeaponProfile profile
    ) {

        if (itemId == null
                || profile == null) {

            return;
        }

        ITEM_OVERRIDES.put(
                itemId,
                profile
        );

        invalidateDetectedParryStyles();
    }

    public static void removeOverride(
            ResourceLocation itemId
    ) {

        if (itemId == null) {
            return;
        }

        ITEM_OVERRIDES.remove(
                itemId
        );

        invalidateDetectedParryStyles();
    }

    public static void clearOverrides() {

        ITEM_OVERRIDES.clear();
        invalidateDetectedParryStyles();
    }

    public static WeaponProfile getOverride(
            ResourceLocation itemId
    ) {

        return ITEM_OVERRIDES.get(
                itemId
        );
    }

    private static WeaponProfile oneHanded(
            WeaponType type,
            DefenseFamily family,
            ParryStyle parryStyle
    ) {

        return profile(
                type,
                HandStyle.ONE_HANDED,
                family,
                parryStyle,

                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,

                false,

                true,
                true,
                0.50F
        );
    }

    private static WeaponProfile twoHanded(
            WeaponType type,
            DefenseFamily family,
            ParryStyle parryStyle
    ) {

        return profile(
                type,
                HandStyle.TWO_HANDED,
                family,
                parryStyle,

                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,

                false,

                true,
                true,
                0.40F
        );
    }

    private static WeaponProfile throwable(
            WeaponType type,
            ParryStyle parryStyle
    ) {

        /*
         * Dedicated throwing weapons currently use the ordinary 1H baseline
         * when Gyeokbu is activated through the dedicated key.
         *
         * Their exact special stats can be balanced later.
         */
        return profile(
                type,
                HandStyle.ONE_HANDED,
                DefenseFamily.THROWABLE,
                parryStyle,

                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,

                false,

                true,
                true,
                0.50F
        );
    }

    private static WeaponProfile toolProfile() {

        return profile(
                WeaponType.TOOL,
                HandStyle.ONE_HANDED,
                DefenseFamily.TOOL,
                ParryStyle.TOOL,

                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,
                TraitStyle.INHERIT,

                false,

                false,
                true,
                0.85F
        );
    }

    private static WeaponProfile profile(
            WeaponType type,
            HandStyle handStyle,
            DefenseFamily family,
            ParryStyle parryStyle,

            TraitStyle perfectParryStyle,
            TraitStyle normalCounterDamageStyle,
            TraitStyle perfectCounterDamageStyle,
            TraitStyle stunStyle,

            boolean reflectOnNormalParry,

            boolean canStun,
            boolean canKnockback,
            float blockDamageMultiplier
    ) {

        return new WeaponProfile(
                type,
                handStyle,
                family,
                parryStyle,

                perfectParryStyle,
                normalCounterDamageStyle,
                perfectCounterDamageStyle,
                stunStyle,

                reflectOnNormalParry,

                canStun,
                canKnockback,
                blockDamageMultiplier
        );
    }

    private static WeaponProfile classifyBetterCombatMetadata(
            BetterCombatWeaponMetadata.Metadata metadata
    ) {
        if (metadata == null || !metadata.present()) {
            return null;
        }

        String descriptor = (
                (metadata.category() == null ? "" : metadata.category())
                        + " "
                        + (metadata.pose() == null ? "" : metadata.pose())
        ).toLowerCase(Locale.ROOT);

        boolean twoHanded = metadata.twoHanded();

        /* Specific identities must precede broad sword/axe/hammer terms. */
        if (containsAny(descriptor, "parrying_dagger", "parryingdagger")) {
            return handed(
                    WeaponType.PARRYING_DAGGER,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.PARRYING_DAGGER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "greatsword", "great_sword", "claymore",
                "zweihander", "two_handed_sword", "two-handed-sword")) {
            return handed(
                    WeaponType.GREATSWORD,
                    DefenseFamily.HEAVY,
                    ParryStyle.GREATSWORD,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "longsword", "long_sword")) {
            return handed(
                    WeaponType.LONGSWORD,
                    DefenseFamily.SWORD,
                    ParryStyle.LONGSWORD,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "saber", "sabre")) {
            return handed(
                    WeaponType.SABER,
                    DefenseFamily.SWORD,
                    ParryStyle.SABER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "rapier", "estoc")) {
            return handed(
                    WeaponType.RAPIER,
                    DefenseFamily.THRUSTING,
                    ParryStyle.RAPIER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "dagger", "knife", "sai")) {
            return handed(
                    WeaponType.DAGGER,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.DAGGER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "katana", "nodachi")) {
            return handed(
                    WeaponType.KATANA,
                    DefenseFamily.SWORD,
                    ParryStyle.KATANA,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "pike")) {
            return handed(
                    WeaponType.PIKE,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "lance")) {
            return handed(
                    WeaponType.LANCE,
                    DefenseFamily.THRUSTING,
                    ParryStyle.LANCE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "halberd")) {
            return handed(
                    WeaponType.HALBERD,
                    DefenseFamily.POLEARM,
                    ParryStyle.HALBERD,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "glaive", "polearm")) {
            return handed(
                    WeaponType.GLAIVE,
                    DefenseFamily.POLEARM,
                    ParryStyle.GLAIVE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "spear", "trident")) {
            return handed(
                    WeaponType.SPEAR,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "quarterstaff", "quarter_staff")) {
            return handed(
                    WeaponType.QUARTERSTAFF,
                    DefenseFamily.POLEARM,
                    ParryStyle.QUARTERSTAFF,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "staff")) {
            return handed(
                    WeaponType.STAFF,
                    DefenseFamily.POLEARM,
                    ParryStyle.STAFF,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "sickle")) {
            return handed(
                    WeaponType.SICKLE,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.SICKLE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "scythe")) {
            return handed(
                    WeaponType.SCYTHE,
                    DefenseFamily.POLEARM,
                    ParryStyle.SCYTHE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "battle_hammer", "battlehammer",
                "great_hammer", "greathammer")) {
            return handed(
                    WeaponType.BATTLE_HAMMER,
                    DefenseFamily.HEAVY,
                    ParryStyle.BATTLE_HAMMER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "warhammer", "war_hammer")) {
            return handed(
                    WeaponType.WARHAMMER,
                    DefenseFamily.HEAVY,
                    ParryStyle.WARHAMMER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "hammer")) {
            return handed(
                    WeaponType.HAMMER,
                    DefenseFamily.BLUNT,
                    ParryStyle.HAMMER,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "flanged_mace", "flangedmace")) {
            return handed(
                    WeaponType.FLANGED_MACE,
                    DefenseFamily.BLUNT,
                    ParryStyle.FLANGED_MACE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "mace")) {
            return handed(
                    WeaponType.MACE,
                    DefenseFamily.BLUNT,
                    ParryStyle.MACE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "club", "baton")) {
            return handed(
                    WeaponType.CLUB,
                    DefenseFamily.BLUNT,
                    ParryStyle.CLUB,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "battleaxe", "battle_axe", "great_axe", "greataxe")) {
            return handed(
                    WeaponType.BATTLEAXE,
                    DefenseFamily.HEAVY,
                    ParryStyle.BATTLEAXE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "axe")) {
            return handed(
                    WeaponType.AXE,
                    DefenseFamily.HEAVY,
                    ParryStyle.AXE,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "cestus", "fist")) {
            return handed(
                    WeaponType.CESTUS,
                    DefenseFamily.UNARMED,
                    ParryStyle.CESTUS,
                    twoHanded
            );
        }

        if (containsAny(descriptor, "sword", "blade", "cutlass", "falchion", "scimitar")) {
            return handed(
                    WeaponType.SWORD,
                    DefenseFamily.SWORD,
                    ParryStyle.SWORD,
                    twoHanded
            );
        }

        /*
         * Better Combat knows this is a weapon, but its category is not one
         * Gyeokbu can identify.  Return null so the caller can continue through
         * Gyeokbu's category/tag/name detection while still retaining BC's
         * handedness for the final result.
         */
        return null;
    }

    private static WeaponProfile handed(
            WeaponType type,
            DefenseFamily family,
            ParryStyle parryStyle,
            boolean twoHanded
    ) {
        return twoHanded
                ? twoHanded(type, family, parryStyle)
                : oneHanded(type, family, parryStyle);
    }

    private static WeaponProfile classifySpecializedTags(
            ItemStack stack
    ) {
        if (stack == null || stack.isEmpty()) {
            return null;
        }

        if (stack.is(COMMON_RAPIERS)) {
            return oneHanded(
                    WeaponType.RAPIER,
                    DefenseFamily.THRUSTING,
                    ParryStyle.RAPIER
            );
        }

        if (stack.is(COMMON_DAGGERS)) {
            return oneHanded(
                    WeaponType.DAGGER,
                    DefenseFamily.LIGHT_BLADE,
                    ParryStyle.DAGGER
            );
        }

        if (stack.is(COMMON_HALBERDS)) {
            return twoHanded(
                    WeaponType.HALBERD,
                    DefenseFamily.POLEARM,
                    ParryStyle.HALBERD
            );
        }

        if (stack.is(COMMON_GLAIVES)) {
            return twoHanded(
                    WeaponType.GLAIVE,
                    DefenseFamily.POLEARM,
                    ParryStyle.GLAIVE
            );
        }

        if (stack.is(COMMON_SPEARS)) {
            return twoHanded(
                    WeaponType.SPEAR,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR
            );
        }

        if (stack.is(COMMON_HAMMERS)) {
            return oneHanded(
                    WeaponType.HAMMER,
                    DefenseFamily.BLUNT,
                    ParryStyle.HAMMER
            );
        }

        if (stack.is(COMMON_MACES)) {
            return oneHanded(
                    WeaponType.MACE,
                    DefenseFamily.BLUNT,
                    ParryStyle.MACE
            );
        }

        if (stack.is(COMMON_STAVES)) {
            return twoHanded(
                    WeaponType.STAFF,
                    DefenseFamily.POLEARM,
                    ParryStyle.STAFF
            );
        }

        if (stack.is(COMMON_SCYTHES)) {
            return twoHanded(
                    WeaponType.SCYTHE,
                    DefenseFamily.POLEARM,
                    ParryStyle.SCYTHE
            );
        }

        return null;
    }

    private static WeaponProfile classifyBroadMetadata(
            Item item,
            ItemStack stack
    ) {
        if (stack == null || stack.isEmpty()) {
            return null;
        }

        if (stack.is(MINECRAFT_TRIDENT_ENCHANTABLE)) {
            return twoHanded(
                    WeaponType.SPEAR,
                    DefenseFamily.THRUSTING,
                    ParryStyle.SPEAR
            );
        }

        if (item instanceof SwordItem
                || stack.is(MINECRAFT_SWORDS)
                || stack.is(MINECRAFT_SWORD_ENCHANTABLE)
                || stack.is(COMMON_SWORDS)) {
            return oneHanded(
                    WeaponType.SWORD,
                    DefenseFamily.SWORD,
                    ParryStyle.SWORD
            );
        }

        if (item instanceof AxeItem
                || stack.is(MINECRAFT_AXES)
                || stack.is(COMMON_AXES)) {
            return toolProfile();
        }

        if (item instanceof PickaxeItem
                || stack.is(MINECRAFT_PICKAXES)) {
            return toolProfile();
        }

        if (stack.is(COMMON_MELEE_WEAPONS)
                || stack.is(MINECRAFT_WEAPON_ENCHANTABLE)) {
            return fallbackProfile(
                    ParryStyle.GENERIC
            );
        }

        return null;
    }

    private static boolean hasMainHandAttackDamage(
            ItemStack stack
    ) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }

        final boolean[] found = {false};

        stack.forEachModifier(
                EquipmentSlot.MAINHAND,
                (attribute, modifier) -> {
                    if (found[0]
                            || !attribute.equals(Attributes.ATTACK_DAMAGE)) {
                        return;
                    }

                    if (modifier.amount() > 0.0D) {
                        found[0] = true;
                    }
                }
        );

        return found[0];
    }

    private static TagKey<Item> itemTag(
            String namespace,
            String path
    ) {
        return TagKey.create(
                Registries.ITEM,
                ResourceLocation.fromNamespaceAndPath(
                        namespace,
                        path
                )
        );
    }

    private static boolean isToolName(
            String path
    ) {

        return containsAny(
                path,
                "pickaxe",
                "pick",
                "shovel",
                "spade",
                "hoe",
                "axe"
        );
    }

    private static boolean containsAny(
            String value,
            String... terms
    ) {

        for (String term : terms) {

            if (value.contains(
                    term
            )) {

                return true;
            }
        }

        return false;
    }
}
