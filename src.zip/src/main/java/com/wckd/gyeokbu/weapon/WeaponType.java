package com.wckd.gyeokbu.weapon;

public enum WeaponType {

    SWORD,
    LONGSWORD,
    SABER,

    RAPIER,

    DAGGER,
    PARRYING_DAGGER,

    GREATSWORD,
    KATANA,

    SPEAR,
    PIKE,
    LANCE,

    GLAIVE,
    HALBERD,

    AXE,
    BATTLEAXE,

    HAMMER,
    WARHAMMER,
    BATTLE_HAMMER,

    MACE,
    FLANGED_MACE,
    CLUB,

    STAFF,
    QUARTERSTAFF,

    SCYTHE,
    SICKLE,

    CESTUS,

    /*
     * Recognized now for compatibility, but normal Gyeokbu defense remains
     * disabled until the dedicated throwable-input lockout is implemented.
     */
    THROWING_KNIFE,
    TOMAHAWK,
    JAVELIN,
    BOOMERANG,

    TOOL,

    GENERIC,

    UNKNOWN
}
