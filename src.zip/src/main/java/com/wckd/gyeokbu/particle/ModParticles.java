package com.wckd.gyeokbu.particle;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModParticles {

    public static final DeferredRegister<ParticleType<?>>
            PARTICLE_TYPES =
            DeferredRegister.create(
                    BuiltInRegistries.PARTICLE_TYPE,
                    GyeokbuV2.MODID
            );

    /*
     * The four stun particles share the vanilla critical-hit texture and
     * differ only in render scale. Parry sparks use the same texture with
     * their own client-side lifetime/movement behavior.
     */

    public static final DeferredHolder<
            ParticleType<?>,
            SimpleParticleType
            > STUN_CRIT_BIG =
            PARTICLE_TYPES.register(
                    "stun_crit_big",
                    () -> new SimpleParticleType(
                            false
                    )
            );

    public static final DeferredHolder<
            ParticleType<?>,
            SimpleParticleType
            > STUN_CRIT_MEDIUM =
            PARTICLE_TYPES.register(
                    "stun_crit_medium",
                    () -> new SimpleParticleType(
                            false
                    )
            );

    public static final DeferredHolder<
            ParticleType<?>,
            SimpleParticleType
            > STUN_CRIT_SMALL =
            PARTICLE_TYPES.register(
                    "stun_crit_small",
                    () -> new SimpleParticleType(
                            false
                    )
            );

    public static final DeferredHolder<
            ParticleType<?>,
            SimpleParticleType
            > STUN_CRIT_TINY =
            PARTICLE_TYPES.register(
                    "stun_crit_tiny",
                    () -> new SimpleParticleType(
                            false
                    )
            );

    public static final DeferredHolder<
            ParticleType<?>,
            SimpleParticleType
            > PARRY_SPARK =
            PARTICLE_TYPES.register(
                    "parry_spark",
                    () -> new SimpleParticleType(
                            false
                    )
            );

    private ModParticles() {
    }
}