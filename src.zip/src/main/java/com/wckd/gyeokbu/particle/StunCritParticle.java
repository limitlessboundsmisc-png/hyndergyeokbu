package com.wckd.gyeokbu.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

public final class StunCritParticle
        extends TextureSheetParticle {

    private StunCritParticle(
            ClientLevel level,
            double x,
            double y,
            double z,
            SpriteSet spriteSet,
            float scale
    ) {

        super(
                level,
                x,
                y,
                z
        );

        /*
         * These particles don't move themselves.
         *
         * StunManager controls their orbit by spawning
         * them at a new position every server tick.
         */
        this.xd = 0.0D;
        this.yd = 0.0D;
        this.zd = 0.0D;

        this.gravity =
                0.0F;

        this.hasPhysics =
                false;

        /*
         * VERY IMPORTANT:
         *
         * Lifetime = 1 tick.
         *
         * StunManager spawns exactly four particles
         * every tick.
         *
         * By removing them on the next particle tick,
         * old trail particles do not accumulate.
         */
        this.lifetime =
                1;

        /*
         * Actual render size.
         *
         * Unlike our previous fake approach,
         * this really changes the particle's quad size.
         */
        this.quadSize *=
                scale;

        /*
         * Keep the vanilla sprite coloring.
         */
        this.rCol = 1.0F;
        this.gCol = 1.0F;
        this.bCol = 1.0F;

        this.alpha =
                1.0F;

        /*
         * There is only one sprite in each particle
         * description, but SpriteSet still needs to
         * choose it.
         */
        this.setSpriteFromAge(
                spriteSet
        );
    }

    @Override
    public ParticleRenderType getRenderType() {

        return ParticleRenderType
                .PARTICLE_SHEET_TRANSLUCENT;
    }

    /*
     * Generic provider with a configurable scale.
     */
    public static final class Provider
            implements ParticleProvider<SimpleParticleType> {

        private final SpriteSet spriteSet;
        private final float scale;

        public Provider(
                SpriteSet spriteSet,
                float scale
        ) {

            this.spriteSet =
                    spriteSet;

            this.scale =
                    scale;
        }

        @Override
        public Particle createParticle(
                SimpleParticleType type,
                ClientLevel level,
                double x,
                double y,
                double z,
                double xSpeed,
                double ySpeed,
                double zSpeed
        ) {

            return new StunCritParticle(
                    level,
                    x,
                    y,
                    z,
                    spriteSet,
                    scale
            );
        }
    }
}