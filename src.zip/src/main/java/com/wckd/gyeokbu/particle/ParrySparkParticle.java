package com.wckd.gyeokbu.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.wckd.gyeokbu.client.ParryParticleTransitionConfig;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

/** Successful-Parry spark with configurable motion, color and opacity. */
public final class ParrySparkParticle extends TextureSheetParticle {

    private static final float START_SIZE_FACTOR = 0.928F;
    private static final double PREVIOUS_TRAVEL_FACTOR = 4.4632992768D;
    private static final double EXPANSION_MULTIPLIER = 1.50D;
    private static final double FALL_ACCELERATION = 0.025D;

    private static final ConcurrentHashMap<Integer, Integer> ACTIVE_BURSTS =
            new ConcurrentHashMap<>();
    private static final ThreadLocal<BurstContext> CREATION_CONTEXT = new ThreadLocal<>();

    private final int burstDefenderId;
    private final int burstGeneration;
    private final ParryParticleTransitionConfig.Motion motion;
    private final float configuredAlpha;
    private final float configuredRed;
    private final float configuredGreen;
    private final float configuredBlue;
    private final float startingQuadSize;
    private final double originX;
    private final double originY;
    private final double originZ;
    private final double travelX;
    private final double travelY;
    private final double travelZ;
    private final double fallVelocityX;
    private final double fallVelocityY;
    private final double fallVelocityZ;
    /** Each spark gets its own fixed rotation direction for the whole burst. */
    private final int turnDirection;

    /**
     * Starts a new successful-Parry burst. Older Gyeokbu Parry sparks remove
     * themselves on their next tick, so rapid multi-Parries never overlay.
     */
    public static void beginBurst(int defenderEntityId, int[] palette) {
        int generation = ACTIVE_BURSTS.merge(defenderEntityId, 1, Integer::sum);
        int[] safePalette = palette == null || palette.length == 0
                ? new int[]{0xFFFFFF}
                : Arrays.copyOf(palette, palette.length);
        CREATION_CONTEXT.set(new BurstContext(
                defenderEntityId,
                generation,
                safePalette,
                ParryParticleTransitionConfig.opacity()
        ));
    }

    public static void endBurst() {
        CREATION_CONTEXT.remove();
    }

    private ParrySparkParticle(
            ClientLevel level,
            double x,
            double y,
            double z,
            double xSpeed,
            double ySpeed,
            double zSpeed,
            SpriteSet spriteSet
    ) {
        super(level, x, y, z);

        BurstContext context = CREATION_CONTEXT.get();
        this.burstDefenderId = context == null ? -1 : context.defenderEntityId();
        this.burstGeneration = context == null ? 0 : context.generation();
        this.motion = ParryParticleTransitionConfig.motion();
        this.configuredAlpha = context == null
                ? ParryParticleTransitionConfig.opacity()
                : context.opacity();

        int[] palette = context == null ? new int[]{0xFFFFFF} : context.palette();
        int rgb = palette[ThreadLocalRandom.current().nextInt(palette.length)];
        this.configuredRed = ((rgb >> 16) & 0xFF) / 255.0F;
        this.configuredGreen = ((rgb >> 8) & 0xFF) / 255.0F;
        this.configuredBlue = (rgb & 0xFF) / 255.0F;

        this.gravity = 0.0F;
        this.friction = 1.0F;
        this.hasPhysics = false;
        this.lifetime = ParryParticleTransitionConfig.durationTicks();

        this.originX = x;
        this.originY = y;
        this.originZ = z;

        double travelFactor = PREVIOUS_TRAVEL_FACTOR * EXPANSION_MULTIPLIER;
        this.travelX = xSpeed * travelFactor;
        this.travelY = ySpeed * travelFactor;
        this.travelZ = zSpeed * travelFactor;

        /* Fall-only keeps the burst close to the contact point. It inherits
         * only a little of the shape vector as inertia, then gravity becomes
         * the dominant motion instead of the normal outward expansion. */
        this.fallVelocityX = xSpeed * 0.18D;
        this.fallVelocityY = Math.abs(ySpeed) * 0.18D + 0.025D;
        this.fallVelocityZ = zSpeed * 0.18D;
        this.turnDirection = ThreadLocalRandom.current().nextBoolean() ? 1 : -1;

        this.xd = 0.0D;
        this.yd = 0.0D;
        this.zd = 0.0D;

        this.quadSize *= START_SIZE_FACTOR * ParryParticleTransitionConfig.size();
        this.startingQuadSize = this.quadSize;

        applyAppearance();
        this.setSpriteFromAge(spriteSet);
    }

    @Override
    public void tick() {
        if (this.burstDefenderId >= 0
                && ACTIVE_BURSTS.getOrDefault(this.burstDefenderId, 0) != this.burstGeneration) {
            this.remove();
            return;
        }

        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }

        /*
         * Rotation is deliberately discrete. Every configured delay interval
         * the spark snaps exactly 90 degrees, then waits for the next interval.
         * A delay of 1 tick therefore produces a turn every tick.
         */
        int turnDelay = ParryParticleTransitionConfig.turnDelayTicks();
        if (turnDelay > 0 && this.age % turnDelay == 0) {
            this.roll += this.turnDirection * (float) (Math.PI * 0.5D);
            /* Keep previous and current roll identical so Minecraft's
             * partial-tick interpolation cannot smooth the 90° snap. */
            this.oRoll = this.roll;
        } else {
            this.oRoll = this.roll;
        }

        float rawProgress = (float) this.age / (float) Math.max(1, this.lifetime);
        float expansionProgress = ParryParticleTransitionConfig.applyCurve(rawProgress);

        double motionX;
        double motionY;
        double motionZ;

        if (this.motion == ParryParticleTransitionConfig.Motion.FALL) {
            /* Ballistic sparks: initial directional motion + gravity. */
            motionX = this.fallVelocityX * this.age;
            motionY = this.fallVelocityY * this.age;
            motionZ = this.fallVelocityZ * this.age;
        } else {
            motionX = this.motion.expands() ? this.travelX * expansionProgress : 0.0D;
            motionY = this.motion.expands() ? this.travelY * expansionProgress : 0.0D;
            motionZ = this.motion.expands() ? this.travelZ * expansionProgress : 0.0D;
        }

        /* y = v*t - 1/2*a*t^2 gives Fall/Expand+Fall a gravity-like drop. */
        double fall = this.motion.falls()
                ? 0.5D * FALL_ACCELERATION * this.age * this.age
                : 0.0D;

        /*
         * Successful-Parry sparks are world-space impact effects. Once the
         * contact point is chosen they stay there; player/camera movement must
         * never drag the burst along in third person. ClientParryFeedback
         * places the origin toward the actual incoming contact side first.
         */
        this.setPos(
                this.originX + motionX,
                this.originY + motionY - fall,
                this.originZ + motionZ
        );

        /* Keep 100% -> 0% disappearance by scale; opacity itself does not fade. */
        float shrinkProgress = (float) this.age / (float) Math.max(1, this.lifetime);
        this.quadSize = this.startingQuadSize * Math.max(0.0F, 1.0F - shrinkProgress);
        applyAppearance();
    }

    private void applyAppearance() {
        this.rCol = configuredRed;
        this.gCol = configuredGreen;
        this.bCol = configuredBlue;
        this.alpha = configuredAlpha;
    }

    @Override
    public void render(VertexConsumer buffer, Camera camera, float partialTicks) {
        /*
         * A newer successful-Parry burst immediately supersedes the previous
         * one. This render-time guard prevents even a single frame of overlap
         * when two Parries succeed between client particle ticks.
         */
        if (this.burstDefenderId >= 0
                && ACTIVE_BURSTS.getOrDefault(this.burstDefenderId, 0) != this.burstGeneration) {
            return;
        }

        super.render(buffer, camera, partialTicks);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    private record BurstContext(
            int defenderEntityId,
            int generation,
            int[] palette,
            float opacity
    ) {
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet spriteSet;

        public Provider(SpriteSet spriteSet) {
            this.spriteSet = spriteSet;
        }

        @Override
        public Particle createParticle(
                SimpleParticleType type,
                ClientLevel level,
                double x,
                double y,
                double z,
                double xSpeed,
                double ySpeed,
                double zSpeed
        ) {
            return new ParrySparkParticle(
                    level,
                    x,
                    y,
                    z,
                    xSpeed,
                    ySpeed,
                    zSpeed,
                    spriteSet
            );
        }
    }
}
