package com.wckd.gyeokbu.enchantment;

import com.wckd.gyeokbu.Config;
import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.ItemEnchantments;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Shared final-roll filtering used before the enchanting-table clue/result is exposed. */
public final class GyeokbuEnchantingRules {
    private static final int MAX_BACKTRACK_CANDIDATES = 18;

    private GyeokbuEnchantingRules() {
    }

    public static List<EnchantmentInstance> filterTableRoll(
            ItemStack stack,
            List<EnchantmentInstance> generated
    ) {
        if (stack == null || stack.isEmpty() || generated == null || generated.isEmpty()) {
            return generated == null ? List.of() : generated;
        }

        if (!Config.SURVIVAL_ACQUISITION_ENABLED.getAsBoolean()) {
            return removeAllGyeokbuEnchantments(generated);
        }

        /* Books are carriers: requirements are intentionally ignored here. */
        if (stack.is(Items.BOOK) || stack.is(Items.ENCHANTED_BOOK)) {
            return filterCarrierBook(generated);
        }

        /* Shields stay book/anvil-only for Gyeokbu even if another mod enchants them at a table. */
        if (GyeokbuEnchantments.isShield(stack)) {
            return removeAllGyeokbuEnchantments(generated);
        }

        if (!GyeokbuEnchantments.isEligibleWeaponForEnchantments(stack)) {
            return removeAllGyeokbuEnchantments(generated);
        }

        return filterWeaponRoll(stack, generated);
    }

    private static List<EnchantmentInstance> filterCarrierBook(List<EnchantmentInstance> generated) {
        List<EnchantmentInstance> result = new ArrayList<>(generated.size());
        Set<Holder<Enchantment>> acceptedGyeokbu = new HashSet<>();

        for (EnchantmentInstance instance : generated) {
            Holder<Enchantment> enchantment = instance.enchantment;
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)) {
                result.add(instance);
                continue;
            }

            if (GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)
                    || conflictsWith(enchantment, acceptedGyeokbu)) {
                continue;
            }

            acceptedGyeokbu.add(enchantment);
            result.add(instance);
        }

        return result;
    }

    private static List<EnchantmentInstance> removeAllGyeokbuEnchantments(
            List<EnchantmentInstance> generated
    ) {
        List<EnchantmentInstance> result = new ArrayList<>(generated.size());
        for (EnchantmentInstance instance : generated) {
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(instance.enchantment)) {
                result.add(instance);
            }
        }
        return result;
    }

    private static List<EnchantmentInstance> filterWeaponRoll(
            ItemStack stack,
            List<EnchantmentInstance> generated
    ) {
        ItemEnchantments existingEnchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        Set<Holder<Enchantment>> existingGyeokbu = new HashSet<>();
        Set<Holder<Enchantment>> existingVanillaBridges = new HashSet<>();
        for (Holder<Enchantment> enchantment : existingEnchantments.keySet()) {
            if (GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)
                    && !GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                existingGyeokbu.add(enchantment);
            } else if (GyeokbuEnchantments.isVanillaGyeokbuBridge(enchantment)) {
                existingVanillaBridges.add(enchantment);
            }
        }

        /* Preserve first appearance/order if a modded table somehow duplicates a key. */
        Map<Holder<Enchantment>, Integer> candidateIndexes = new LinkedHashMap<>();
        for (EnchantmentInstance instance : generated) {
            Holder<Enchantment> enchantment = instance.enchantment;
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)
                    || GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                continue;
            }
            candidateIndexes.computeIfAbsent(enchantment, ignored -> candidateIndexes.size());
        }

        if (candidateIndexes.isEmpty()) {
            return generated;
        }

        if (candidateIndexes.size() > MAX_BACKTRACK_CANDIDATES) {
            /* Defensive fallback; vanilla-sized rolls never approach this count. */
            return greedyFilter(stack, generated, existingGyeokbu, existingVanillaBridges);
        }

        List<Holder<Enchantment>> candidates = new ArrayList<>(candidateIndexes.keySet());
        boolean[] selected = new boolean[candidates.size()];
        boolean[] solution = findLexicographicSolution(
                0,
                selected,
                candidates,
                candidateIndexes,
                generated,
                stack,
                existingGyeokbu,
                existingVanillaBridges
        );

        if (solution == null) {
            return removeAllGyeokbuEnchantments(generated);
        }

        List<EnchantmentInstance> result = new ArrayList<>(generated.size());
        for (EnchantmentInstance instance : generated) {
            Holder<Enchantment> enchantment = instance.enchantment;
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)) {
                result.add(instance);
                continue;
            }

            Integer index = candidateIndexes.get(enchantment);
            if (index != null && solution[index]) {
                result.add(instance);
            }
        }
        return result;
    }

    /**
     * Inclusion is attempted before exclusion at each generated position. The
     * first complete valid solution therefore obeys generated-order priority
     * while still looking ahead for Block dependencies later in the same roll.
     */
    private static boolean[] findLexicographicSolution(
            int index,
            boolean[] selected,
            List<Holder<Enchantment>> candidates,
            Map<Holder<Enchantment>, Integer> candidateIndexes,
            List<EnchantmentInstance> generated,
            ItemStack stack,
            Set<Holder<Enchantment>> existingGyeokbu,
            Set<Holder<Enchantment>> existingVanillaBridges
    ) {
        if (index >= candidates.size()) {
            if (isFeasibleSelection(
                    selected, candidates, candidateIndexes, generated, stack,
                    existingGyeokbu, existingVanillaBridges)) {
                return selected.clone();
            }
            return null;
        }

        selected[index] = true;
        boolean[] with = findLexicographicSolution(
                index + 1, selected, candidates, candidateIndexes, generated, stack,
                existingGyeokbu, existingVanillaBridges);
        if (with != null) {
            return with;
        }

        selected[index] = false;
        return findLexicographicSolution(
                index + 1, selected, candidates, candidateIndexes, generated, stack,
                existingGyeokbu, existingVanillaBridges);
    }

    private static boolean isFeasibleSelection(
            boolean[] selected,
            List<Holder<Enchantment>> candidates,
            Map<Holder<Enchantment>, Integer> candidateIndexes,
            List<EnchantmentInstance> generated,
            ItemStack stack,
            Set<Holder<Enchantment>> existingGyeokbu,
            Set<Holder<Enchantment>> existingVanillaBridges
    ) {
        Set<Holder<Enchantment>> chosen = new HashSet<>(existingGyeokbu);
        for (int i = 0; i < candidates.size(); i++) {
            if (!selected[i]) {
                continue;
            }
            Holder<Enchantment> candidate = candidates.get(i);
            if (conflictsWith(candidate, chosen)) {
                return false;
            }
            chosen.add(candidate);
        }

        boolean blockProvider = containsKey(chosen, GyeokbuEnchantments.BLOCK)
                || containsKey(chosen, GyeokbuEnchantments.PERFECT_BLOCK);
        if (!blockProvider) {
            for (int i = 0; i < candidates.size(); i++) {
                if (selected[i] && GyeokbuEnchantments.requiresBlockProvider(candidates.get(i))) {
                    return false;
                }
            }
        }

        int capacity = GyeokbuEnchantments.getCapacity(stack);
        int usedSlots = GyeokbuEnchantments.countOccupiedGyeokbuSlots(stack);
        Set<Holder<Enchantment>> chargedExisting = new HashSet<>(existingGyeokbu);
        Set<Holder<Enchantment>> chargedVanillaBridges = new HashSet<>(existingVanillaBridges);

        for (EnchantmentInstance instance : generated) {
            Holder<Enchantment> enchantment = instance.enchantment;
            Integer candidateIndex = candidateIndexes.get(enchantment);

            if (candidateIndex != null) {
                if (!selected[candidateIndex]) {
                    continue;
                }
                if (chargedExisting.add(enchantment)) {
                    int cost = GyeokbuEnchantments.getOriginalSlotCost(enchantment);
                    if (usedSlots + cost > capacity) {
                        return false;
                    }
                    usedSlots += cost;
                }
                continue;
            }

            /* Vanilla Knockback/Fire Aspect always remain vanilla enchantments;
             * this only determines whether their extra Gyeokbu behavior claims
             * a remaining slot before later generated Gyeokbu candidates. */
            if (GyeokbuEnchantments.isVanillaGyeokbuBridge(enchantment)
                    && chargedVanillaBridges.add(enchantment)
                    && usedSlots < capacity) {
                usedSlots++;
            }
        }

        return true;
    }

    private static List<EnchantmentInstance> greedyFilter(
            ItemStack stack,
            List<EnchantmentInstance> generated,
            Set<Holder<Enchantment>> existingGyeokbu,
            Set<Holder<Enchantment>> existingVanillaBridges
    ) {
        int capacity = GyeokbuEnchantments.getCapacity(stack);
        int usedSlots = GyeokbuEnchantments.countOccupiedGyeokbuSlots(stack);
        Set<Holder<Enchantment>> accepted = new HashSet<>(existingGyeokbu);
        Set<Holder<Enchantment>> chargedVanillaBridges = new HashSet<>(existingVanillaBridges);
        List<EnchantmentInstance> result = new ArrayList<>(generated.size());

        boolean generatedProvider = false;
        for (EnchantmentInstance instance : generated) {
            if (instance.enchantment.is(GyeokbuEnchantments.BLOCK)
                    || instance.enchantment.is(GyeokbuEnchantments.PERFECT_BLOCK)) {
                generatedProvider = true;
                break;
            }
        }
        boolean hasProvider = generatedProvider
                || containsKey(existingGyeokbu, GyeokbuEnchantments.BLOCK)
                || containsKey(existingGyeokbu, GyeokbuEnchantments.PERFECT_BLOCK);

        for (EnchantmentInstance instance : generated) {
            Holder<Enchantment> enchantment = instance.enchantment;
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)) {
                result.add(instance);
                if (GyeokbuEnchantments.isVanillaGyeokbuBridge(enchantment)
                        && chargedVanillaBridges.add(enchantment)
                        && usedSlots < capacity) {
                    usedSlots++;
                }
                continue;
            }
            if (GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)
                    || (GyeokbuEnchantments.requiresBlockProvider(enchantment) && !hasProvider)
                    || conflictsWith(enchantment, accepted)) {
                continue;
            }
            int cost = accepted.contains(enchantment) ? 0 : GyeokbuEnchantments.getOriginalSlotCost(enchantment);
            if (usedSlots + cost > capacity) {
                continue;
            }
            usedSlots += cost;
            accepted.add(enchantment);
            result.add(instance);
        }
        return result;
    }

    private static boolean conflictsWith(
            Holder<Enchantment> candidate,
            Set<Holder<Enchantment>> others
    ) {
        for (Holder<Enchantment> other : others) {
            if (!candidate.equals(other) && GyeokbuEnchantments.areMutuallyExclusive(candidate, other)) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsKey(
            Set<Holder<Enchantment>> enchantments,
            net.minecraft.resources.ResourceKey<Enchantment> key
    ) {
        for (Holder<Enchantment> enchantment : enchantments) {
            if (enchantment.is(key)) {
                return true;
            }
        }
        return false;
    }
}
