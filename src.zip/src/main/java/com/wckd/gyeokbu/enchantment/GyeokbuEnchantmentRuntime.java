package com.wckd.gyeokbu.enchantment;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.StunStateSyncPayload;
import com.wckd.gyeokbu.particle.ModParticles;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.CriticalHitEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Server-side runtime for Gyeokbu's active Parry enchantment effects. */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class GyeokbuEnchantmentRuntime {

    private static final double SOFT_BLOW_SPEED_MODIFIER = -0.40D;
    private static final double CONCUSSION_SPEED_MODIFIER = -1.00D;

    private static final ResourceLocation SOFT_BLOW_SPEED_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(
                    GyeokbuV2.MODID,
                    "soft_blow_speed"
            );

    private static final ResourceLocation CONCUSSION_SPEED_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(
                    GyeokbuV2.MODID,
                    "concussion_speed"
            );

    private static final double ORBIT_RADIUS = 0.55D;
    private static final double ORBIT_SPEED = 0.55D;
    private static final double MEDIUM_OFFSET = 0.22D;
    private static final double SMALL_OFFSET = 0.42D;
    private static final double TINY_OFFSET = 0.60D;

    private static final Map<UUID, TimedTargetEffect> SOFT_BLOW_TARGETS =
            new HashMap<>();

    private static final Map<UUID, ConcussionEffect> CONCUSSED_TARGETS =
            new HashMap<>();

    private static final Map<UUID, VulnerabilityEffect> VULNERABLE_TARGETS =
            new HashMap<>();

    /*
     * Vulnerability uses vanilla critical feedback even when the bonus hit is
     * not itself a critical. These short-lived markers prevent us from
     * replaying that feedback when Minecraft already produced it for a natural
     * jumping critical.
     */
    private static final Map<UUID, UUID> NATURAL_CRIT_VULNERABILITY_HITS =
            new HashMap<>();
    private static final Map<UUID, UUID> VULNERABILITY_MANUAL_FEEDBACK =
            new HashMap<>();

    /** Prevent reflected damage from being mistaken for a fresh melee input. */
    private static final ThreadLocal<Boolean> APPLYING_REFLECT_DAMAGE =
            ThreadLocal.withInitial(() -> false);

    private GyeokbuEnchantmentRuntime() {
    }

    public static void remove(ServerPlayer player) {
        clearSoftBlow(player);
        clearConcussion(player, false);
        clearVulnerability(player);
    }

    /** Called once per server-player tick from DefenseManager. */
    public static void tick(ServerPlayer player) {
        GyeokbuVanillaEnchantmentSlots.syncClaimsFromCurrentEnchantments(
                player.getMainHandItem()
        );
    }

    /** Shared successful-Parry hook for weapon Parries. */
    public static void onSuccessfulParry(
            ServerPlayer defender,
            LivingEntity parriedTarget
    ) {
        applyParryEffects(
                defender,
                parriedTarget,
                defender.getMainHandItem(),
                true
        );
    }

    /**
     * Successful Parry reported by an external shield system. The shield owns
     * only one Gyeokbu slot and Gyeokbu deliberately adds no shield particles.
     */
    public static void onSuccessfulShieldParry(
            ServerPlayer defender,
            LivingEntity parriedTarget,
            ItemStack shield
    ) {
        if (shield == null || shield.isEmpty()) {
            return;
        }

        int reflectLevel = GyeokbuEnchantments.getLevel(
                defender.level(), shield, GyeokbuEnchantments.REFLECT);
        if (reflectLevel > 0) {
            applyReflectDamage(defender, parriedTarget, reflectLevel, shield);
        }

        applyParryEffects(defender, parriedTarget, shield, false);
    }

    private static void applyParryEffects(
            ServerPlayer defender,
            LivingEntity parriedTarget,
            ItemStack sourceStack,
            boolean includeVanillaBridges
    ) {
        if (parriedTarget == null
                || parriedTarget.isRemoved()
                || !parriedTarget.isAlive()) {
            return;
        }

        int softBlowLevel = GyeokbuEnchantments.getLevel(
                defender.level(), sourceStack, GyeokbuEnchantments.SOFT_BLOW);
        if (softBlowLevel > 0) {
            applySoftBlow(
                    parriedTarget,
                    switch (softBlowLevel) {
                        case 1 -> 20;
                        case 2 -> 40;
                        default -> 80;
                    }
            );
        }

        int concussionLevel = GyeokbuEnchantments.getLevel(
                defender.level(), sourceStack, GyeokbuEnchantments.CONCUSSION);
        if (concussionLevel > 0) {
            applyConcussion(
                    parriedTarget,
                    concussionLevel >= 2 ? 30 : 10,
                    defender,
                    concussionLevel
            );
        }

        int vulnerabilityLevel = GyeokbuEnchantments.getLevel(
                defender.level(), sourceStack, GyeokbuEnchantments.VULNERABILITY);
        if (vulnerabilityLevel > 0) {
            applyVulnerability(
                    parriedTarget,
                    switch (vulnerabilityLevel) {
                        case 1 -> 0.10F;
                        case 2 -> 0.30F;
                        default -> 0.50F;
                    },
                    defender,
                    vulnerabilityLevel
            );
        }

        if (!includeVanillaBridges) {
            return;
        }

        int fireAspectLevel = GyeokbuVanillaEnchantmentSlots.getActiveLevel(
                sourceStack, Enchantments.FIRE_ASPECT);
        if (fireAspectLevel > 0) {
            parriedTarget.igniteForSeconds(4.0F * fireAspectLevel);
        }

        /* Vanilla Knockback is applied by DefenseCombatEvents together with
         * the base Successful Parry knockback. Keeping it centralized is
         * important because knockback-resistant targets may redirect the whole
         * intended amount back to the parrying player. */
    }

    public static double getSuccessfulParryKnockbackBonus(
            ServerPlayer defender,
            ItemStack sourceStack
    ) {
        if (defender == null || sourceStack == null || sourceStack.isEmpty()) {
            return 0.0D;
        }
        int level = GyeokbuVanillaEnchantmentSlots.getActiveLevel(
                sourceStack, Enchantments.KNOCKBACK);
        return level > 0 ? 0.50D * level : 0.0D;
    }

    public static boolean isApplyingReflectDamage() {
        return APPLYING_REFLECT_DAMAGE.get();
    }

    /**
     * Reflect uses only the held weapon's own main-hand ATTACK_DAMAGE
     * modifiers. Sharpness/Smite/Bane and temporary player buffs are excluded.
     */
    public static void applyReflectDamage(
            ServerPlayer defender,
            LivingEntity attacker,
            int reflectLevel
    ) {
        applyReflectDamage(defender, attacker, reflectLevel, defender.getMainHandItem());
    }

    private static void applyReflectDamage(
            ServerPlayer defender,
            LivingEntity attacker,
            int reflectLevel,
            ItemStack sourceStack
    ) {
        if (reflectLevel <= 0) {
            return;
        }

        double percent = Math.min(3, reflectLevel) * 0.20D;
        float reflectedDamage = (float) Math.max(
                0.0D,
                getHeldWeaponAttackDamage(sourceStack) * percent
        );

        if (reflectedDamage <= 0.0F) {
            return;
        }

        APPLYING_REFLECT_DAMAGE.set(true);

        try {
            attacker.hurt(
                    defender.damageSources().playerAttack(defender),
                    reflectedDamage
            );
        } finally {
            APPLYING_REFLECT_DAMAGE.set(false);
        }
    }

    private static double getHeldWeaponAttackDamage(ItemStack weapon) {
        if (weapon == null || weapon.isEmpty()) {
            return 1.0D;
        }

        final double[] additions = {0.0D};
        final double[] multipliedBase = {0.0D};
        final double[] multipliedTotal = {1.0D};

        weapon.forEachModifier(
                EquipmentSlot.MAINHAND,
                (attribute, modifier) -> {
                    if (!attribute.equals(Attributes.ATTACK_DAMAGE)) {
                        return;
                    }

                    switch (modifier.operation()) {
                        case ADD_VALUE -> additions[0] += modifier.amount();
                        case ADD_MULTIPLIED_BASE -> multipliedBase[0] += modifier.amount();
                        case ADD_MULTIPLIED_TOTAL -> multipliedTotal[0] *= 1.0D + modifier.amount();
                    }
                }
        );

        double basePlayerDamage = 1.0D;
        double afterAddition = basePlayerDamage + additions[0];
        double afterBaseMultipliers = afterAddition + basePlayerDamage * multipliedBase[0];
        return Math.max(0.0D, afterBaseMultipliers * multipliedTotal[0]);
    }

    public static boolean isConcussed(Entity entity) {
        return entity != null
                && CONCUSSED_TARGETS.containsKey(entity.getUUID());
    }

    public static boolean isVulnerable(Entity entity) {
        return entity != null
                && VULNERABLE_TARGETS.containsKey(entity.getUUID());
    }

    /**
     * Marks the next qualifying player hit for Vulnerability's damage increase.
     * Consumption is deliberately deferred until LivingDamageEvent.Post so a
     * hit that is later canceled (for example by a Parry) cannot waste the
     * one-hit effect.
     */
    public static void applyVulnerabilityDamage(LivingIncomingDamageEvent event) {
        LivingEntity target = event.getEntity();
        VulnerabilityEffect active = VULNERABLE_TARGETS.get(target.getUUID());

        if (active == null || event.getAmount() <= 0.0F) {
            return;
        }

        if (!(event.getSource().getEntity() instanceof ServerPlayer attacker)) {
            return;
        }

        UUID targetId = target.getUUID();
        UUID naturalCritAttacker = NATURAL_CRIT_VULNERABILITY_HITS.remove(targetId);

        if (!isConcussed(target)
                && !attacker.getUUID().equals(naturalCritAttacker)) {
            VULNERABILITY_MANUAL_FEEDBACK.put(targetId, attacker.getUUID());
        } else {
            VULNERABILITY_MANUAL_FEEDBACK.remove(targetId);
        }

        event.setAmount(event.getAmount() * (1.0F + active.damageIncrease()));
    }

    /**
     * Consumes Vulnerability only after the enhanced hit actually dealt
     * positive damage. Outside Concussion, mirror vanilla jumping-critical
     * particles and sound for the enhanced hit. During Concussion, the forced
     * real vanilla critical already supplies that feedback itself.
     */
    public static void consumeVulnerabilityAfterDamage(LivingDamageEvent.Post event) {
        LivingEntity target = event.getEntity();

        if (event.getNewDamage() <= 0.0F
                || !isVulnerable(target)
                || !(event.getSource().getEntity() instanceof ServerPlayer attacker)) {
            return;
        }

        UUID targetId = target.getUUID();
        VULNERABLE_TARGETS.remove(targetId);
        NATURAL_CRIT_VULNERABILITY_HITS.remove(targetId);
        UUID manualFeedbackAttacker = VULNERABILITY_MANUAL_FEEDBACK.remove(targetId);

        if (!isConcussed(target)
                && attacker.getUUID().equals(manualFeedbackAttacker)) {
            spawnVanillaCriticalFeedback(attacker, target);
        }
    }

    /**
     * Concussion uses NeoForge's actual Player.attack critical-hit hook. Forced
     * criticals therefore follow vanilla's 1.5x multiplier and normal critical
     * attack feedback instead of adding a separate damage packet.
     */
    @SubscribeEvent
    public static void onCriticalHit(CriticalHitEvent event) {
        if (event.getEntity().level().isClientSide) {
            return;
        }

        if (!(event.getTarget() instanceof LivingEntity target)) {
            return;
        }

        boolean concussed = isConcussed(target);
        boolean vulnerable = isVulnerable(target);

        if (vulnerable && !concussed && event.isCriticalHit()) {
            NATURAL_CRIT_VULNERABILITY_HITS.put(
                    target.getUUID(),
                    event.getEntity().getUUID()
            );
        }

        if (!concussed) {
            return;
        }

        if (event.isCriticalHit()) {
            event.setDamageMultiplier(1.5F);
            return;
        }

        boolean guaranteed = vulnerable;
        boolean rolledCritical = guaranteed || event.getEntity().getRandom().nextBoolean();

        if (!rolledCritical) {
            return;
        }

        event.setCriticalHit(true);
        event.setDamageMultiplier(1.5F);
    }

    private static void applySoftBlow(
            LivingEntity target,
            int durationTicks
    ) {
        if (target == null
                || target.isRemoved()
                || !target.isAlive()) {
            return;
        }

        var movement = target.getAttribute(Attributes.MOVEMENT_SPEED);

        if (movement != null) {
            movement.removeModifier(SOFT_BLOW_SPEED_MODIFIER_ID);
            movement.addTransientModifier(
                    new AttributeModifier(
                            SOFT_BLOW_SPEED_MODIFIER_ID,
                            SOFT_BLOW_SPEED_MODIFIER,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                    )
            );
        }

        TimedTargetEffect previous = SOFT_BLOW_TARGETS.get(target.getUUID());
        double phase = previous == null ? 0.0D : previous.phase();

        SOFT_BLOW_TARGETS.put(
                target.getUUID(),
                new TimedTargetEffect(target, durationTicks, phase)
        );

        if (!isConcussed(target)) {
            spawnStunTrail(target, phase);
        }
    }

    private static void applyConcussion(
            LivingEntity target,
            int durationTicks,
            ServerPlayer source,
            int level
    ) {
        if (target == null
                || target.isRemoved()
                || !target.isAlive()) {
            return;
        }

        var movement = target.getAttribute(Attributes.MOVEMENT_SPEED);

        if (movement != null) {
            movement.removeModifier(CONCUSSION_SPEED_MODIFIER_ID);
            movement.addTransientModifier(
                    new AttributeModifier(
                            CONCUSSION_SPEED_MODIFIER_ID,
                            CONCUSSION_SPEED_MODIFIER,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                    )
            );
        }

        ConcussionEffect previous = CONCUSSED_TARGETS.get(target.getUUID());

        float lockedYaw = previous == null ? target.getYRot() : previous.lockedYaw();
        float lockedPitch = previous == null ? target.getXRot() : previous.lockedPitch();
        float lockedHeadYaw = previous == null ? target.yHeadRot : previous.lockedHeadYaw();
        float lockedBodyYaw = previous == null ? target.yBodyRot : previous.lockedBodyYaw();
        double phase = previous == null ? 0.0D : previous.phase();

        CONCUSSED_TARGETS.put(
                target.getUUID(),
                new ConcussionEffect(
                        target,
                        durationTicks,
                        phase,
                        lockedYaw,
                        lockedPitch,
                        lockedHeadYaw,
                        lockedBodyYaw,
                        source.getUUID(),
                        Math.max(1, Math.min(2, level))
                )
        );

        applyConcussionLock(target, lockedYaw, lockedPitch, lockedHeadYaw, lockedBodyYaw);
        spawnStunTrail(target, phase);

        if (target instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(
                    player,
                    new StunStateSyncPayload(StunStateSyncPayload.HARD)
            );
        }
    }

    private static void applyVulnerability(
            LivingEntity target,
            float damageIncrease,
            ServerPlayer source,
            int level
    ) {
        if (target == null
                || target.isRemoved()
                || !target.isAlive()) {
            return;
        }

        UUID targetId = target.getUUID();
        NATURAL_CRIT_VULNERABILITY_HITS.remove(targetId);
        VULNERABILITY_MANUAL_FEEDBACK.remove(targetId);

        VULNERABLE_TARGETS.put(
                targetId,
                new VulnerabilityEffect(
                        target,
                        Math.max(0.0F, damageIncrease),
                        source.getUUID(),
                        Math.max(1, Math.min(3, level))
                )
        );
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        tickSoftBlowTargets();
        tickConcussedTargets();
        tickVulnerableTargets();
    }

    private static void tickSoftBlowTargets() {
        Iterator<Map.Entry<UUID, TimedTargetEffect>> iterator =
                SOFT_BLOW_TARGETS.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<UUID, TimedTargetEffect> entry = iterator.next();
            TimedTargetEffect active = entry.getValue();
            LivingEntity target = active.target();

            if (target == null || target.isRemoved() || !target.isAlive()) {
                if (target != null) {
                    removeSoftBlowModifier(target);
                }
                iterator.remove();
                continue;
            }

            if (!isConcussed(target)) {
                spawnStunTrail(target, active.phase());
            }

            int remaining = active.remainingTicks() - 1;

            if (remaining <= 0) {
                removeSoftBlowModifier(target);
                iterator.remove();
                continue;
            }

            entry.setValue(
                    new TimedTargetEffect(
                            target,
                            remaining,
                            active.phase() + ORBIT_SPEED
                    )
            );
        }
    }

    private static void tickConcussedTargets() {
        Iterator<Map.Entry<UUID, ConcussionEffect>> iterator =
                CONCUSSED_TARGETS.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<UUID, ConcussionEffect> entry = iterator.next();
            ConcussionEffect active = entry.getValue();
            LivingEntity target = active.target();

            if (target == null || target.isRemoved() || !target.isAlive()) {
                if (target != null) {
                    removeConcussionModifier(target);
                }
                iterator.remove();
                continue;
            }

            applyConcussionLock(
                    target,
                    active.lockedYaw(),
                    active.lockedPitch(),
                    active.lockedHeadYaw(),
                    active.lockedBodyYaw()
            );
            spawnStunTrail(target, active.phase());

            int remaining = active.remainingTicks() - 1;

            if (remaining <= 0) {
                finishConcussion(target);
                iterator.remove();
                continue;
            }

            entry.setValue(
                    new ConcussionEffect(
                            target,
                            remaining,
                            active.phase() + ORBIT_SPEED,
                            active.lockedYaw(),
                            active.lockedPitch(),
                            active.lockedHeadYaw(),
                            active.lockedBodyYaw(),
                            active.sourceId(),
                            active.level()
                    )
            );
        }
    }

    private static void tickVulnerableTargets() {
        Iterator<Map.Entry<UUID, VulnerabilityEffect>> iterator =
                VULNERABLE_TARGETS.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<UUID, VulnerabilityEffect> entry = iterator.next();
            LivingEntity target = entry.getValue().target();
            if (target == null || target.isRemoved() || !target.isAlive()) {
                UUID targetId = entry.getKey();
                iterator.remove();
                NATURAL_CRIT_VULNERABILITY_HITS.remove(targetId);
                VULNERABILITY_MANUAL_FEEDBACK.remove(targetId);
            }
        }
    }

    /**
     * Stops voluntary locomotion/turning without clearing deltaMovement, so
     * vanilla knockback and other outside forces continue to move the target.
     */
    private static void applyConcussionLock(
            LivingEntity target,
            float yaw,
            float pitch,
            float headYaw,
            float bodyYaw
    ) {
        target.xxa = 0.0F;
        target.zza = 0.0F;
        target.setSprinting(false);

        target.setYRot(yaw);
        target.setXRot(pitch);
        target.yHeadRot = headYaw;
        target.yHeadRotO = headYaw;
        target.yBodyRot = bodyYaw;
        target.yBodyRotO = bodyYaw;

        if (target instanceof Mob mob) {
            mob.getNavigation().stop();
        }
    }

    private static void clearSoftBlow(LivingEntity target) {
        if (target == null) {
            return;
        }

        SOFT_BLOW_TARGETS.remove(target.getUUID());
        removeSoftBlowModifier(target);
    }

    private static void clearConcussion(
            LivingEntity target,
            boolean syncClient
    ) {
        if (target == null) {
            return;
        }

        CONCUSSED_TARGETS.remove(target.getUUID());
        removeConcussionModifier(target);

        if (syncClient && target instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(
                    player,
                    new StunStateSyncPayload(StunStateSyncPayload.NONE)
            );
        }
    }

    private static void clearVulnerability(LivingEntity target) {
        if (target != null) {
            UUID targetId = target.getUUID();
            VULNERABLE_TARGETS.remove(targetId);
            NATURAL_CRIT_VULNERABILITY_HITS.remove(targetId);
            VULNERABILITY_MANUAL_FEEDBACK.remove(targetId);
        }
    }

    private static void finishConcussion(LivingEntity target) {
        removeConcussionModifier(target);

        if (target instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(
                    player,
                    new StunStateSyncPayload(StunStateSyncPayload.NONE)
            );
        }
    }

    private static void removeSoftBlowModifier(LivingEntity target) {
        var movement = target.getAttribute(Attributes.MOVEMENT_SPEED);

        if (movement != null) {
            movement.removeModifier(SOFT_BLOW_SPEED_MODIFIER_ID);
        }
    }

    private static void removeConcussionModifier(LivingEntity target) {
        var movement = target.getAttribute(Attributes.MOVEMENT_SPEED);

        if (movement != null) {
            movement.removeModifier(CONCUSSION_SPEED_MODIFIER_ID);
        }
    }

    private static void spawnVanillaCriticalFeedback(
            ServerPlayer attacker,
            LivingEntity target
    ) {
        attacker.crit(target);
        attacker.level().playSound(
                null,
                attacker.getX(),
                attacker.getY(),
                attacker.getZ(),
                SoundEvents.PLAYER_ATTACK_CRIT,
                SoundSource.PLAYERS,
                1.0F,
                1.0F
        );
    }

    /* Same four orbiting stun particles already used by Gyeokbu's old stun. */
    private static void spawnStunTrail(
            LivingEntity target,
            double phase
    ) {
        if (!(target.level() instanceof ServerLevel level)) {
            return;
        }

        double centerX = target.getX();
        double centerY = target.getY() + target.getBbHeight() + 0.28D;
        double centerZ = target.getZ();

        spawnSingleOrbitParticle(level, ModParticles.STUN_CRIT_BIG.get(), centerX, centerY, centerZ, phase, 0.0D);
        spawnSingleOrbitParticle(level, ModParticles.STUN_CRIT_MEDIUM.get(), centerX, centerY, centerZ, phase - MEDIUM_OFFSET, -0.02D);
        spawnSingleOrbitParticle(level, ModParticles.STUN_CRIT_SMALL.get(), centerX, centerY, centerZ, phase - SMALL_OFFSET, -0.04D);
        spawnSingleOrbitParticle(level, ModParticles.STUN_CRIT_TINY.get(), centerX, centerY, centerZ, phase - TINY_OFFSET, -0.06D);
    }

    private static void spawnSingleOrbitParticle(
            ServerLevel level,
            net.minecraft.core.particles.SimpleParticleType type,
            double centerX,
            double centerY,
            double centerZ,
            double phase,
            double yOffset
    ) {
        double x = centerX + Math.cos(phase) * ORBIT_RADIUS;
        double z = centerZ + Math.sin(phase) * ORBIT_RADIUS;

        level.sendParticles(
                type,
                x,
                centerY + yOffset,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
        );
    }

    private record TimedTargetEffect(
            LivingEntity target,
            int remainingTicks,
            double phase
    ) {
    }

    private record ConcussionEffect(
            LivingEntity target,
            int remainingTicks,
            double phase,
            float lockedYaw,
            float lockedPitch,
            float lockedHeadYaw,
            float lockedBodyYaw,
            UUID sourceId,
            int level
    ) {
    }

    private record VulnerabilityEffect(
            LivingEntity target,
            float damageIncrease,
            UUID sourceId,
            int level
    ) {
    }
}
