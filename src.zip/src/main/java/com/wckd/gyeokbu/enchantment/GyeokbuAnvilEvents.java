package com.wckd.gyeokbu.enchantment;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.compat.ShieldParryCompat;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AnvilUpdateEvent;
import net.neoforged.neoforge.event.entity.player.AnvilRepairEvent;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Gyeokbu anvil bridge with slot, requirement and incompatibility validation. */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class GyeokbuAnvilEvents {

    private GyeokbuAnvilEvents() {
    }

    @SubscribeEvent
    public static void onAnvilUpdate(AnvilUpdateEvent event) {
        ItemStack left = event.getLeft();
        ItemStack right = event.getRight();

        if (left.isEmpty() || !right.is(Items.ENCHANTED_BOOK)) {
            return;
        }

        ItemEnchantments bookEnchantments = EnchantmentHelper.getEnchantmentsForCrafting(right);
        if (bookEnchantments.isEmpty()) {
            return;
        }

        List<Holder<Enchantment>> incomingGyeokbu = new ArrayList<>();
        for (Holder<Enchantment> enchantment : bookEnchantments.keySet()) {
            if (GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)
                    && !GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                incomingGyeokbu.add(enchantment);
            }
        }

        if (incomingGyeokbu.isEmpty()) {
            return;
        }

        boolean targetBook = left.is(Items.ENCHANTED_BOOK);
        boolean targetShield = GyeokbuEnchantments.isShield(left);
        boolean targetWeapon = GyeokbuEnchantments.isEligibleWeaponForEnchantments(left);

        if (!targetBook && !targetShield && !targetWeapon) {
            /*
             * Let vanilla/modded anvil logic handle unrelated targets. The
             * Gyeokbu enchantments' supported-item data already prevents them
             * from applying here, while a mixed book can still contribute its
             * unrelated vanilla enchantments normally.
             */
            return;
        }

        ItemEnchantments current = EnchantmentHelper.getEnchantmentsForCrafting(left);
        Map<Holder<Enchantment>, Integer> result = new LinkedHashMap<>();
        for (Holder<Enchantment> enchantment : current.keySet()) {
            result.put(enchantment, current.getLevel(enchantment));
        }

        List<Holder<Enchantment>> applicable = new ArrayList<>();
        boolean pureGyeokbuBook = incomingGyeokbu.size() == bookEnchantments.size();

        for (Holder<Enchantment> enchantment : incomingGyeokbu) {
            if (targetShield) {
                if (GyeokbuEnchantments.isWeaponOnlyEnchantment(enchantment)) {
                    event.setCanceled(true);
                    return;
                }

                if (GyeokbuEnchantments.isParryEnchantment(enchantment)
                        && (!GyeokbuEnchantments.isShieldParryCompatibleEnchantment(enchantment)
                        || !ShieldParryCompat.isParryCapableShield(left))) {
                    event.setCanceled(true);
                    return;
                }
            }

            if (!pureGyeokbuBook && !targetBook && !left.supportsEnchantment(enchantment)) {
                continue;
            }

            int existing = result.getOrDefault(enchantment, 0);
            int incoming = Math.max(1, bookEnchantments.getLevel(enchantment));
            int combined = combineLevels(existing, incoming, enchantment.value().getMaxLevel());
            result.put(enchantment, combined);
            applicable.add(enchantment);
        }

        if (applicable.isEmpty()) {
            return;
        }

        if (hasMutualExclusion(result)) {
            event.setCanceled(true);
            return;
        }

        /*
         * Enchanted books are unrestricted requirement carriers. They may hold
         * Projectile Reflect/Blast Guard/etc. without Block, and they do not
         * consume an item's three-slot capacity until actually applied.
         */
        if (targetBook) {
            return;
        }

        if (!requirementsSatisfied(result, targetShield)) {
            event.setCanceled(true);
            return;
        }

        int capacity = GyeokbuEnchantments.getCapacity(left);

        /* Existing active Knockback/Fire Aspect Gyeokbu bridge claims are
         * real occupied slots and must not be silently displaced by a later
         * custom-book application. New bridge enchantments on the incoming
         * book remain vanilla even if no Gyeokbu slot is available. */
        int existingBridgeSlots = Math.max(
                0,
                GyeokbuEnchantments.countOccupiedGyeokbuSlots(left)
                        - GyeokbuEnchantments.countOriginalGyeokbuSlots(left)
        );
        int slots = existingBridgeSlots;
        for (Holder<Enchantment> enchantment : result.keySet()) {
            slots += GyeokbuEnchantments.getOriginalSlotCost(enchantment);
        }

        if (slots > capacity) {
            event.setCanceled(true);
            return;
        }

        /* Mixed books keep vanilla/modded result construction. */
        if (!pureGyeokbuBook) {
            return;
        }

        ItemStack output = left.copy();
        EnchantmentHelper.updateEnchantments(
                output,
                mutable -> {
                    for (Holder<Enchantment> enchantment : applicable) {
                        int oldLevel = current.getLevel(enchantment);
                        int bookLevel = Math.max(1, bookEnchantments.getLevel(enchantment));
                        int resultLevel = combineLevels(
                                oldLevel, bookLevel, enchantment.value().getMaxLevel());
                        if (resultLevel > oldLevel) {
                            mutable.set(enchantment, resultLevel);
                        }
                    }
                }
        );

        String requestedName = event.getName();
        if (requestedName != null) {
            if (requestedName.isBlank()) {
                output.remove(DataComponents.CUSTOM_NAME);
            } else {
                output.set(DataComponents.CUSTOM_NAME, Component.literal(requestedName));
            }
        }

        long enchantmentCost = 0L;
        ItemEnchantments outputEnchantments = EnchantmentHelper.getEnchantmentsForCrafting(output);
        for (Holder<Enchantment> enchantment : applicable) {
            enchantmentCost += (long) enchantment.value().getAnvilCost()
                    * Math.max(1, outputEnchantments.getLevel(enchantment));
        }

        event.setCost(Math.max(1L, event.getCost() + enchantmentCost));
        event.setMaterialCost(1);
        event.setOutput(output);
    }

    @SubscribeEvent
    public static void onAnvilRepair(AnvilRepairEvent event) {
        ItemStack output = event.getOutput();
        if (output == null || output.isEmpty()
                || (!GyeokbuEnchantments.isEligibleWeaponForEnchantments(output)
                && !GyeokbuEnchantments.isShield(output))) {
            return;
        }

        GyeokbuVanillaEnchantmentSlots.recordBookClaims(output, event.getRight());
        GyeokbuVanillaEnchantmentSlots.syncClaimsFromCurrentEnchantments(output);
    }

    private static boolean requirementsSatisfied(
            Map<Holder<Enchantment>, Integer> result,
            boolean shield
    ) {
        boolean blockProvider = shield;
        if (!blockProvider) {
            for (Holder<Enchantment> enchantment : result.keySet()) {
                if (enchantment.is(GyeokbuEnchantments.BLOCK)
                        || enchantment.is(GyeokbuEnchantments.PERFECT_BLOCK)) {
                    blockProvider = true;
                    break;
                }
            }
        }

        for (Holder<Enchantment> enchantment : result.keySet()) {
            if (GyeokbuEnchantments.requiresBlockProvider(enchantment)
                    && !blockProvider) {
                return false;
            }
        }
        return true;
    }

    private static boolean hasMutualExclusion(Map<Holder<Enchantment>, Integer> result) {
        List<Holder<Enchantment>> enchantments = new ArrayList<>(result.keySet());
        for (int i = 0; i < enchantments.size(); i++) {
            for (int j = i + 1; j < enchantments.size(); j++) {
                if (GyeokbuEnchantments.areMutuallyExclusive(
                        enchantments.get(i), enchantments.get(j))) {
                    return true;
                }
            }
        }
        return false;
    }

    private static int combineLevels(int currentLevel, int incomingLevel, int maxLevel) {
        if (currentLevel <= 0) {
            return Math.min(incomingLevel, maxLevel);
        }
        if (currentLevel == incomingLevel && currentLevel < maxLevel) {
            return currentLevel + 1;
        }
        return Math.min(Math.max(currentLevel, incomingLevel), maxLevel);
    }
}
