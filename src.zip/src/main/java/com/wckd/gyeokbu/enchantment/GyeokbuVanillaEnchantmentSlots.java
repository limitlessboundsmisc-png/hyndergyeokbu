package com.wckd.gyeokbu.enchantment;

import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Stores deterministic claim order for vanilla enchantments that optionally
 * gain a Gyeokbu effect. Their normal vanilla behavior never depends on these
 * claims; only the extra Parry behavior does.
 */
public final class GyeokbuVanillaEnchantmentSlots {

    private static final String COUNTER = "gyeokbu_claim_counter";
    private static final String KNOCKBACK_CLAIM = "gyeokbu_knockback_claim";
    private static final String FIRE_ASPECT_CLAIM = "gyeokbu_fire_aspect_claim";

    private GyeokbuVanillaEnchantmentSlots() {
    }

    /** Exact table-generated order is preserved when NeoForge supplies it. */
    public static void recordTableClaims(
            ItemStack stack,
            List<EnchantmentInstance> applied
    ) {
        if (stack == null || stack.isEmpty()) {
            return;
        }

        pruneMissingClaims(stack);

        for (EnchantmentInstance instance : applied) {
            Holder<Enchantment> enchantment = instance.enchantment;

            if (enchantment.is(Enchantments.KNOCKBACK)) {
                ensureClaim(stack, KNOCKBACK_CLAIM);
            } else if (enchantment.is(Enchantments.FIRE_ASPECT)) {
                ensureClaim(stack, FIRE_ASPECT_CLAIM);
            }
        }
    }


    /** Records qualifying vanilla enchantments in the order stored on an anvil book. */
    public static void recordBookClaims(
            ItemStack output,
            ItemStack rightBook
    ) {
        if (output == null || output.isEmpty()
                || rightBook == null || rightBook.isEmpty()) {
            return;
        }

        pruneMissingClaims(output);
        ItemEnchantments bookEnchantments =
                EnchantmentHelper.getEnchantmentsForCrafting(rightBook);

        for (Holder<Enchantment> enchantment : bookEnchantments.keySet()) {
            if (enchantment.is(Enchantments.KNOCKBACK)) {
                ensureClaim(output, KNOCKBACK_CLAIM);
            } else if (enchantment.is(Enchantments.FIRE_ASPECT)) {
                ensureClaim(output, FIRE_ASPECT_CLAIM);
            }
        }
    }

    /**
     * Migration/fallback path for anvil, loot, command and pre-Rework-7 items.
     * Missing claims are assigned in the item's stored enchantment iteration
     * order and then remain stable on the individual ItemStack.
     */
    public static void syncClaimsFromCurrentEnchantments(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return;
        }

        if (!stack.isEnchanted() && !stack.has(DataComponents.CUSTOM_DATA)) {
            return;
        }

        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        boolean hasKnockback = getLevel(enchantments, Enchantments.KNOCKBACK) > 0;
        boolean hasFireAspect = getLevel(enchantments, Enchantments.FIRE_ASPECT) > 0;

        CompoundTag current = stack.getOrDefault(
                DataComponents.CUSTOM_DATA,
                CustomData.EMPTY
        ).copyTag();

        boolean hasKnockbackClaim = current.contains(KNOCKBACK_CLAIM);
        boolean hasFireAspectClaim = current.contains(FIRE_ASPECT_CLAIM);

        /*
         * This method runs once per server-player tick as a migration/fallback
         * safety net. Stable weapons should therefore be a true no-op: avoid
         * replacing CUSTOM_DATA every tick when the stored claims already
         * match the held enchantments.
         */
        if (hasKnockback == hasKnockbackClaim
                && hasFireAspect == hasFireAspectClaim) {
            return;
        }

        CustomData.update(
                DataComponents.CUSTOM_DATA,
                stack,
                tag -> {
                    if (!hasKnockback) {
                        tag.remove(KNOCKBACK_CLAIM);
                    }
                    if (!hasFireAspect) {
                        tag.remove(FIRE_ASPECT_CLAIM);
                    }

                    int next = Math.max(0, tag.getInt(COUNTER));
                    if (tag.contains(KNOCKBACK_CLAIM)) {
                        next = Math.max(next, tag.getInt(KNOCKBACK_CLAIM));
                    }
                    if (tag.contains(FIRE_ASPECT_CLAIM)) {
                        next = Math.max(next, tag.getInt(FIRE_ASPECT_CLAIM));
                    }

                    /* Preserve the item's stored enchantment iteration order. */
                    for (Holder<Enchantment> enchantment : enchantments.keySet()) {
                        if (enchantment.is(Enchantments.KNOCKBACK)
                                && !tag.contains(KNOCKBACK_CLAIM)) {
                            tag.putInt(KNOCKBACK_CLAIM, ++next);
                        } else if (enchantment.is(Enchantments.FIRE_ASPECT)
                                && !tag.contains(FIRE_ASPECT_CLAIM)) {
                            tag.putInt(FIRE_ASPECT_CLAIM, ++next);
                        }
                    }

                    if (next > tag.getInt(COUNTER)) {
                        tag.putInt(COUNTER, next);
                    }
                }
        );
    }

    public static boolean isActive(
            ItemStack stack,
            ResourceKey<Enchantment> key
    ) {
        if (stack == null || stack.isEmpty() || GyeokbuEnchantments.isShield(stack)) {
            return false;
        }

        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);

        if (getLevel(enchantments, key) <= 0) {
            return false;
        }

        int available = GyeokbuEnchantments.getCapacity(stack)
                - GyeokbuEnchantments.countOriginalGyeokbuSlots(stack);

        if (available <= 0) {
            return false;
        }

        List<Claim> claims = presentClaims(stack, enchantments);
        claims.sort(Comparator.comparingInt(Claim::order));

        for (int index = 0; index < claims.size() && index < available; index++) {
            if (claims.get(index).key().equals(key)) {
                return true;
            }
        }

        return false;
    }

    public static int getActiveLevel(
            ItemStack stack,
            ResourceKey<Enchantment> key
    ) {
        if (!isActive(stack, key)) {
            return 0;
        }

        return getLevel(EnchantmentHelper.getEnchantmentsForCrafting(stack), key);
    }

    public static int getStoredLevel(
            ItemStack stack,
            ResourceKey<Enchantment> key
    ) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }

        return getLevel(EnchantmentHelper.getEnchantmentsForCrafting(stack), key);
    }

    private static List<Claim> presentClaims(
            ItemStack stack,
            ItemEnchantments enchantments
    ) {
        List<Claim> claims = new ArrayList<>(2);
        CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();

        int fallback = 1_000_000;

        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(Enchantments.KNOCKBACK)) {
                int order = tag.contains(KNOCKBACK_CLAIM)
                        ? tag.getInt(KNOCKBACK_CLAIM)
                        : fallback++;
                claims.add(new Claim(Enchantments.KNOCKBACK, order));
            } else if (enchantment.is(Enchantments.FIRE_ASPECT)) {
                int order = tag.contains(FIRE_ASPECT_CLAIM)
                        ? tag.getInt(FIRE_ASPECT_CLAIM)
                        : fallback++;
                claims.add(new Claim(Enchantments.FIRE_ASPECT, order));
            }
        }

        return claims;
    }

    private static int getLevel(
            ItemEnchantments enchantments,
            ResourceKey<Enchantment> key
    ) {
        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(key)) {
                return enchantments.getLevel(enchantment);
            }
        }

        return 0;
    }

    private static void pruneMissingClaims(ItemStack stack) {
        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        boolean hasKnockback = getLevel(enchantments, Enchantments.KNOCKBACK) > 0;
        boolean hasFireAspect = getLevel(enchantments, Enchantments.FIRE_ASPECT) > 0;

        CustomData.update(
                DataComponents.CUSTOM_DATA,
                stack,
                tag -> {
                    if (!hasKnockback) {
                        tag.remove(KNOCKBACK_CLAIM);
                    }
                    if (!hasFireAspect) {
                        tag.remove(FIRE_ASPECT_CLAIM);
                    }
                }
        );
    }

    private static void ensureClaim(
            ItemStack stack,
            String claimKey
    ) {
        CustomData.update(
                DataComponents.CUSTOM_DATA,
                stack,
                tag -> {
                    if (tag.contains(claimKey)) {
                        return;
                    }

                    int next = Math.max(0, tag.getInt(COUNTER)) + 1;
                    tag.putInt(COUNTER, next);
                    tag.putInt(claimKey, next);
                }
        );
    }

    private record Claim(ResourceKey<Enchantment> key, int order) {
    }
}
