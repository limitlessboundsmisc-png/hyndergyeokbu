package com.wckd.gyeokbu.enchantment;

import com.wckd.gyeokbu.Config;
import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;

/**
 * Resource keys and dedicated-slot helpers for Gyeokbu enchantments.
 *
 * Gyeokbu uses Minecraft's normal enchantment component, levels, books,
 * enchanting table and anvil conventions. The deliberate exception is that a
 * recognized weapon has only three Gyeokbu-effect slots.
 */
public final class GyeokbuEnchantments {

    public static final int DEFAULT_GYEOKBU_CAPACITY = 3;

    public static final TagKey<Item> SHIELDS = TagKey.create(
            Registries.ITEM,
            ResourceLocation.fromNamespaceAndPath(GyeokbuV2.MODID, "shields")
    );

    public static final ResourceKey<Enchantment> REFLECT = key("reflect");
    public static final ResourceKey<Enchantment> SOFT_BLOW = key("soft_blow");
    public static final ResourceKey<Enchantment> CONCUSSION = key("concussion");
    public static final ResourceKey<Enchantment> VULNERABILITY = key("vulnerability");
    public static final ResourceKey<Enchantment> BLAST_NEGATION = key("blast_negation");
    public static final ResourceKey<Enchantment> MASTERY = key("mastery");
    public static final ResourceKey<Enchantment> SWEEPING_GUARD = key("sweeping_guard");

    public static final ResourceKey<Enchantment> BLOCK = key("block");
    public static final ResourceKey<Enchantment> PERFECT_BLOCK = key("perfect_block");
    public static final ResourceKey<Enchantment> BLOCKING_STANCE = key("blocking_stance");
    public static final ResourceKey<Enchantment> PUSHBACK = key("pushback");
    public static final ResourceKey<Enchantment> PROJECTILE_REFLECT = key("projectile_reflect");
    public static final ResourceKey<Enchantment> BLAST_GUARD = key("blast_guard");

    /**
     * Legacy-only key retained so old items/world data can still deserialize.
     * It is intentionally excluded from active gameplay, slot usage, creative
     * generation and normal acquisition.
     */
    public static final ResourceKey<Enchantment> FLEETING_FOOTWORK = key("fleeting_footwork");

    private GyeokbuEnchantments() {
    }

    private static ResourceKey<Enchantment> key(String path) {
        return ResourceKey.create(
                Registries.ENCHANTMENT,
                ResourceLocation.fromNamespaceAndPath(GyeokbuV2.MODID, path)
        );
    }

    public static Holder.Reference<Enchantment> holder(
            HolderLookup.Provider provider,
            ResourceKey<Enchantment> enchantment
    ) {
        return provider.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(enchantment);
    }

    public static int getLevel(
            Level level,
            ItemStack stack,
            ResourceKey<Enchantment> enchantment
    ) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }

        return EnchantmentHelper.getTagEnchantmentLevel(
                holder(level.registryAccess(), enchantment),
                stack
        );
    }

    public static boolean has(
            Level level,
            ItemStack stack,
            ResourceKey<Enchantment> enchantment
    ) {
        return getLevel(level, stack, enchantment) > 0;
    }

    public static boolean hasBlockProvider(
            Level level,
            ItemStack stack
    ) {
        return has(level, stack, BLOCK)
                || has(level, stack, PERFECT_BLOCK);
    }

    /** Shields inherently satisfy Block-modifier requirements. */
    public static boolean satisfiesBlockRequirement(
            Level level,
            ItemStack stack
    ) {
        return isShield(stack) || hasBlockProvider(level, stack);
    }

    public static boolean isShield(ItemStack stack) {
        return stack != null
                && !stack.isEmpty()
                && (stack.getItem() instanceof ShieldItem || stack.is(SHIELDS));
    }

    /**
     * Vanilla axes and pickaxes remain eligible. Shovels, hoes and the vanilla
     * mace are deliberately excluded from Gyeokbu enchantment application.
     */
    public static boolean isEligibleWeaponForEnchantments(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }

        if (stack.is(Items.MACE)
                || stack.getItem() instanceof ShovelItem
                || stack.getItem() instanceof HoeItem) {
            return false;
        }

        return com.wckd.gyeokbu.weapon.WeaponClassifier.classify(stack).isSupported();
    }

    public static int getCapacity(ItemStack stack) {
        return isShield(stack)
                ? Config.DEFAULT_SHIELD_SLOTS.getAsInt()
                : Config.DEFAULT_WEAPON_SLOTS.getAsInt();
    }

    public static boolean requiresBlockProvider(Holder<Enchantment> enchantment) {
        return enchantment != null
                && (enchantment.is(BLOCKING_STANCE)
                || enchantment.is(PUSHBACK)
                || enchantment.is(PROJECTILE_REFLECT)
                || enchantment.is(BLAST_GUARD));
    }

    public static boolean isParryEnchantment(Holder<Enchantment> enchantment) {
        if (enchantment == null) {
            return false;
        }

        return enchantment.is(REFLECT)
                || enchantment.is(SOFT_BLOW)
                || enchantment.is(CONCUSSION)
                || enchantment.is(VULNERABILITY)
                || enchantment.is(BLAST_NEGATION)
                || enchantment.is(MASTERY)
                || enchantment.is(SWEEPING_GUARD)
                || enchantment.is(Enchantments.KNOCKBACK)
                || enchantment.is(Enchantments.FIRE_ASPECT);
    }

    /**
     * Parry effects that can safely react to a successful Parry reported by an
     * external shield mod. Mastery, Sweeping Guard and Blast Negation need
     * control/knowledge of the actual Parry window, so they deliberately remain
     * weapon-only for generic shield compatibility. Vanilla
     * Knockback/Fire Aspect bridge behavior also remains weapon-only.
     */
    public static boolean isShieldParryCompatibleEnchantment(Holder<Enchantment> enchantment) {
        if (enchantment == null) {
            return false;
        }

        return enchantment.is(REFLECT)
                || enchantment.is(SOFT_BLOW)
                || enchantment.is(CONCUSSION)
                || enchantment.is(VULNERABILITY);
    }

    public static boolean isWeaponOnlyEnchantment(Holder<Enchantment> enchantment) {
        if (enchantment == null) {
            return false;
        }

        return enchantment.is(BLOCK)
                || enchantment.is(PERFECT_BLOCK)
                || enchantment.is(MASTERY)
                || enchantment.is(BLAST_NEGATION)
                || enchantment.is(SWEEPING_GUARD);
    }

    public static boolean isGyeokbuEnchantment(Holder<Enchantment> enchantment) {
        return enchantment.unwrapKey()
                .map(key -> key.location().getNamespace().equals(GyeokbuV2.MODID))
                .orElse(false);
    }

    public static boolean isLegacyRemovedEnchantment(Holder<Enchantment> enchantment) {
        return enchantment.is(FLEETING_FOOTWORK);
    }

    public static boolean isVanillaGyeokbuBridge(Holder<Enchantment> enchantment) {
        return enchantment.is(Enchantments.KNOCKBACK)
                || enchantment.is(Enchantments.FIRE_ASPECT);
    }

    /** Active original Gyeokbu enchantments only. */
    public static int getOriginalSlotCost(Holder<Enchantment> enchantment) {
        if (!isGyeokbuEnchantment(enchantment)
                || isLegacyRemovedEnchantment(enchantment)) {
            return 0;
        }

        return getSlotCost(enchantment.unwrapKey().orElse(null));
    }

    public static int getSlotCost(ResourceKey<Enchantment> enchantment) {
        if (enchantment == null
                || enchantment.equals(FLEETING_FOOTWORK)) {
            return 0;
        }

        if (enchantment.equals(PERFECT_BLOCK)) {
            return 2;
        }

        return 1;
    }

    public static boolean areMutuallyExclusive(
            Holder<Enchantment> first,
            Holder<Enchantment> second
    ) {
        if (first == null || second == null || first.equals(second)) {
            return false;
        }

        return isPair(first, second, SOFT_BLOW, CONCUSSION)
                || isPair(first, second, BLOCK, PERFECT_BLOCK);
    }

    private static boolean isPair(
            Holder<Enchantment> first,
            Holder<Enchantment> second,
            ResourceKey<Enchantment> a,
            ResourceKey<Enchantment> b
    ) {
        return (first.is(a) && second.is(b))
                || (first.is(b) && second.is(a));
    }

    public static int countOriginalGyeokbuSlots(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }

        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        int occupied = 0;

        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            occupied += getOriginalSlotCost(enchantment);
        }

        return occupied;
    }

    /** Includes active Knockback / Fire Aspect Gyeokbu bridge slots. */
    public static int countOccupiedGyeokbuSlots(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return 0;
        }

        int occupied = countOriginalGyeokbuSlots(stack);

        if (GyeokbuVanillaEnchantmentSlots.isActive(stack, Enchantments.KNOCKBACK)) {
            occupied++;
        }
        if (GyeokbuVanillaEnchantmentSlots.isActive(stack, Enchantments.FIRE_ASPECT)) {
            occupied++;
        }

        return Math.min(getCapacity(stack), occupied);
    }

    public static ItemStack createBook(
            HolderLookup.Provider provider,
            ResourceKey<Enchantment> enchantment,
            int level
    ) {
        Holder.Reference<Enchantment> holder = holder(provider, enchantment);
        int clamped = Math.max(1, Math.min(level, holder.value().getMaxLevel()));

        return EnchantedBookItem.createForEnchantment(
                new EnchantmentInstance(holder, clamped)
        );
    }

    public static ItemStack createBook(
            HolderLookup.Provider provider,
            ResourceKey<Enchantment> enchantment
    ) {
        return createBook(provider, enchantment, 1);
    }
}
