package com.wckd.gyeokbu.enchantment;

import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Final safety pass for generated enchanted items.
 *
 * Books remain requirement carriers, but generated books still cannot retain
 * mutually-exclusive Gyeokbu enchantments. Actual weapons must satisfy all
 * Gyeokbu dependencies and mutual exclusions before they are handed to the
 * player/world.
 */
public final class GyeokbuGeneratedEnchantmentSanitizer {

    private GyeokbuGeneratedEnchantmentSanitizer() {
    }

    public static ItemStack sanitize(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return stack;
        }

        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        if (enchantments.isEmpty()) {
            return stack;
        }

        boolean carrierBook = stack.is(Items.BOOK) || stack.is(Items.ENCHANTED_BOOK);
        boolean shield = GyeokbuEnchantments.isShield(stack);
        boolean weapon = GyeokbuEnchantments.isEligibleWeaponForEnchantments(stack);

        if (!carrierBook && !shield && !weapon) {
            return stack;
        }

        Set<Holder<Enchantment>> rejected = new HashSet<>();
        Set<Holder<Enchantment>> accepted = new LinkedHashSet<>();

        boolean hasBlockProvider = shield || containsProvider(enchantments);

        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (!GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)) {
                continue;
            }

            if (GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                rejected.add(enchantment);
                continue;
            }

            if (!carrierBook
                    && GyeokbuEnchantments.requiresBlockProvider(enchantment)
                    && !hasBlockProvider) {
                rejected.add(enchantment);
                continue;
            }

            if (conflictsWithAccepted(enchantment, accepted)) {
                rejected.add(enchantment);
                continue;
            }

            accepted.add(enchantment);
        }

        if (!rejected.isEmpty()) {
            EnchantmentHelper.updateEnchantments(
                    stack,
                    mutable -> mutable.removeIf(rejected::contains)
            );
        }

        return stack;
    }

    private static boolean containsProvider(ItemEnchantments enchantments) {
        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(GyeokbuEnchantments.BLOCK)
                    || enchantment.is(GyeokbuEnchantments.PERFECT_BLOCK)) {
                return true;
            }
        }
        return false;
    }

    private static boolean conflictsWithAccepted(
            Holder<Enchantment> candidate,
            Set<Holder<Enchantment>> accepted
    ) {
        for (Holder<Enchantment> other : accepted) {
            if (!candidate.equals(other)
                    && GyeokbuEnchantments.areMutuallyExclusive(candidate, other)) {
                return true;
            }
        }
        return false;
    }
}
