package com.wckd.gyeokbu.enchantment;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.enchantment.Enchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEnchantItemEvent;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Enforces Gyeokbu capacity, requirements and incompatibilities after table rolls. */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class GyeokbuEnchantingEvents {

    private GyeokbuEnchantingEvents() {
    }

    @SubscribeEvent
    public static void onPlayerEnchantItem(PlayerEnchantItemEvent event) {
        ItemStack stack = event.getEnchantedItem();

        if (stack == null || stack.isEmpty()) {
            return;
        }

        boolean shield = GyeokbuEnchantments.isShield(stack);
        if (!shield && !GyeokbuEnchantments.isEligibleWeaponForEnchantments(stack)) {
            return;
        }

        List<EnchantmentInstance> applied = event.getEnchantments();
        GyeokbuVanillaEnchantmentSlots.recordTableClaims(stack, applied);

        int capacity = GyeokbuEnchantments.getCapacity(stack);
        int usedSlots = 0;
        Set<Holder<Enchantment>> rejected = new HashSet<>();
        Set<Holder<Enchantment>> accepted = new HashSet<>();

        /*
         * Process the generated order deterministically. Rejected entries are
         * never added to accepted, so they cannot create false conflicts or
         * satisfy requirements for enchantments later in the same roll.
         */
        for (EnchantmentInstance instance : applied) {
            Holder<Enchantment> enchantment = instance.enchantment;
            if (accepted.contains(enchantment) || rejected.contains(enchantment)) {
                continue;
            }

            if (GyeokbuEnchantments.isGyeokbuEnchantment(enchantment)) {
                if (GyeokbuEnchantments.isLegacyRemovedEnchantment(enchantment)) {
                    rejected.add(enchantment);
                    continue;
                }

                /* Gyeokbu never makes shields directly table-enchantable.
                 * This post-roll guard mirrors EnchantmentMenuMixin for
                 * modded enchanting-table paths that bypass the vanilla menu. */
                if (shield) {
                    rejected.add(enchantment);
                    continue;
                }

                if (conflictsWithAccepted(enchantment, accepted)) {
                    rejected.add(enchantment);
                    continue;
                }

                int cost = GyeokbuEnchantments.getOriginalSlotCost(enchantment);
                if (usedSlots + cost > capacity) {
                    rejected.add(enchantment);
                    continue;
                }

                usedSlots += cost;
                accepted.add(enchantment);
                continue;
            }

            if (!shield && GyeokbuEnchantments.isVanillaGyeokbuBridge(enchantment)) {
                if (usedSlots < capacity) {
                    usedSlots++;
                }
            }
        }

        /* A Block modifier may only survive the roll if its resulting item has Block. */
        boolean hasAcceptedBlockProvider = shield
                || contains(accepted, GyeokbuEnchantments.BLOCK)
                || contains(accepted, GyeokbuEnchantments.PERFECT_BLOCK)
                || hasSurvivingBlockProvider(stack, rejected);

        if (!hasAcceptedBlockProvider) {
            for (Holder<Enchantment> enchantment : Set.copyOf(accepted)) {
                if (GyeokbuEnchantments.requiresBlockProvider(enchantment)) {
                    accepted.remove(enchantment);
                    rejected.add(enchantment);
                }
            }
        }

        if (!rejected.isEmpty()) {
            EnchantmentHelper.updateEnchantments(
                    stack,
                    mutable -> mutable.removeIf(rejected::contains)
            );
        }

        /* Record vanilla bridge claims only after rejected custom enchants are removed. */
        GyeokbuVanillaEnchantmentSlots.syncClaimsFromCurrentEnchantments(stack);
    }


    private static boolean hasSurvivingBlockProvider(
            ItemStack stack,
            Set<Holder<Enchantment>> rejected
    ) {
        for (Holder<Enchantment> enchantment :
                EnchantmentHelper.getEnchantmentsForCrafting(stack).keySet()) {
            if (!rejected.contains(enchantment)
                    && (enchantment.is(GyeokbuEnchantments.BLOCK)
                    || enchantment.is(GyeokbuEnchantments.PERFECT_BLOCK))) {
                return true;
            }
        }
        return false;
    }

    private static boolean contains(
            Set<Holder<Enchantment>> enchantments,
            net.minecraft.resources.ResourceKey<Enchantment> key
    ) {
        for (Holder<Enchantment> enchantment : enchantments) {
            if (enchantment.is(key)) {
                return true;
            }
        }
        return false;
    }

    private static boolean conflictsWithAccepted(
            Holder<Enchantment> candidate,
            Set<Holder<Enchantment>> accepted
    ) {
        for (Holder<Enchantment> other : accepted) {
            if (other != candidate
                    && GyeokbuEnchantments.areMutuallyExclusive(candidate, other)) {
                return true;
            }
        }
        return false;
    }
}
