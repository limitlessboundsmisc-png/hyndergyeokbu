package com.wckd.gyeokbu.loot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.wckd.gyeokbu.Config;
import com.wckd.gyeokbu.GyeokbuV2;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.neoforged.neoforge.common.loot.IGlobalLootModifier;
import net.neoforged.neoforge.common.loot.LootModifier;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

/** Additive supplemental exploration-book roll for one configured Gyeokbu loot tier. */
public final class GyeokbuBookLootModifier extends LootModifier {
    public static final MapCodec<GyeokbuBookLootModifier> CODEC = RecordCodecBuilder.mapCodec(instance ->
            LootModifier.codecStart(instance).and(
                    Codec.STRING.fieldOf("tier").forGetter(modifier -> modifier.tier)
            ).apply(instance, GyeokbuBookLootModifier::new)
    );

    private final String tier;

    public GyeokbuBookLootModifier(LootItemCondition[] conditions, String tier) {
        super(conditions);
        this.tier = normalizeTier(tier);
    }

    @Override
    public MapCodec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(
            ObjectArrayList<ItemStack> generatedLoot,
            LootContext context
    ) {
        if (!Config.SURVIVAL_ACQUISITION_ENABLED.getAsBoolean()
                || !Config.SUPPLEMENTAL_LOOT_ENABLED.getAsBoolean()
                || !tierEnabled()) {
            return generatedLoot;
        }

        RandomSource random = context.getRandom();
        double chance = Math.min(1.0D, baseChance() * Config.LOOT_FREQUENCY_MULTIPLIER.getAsDouble());
        if (chance <= 0.0D || random.nextDouble() >= chance) {
            return generatedLoot;
        }

        HolderLookup.RegistryLookup<Enchantment> lookup =
                context.getLevel().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        TagKey<Enchantment> tag = TagKey.create(
                Registries.ENCHANTMENT,
                ResourceLocation.fromNamespaceAndPath(GyeokbuV2.MODID, "loot/" + tier)
        );

        Optional<HolderSet.Named<Enchantment>> tagged = lookup.get(tag);
        if (tagged.isEmpty()) {
            return generatedLoot;
        }

        List<Holder<Enchantment>> options = tagged.get().stream().toList();
        if (options.isEmpty()) {
            return generatedLoot;
        }

        Holder<Enchantment> enchantment = options.get(random.nextInt(options.size()));
        int level = chooseLevel(random, enchantment.value().getMaxLevel());

        generatedLoot.add(EnchantedBookItem.createForEnchantment(
                new EnchantmentInstance(enchantment, level)
        ));
        return generatedLoot;
    }

    private boolean tierEnabled() {
        return switch (tier) {
            case "advanced" -> Config.ADVANCED_LOOT_ENABLED.getAsBoolean();
            case "elite" -> Config.ELITE_LOOT_ENABLED.getAsBoolean();
            default -> Config.COMMON_LOOT_ENABLED.getAsBoolean();
        };
    }

    private double baseChance() {
        return switch (tier) {
            case "advanced" -> Config.ADVANCED_LOOT_CHANCE.getAsDouble();
            case "elite" -> Config.ELITE_LOOT_CHANCE.getAsDouble();
            default -> Config.COMMON_LOOT_CHANCE.getAsDouble();
        };
    }

    private int chooseLevel(RandomSource random, int maxLevel) {
        if (maxLevel <= 1) {
            return 1;
        }

        double sample = random.nextDouble();
        double biased = switch (tier) {
            case "common" -> sample * sample;
            case "elite" -> 1.0D - ((1.0D - sample) * (1.0D - sample));
            default -> sample;
        };

        int level = 1 + (int) Math.floor(biased * maxLevel);
        return Math.max(1, Math.min(maxLevel, level));
    }

    private static String normalizeTier(String value) {
        if (value == null) {
            return "common";
        }
        return switch (value.toLowerCase(Locale.ROOT)) {
            case "advanced" -> "advanced";
            case "elite" -> "elite";
            default -> "common";
        };
    }
}
