package com.wckd.gyeokbu.advancement;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** Lightweight, code-awarded guidance advancements keyed to real Gyeokbu gameplay. */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class GyeokbuAdvancements {
    private static final ResourceLocation TECHNIQUE_ACQUIRED = id("technique_acquired");
    private static final ResourceLocation FIRST_DEFENSE = id("first_defense");
    private static final ResourceLocation HOLD_YOUR_GROUND = id("hold_your_ground");
    private static final ResourceLocation FULL_TECHNIQUE_SET = id("full_technique_set");
    private static final ResourceLocation PERFECT_DEFENSE = id("perfect_defense");
    private static final ResourceLocation UNTOUCHABLE = id("untouchable");

    private GyeokbuAdvancements() {
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        /* Once per second per player; this catches table, anvil, trade, chest,
         * command and modded inventory acquisition without a custom item system. */
        if (player.level().getGameTime() % 20L != Math.floorMod(player.getId(), 20)) {
            return;
        }

        scanInventory(player);
    }

    public static void awardFirstDefense(ServerPlayer player) {
        award(player, FIRST_DEFENSE);
    }

    public static void awardHoldYourGround(ServerPlayer player) {
        award(player, HOLD_YOUR_GROUND);
    }

    public static void awardUntouchable(ServerPlayer player) {
        award(player, UNTOUCHABLE);
    }

    private static void scanInventory(ServerPlayer player) {
        for (int slot = 0; slot < player.getInventory().getContainerSize(); slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack.isEmpty()) {
                continue;
            }

            if (GyeokbuEnchantments.countOccupiedGyeokbuSlots(stack) > 0) {
                award(player, TECHNIQUE_ACQUIRED);
            }

            if (contains(stack, GyeokbuEnchantments.PERFECT_BLOCK)) {
                award(player, PERFECT_DEFENSE);
            }

            if (GyeokbuEnchantments.isEligibleWeaponForEnchantments(stack)
                    && GyeokbuEnchantments.getCapacity(stack) >= 3
                    && GyeokbuEnchantments.countOccupiedGyeokbuSlots(stack) >= 3) {
                award(player, FULL_TECHNIQUE_SET);
            }
        }
    }

    private static boolean contains(
            ItemStack stack,
            net.minecraft.resources.ResourceKey<Enchantment> key
    ) {
        ItemEnchantments enchantments = EnchantmentHelper.getEnchantmentsForCrafting(stack);
        for (Holder<Enchantment> enchantment : enchantments.keySet()) {
            if (enchantment.is(key)) {
                return true;
            }
        }
        return false;
    }

    private static void award(ServerPlayer player, ResourceLocation id) {
        if (player == null) {
            return;
        }

        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        AdvancementHolder advancement = server.getAdvancements().get(id);
        if (advancement == null
                || player.getAdvancements().getOrStartProgress(advancement).isDone()) {
            return;
        }

        player.getAdvancements().award(advancement, "trigger");
    }

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(GyeokbuV2.MODID, path);
    }
}
