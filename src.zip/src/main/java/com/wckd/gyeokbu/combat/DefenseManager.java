package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.compat.BetterCombatServerCompat;
import com.wckd.gyeokbu.compat.ThrowableWeaponCompat;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantmentRuntime;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.network.DefenseAttackCancelPayload;
import com.wckd.gyeokbu.network.DefenseMovementSyncPayload;
import com.wckd.gyeokbu.network.ParryCooldownSyncPayload;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.HandStyle;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-authoritative Gyeokbu defense controller.
 *
 * This reworks the existing state machine rather than replacing the rest of
 * Gyeokbu. Weapon classification is preserved for stance/animation identity,
 * while the base mechanics are now universal for every supported weapon.
 */
public final class DefenseManager {

    private static final Map<UUID, DefenseData> PLAYER_DATA =
            new ConcurrentHashMap<>();

    private static final Map<UUID, Boolean> DEVELOPER_MESSAGES =
            new ConcurrentHashMap<>();

    /**
     * Kept as an internal timing marker for future Perfect-Parry Techniques.
     * It has no default reward.
     */
    public static final int PERFECT_PARRY_TICKS = 2;

    /** 0.30 seconds at 20 TPS. */
    public static final int PARRY_TICKS = 6;

    /** 1.00 second at 20 TPS after a missed Parry attempt. */
    public static final int MISSED_PARRY_COOLDOWN_TICKS = 20;

    public static final float DEFENSE_MOVEMENT_MULTIPLIER = 0.20F;

    private DefenseManager() {
    }

    public static DefenseData get(
            ServerPlayer player
    ) {
        return PLAYER_DATA.computeIfAbsent(
                player.getUUID(),
                uuid -> new DefenseData()
        );
    }

    public static void remove(
            ServerPlayer player
    ) {
        BetterCombatServerCompat.setAttacksDisabled(
                player,
                false
        );

        AttackCommitManager.remove(player);
        GyeokbuEnchantmentRuntime.remove(player);
        PLAYER_DATA.remove(player.getUUID());
        DEVELOPER_MESSAGES.remove(player.getUUID());
    }

    public static boolean canStartDefense(
            ServerPlayer player
    ) {
        return getDefenseStartRejectReason(player) == null;
    }

    /**
     * Null means the request is valid. The text is only surfaced when the
     * existing developer-message option is enabled, so normal players do not
     * receive debug spam.
     */
    private static String getDefenseStartRejectReason(
            ServerPlayer player
    ) {
        DefenseData data = get(player);
        long currentGameTime = player.serverLevel().getGameTime();

        if (data.isOnMissedParryCooldown(currentGameTime)) {
            return "miss cooldown ("
                    + data.getMissedParryCooldownTicks(currentGameTime)
                    + "t)";
        }

        WeaponProfile profile = WeaponClassifier.classify(
                player.getMainHandItem()
        );

        if (!profile.isSupported()) {
            return "mainhand unsupported";
        }

        if (!DualWieldRules.isValidDefenseLoadout(player)) {
            return "invalid loadout ("
                    + profile.handStyle().name()
                    + ")";
        }

        if (ThrowableWeaponCompat.isThrowActionActive(player)) {
            return "native throw active";
        }

        if (!AttackCommitManager.canStartDefense(player)) {
            return "active attack not hit-confirmed";
        }

        return null;
    }

    private static boolean canContinueDefense(
            ServerPlayer player,
            DefenseData data
    ) {
        if (ThrowableWeaponCompat.isThrowActionActive(player)) {
            return false;
        }

        if (!DualWieldRules.isValidDefenseLoadout(player)) {
            return false;
        }

        WeaponProfile profile = WeaponClassifier.classify(
                player.getMainHandItem()
        );

        if (!profile.isSupported()) {
            return false;
        }

        ResourceLocation currentMain = BuiltInRegistries.ITEM.getKey(
                player.getMainHandItem().getItem()
        );

        ResourceLocation startedMain = data.getStartedItemId();

        if (startedMain == null
                || !startedMain.equals(currentMain)) {
            return false;
        }

        boolean currentlyDual = DualWieldRules.isDualWield(player);

        if (currentlyDual != data.startedDualWield()) {
            return false;
        }

        if (!currentlyDual) {
            /*
             * Better Combat two-handed weapons disable/ignore their offhand.
             * Once the classifier marks the mainhand as two-handed, a visible
             * offhand stack must not invalidate Gyeokbu defense.
             */
            return profile.isTwoHanded()
                    || player.getOffhandItem().isEmpty();
        }

        ResourceLocation currentOff = BuiltInRegistries.ITEM.getKey(
                player.getOffhandItem().getItem()
        );

        ResourceLocation startedOff = data.getStartedOffhandItemId();

        return startedOff != null
                && startedOff.equals(currentOff);
    }

    public static void startDefense(
            ServerPlayer player
    ) {
        DefenseData data = get(player);

        if (data.isDefending()) {
            return;
        }

        /*
         * Hard missed-Parry lockout. Rejected presses during cooldown never
         * start/sync a Parry, and the remaining server value is mirrored back
         * to the client in case its local timer drifted or the original packet
         * arrived late.
         */
        long currentGameTime = player.serverLevel().getGameTime();
        if (data.isOnMissedParryCooldown(currentGameTime)) {
            syncParryCooldown(
                    player,
                    data.getMissedParryCooldownTicks(currentGameTime)
            );
            syncDefenseAnimation(
                    player,
                    DefenseAnimationSyncPayload.NONE
            );
            return;
        }

        String rejectReason = getDefenseStartRejectReason(player);
        if (rejectReason != null) {
            showActionbar(
                    player,
                    "§cParry rejected: " + rejectReason
            );
            /* Any client-side predicted PARRY must be revoked on a rejected click. */
            syncDefenseAnimation(
                    player,
                    DefenseAnimationSyncPayload.NONE
            );
            syncMovementPenalty(player, false);
            return;
        }

        ResourceLocation itemId = BuiltInRegistries.ITEM.getKey(
                player.getMainHandItem().getItem()
        );

        /*
         * Better Combat enhancement:
         * only a hit-confirmed active attack can reach this point. Cancel the
         * remainder of that exact attack generation before defense begins.
         */
        if (AttackCommitManager.isActive(player)) {
            AttackCommitManager.cancelCurrentAttack(player);
        }

        boolean dualWield = DualWieldRules.isDualWield(player);

        ResourceLocation offhandItemId = dualWield
                ? BuiltInRegistries.ITEM.getKey(
                        player.getOffhandItem().getItem()
                )
                : null;

        data.beginDefense(
                itemId,
                offhandItemId,
                dualWield,
                currentGameTime
        );

        /* Accepted defense proves there is no active server cooldown. */
        syncParryCooldown(player, 0);

        BetterCombatServerCompat.setAttacksDisabled(
                player,
                true
        );

        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                player,
                new DefenseAttackCancelPayload(player.getId(), true)
        );

        syncMovementPenalty(player, true);

        /* Client resolves the saved category/item Parry stance. */
        syncDefenseAnimation(
                player,
                DefenseAnimationSyncPayload.PARRY
        );

        player.setSprinting(false);
    }

    public static void releaseDefenseInput(
            ServerPlayer player
    ) {
        DefenseData data = get(player);

        if (!data.isDefending()) {
            return;
        }

        data.releaseInput();

        /*
         * Click-mode Parry is committed for its full timing window. Releasing
         * RMB early only records that Block should not begin afterward.
         *
         * Re-assert the authoritative live PARRY presentation on release. The
         * client input latch is allowed to drop immediately, but the visual
         * stance and movement penalty belong to DefenseData, not to the
         * physical RMB state. Only success or natural expiry may clear them.
         */
        if (data.getState() == DefenseState.PARRY) {
            BetterCombatServerCompat.setAttacksDisabled(
                    player,
                    true
            );

            syncMovementPenalty(player, true);
            syncDefenseAnimation(
                    player,
                    DefenseAnimationSyncPayload.PARRY
            );
            return;
        }

        BetterCombatServerCompat.setAttacksDisabled(
                player,
                false
        );

        syncMovementPenalty(player, false);
        syncDefenseAnimation(
                player,
                DefenseAnimationSyncPayload.NONE
        );

        showActionbar(
                player,
                "§aReady"
        );
    }

    /**
     * Forced interruption used by actions that must take ownership immediately
     * (for example Shift + RMB native throwable use). Unlike releasing RMB
     * during click-mode Parry, this really ends the current defense state.
     */
    public static void cancelDefense(
            ServerPlayer player
    ) {
        DefenseData data = get(player);

        if (!data.isDefending()) {
            return;
        }

        data.endDefense();
        BetterCombatServerCompat.setAttacksDisabled(player, false);
        syncMovementPenalty(player, false);
        syncDefenseAnimation(player, DefenseAnimationSyncPayload.NONE);
    }

    /**
     * Attack input cleanly drops Block and allows the attack immediately.
     */
    public static void cancelBlockForAttack(
            ServerPlayer player
    ) {
        DefenseData data = get(player);

        if (data.getState() != DefenseState.BLOCK) {
            return;
        }

        data.endDefense();

        BetterCombatServerCompat.setAttacksDisabled(
                player,
                false
        );

        syncMovementPenalty(player, false);
        syncDefenseAnimation(
                player,
                DefenseAnimationSyncPayload.NONE
        );
    }

    /**
     * A normal successful Parry consumes the current attempt and never rolls
     * directly into Block. Sweeping Guard is the explicit exception: it keeps
     * the same original Parry window active for additional successes without
     * refreshing its timer.
     */
    public static void successfulParry(
            ServerPlayer player,
            ParryGrade grade,
            HandStyle style,
            boolean keepOriginalWindow
    ) {
        DefenseData data = get(player);

        data.successfulParry(
                grade,
                keepOriginalWindow
        );

        if (keepOriginalWindow) {
            /* Sweeping Guard keeps the same input/window and stance active. */
            BetterCombatServerCompat.setAttacksDisabled(player, true);
            syncMovementPenalty(player, true);
            return;
        }

        /*
         * A successful normal Parry is immediately reusable. End the defense
         * presentation at the impact point and re-enable attacks immediately;
         * no success grace or cooldown exists.
         */
        BetterCombatServerCompat.setAttacksDisabled(player, false);
        syncMovementPenalty(player, false);
        syncDefenseAnimation(
                player,
                DefenseAnimationSyncPayload.NONE
        );
    }

    public static void tick(
            ServerPlayer player
    ) {
        GyeokbuEnchantmentRuntime.tick(player);

        DefenseData data = get(player);
        long currentGameTime = player.serverLevel().getGameTime();

        if (data.isDefending()
                && !canContinueDefense(player, data)) {
            data.endDefense();

            BetterCombatServerCompat.setAttacksDisabled(
                    player,
                    false
            );

            syncMovementPenalty(player, false);
            syncDefenseAnimation(
                    player,
                    DefenseAnimationSyncPayload.NONE
            );

            return;
        }

        if (data.getState() == DefenseState.BLOCK) {
            if (!GyeokbuEnchantments.hasBlockProvider(
                    player.level(),
                    player.getMainHandItem()
            )) {
                data.endDefense();
                BetterCombatServerCompat.setAttacksDisabled(player, false);
                syncMovementPenalty(player, false);
                syncDefenseAnimation(player, DefenseAnimationSyncPayload.NONE);
            }
            return;
        }

        if (data.getState() != DefenseState.PARRY) {
            return;
        }

        int elapsedParryTicks = data.getElapsedParryTicks(currentGameTime);

        if (elapsedParryTicks < getParryWindowTicks(player)) {
            return;
        }

        /*
         * A Sweeping Guard window that successfully Parried at least once still
         * follows the universal success rule at its natural end: it returns to
         * neutral instead of rolling into Block while RMB remains held.
         */
        if (data.getLastParryGrade() != ParryGrade.NONE) {
            data.finishUnusedParryWindow();
            BetterCombatServerCompat.setAttacksDisabled(player, false);
            syncMovementPenalty(player, false);
            syncDefenseAnimation(player, DefenseAnimationSyncPayload.NONE);
            return;
        }

        /*
         * Block is enchantment-granted, not universal. Holding through an
         * unused Parry window enters Block only when the held weapon has
         * Block I-III or Perfect Block I.
         */
        if (data.isInputHeld()
                && GyeokbuEnchantments.hasBlockProvider(
                        player.level(),
                        player.getMainHandItem()
                )) {
            data.startMissedParryCooldown(
                    currentGameTime,
                    MISSED_PARRY_COOLDOWN_TICKS
            );
            syncParryCooldown(player, MISSED_PARRY_COOLDOWN_TICKS);
            data.beginBlock();
            BetterCombatServerCompat.setAttacksDisabled(
                    player,
                    true
            );

            syncMovementPenalty(
                    player,
                    data.shouldApplyDefenseMovementPenalty()
            );

            syncDefenseAnimation(
                    player,
                    DefenseAnimationSyncPayload.BLOCK
            );

            return;
        }

        data.startMissedParryCooldown(
                currentGameTime,
                MISSED_PARRY_COOLDOWN_TICKS
        );
        syncParryCooldown(player, MISSED_PARRY_COOLDOWN_TICKS);
        data.finishUnusedParryWindow();

        BetterCombatServerCompat.setAttacksDisabled(
                player,
                false
        );

        syncMovementPenalty(player, false);
        syncDefenseAnimation(
                player,
                DefenseAnimationSyncPayload.NONE
        );
    }

    /** Mastery I-III add 1/2/3 ticks to the normal six-tick Parry window. */
    public static int getParryWindowTicks(ServerPlayer player) {
        int masteryLevel = GyeokbuEnchantments.getLevel(
                player.level(),
                player.getMainHandItem(),
                GyeokbuEnchantments.MASTERY
        );
        return PARRY_TICKS + Math.max(0, Math.min(3, masteryLevel));
    }

    /**
     * Perfect timing remains internally detectable for a future Perfect-Parry
     * Technique, but it has no default visual or gameplay reward.
     */
    public static ParryGrade getCurrentParryGrade(
            ServerPlayer player
    ) {
        DefenseData data = get(player);

        if (data.getState() != DefenseState.PARRY) {
            return ParryGrade.NONE;
        }

        int elapsedParryTicks = data.getElapsedParryTicks(
                player.serverLevel().getGameTime()
        );

        if (elapsedParryTicks < PERFECT_PARRY_TICKS) {
            return ParryGrade.PERFECT;
        }

        if (elapsedParryTicks < getParryWindowTicks(player)) {
            return ParryGrade.NORMAL;
        }

        return ParryGrade.NONE;
    }

    /**
     * Actionbar shows only the universal defense state. 1H/2H/category data is
     * now for stance/animation selection rather than combat identity.
     */
    public static void showCurrentState(
            ServerPlayer player
    ) {
        DefenseData data = get(player);

        switch (data.getState()) {
            case NEUTRAL -> {
            }

            case PARRY -> showActionbar(
                    player,
                    "§aParrying..."
            );

            case BLOCK -> showActionbar(
                    player,
                    "§bBLOCK"
            );

        }
    }

    private static void syncParryCooldown(
            ServerPlayer player,
            int ticks
    ) {
        PacketDistributor.sendToPlayer(
                player,
                new ParryCooldownSyncPayload(
                        Math.max(0, ticks)
                )
        );
    }

    public static void syncMovementPenalty(
            ServerPlayer player,
            boolean active
    ) {
        PacketDistributor.sendToPlayer(
                player,
                new DefenseMovementSyncPayload(active)
        );
    }

    public static void syncDefenseAnimation(
            ServerPlayer player,
            int mode
    ) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                player,
                new DefenseAnimationSyncPayload(
                        player.getId(),
                        mode
                )
        );
    }

    /**
     * Current server-authoritative visual state without creating a new
     * DefenseData entry. Used when a client begins tracking a player who may
     * already be defending.
     */
    public static int getCurrentAnimationMode(ServerPlayer player) {
        if (player == null) {
            return DefenseAnimationSyncPayload.NONE;
        }

        DefenseData data = PLAYER_DATA.get(player.getUUID());
        if (data == null) {
            return DefenseAnimationSyncPayload.NONE;
        }

        return switch (data.getState()) {
            case PARRY -> DefenseAnimationSyncPayload.PARRY;
            case BLOCK -> DefenseAnimationSyncPayload.BLOCK;
            case NEUTRAL -> DefenseAnimationSyncPayload.NONE;
        };
    }

    public static void setDeveloperMessagesEnabled(
            ServerPlayer player,
            boolean enabled
    ) {
        if (enabled) {
            DEVELOPER_MESSAGES.put(player.getUUID(), true);
        } else {
            DEVELOPER_MESSAGES.remove(player.getUUID());
        }
    }

    public static boolean areDeveloperMessagesEnabled(ServerPlayer player) {
        return player != null
                && DEVELOPER_MESSAGES.getOrDefault(player.getUUID(), false);
    }

    public static void showActionbar(
            ServerPlayer player,
            String text
    ) {
        if (!areDeveloperMessagesEnabled(player)) {
            return;
        }

        player.displayClientMessage(
                Component.literal(text),
                true
        );
    }
}
