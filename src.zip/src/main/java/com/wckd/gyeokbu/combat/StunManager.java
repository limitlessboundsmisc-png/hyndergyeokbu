package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.network.StunStateSyncPayload;
import com.wckd.gyeokbu.particle.ModParticles;
import com.wckd.gyeokbu.weapon.HandStyle;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class StunManager {

    public static final int MAX_WAIT_TICKS =
            10;

    private static final double STOPPED_THRESHOLD =
            0.0001D;

    private static final double ORBIT_RADIUS =
            0.55D;

    private static final double ORBIT_SPEED =
            0.55D;

    private static final double MEDIUM_OFFSET =
            0.22D;

    private static final double SMALL_OFFSET =
            0.42D;

    private static final double TINY_OFFSET =
            0.60D;

    /*
     * HARD STUN movement lock.
     *
     * Do NOT use Mob#setNoAi(true). No-AI mobs can stop normal physics
     * processing and appear frozen in mid-air.
     *
     * Instead, hard stun removes horizontal locomotion while normal entity
     * ticking continues, so gravity/falling still works.
     */
    private static final double HARD_STUN_SPEED_MODIFIER =
            -1.00D;

    private static final ResourceLocation HARD_STUN_SPEED_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(
                    GyeokbuV2.MODID,
                    "hard_stun_speed"
            );

    /*
     * Soft Stun movement after the first successful
     * player hit breaks HARD stun:
     *
     * ONE_HANDED -> 70% normal movement
     * TWO_HANDED -> 50% normal movement
     *
     * ADD_MULTIPLIED_TOTAL therefore uses:
     * -0.30 for 1H and -0.50 for 2H.
     */
    private static final double ONE_HANDED_SOFT_STUN_SPEED_MODIFIER =
            -0.30D;

    private static final double TWO_HANDED_SOFT_STUN_SPEED_MODIFIER =
            -0.50D;

    private static final ResourceLocation SOFT_STUN_SPEED_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(
                    GyeokbuV2.MODID,
                    "soft_stun_speed"
            );

    private static final Map<UUID, PendingStun>
            PENDING_STUNS =
            new HashMap<>();

    private static final Map<UUID, ActiveStun>
            ACTIVE_STUNS =
            new HashMap<>();

    private StunManager() {
    }

    public static void scheduleStun(
            LivingEntity target,
            ServerPlayer defender,
            int counterGeneration,
            int stunTicks,
            HandStyle handStyle
    ) {

        if (target == null
                || defender == null
                || target.isRemoved()
                || !target.isAlive()
                || stunTicks <= 0
                || handStyle == null) {

            return;
        }

        /*
         * 1H no longer creates a hard stun.
         *
         * Preserve the existing call sites (melee and reflected projectile)
         * but route the 1H reward into the dedicated -50% movement slow.
         * The target keeps AI and can still attack normally.
         */
        if (handStyle == HandStyle.ONE_HANDED) {

            clearExistingStun(
                    target
            );

            OneHandedParrySlowManager.apply(
                    target,
                    stunTicks
            );

            /*
             * Existing 1H Perfect guaranteed-crit timing begins with the new
             * movement-slow window instead of a hard-stun window.
             */
            PerfectParryCritManager.activatePerfectOnStunStart(
                    defender,
                    target,
                    stunTicks
            );

            return;
        }

        clearExistingStun(
                target
        );

        PENDING_STUNS.put(
                target.getUUID(),
                new PendingStun(
                        target,
                        defender.getUUID(),
                        counterGeneration,
                        stunTicks,
                        0,
                        0.0D,
                        handStyle
                )
        );

        spawnStunTrail(
                target,
                0.0D
        );
    }

    public static boolean isPending(
            Entity entity
    ) {

        return entity != null
                && PENDING_STUNS.containsKey(
                entity.getUUID()
        );
    }

    public static boolean isHardStunned(
            Entity entity
    ) {

        if (entity == null) {
            return false;
        }

        ActiveStun active =
                ACTIVE_STUNS.get(
                        entity.getUUID()
                );

        return active != null
                && !active.soft();
    }


    public static boolean isHardStunnedBy(
            Entity entity,
            HandStyle handStyle
    ) {
        if (entity == null
                || handStyle == null) {
            return false;
        }

        ActiveStun active =
                ACTIVE_STUNS.get(
                        entity.getUUID()
                );

        return active != null
                && !active.soft()
                && active.handStyle() == handStyle;
    }

    public static boolean isSoftStunned(
            Entity entity
    ) {

        if (entity == null) {
            return false;
        }

        ActiveStun active =
                ACTIVE_STUNS.get(
                        entity.getUUID()
                );

        return active != null
                && active.soft();
    }

    public static boolean isStunned(
            Entity entity
    ) {

        return isHardStunned(entity)
                || isSoftStunned(entity);
    }

    public static void clearForReparry(
            LivingEntity target
    ) {

        clearExistingStun(
                target
        );

        OneHandedParrySlowManager.clear(
                target
        );
    }

    /*
     * TWO-HANDED HARD -> SOFT STUN.
     *
     * The first successful PLAYER hit against a TWO-HANDED target
     * currently in HARD stun converts that target to SOFT stun
     * for exactly the remaining ORIGINAL timer.
     *
     * ONE-HANDED stuns are hard-only and never convert.
     *
     * ONE_HANDED soft stun -> 70% movement.
     * TWO_HANDED soft stun -> 50% movement.
     *
     * The successful hit and its normal Minecraft /
     * Better Combat knockback have already happened.
     * We only change the remaining stun state here.
     *
     * HARD stun no longer disables Mob AI. It uses a movement-speed lock plus
     * navigation/horizontal-motion suppression, so gravity remains active.
     *
     * Because projectile-parry stuns store HandStyle in
     * the same ActiveStun record, this rule automatically
     * applies to melee-created AND reflected-projectile-
     * created stuns.
     */
    public static boolean convertHardToSoft(
            LivingEntity target
    ) {

        if (target == null) {
            return false;
        }

        ActiveStun active =
                ACTIVE_STUNS.get(
                        target.getUUID()
                );

        if (active == null
                || active.soft()
                || active.handStyle() != HandStyle.TWO_HANDED) {

            return false;
        }

        removeHardStunModifier(
                target
        );

        applySoftStunModifier(
                target,
                active.handStyle()
        );

        if (target instanceof ServerPlayer player) {

            syncPlayerStunMode(
                    player,
                    StunStateSyncPayload.SOFT
            );
        }

        ACTIVE_STUNS.put(
                target.getUUID(),
                new ActiveStun(
                        target,
                        active.remainingTicks(),
                        active.phase(),
                        active.originalNoAi(),
                        active.handStyle(),
                        true
                )
        );

        return true;
    }

    @SubscribeEvent
    public static void onServerTick(
            ServerTickEvent.Post event
    ) {

        long now =
                event.getServer()
                        .overworld()
                        .getGameTime();

        processPendingStuns(
                event,
                now
        );

        processActiveStuns();
    }

    private static void processPendingStuns(
            ServerTickEvent.Post event,
            long now
    ) {

        Iterator<Map.Entry<UUID, PendingStun>>
                iterator =
                PENDING_STUNS
                        .entrySet()
                        .iterator();

        while (iterator.hasNext()) {

            Map.Entry<UUID, PendingStun> entry =
                    iterator.next();

            PendingStun pending =
                    entry.getValue();

            LivingEntity target =
                    pending.target();

            if (target == null
                    || target.isRemoved()
                    || !target.isAlive()) {

                /*
                 * Do NOT punish the defender for killing the parried target
                 * before the stun timer would have begun.
                 *
                 * For a 1H Perfect Parry, the guaranteed-crit reward belongs
                 * to the PLAYER, so it still receives the full intended
                 * duration even if the parried target dies before hard stun
                 * activation.
                 */
                if (target != null
                        && pending.handStyle()
                        == HandStyle.ONE_HANDED) {

                    ServerPlayer defender =
                            event.getServer()
                                    .getPlayerList()
                                    .getPlayer(
                                            pending.defenderId()
                                    );

                    if (defender != null) {
                        PerfectParryCritManager
                                .activatePerfectWithoutStun(
                                        defender,
                                        target,
                                        pending.stunTicks()
                                );
                    }
                }

                iterator.remove();
                continue;
            }

            spawnStunTrail(
                    target,
                    pending.phase()
            );

            boolean stoppedMoving =
                    target.getDeltaMovement()
                            .horizontalDistanceSqr()
                            < STOPPED_THRESHOLD;

            boolean timedOut =
                    pending.waitedTicks()
                            >= MAX_WAIT_TICKS;

            if (stoppedMoving
                    || timedOut) {

                boolean originalNoAi =
                        getOriginalNoAi(
                                target
                        );

                activateHardStun(
                        target
                );

                ACTIVE_STUNS.put(
                        target.getUUID(),
                        new ActiveStun(
                                target,
                                pending.stunTicks(),
                                pending.phase(),
                                originalNoAi,
                                pending.handStyle(),
                                false
                        )
                );

                if (target
                        instanceof ServerPlayer stunnedPlayer) {

                    syncPlayerStunMode(
                            stunnedPlayer,
                            StunStateSyncPayload.HARD
                    );
                }

                ServerPlayer defender =
                        event.getServer()
                                .getPlayerList()
                                .getPlayer(
                                        pending.defenderId()
                                );

                if (defender != null) {

                    CounterStateManager
                            .updateEndTick(
                                    defender,
                                    pending.counterGeneration(),
                                    now,
                                    pending.stunTicks()
                            );

                    if (pending.handStyle()
                            == HandStyle.ONE_HANDED) {

                        PerfectParryCritManager
                                .activatePerfectOnStunStart(
                                        defender,
                                        target,
                                        pending.stunTicks()
                                );
                    }
                }

                iterator.remove();
                continue;
            }

            entry.setValue(
                    new PendingStun(
                            target,
                            pending.defenderId(),
                            pending.counterGeneration(),
                            pending.stunTicks(),
                            pending.waitedTicks() + 1,
                            pending.phase()
                                    + ORBIT_SPEED,
                            pending.handStyle()
                    )
            );
        }
    }

    private static void processActiveStuns() {

        Iterator<Map.Entry<UUID, ActiveStun>>
                iterator =
                ACTIVE_STUNS
                        .entrySet()
                        .iterator();

        while (iterator.hasNext()) {

            Map.Entry<UUID, ActiveStun> entry =
                    iterator.next();

            ActiveStun active =
                    entry.getValue();

            LivingEntity target =
                    active.target();

            if (target == null
                    || target.isRemoved()
                    || !target.isAlive()) {

                cleanupActiveStun(
                        active
                );

                iterator.remove();
                continue;
            }

            if (!active.soft()) {

                /*
                 * HARD stun keeps the existing visual trail.
                 * SOFT stun intentionally has no stun particles.
                 */
                spawnStunTrail(
                        target,
                        active.phase()
                );

                /*
                 * HARD stun:
                 * do not continuously zero deltaMovement.
                 * Gravity and external knockback still work.
                 */
                if (target instanceof Mob mob) {

                    /*
                     * Keep AI ticking so gravity and normal physics continue,
                     * but stop path movement every server tick.
                     */
                    mob.getNavigation()
                            .stop();

                    /*
                     * Remove only horizontal velocity.
                     * Y is preserved so gravity, falling, and external vertical
                     * motion continue normally.
                     */
                    mob.setDeltaMovement(
                            0.0D,
                            mob.getDeltaMovement().y,
                            0.0D
                    );

                    mob.hurtMarked =
                            true;
                }

                if (target instanceof ServerPlayer player) {

                    player.xxa =
                            0.0F;

                    player.zza =
                            0.0F;

                    player.setSprinting(
                            false
                    );
                }
            }

            int remaining =
                    active.remainingTicks() - 1;

            if (remaining <= 0) {

                cleanupActiveStun(
                        active
                );

                iterator.remove();
                continue;
            }

            entry.setValue(
                    new ActiveStun(
                            target,
                            remaining,
                            active.phase()
                                    + ORBIT_SPEED,
                            active.originalNoAi(),
                            active.handStyle(),
                            active.soft()
                    )
            );
        }
    }

    private static void activateHardStun(
            LivingEntity target
    ) {

        removeSoftStunModifier(
                target
        );

        applyHardStunModifier(
                target
        );

        if (target instanceof Mob mob) {

            /*
             * Navigation is stopped, but AI itself stays enabled.
             * This is what lets gravity continue affecting mobs in mid-air.
             */
            mob.getNavigation()
                    .stop();

            mob.setDeltaMovement(
                    0.0D,
                    mob.getDeltaMovement().y,
                    0.0D
            );

            mob.hurtMarked =
                    true;
        }
    }

    private static boolean getOriginalNoAi(
            LivingEntity target
    ) {

        if (target instanceof Mob mob) {

            return mob.isNoAi();
        }

        return false;
    }

    private static void applyHardStunModifier(
            LivingEntity target
    ) {

        var movementSpeed =
                target.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movementSpeed == null) {
            return;
        }

        removeHardStunModifier(
                target
        );

        movementSpeed.addTransientModifier(
                new AttributeModifier(
                        HARD_STUN_SPEED_MODIFIER_ID,
                        HARD_STUN_SPEED_MODIFIER,
                        AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                )
        );
    }

    private static void removeHardStunModifier(
            LivingEntity target
    ) {

        var movementSpeed =
                target.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movementSpeed == null) {
            return;
        }

        movementSpeed.removeModifier(
                HARD_STUN_SPEED_MODIFIER_ID
        );
    }

    private static void applySoftStunModifier(
            LivingEntity target,
            HandStyle handStyle
    ) {

        if (target.getAttribute(
                Attributes.MOVEMENT_SPEED
        ) == null) {

            return;
        }

        removeSoftStunModifier(
                target
        );

        double modifierAmount =
                handStyle == HandStyle.ONE_HANDED
                        ? ONE_HANDED_SOFT_STUN_SPEED_MODIFIER
                        : TWO_HANDED_SOFT_STUN_SPEED_MODIFIER;

        AttributeModifier modifier =
                new AttributeModifier(
                        SOFT_STUN_SPEED_MODIFIER_ID,
                        modifierAmount,
                        AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                );

        target.getAttribute(
                Attributes.MOVEMENT_SPEED
        ).addTransientModifier(
                modifier
        );
    }

    private static void removeSoftStunModifier(
            LivingEntity target
    ) {

        var movementSpeed =
                target.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movementSpeed == null) {
            return;
        }

        movementSpeed.removeModifier(
                SOFT_STUN_SPEED_MODIFIER_ID
        );
    }

    private static void clearExistingStun(
            LivingEntity target
    ) {

        PENDING_STUNS.remove(
                target.getUUID()
        );

        ActiveStun active =
                ACTIVE_STUNS.remove(
                        target.getUUID()
                );

        if (active != null) {

            cleanupActiveStun(
                    active
            );
        }
    }

    private static void cleanupActiveStun(
            ActiveStun active
    ) {

        LivingEntity target =
                active.target();

        if (target == null) {
            return;
        }

        removeHardStunModifier(
                target
        );

        removeSoftStunModifier(
                target
        );

        if (target instanceof ServerPlayer player) {

            syncPlayerStunMode(
                    player,
                    StunStateSyncPayload.NONE
            );
        }
    }

    private static void syncPlayerStunMode(
            ServerPlayer player,
            int mode
    ) {

        PacketDistributor.sendToPlayer(
                player,
                new StunStateSyncPayload(
                        mode
                )
        );
    }

    /*
     * EXACT FOUR PARTICLES:
     *
     * BIG -> MEDIUM -> SMALL -> TINY
     */
    private static void spawnStunTrail(
            LivingEntity target,
            double phase
    ) {

        if (!(target.level()
                instanceof ServerLevel level)) {

            return;
        }

        double centerX =
                target.getX();

        double centerY =
                target.getY()
                        + target.getBbHeight()
                        + 0.28D;

        double centerZ =
                target.getZ();

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_BIG.get(),
                centerX,
                centerY,
                centerZ,
                phase,
                0.0D
        );

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_MEDIUM.get(),
                centerX,
                centerY,
                centerZ,
                phase - MEDIUM_OFFSET,
                -0.02D
        );

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_SMALL.get(),
                centerX,
                centerY,
                centerZ,
                phase - SMALL_OFFSET,
                -0.04D
        );

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_TINY.get(),
                centerX,
                centerY,
                centerZ,
                phase - TINY_OFFSET,
                -0.06D
        );
    }

    private static void spawnSingleOrbitParticle(
            ServerLevel level,
            net.minecraft.core.particles.SimpleParticleType type,
            double centerX,
            double centerY,
            double centerZ,
            double phase,
            double yOffset
    ) {

        double x =
                centerX
                        + Math.cos(
                        phase
                )
                        * ORBIT_RADIUS;

        double z =
                centerZ
                        + Math.sin(
                        phase
                )
                        * ORBIT_RADIUS;

        level.sendParticles(
                type,
                x,
                centerY + yOffset,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
        );
    }

    private record PendingStun(
            LivingEntity target,
            UUID defenderId,
            int counterGeneration,
            int stunTicks,
            int waitedTicks,
            double phase,
            HandStyle handStyle
    ) {
    }

    private record ActiveStun(
            LivingEntity target,
            int remainingTicks,
            double phase,
            boolean originalNoAi,
            HandStyle handStyle,
            boolean soft
    ) {
    }
}
