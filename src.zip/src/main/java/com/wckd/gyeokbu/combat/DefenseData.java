package com.wckd.gyeokbu.combat;

import net.minecraft.resources.ResourceLocation;

/**
 * Server-authoritative per-player defense state for the universal Build 1
 * baseline.
 *
 * Weapon categories do not influence combat rewards here. The state only
 * remembers enough information to keep one continuous defense attempt bound to
 * the same loadout until release/interruption.
 */
public final class DefenseData {

    private DefenseState state = DefenseState.NEUTRAL;
    private ParryGrade lastParryGrade = ParryGrade.NONE;

    /*
     * Absolute server game-time markers are used instead of incrementing a
     * counter from PlayerTick.Post. A Parry can begin earlier in the same tick
     * as PlayerTick.Post; incrementing immediately would make a five-tick
     * window last only four full tick intervals (~0.20 s). Game time preserves
     * the requested real six-tick / 0.30 s lifetime.
     */
    private long parryStartedGameTime = Long.MIN_VALUE;
    private long missedParryCooldownUntilGameTime = Long.MIN_VALUE;

    private boolean inputHeld = false;

    private ResourceLocation startedItemId = null;
    private ResourceLocation startedOffhandItemId = null;
    private boolean startedDualWield = false;

    public DefenseState getState() {
        return state;
    }

    public ParryGrade getLastParryGrade() {
        return lastParryGrade;
    }

    public int getElapsedParryTicks(long currentGameTime) {
        if (state != DefenseState.PARRY
                || parryStartedGameTime == Long.MIN_VALUE) {
            return 0;
        }

        long elapsed = currentGameTime - parryStartedGameTime;
        if (elapsed <= 0L) {
            return 0;
        }

        return elapsed >= Integer.MAX_VALUE
                ? Integer.MAX_VALUE
                : (int) elapsed;
    }

    public int getMissedParryCooldownTicks(long currentGameTime) {
        if (missedParryCooldownUntilGameTime == Long.MIN_VALUE) {
            return 0;
        }

        long remaining = missedParryCooldownUntilGameTime - currentGameTime;
        if (remaining <= 0L) {
            return 0;
        }

        return remaining >= Integer.MAX_VALUE
                ? Integer.MAX_VALUE
                : (int) remaining;
    }

    public boolean isOnMissedParryCooldown(long currentGameTime) {
        return getMissedParryCooldownTicks(currentGameTime) > 0;
    }

    public void startMissedParryCooldown(
            long currentGameTime,
            int ticks
    ) {
        long requestedUntil = currentGameTime + Math.max(0, ticks);
        missedParryCooldownUntilGameTime = Math.max(
                missedParryCooldownUntilGameTime,
                requestedUntil
        );
    }

    public boolean isInputHeld() {
        return inputHeld;
    }

    public ResourceLocation getStartedItemId() {
        return startedItemId;
    }

    public ResourceLocation getStartedOffhandItemId() {
        return startedOffhandItemId;
    }

    public boolean startedDualWield() {
        return startedDualWield;
    }

    public boolean isDefending() {
        return state == DefenseState.PARRY
                || state == DefenseState.BLOCK;
    }

    public boolean shouldApplyDefenseMovementPenalty() {
        return isDefending();
    }

    public void beginDefense(
            ResourceLocation itemId,
            ResourceLocation offhandItemId,
            boolean dualWield,
            long currentGameTime
    ) {
        state = DefenseState.PARRY;
        lastParryGrade = ParryGrade.NONE;
        parryStartedGameTime = currentGameTime;
        inputHeld = true;
        startedItemId = itemId;
        startedOffhandItemId = offhandItemId;
        startedDualWield = dualWield;
    }

    /**
     * Click-mode Parry keeps the active Parry window alive after an early RMB
     * release. Releasing only ends defense immediately once the attempt has
     * already rolled into Block.
     */
    public void releaseInput() {
        inputHeld = false;

        if (state == DefenseState.BLOCK) {
            endDefense();
        }
    }

    /**
     * Holding through an unused Parry window becomes ordinary Block.
     */
    public void beginBlock() {
        if (state != DefenseState.PARRY) {
            return;
        }

        state = DefenseState.BLOCK;
        parryStartedGameTime = Long.MIN_VALUE;
        lastParryGrade = ParryGrade.NONE;
    }

    /**
     * Normal Parries consume the attempt immediately. Sweeping Guard is the
     * exception: it keeps the original Parry window alive without refreshing
     * the original game-time marker, so multiple attacks can be Parried before
     * that same window naturally ends.
     */
    public void successfulParry(
            ParryGrade grade,
            boolean keepOriginalWindow
    ) {
        lastParryGrade = grade;

        if (keepOriginalWindow && state == DefenseState.PARRY) {
            return;
        }

        /* A normal successful Parry ends immediately and is reusable at once. */
        parryStartedGameTime = Long.MIN_VALUE;
        state = DefenseState.NEUTRAL;
        inputHeld = false;
        clearDefenseLoadout();
    }

    public void finishUnusedParryWindow() {
        endDefense();
    }

    public void endDefense() {
        state = DefenseState.NEUTRAL;
        lastParryGrade = ParryGrade.NONE;
        parryStartedGameTime = Long.MIN_VALUE;
        inputHeld = false;
        clearDefenseLoadout();
    }

    public void reset() {
        endDefense();
        missedParryCooldownUntilGameTime = Long.MIN_VALUE;
    }

    private void clearDefenseLoadout() {
        startedItemId = null;
        startedOffhandItemId = null;
        startedDualWield = false;
    }
}
