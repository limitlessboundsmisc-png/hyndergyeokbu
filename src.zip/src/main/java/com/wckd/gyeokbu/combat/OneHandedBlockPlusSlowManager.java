package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.particle.ModParticles;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * ONE-HANDED BLOCK+ melee-attacker slow.
 *
 * This is intentionally separate from BlockPlusSlowManager so the established
 * 2H Block+ behavior remains completely unchanged.
 *
 * 1H Block+:
 * - living melee attacker receives -50% movement speed;
 * - duration is supplied by DefenseCombatEvents (30 ticks / 1.5 s);
 * - no Gyeokbu knockback is applied to the enemy;
 * - a direct player hit breaks the slow;
 * - the breaking hit continues through normal damage;
 * - the breaking hit applies no extra Gyeokbu knockback.
 */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class OneHandedBlockPlusSlowManager {

    private static final double SPEED_MODIFIER =
            -0.50D;

    private static final ResourceLocation SPEED_MODIFIER_ID =
            ResourceLocation.fromNamespaceAndPath(
                    GyeokbuV2.MODID,
                    "one_handed_block_plus_slow"
            );

    /*
     * Slowness uses the same four status particles as Parry stun/slowness,
     * but keeps the slower orbit used by the 1H Parry slow.
     *
     * Regular stun orbit = 0.55 rad/tick
     * Slowness orbit      = 0.22 rad/tick (60% slower)
     */
    private static final double ORBIT_RADIUS =
            0.55D;

    private static final double ORBIT_SPEED =
            0.22D;

    private static final double MEDIUM_OFFSET =
            0.22D;

    private static final double SMALL_OFFSET =
            0.42D;

    private static final double TINY_OFFSET =
            0.60D;

    private static final Map<UUID, ActiveSlow> ACTIVE =
            new HashMap<>();

    private OneHandedBlockPlusSlowManager() {
    }

    public static void apply(
            LivingEntity target,
            int durationTicks
    ) {
        if (target == null
                || target.isRemoved()
                || !target.isAlive()
                || durationTicks <= 0) {
            return;
        }

        clear(
                target
        );

        var movement =
                target.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movement != null) {
            movement.addTransientModifier(
                    new AttributeModifier(
                            SPEED_MODIFIER_ID,
                            SPEED_MODIFIER,
                            AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
                    )
            );
        }

        ACTIVE.put(
                target.getUUID(),
                new ActiveSlow(
                        target,
                        durationTicks,
                        0.0D
                )
        );

        spawnSlowTrail(
                target,
                0.0D
        );
    }

    public static boolean isSlowed(
            LivingEntity target
    ) {
        return target != null
                && ACTIVE.containsKey(
                        target.getUUID()
                );
    }

    /**
     * Returns true only when a direct player attack consumes the 1H Block+
     * slow. DefenseCombatEvents leaves that breaking hit uncanceled, so normal
     * damage continues. No extra Gyeokbu knockback is added to the enemy.
     */
    public static boolean consumeOnPlayerAttack(
            LivingEntity target,
            Entity directAttacker
    ) {
        if (!(directAttacker instanceof ServerPlayer)
                || !isSlowed(target)) {
            return false;
        }

        clear(
                target
        );

        return true;
    }

    public static void clear(
            LivingEntity target
    ) {
        if (target == null) {
            return;
        }

        ACTIVE.remove(
                target.getUUID()
        );

        removeModifier(
                target
        );
    }

    @SubscribeEvent
    public static void onServerTick(
            ServerTickEvent.Post event
    ) {
        Iterator<Map.Entry<UUID, ActiveSlow>> iterator =
                ACTIVE.entrySet()
                        .iterator();

        while (iterator.hasNext()) {
            Map.Entry<UUID, ActiveSlow> entry =
                    iterator.next();

            ActiveSlow active =
                    entry.getValue();

            LivingEntity target =
                    active.target();

            if (target == null
                    || target.isRemoved()
                    || !target.isAlive()) {
                if (target != null) {
                    removeModifier(
                            target
                    );
                }

                iterator.remove();
                continue;
            }

            spawnSlowTrail(
                    target,
                    active.phase()
            );

            int remaining =
                    active.remainingTicks() - 1;

            if (remaining <= 0) {
                removeModifier(
                        target
                );

                iterator.remove();
                continue;
            }

            entry.setValue(
                    new ActiveSlow(
                            target,
                            remaining,
                            active.phase() + ORBIT_SPEED
                    )
            );
        }
    }

    private static void removeModifier(
            LivingEntity target
    ) {
        var movement =
                target.getAttribute(
                        Attributes.MOVEMENT_SPEED
                );

        if (movement != null) {
            movement.removeModifier(
                    SPEED_MODIFIER_ID
            );
        }
    }

    /**
     * Same four Gyeokbu status particles used by Parry stun/slowness.
     * Block+ slowness uses the slower slowness orbit.
     */
    private static void spawnSlowTrail(
            LivingEntity target,
            double phase
    ) {
        if (!(target.level()
                instanceof ServerLevel level)) {
            return;
        }

        double centerX =
                target.getX();

        double centerY =
                target.getY()
                        + target.getBbHeight()
                        + 0.28D;

        double centerZ =
                target.getZ();

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_BIG.get(),
                centerX,
                centerY,
                centerZ,
                phase,
                0.0D
        );

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_MEDIUM.get(),
                centerX,
                centerY,
                centerZ,
                phase - MEDIUM_OFFSET,
                -0.02D
        );

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_SMALL.get(),
                centerX,
                centerY,
                centerZ,
                phase - SMALL_OFFSET,
                -0.04D
        );

        spawnSingleOrbitParticle(
                level,
                ModParticles.STUN_CRIT_TINY.get(),
                centerX,
                centerY,
                centerZ,
                phase - TINY_OFFSET,
                -0.06D
        );
    }

    private static void spawnSingleOrbitParticle(
            ServerLevel level,
            net.minecraft.core.particles.SimpleParticleType type,
            double centerX,
            double centerY,
            double centerZ,
            double phase,
            double yOffset
    ) {
        double x =
                centerX
                        + Math.cos(
                                phase
                        )
                        * ORBIT_RADIUS;

        double z =
                centerZ
                        + Math.sin(
                                phase
                        )
                        * ORBIT_RADIUS;

        level.sendParticles(
                type,
                x,
                centerY + yOffset,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
        );
    }

    private record ActiveSlow(
            LivingEntity target,
            int remainingTicks,
            double phase
    ) {
    }
}
