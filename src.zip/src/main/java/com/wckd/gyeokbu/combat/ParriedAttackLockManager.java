package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Tiny server-side damage lock applied to the entity that was just Parried.
 *
 * It does not stun movement, rotation, AI, or animation. It only prevents that
 * attacker from dealing damage for two server ticks (0.1 seconds), which closes
 * the immediate re-hit gap after a successful Parry without giving the defender
 * any post-Parry invulnerability.
 */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class ParriedAttackLockManager {

    public static final int ATTACK_LOCK_TICKS = 2;

    private static final Map<UUID, LockedAttacker> LOCKED_ATTACKERS =
            new HashMap<>();

    private ParriedAttackLockManager() {
    }

    public static void lock(LivingEntity attacker) {
        if (attacker == null || attacker.level().isClientSide) {
            return;
        }

        long unlockGameTime = attacker.level().getGameTime() + ATTACK_LOCK_TICKS;

        LOCKED_ATTACKERS.put(
                attacker.getUUID(),
                new LockedAttacker(attacker, unlockGameTime)
        );
    }

    public static boolean isLocked(LivingEntity attacker) {
        if (attacker == null || attacker.level().isClientSide) {
            return false;
        }

        LockedAttacker locked = LOCKED_ATTACKERS.get(attacker.getUUID());

        if (locked == null) {
            return false;
        }

        if (locked.attacker() != attacker
                || attacker.isRemoved()
                || !attacker.isAlive()
                || attacker.level().getGameTime() >= locked.unlockGameTime()) {
            LOCKED_ATTACKERS.remove(attacker.getUUID());
            return false;
        }

        return true;
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        Iterator<Map.Entry<UUID, LockedAttacker>> iterator =
                LOCKED_ATTACKERS.entrySet().iterator();

        while (iterator.hasNext()) {
            LockedAttacker locked = iterator.next().getValue();
            LivingEntity attacker = locked.attacker();

            if (attacker == null
                    || attacker.isRemoved()
                    || !attacker.isAlive()
                    || attacker.level().getGameTime() >= locked.unlockGameTime()) {
                iterator.remove();
            }
        }
    }

    private record LockedAttacker(
            LivingEntity attacker,
            long unlockGameTime
    ) {
    }
}
