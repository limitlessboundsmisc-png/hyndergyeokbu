package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.advancement.GyeokbuAdvancements;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantmentRuntime;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Projectile Parry baseline and the Projectile Reflect Block enchantment. */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class ProjectileParryManager {

    private static final float REFLECTED_DAMAGE_MULTIPLIER = 0.50F;

    private static final Map<UUID, ReflectedProjectileData> REFLECTED_PROJECTILES =
            new HashMap<>();

    private ProjectileParryManager() {
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        Projectile projectile = event.getProjectile();

        if (projectile.level().isClientSide) {
            return;
        }

        HitResult hitResult = event.getRayTraceResult();

        if (!(hitResult instanceof EntityHitResult entityHitResult)) {
            return;
        }

        Entity hitEntity = entityHitResult.getEntity();

        if (!(hitEntity instanceof ServerPlayer defender)) {
            return;
        }

        Entity owner = projectile.getOwner();

        if (!(owner instanceof LivingEntity attacker) || attacker == defender) {
            return;
        }

        WeaponProfile profile = WeaponClassifier.classify(defender.getMainHandItem());

        if (!profile.isSupported()) {
            return;
        }

        DefenseData data = DefenseManager.get(defender);

        if (data.getState() == DefenseState.PARRY) {
            handleProjectileParry(
                    event,
                    projectile,
                    defender,
                    attacker,
                    profile
            );
            return;
        }

        if (data.getState() == DefenseState.BLOCK
                && GyeokbuEnchantments.hasBlockProvider(
                        defender.level(),
                        defender.getMainHandItem()
                )
                && GyeokbuEnchantments.has(
                        defender.level(),
                        defender.getMainHandItem(),
                        GyeokbuEnchantments.PROJECTILE_REFLECT
                )) {
            handleProjectileBlockReflect(
                    projectile,
                    defender,
                    attacker
            );
        }
    }

    private static void handleProjectileParry(
            ProjectileImpactEvent event,
            Projectile projectile,
            ServerPlayer defender,
            LivingEntity attacker,
            WeaponProfile profile
    ) {
        ParryGrade grade = DefenseManager.getCurrentParryGrade(defender);

        if (grade == ParryGrade.NONE) {
            return;
        }

        event.setCanceled(true);
        performProjectileParry(projectile, defender, attacker, profile, grade);
    }

    /**
     * Fallback for modded Projectile implementations that deal damage through
     * their own collision loop and never fire ProjectileImpactEvent.
     *
     * Iron's Spells normally reaches the regular impact hook. Wind Spellbooks'
     * WindBladeProjectile is one example that needs this damage-event path.
     */
    public static boolean tryParryIncomingDamage(
            LivingIncomingDamageEvent event,
            Projectile projectile,
            ServerPlayer defender,
            LivingEntity attacker,
            WeaponProfile profile,
            ParryGrade grade
    ) {
        if (grade == ParryGrade.NONE
                || projectile == null
                || attacker == null
                || attacker == defender) {
            return false;
        }

        event.setCanceled(true);
        performProjectileParry(projectile, defender, attacker, profile, grade);
        return true;
    }

    private static void performProjectileParry(
            Projectile projectile,
            ServerPlayer defender,
            LivingEntity attacker,
            WeaponProfile profile,
            ParryGrade grade
    ) {
        Vec3 incomingDirection = projectile.getDeltaMovement();

        reflectTowardAttacker(projectile, defender, attacker);
        markReflected(projectile, REFLECTED_DAMAGE_MULTIPLIER);

        /* A projectile Successful Parry also receives the same centralized
         * knockback/redirect rule as a melee Successful Parry. */
        DefenseCombatEvents.applySuccessfulParryKnockback(
                defender,
                attacker,
                defender.getMainHandItem()
        );

        /* Soft Blow, Concussion, Vulnerability and other non-knockback hooks. */
        GyeokbuEnchantmentRuntime.onSuccessfulParry(defender, attacker);
        ParriedAttackLockManager.lock(attacker);

        DefenseCombatEvents.playSuccessfulParryFeedback(
                defender,
                projectile,
                incomingDirection
        );

        boolean sweepingGuard = GyeokbuEnchantments.has(
                defender.level(),
                defender.getMainHandItem(),
                GyeokbuEnchantments.SWEEPING_GUARD
        );

        DefenseManager.successfulParry(
                defender,
                grade,
                profile.handStyle(),
                sweepingGuard
        );

        DefenseManager.showActionbar(
                defender,
                "§aProjectile Parry! §7| Returned"
        );
        GyeokbuAdvancements.awardFirstDefense(defender);
    }

    /**
     * Block reflection deliberately does NOT cancel the original impact. The
     * defender therefore still receives Gyeokbu's normal Block treatment for
     * direct projectile damage (and ordinary explosion behavior for explosion
     * types that Gyeokbu does not normally block). A cloned redirected
     * projectile is sent back to the real sender at 50% damage.
     */
    /** Public bridge used by shield Block modifiers. */
    public static void reflectBlockedProjectile(
            Projectile original,
            ServerPlayer defender,
            LivingEntity attacker
    ) {
        handleProjectileBlockReflect(original, defender, attacker);
    }

    private static void handleProjectileBlockReflect(
            Projectile original,
            ServerPlayer defender,
            LivingEntity attacker
    ) {
        Projectile reflected = cloneProjectile(original);

        if (reflected == null) {
            return;
        }

        reflectTowardAttacker(reflected, defender, attacker);
        markReflected(reflected, REFLECTED_DAMAGE_MULTIPLIER);

        if (reflected.level() instanceof ServerLevel serverLevel) {
            if (!serverLevel.addFreshEntity(reflected)) {
                REFLECTED_PROJECTILES.remove(reflected.getUUID());
            }
        }
    }

    /** All damage sourced by a reflected projectile uses its stored multiplier. */
    public static void applyReflectedDamageScaling(LivingIncomingDamageEvent event) {
        Entity direct = event.getSource().getDirectEntity();

        if (!(direct instanceof Projectile projectile)) {
            return;
        }

        ReflectedProjectileData reflected = REFLECTED_PROJECTILES.get(projectile.getUUID());

        if (reflected == null) {
            return;
        }

        event.setAmount(event.getAmount() * reflected.damageMultiplier());
    }

    /**
     * Kept for the existing caller. Reflected entries now survive the first
     * hit so piercing/AOE/explosion damage from the same projectile is also
     * consistently scaled; cleanup happens when the projectile is removed.
     */
    public static void handleReflectedDamageApplied(LivingDamageEvent.Post event) {
        // Intentionally no first-hit removal.
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        Iterator<Map.Entry<UUID, ReflectedProjectileData>> iterator =
                REFLECTED_PROJECTILES.entrySet().iterator();

        while (iterator.hasNext()) {
            Projectile projectile = iterator.next().getValue().projectile();

            if (projectile == null || projectile.isRemoved() || !projectile.isAlive()) {
                iterator.remove();
            }
        }
    }

    private static void markReflected(Projectile projectile, float multiplier) {
        REFLECTED_PROJECTILES.put(
                projectile.getUUID(),
                new ReflectedProjectileData(projectile, multiplier)
        );
    }

    /**
     * Generic vanilla-projectile copy for Block reflection. If a modded
     * projectile refuses normal entity serialization, the enchantment leaves
     * that impact untouched instead of corrupting or deleting the projectile.
     */
    private static Projectile cloneProjectile(Projectile original) {
        if (!(original.level() instanceof ServerLevel serverLevel)) {
            return null;
        }

        CompoundTag tag = new CompoundTag();

        if (!original.save(tag)) {
            return null;
        }

        Entity copied = EntityType.create(tag, serverLevel).orElse(null);

        if (!(copied instanceof Projectile projectile)) {
            return null;
        }

        projectile.setUUID(UUID.randomUUID());
        return projectile;
    }

    private static void reflectTowardAttacker(
            Projectile projectile,
            ServerPlayer defender,
            LivingEntity attacker
    ) {
        double speed = projectile.getDeltaMovement().length();

        if (speed < 0.10D) {
            speed = 0.10D;
        }

        Vec3 direction = attacker.getEyePosition().subtract(projectile.position());

        if (direction.lengthSqr() < 0.0001D) {
            direction = defender.getLookAngle().scale(-1.0D);
        }

        direction = direction.normalize();

        Vec3 reflectedStart = defender.getEyePosition().add(direction.scale(0.75D));

        projectile.setPos(
                reflectedStart.x,
                reflectedStart.y,
                reflectedStart.z
        );

        projectile.setOwner(defender);

        projectile.shoot(
                direction.x,
                direction.y,
                direction.z,
                (float) speed,
                0.0F
        );

        projectile.hurtMarked = true;
    }

    private record ReflectedProjectileData(
            Projectile projectile,
            float damageMultiplier
    ) {
    }
}
