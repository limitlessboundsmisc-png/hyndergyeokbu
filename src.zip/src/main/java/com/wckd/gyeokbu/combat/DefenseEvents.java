package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.compat.ThrowableWeaponCompat;
import com.wckd.gyeokbu.network.DefenseAnimationSyncPayload;
import com.wckd.gyeokbu.network.StunStateSyncPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class DefenseEvents {

    private DefenseEvents() {
    }


    /**
     * Clear all transient server-authoritative combat state when a player
     * leaves. Without this, reconnecting after a disconnect during defense or
     * a Better Combat attack could inherit stale UUID-keyed state.
     */
    @SubscribeEvent
    public static void onPlayerLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            DefenseManager.remove(player);
        }
    }

    /**
     * A respawn creates a new ServerPlayer with the same UUID. Clear the old
     * UUID-keyed combat state and explicitly reset the new client's local
     * movement/stance/stun state so dying mid-defense or mid-Concussion cannot
     * survive into the respawned player.
     */
    @SubscribeEvent
    public static void onPlayerRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        DefenseManager.remove(player);
        DefenseManager.syncMovementPenalty(player, false);
        DefenseManager.syncDefenseAnimation(
                player,
                DefenseAnimationSyncPayload.NONE
        );
        PacketDistributor.sendToPlayer(
                player,
                new StunStateSyncPayload(StunStateSyncPayload.NONE)
        );
    }

    /**
     * Tracking can begin after the target already entered Parry/Block. Send the
     * current authoritative stance immediately so late-arriving players do not
     * wait for another state transition before seeing the correct pose. Sending
     * NONE also clears any stale client entry from an earlier tracking period.
     */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (!(event.getEntity() instanceof ServerPlayer trackingPlayer)
                || !(event.getTarget() instanceof ServerPlayer trackedPlayer)) {
            return;
        }

        PacketDistributor.sendToPlayer(
                trackingPlayer,
                new DefenseAnimationSyncPayload(
                        trackedPlayer.getId(),
                        DefenseManager.getCurrentAnimationMode(trackedPlayer)
                )
        );
    }

    @SubscribeEvent
    public static void onPlayerTickPre(
            PlayerTickEvent.Pre event
    ) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        DefenseData data = DefenseManager.get(player);

        /*
         * Native throwable use owns its action. The client already releases
         * immediately, but the server remains authoritative.
         */
        if (data.isDefending()
                && ThrowableWeaponCompat.isThrowActionActive(player)) {
            DefenseManager.cancelDefense(player);
            data = DefenseManager.get(player);
        }

        /*
         * Existing universal defense movement slowdown retained for Build 1.
         * No weapon category changes this value.
         */
        if (data.shouldApplyDefenseMovementPenalty()) {
            player.xxa *= DefenseManager.DEFENSE_MOVEMENT_MULTIPLIER;
            player.zza *= DefenseManager.DEFENSE_MOVEMENT_MULTIPLIER;
            player.setSprinting(false);
        }
    }

    @SubscribeEvent
    public static void onPlayerTickPost(
            PlayerTickEvent.Post event
    ) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        DefenseManager.tick(player);

        DefenseData data = DefenseManager.get(player);

        if (data.getState() == DefenseState.PARRY
                || data.getState() == DefenseState.BLOCK) {
            DefenseManager.showCurrentState(player);
        }
    }
}
