package com.wckd.gyeokbu.combat;

import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks the current Better Combat melee attack generation.
 *
 * Rules:
 *
 * ATTACK START
 * -> active
 * -> not confirmed
 * -> parry locked
 *
 * FIRST POSITIVE-DAMAGE MELEE HIT
 * -> confirmed
 * -> parry may now interrupt the remaining attack
 *
 * PARRY DURING CONFIRMED ATTACK
 * -> attack generation becomes cancelled
 * -> any delayed hits from that generation are rejected
 *
 * ATTACK END
 * -> state is cleared
 */
public final class AttackCommitManager {

    private static final Map<UUID, AttackState>
            ATTACK_STATES =
            new ConcurrentHashMap<>();

    private AttackCommitManager() {
    }

    public static void beginAttack(
            ServerPlayer player,
            int generation
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        /*
         * Ignore an obviously stale start packet.
         */
        if (current != null
                && generation
                < current.generation) {

            return;
        }

        ATTACK_STATES.put(
                player.getUUID(),
                new AttackState(
                        generation,
                        true,
                        false,
                        false
                )
        );
    }

    public static void endAttack(
            ServerPlayer player,
            int generation
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        if (current == null) {
            return;
        }

        /*
         * An old attack ending must never clear
         * a newer attack generation.
         */
        if (current.generation
                != generation) {

            return;
        }

        ATTACK_STATES.remove(
                player.getUUID()
        );
    }

    /**
     * Marks the currently active attack as having
     * successfully dealt positive melee damage.
     *
     * @return generation newly confirmed, or -1 if
     * nothing changed.
     */
    public static int confirmPositiveDamage(
            ServerPlayer player
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        if (current == null
                || !current.active
                || current.confirmed
                || current.cancelled) {

            return -1;
        }

        current.confirmed =
                true;

        return current.generation;
    }

    /**
     * Can Gyeokbu begin defense right now?
     *
     * No active attack:
     * yes.
     *
     * Active but not hit-confirmed:
     * no.
     *
     * Active and hit-confirmed:
     * yes.
     */
    public static boolean canStartDefense(
            ServerPlayer player
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        if (current == null
                || !current.active) {

            return true;
        }

        return current.confirmed;
    }

    /**
     * Called when an accepted Gyeokbu parry
     * interrupts a hit-confirmed attack.
     *
     * We keep the generation around until Better
     * Combat reports the animation/action ended.
     *
     * This prevents delayed sweep targets from the
     * old attack from damaging something after the
     * parry has already begun/finished.
     */
    public static void cancelCurrentAttack(
            ServerPlayer player
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        if (current == null
                || !current.active
                || !current.confirmed) {

            return;
        }

        current.cancelled =
                true;
    }

    public static boolean shouldCancelOutgoingDamage(
            ServerPlayer player
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        return current != null
                && current.active
                && current.cancelled;
    }

    public static boolean isActive(
            ServerPlayer player
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        return current != null
                && current.active;
    }

    public static boolean isConfirmed(
            ServerPlayer player
    ) {

        AttackState current =
                ATTACK_STATES.get(
                        player.getUUID()
                );

        return current != null
                && current.active
                && current.confirmed;
    }

    public static void remove(
            ServerPlayer player
    ) {

        ATTACK_STATES.remove(
                player.getUUID()
        );
    }

    private static final class AttackState {

        private final int generation;

        private boolean active;
        private boolean confirmed;
        private boolean cancelled;

        private AttackState(
                int generation,
                boolean active,
                boolean confirmed,
                boolean cancelled
        ) {

            this.generation =
                    generation;

            this.active =
                    active;

            this.confirmed =
                    confirmed;

            this.cancelled =
                    cancelled;
        }
    }
}