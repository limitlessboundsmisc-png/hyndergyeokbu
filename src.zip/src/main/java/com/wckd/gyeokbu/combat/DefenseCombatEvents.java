package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.advancement.GyeokbuAdvancements;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantmentRuntime;
import com.wckd.gyeokbu.enchantment.GyeokbuEnchantments;
import com.wckd.gyeokbu.compat.ShieldParryCompat;
import com.wckd.gyeokbu.network.BetterCombatHitConfirmPayload;
import com.wckd.gyeokbu.network.BlockDamageVisualPayload;
import com.wckd.gyeokbu.network.ParryImpactPayload;
import com.wckd.gyeokbu.weapon.DualWieldRules;
import com.wckd.gyeokbu.weapon.WeaponClassifier;
import com.wckd.gyeokbu.weapon.WeaponProfile;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingKnockBackEvent;
import net.neoforged.neoforge.event.entity.living.LivingShieldBlockEvent;
import net.neoforged.neoforge.event.level.ExplosionKnockbackEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Universal Parry plus enchantment-granted Block combat hooks. */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class DefenseCombatEvents {

    /** Vanilla normal non-sprinting melee-hit knockback strength. */
    public static final double BASE_PARRY_KNOCKBACK = 0.60D;

    private DefenseCombatEvents() {
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        Entity directSource = event.getSource().getDirectEntity();

        /* Reflect damage is deliberate enchantment damage, not a new attack. */
        if (GyeokbuEnchantmentRuntime.isApplyingReflectDamage()) {
            return;
        }

        /* A concussed or just-Parried attacker cannot land outgoing damage. */
        Entity attackOwner = event.getSource().getEntity();
        if (attackOwner instanceof LivingEntity livingAttacker
                && (GyeokbuEnchantmentRuntime.isConcussed(livingAttacker)
                || ParriedAttackLockManager.isLocked(livingAttacker))) {
            event.setCanceled(true);
            return;
        }

        /* Optional Better Combat cancelled-generation protection. */
        if (directSource instanceof ServerPlayer attackingPlayer
                && AttackCommitManager.shouldCancelOutgoingDamage(attackingPlayer)) {
            event.setCanceled(true);
            return;
        }

        /* Players cannot deal an ordinary direct melee hit while defending. */
        if (directSource instanceof ServerPlayer attackingPlayer) {
            DefenseData attackerDefense = DefenseManager.get(attackingPlayer);

            if (attackerDefense.isDefending()) {
                event.setCanceled(true);
                return;
            }
        }

        /* Reflected projectiles retain their stored reflected-damage scaling. */
        ProjectileParryManager.applyReflectedDamageScaling(event);

        /* Vulnerability is shared and modifies the real incoming attack. */
        GyeokbuEnchantmentRuntime.applyVulnerabilityDamage(event);

        if (!(event.getEntity() instanceof ServerPlayer defender)) {
            return;
        }

        DefenseData data = DefenseManager.get(defender);

        if (event.getSource().is(DamageTypeTags.IS_EXPLOSION)) {
            handleExplosionDefense(event, defender, directSource, data);
            return;
        }

        if (data.getState() == DefenseState.BLOCK) {
            WeaponProfile profile = WeaponClassifier.classify(defender.getMainHandItem());

            if (!profile.isSupported()
                    || directSource == null
                    || !GyeokbuEnchantments.hasBlockProvider(
                            defender.level(),
                            defender.getMainHandItem()
                    )) {
                return;
            }

            handleSuccessfulBlock(event, defender, directSource);
            return;
        }

        if (data.getState() != DefenseState.PARRY) {
            return;
        }

        WeaponProfile profile = WeaponClassifier.classify(defender.getMainHandItem());

        if (!profile.isSupported()) {
            return;
        }

        ParryGrade grade = DefenseManager.getCurrentParryGrade(defender);

        /*
         * While the active Parry window exists, entity-sourced damage cannot
         * hurt the defender. Known melee/projectile attacks still take the
         * normal successful-Parry path below so their effects are applied.
         */
        boolean entitySourcedDamage =
                (attackOwner != null && attackOwner != defender)
                        || (directSource != null && directSource != defender);

        if (grade == ParryGrade.NONE) {
            if (entitySourcedDamage) {
                event.setCanceled(true);
            }
            return;
        }

        /*
         * Generic projectile fallback for magic/projectile mods that apply
         * damage without posting ProjectileImpactEvent. Ordinary arrows and
         * Iron's AbstractMagicProjectile normally get handled earlier by the
         * dedicated projectile impact hook.
         */
        if (directSource instanceof Projectile projectile
                && attackOwner instanceof LivingEntity projectileAttacker
                && projectileAttacker != defender
                && ProjectileParryManager.tryParryIncomingDamage(
                        event,
                        projectile,
                        defender,
                        projectileAttacker,
                        profile,
                        grade
                )) {
            return;
        }

        LivingEntity attacker = getDirectLivingAttacker(event);

        if (attacker != null && attacker != defender) {
            handleSuccessfulParry(event, defender, attacker, grade);
            return;
        }

        /*
         * Any remaining entity-sourced damage is still completely negated while
         * the Parry window is active, even when the damage carrier is not a
         * LivingEntity that Gyeokbu can directly classify.
         */
        if (entitySourcedDamage) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onDamageApplied(LivingDamageEvent.Post event) {
        if (GyeokbuEnchantmentRuntime.isApplyingReflectDamage()) {
            return;
        }

        ProjectileParryManager.handleReflectedDamageApplied(event);
        GyeokbuEnchantmentRuntime.consumeVulnerabilityAfterDamage(event);

        if (event.getNewDamage() <= 0.0F) {
            return;
        }

        Entity directSource = event.getSource().getDirectEntity();

        if (!(directSource instanceof ServerPlayer attacker)) {
            return;
        }

        int confirmedGeneration = AttackCommitManager.confirmPositiveDamage(attacker);

        if (confirmedGeneration < 0) {
            return;
        }

        PacketDistributor.sendToPlayer(
                attacker,
                new BetterCombatHitConfirmPayload(confirmedGeneration)
        );
    }

    /** Blocking Stance removes ordinary living-entity knockback while Block is active. */
    @SubscribeEvent
    public static void onLivingKnockBack(LivingKnockBackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer defender)) {
            return;
        }

        if (isBlockingWithModifier(defender, GyeokbuEnchantments.BLOCKING_STANCE)) {
            event.setStrength(0.0F);
        }
    }

    /**
     * Explosion knockback is preserved for Blast Negation and ordinary
     * explosions. It is suppressed only when an explosion is actually being
     * Blocked by Blast Guard while Blocking Stance is also active.
     */
    @SubscribeEvent
    public static void onExplosionKnockback(ExplosionKnockbackEvent event) {
        if (!(event.getAffectedEntity() instanceof ServerPlayer defender)) {
            return;
        }

        if (isBlockingWithModifier(defender, GyeokbuEnchantments.BLOCKING_STANCE)
                && isBlockingWithModifier(defender, GyeokbuEnchantments.BLAST_GUARD)) {
            event.setKnockbackVelocity(Vec3.ZERO);
        }
    }

    private static void handleExplosionDefense(
            LivingIncomingDamageEvent event,
            ServerPlayer defender,
            Entity directSource,
            DefenseData data
    ) {
        /*
         * Shields inherently provide Block. Blast Guard can therefore reduce
         * explosion damage while a shield carrying it is actively raised.
         * Blast Negation remains weapon-only because generic external shield
         * Parry detection does not expose the real Parry window before damage.
         */
        /*
         * An active Parry also makes the player immune to explosions whose
         * damage source is an entity (for example an entity-carried explosive).
         * Environmental explosions remain governed by the existing rules.
         */
        Entity explosionOwner = event.getSource().getEntity();
        boolean entitySourcedExplosion =
                (explosionOwner != null && explosionOwner != defender)
                        || (directSource != null && directSource != defender);

        if (data.getState() == DefenseState.PARRY && entitySourcedExplosion) {
            ParryGrade grade = DefenseManager.getCurrentParryGrade(defender);

            if (grade != ParryGrade.NONE
                    && GyeokbuEnchantments.has(
                            defender.level(),
                            defender.getMainHandItem(),
                            GyeokbuEnchantments.BLAST_NEGATION
                    )) {
                event.setCanceled(true);
                playSuccessfulParryFeedback(defender, directSource, null);
                DefenseManager.successfulParry(
                        defender,
                        grade,
                        WeaponClassifier.classify(defender.getMainHandItem()).handStyle(),
                        false
                );
                DefenseManager.showActionbar(
                        defender,
                        "§aExplosion Parry! §7| Negated"
                );
                GyeokbuAdvancements.awardFirstDefense(defender);
                GyeokbuAdvancements.awardUntouchable(defender);
                return;
            }

            event.setCanceled(true);
            return;
        }

        ItemStack usedItem = defender.getUseItem();
        if (defender.isUsingItem()
                && GyeokbuEnchantments.isShield(usedItem)
                && GyeokbuEnchantments.has(
                        defender.level(), usedItem, GyeokbuEnchantments.BLAST_GUARD)) {
            float sourceDamage = Math.max(0.0F, event.getAmount());
            if (sourceDamage > 0.0F) {
                damageUsedShield(defender, usedItem);
                event.setAmount(sourceDamage * 0.50F);
                playSuccessfulBlockFeedback(defender);
            }
            return;
        }

        ItemStack weapon = defender.getMainHandItem();
        WeaponProfile profile = WeaponClassifier.classify(weapon);

        if (!profile.isSupported()) {
            return;
        }

        if (data.getState() == DefenseState.PARRY
                && GyeokbuEnchantments.has(
                        defender.level(),
                        weapon,
                        GyeokbuEnchantments.BLAST_NEGATION
                )) {
            ParryGrade grade = DefenseManager.getCurrentParryGrade(defender);

            if (grade == ParryGrade.NONE) {
                return;
            }

            /* Defensive-only Option A: no other Parry enchantment is triggered. */
            event.setCanceled(true);

            playSuccessfulParryFeedback(
                    defender,
                    directSource,
                    null
            );

            DefenseManager.successfulParry(
                    defender,
                    grade,
                    profile.handStyle(),
                    false
            );

            DefenseManager.showActionbar(
                    defender,
                    "§aExplosion Parry! §7| Negated"
            );
            GyeokbuAdvancements.awardFirstDefense(defender);
            GyeokbuAdvancements.awardUntouchable(defender);
            return;
        }

        if (data.getState() != DefenseState.BLOCK
                || !GyeokbuEnchantments.hasBlockProvider(defender.level(), weapon)
                || !GyeokbuEnchantments.has(
                        defender.level(),
                        weapon,
                        GyeokbuEnchantments.BLAST_GUARD
                )) {
            return;
        }

        float sourceDamage = Math.max(0.0F, event.getAmount());

        if (sourceDamage <= 0.0F) {
            return;
        }

        damageBlockingWeapon(defender, weapon);
        event.setAmount(sourceDamage * 0.50F);

        /* Blast Guard intentionally keeps normal hurt/red feedback. */
        playSuccessfulBlockFeedback(defender);
        GyeokbuAdvancements.awardHoldYourGround(defender);
    }

    /**
     * Block I-III reduce eligible direct damage by 20/40/60%. Perfect Block
     * fully negates eligible direct melee damage. Its pre-existing projectile
     * behavior remains a 50% reduction because the finalized Perfect Block
     * rule specifically upgrades direct melee damage.
     */
    private static void handleSuccessfulBlock(
            LivingIncomingDamageEvent event,
            ServerPlayer defender,
            Entity directSource
    ) {
        float sourceDamage = Math.max(0.0F, event.getAmount());

        if (sourceDamage <= 0.0F) {
            return;
        }

        ItemStack blockingWeapon = defender.getMainHandItem();
        boolean directMelee = directSource instanceof LivingEntity;

        int blockLevel = GyeokbuEnchantments.getLevel(
                defender.level(),
                blockingWeapon,
                GyeokbuEnchantments.BLOCK
        );

        boolean hasPerfectBlock = GyeokbuEnchantments.has(
                defender.level(),
                blockingWeapon,
                GyeokbuEnchantments.PERFECT_BLOCK
        );

        if (blockLevel <= 0 && !hasPerfectBlock) {
            return;
        }

        boolean hasPushback = directMelee
                && GyeokbuEnchantments.has(
                        defender.level(),
                        blockingWeapon,
                        GyeokbuEnchantments.PUSHBACK
                );

        damageBlockingWeapon(defender, blockingWeapon);

        float reduction;

        if (hasPerfectBlock) {
            reduction = directMelee ? 1.00F : 0.50F;
        } else {
            reduction = Math.min(0.60F, Math.max(1, blockLevel) * 0.20F);
        }

        event.setAmount(sourceDamage * (1.0F - reduction));

        PacketDistributor.sendToPlayer(
                defender,
                new BlockDamageVisualPayload(
                        10,
                        hasPerfectBlock && directMelee
                )
        );

        if (hasPushback
                && directSource instanceof LivingEntity attacker
                && attacker != defender) {
            applyKnockback(defender, attacker, BASE_PARRY_KNOCKBACK);
        }

        playSuccessfulBlockFeedback(defender);
        GyeokbuAdvancements.awardHoldYourGround(defender);
    }

    /** Gyeokbu Block feedback: a quiet, low-pitched XP confirmation only. */
    private static void playSuccessfulBlockFeedback(ServerPlayer defender) {
        defender.level().playSound(
                null,
                defender.blockPosition(),
                SoundEvents.EXPERIENCE_ORB_PICKUP,
                SoundSource.PLAYERS,
                0.28F,
                0.62F
        );
    }

    /**
     * Vanilla/modded shields inherently provide Block. Their one Gyeokbu slot
     * can therefore run Block modifiers without Block/Perfect Block itself.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onShieldBlockedAttack(LivingShieldBlockEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer defender)
                || event.isCanceled() || !event.getBlocked() || event.getBlockedDamage() <= 0.0F) {
            return;
        }

        ItemStack shield = defender.getUseItem();
        if (!GyeokbuEnchantments.isShield(shield)) {
            return;
        }

        Entity owner = event.getDamageSource().getEntity();
        Entity direct = event.getDamageSource().getDirectEntity();

        if (GyeokbuEnchantments.has(
                defender.level(), shield, GyeokbuEnchantments.PUSHBACK)
                && owner instanceof LivingEntity attacker
                && attacker != defender) {
            ShieldParryCompat.runGyeokbuShieldPushback(
                    () -> applyKnockback(defender, attacker, BASE_PARRY_KNOCKBACK)
            );
        }

        if (GyeokbuEnchantments.has(
                defender.level(), shield, GyeokbuEnchantments.PROJECTILE_REFLECT)
                && direct instanceof Projectile projectile
                && owner instanceof LivingEntity attacker
                && attacker != defender) {
            ProjectileParryManager.reflectBlockedProjectile(
                    projectile,
                    defender,
                    attacker
            );
        }
    }


    private static void damageUsedShield(
            ServerPlayer defender,
            ItemStack shield
    ) {
        if (!shield.isDamageableItem()) {
            return;
        }

        EquipmentSlot slot = defender.getUsedItemHand() == InteractionHand.OFF_HAND
                ? EquipmentSlot.OFFHAND
                : EquipmentSlot.MAINHAND;
        shield.hurtAndBreak(1, defender, slot);
    }

    private static void damageBlockingWeapon(
            ServerPlayer defender,
            ItemStack weapon
    ) {
        if (weapon.isDamageableItem()) {
            weapon.hurtAndBreak(
                    1,
                    defender,
                    EquipmentSlot.MAINHAND
            );
        }
    }

    private static boolean isBlockingWithModifier(
            ServerPlayer defender,
            net.minecraft.resources.ResourceKey<net.minecraft.world.item.enchantment.Enchantment> modifier
    ) {
        ItemStack usedItem = defender.getUseItem();
        if (defender.isUsingItem()
                && GyeokbuEnchantments.isShield(usedItem)
                && GyeokbuEnchantments.has(defender.level(), usedItem, modifier)) {
            return true;
        }

        if (DefenseManager.get(defender).getState() != DefenseState.BLOCK) {
            return false;
        }

        ItemStack weapon = defender.getMainHandItem();

        return WeaponClassifier.classify(weapon).isSupported()
                && GyeokbuEnchantments.hasBlockProvider(defender.level(), weapon)
                && GyeokbuEnchantments.has(defender.level(), weapon, modifier);
    }

    private static void handleSuccessfulParry(
            LivingIncomingDamageEvent event,
            ServerPlayer defender,
            LivingEntity attacker,
            ParryGrade grade
    ) {
        event.setCanceled(true);

        ItemStack weapon = defender.getMainHandItem();
        applySuccessfulParryKnockback(defender, attacker, weapon);

        int reflectLevel = GyeokbuEnchantments.getLevel(
                defender.level(),
                weapon,
                GyeokbuEnchantments.REFLECT
        );

        if (reflectLevel > 0) {
            GyeokbuEnchantmentRuntime.applyReflectDamage(
                    defender,
                    attacker,
                    reflectLevel
            );
        }

        GyeokbuEnchantmentRuntime.onSuccessfulParry(defender, attacker);
        ParriedAttackLockManager.lock(attacker);

        playSuccessfulParryFeedback(
                defender,
                attacker,
                defender.getEyePosition().subtract(attacker.getEyePosition())
        );

        boolean sweepingGuard = GyeokbuEnchantments.has(
                defender.level(), weapon, GyeokbuEnchantments.SWEEPING_GUARD);

        DefenseManager.successfulParry(
                defender,
                grade,
                WeaponClassifier.classify(weapon).handStyle(),
                sweepingGuard
        );

        DefenseManager.showActionbar(defender, "§aSuccessful Parry!");
        GyeokbuAdvancements.awardFirstDefense(defender);
    }

    /**
     * Applies the complete intended Successful Parry knockback. If the target
     * actually accepts essentially none of it (for example a Warden or Iron
     * Golem), the same intended strength is redirected to the defender.
     */
    public static void applySuccessfulParryKnockback(
            ServerPlayer defender,
            LivingEntity target,
            ItemStack weapon
    ) {
        double strength = BASE_PARRY_KNOCKBACK
                + GyeokbuEnchantmentRuntime.getSuccessfulParryKnockbackBonus(
                defender, weapon);

        Vec3 before = target.getDeltaMovement();
        target.knockback(
                strength,
                defender.getX() - target.getX(),
                defender.getZ() - target.getZ()
        );
        Vec3 after = target.getDeltaMovement();

        double deltaX = after.x - before.x;
        double deltaZ = after.z - before.z;
        double accepted = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);

        if (accepted < 0.0001D) {
            /* Some entities completely reject LivingEntity.knockback().  Do
             * not leave any tiny partial change on the target; the player's
             * replacement impulse must be the EXACT SAME intended strength
             * that the target was offered. */
            target.setDeltaMovement(before);
            target.hurtMarked = true;

            defender.knockback(
                    strength,
                    target.getX() - defender.getX(),
                    target.getZ() - defender.getZ()
            );
            defender.hurtMarked = true;
        } else {
            target.hurtMarked = true;
        }
    }

    private static void applyKnockback(
            ServerPlayer defender,
            LivingEntity attacker,
            double strength
    ) {
        attacker.knockback(
                strength,
                defender.getX() - attacker.getX(),
                defender.getZ() - attacker.getZ()
        );

        /* ServerPlayer movement needs an explicit velocity sync marker. */
        attacker.hurtMarked = true;
    }

    /** Shared successful-Parry sound and spark feedback. */
    static void playSuccessfulParryFeedback(
            ServerPlayer defender,
            Entity incomingSource,
            Vec3 incomingDirection
    ) {
        defender.level().playSound(
                null,
                defender.blockPosition(),
                SoundEvents.NETHERITE_BLOCK_HIT,
                SoundSource.PLAYERS,
                0.90F,
                1.08F
        );

        defender.level().playSound(
                null,
                defender.blockPosition(),
                SoundEvents.EXPERIENCE_ORB_PICKUP,
                SoundSource.PLAYERS,
                0.45F,
                1.35F
        );

        Vec3 direction = incomingDirection;

        if (direction == null || direction.lengthSqr() < 0.0001D) {
            direction = incomingSource == null
                    ? defender.getLookAngle().scale(-1.0D)
                    : defender.getEyePosition().subtract(incomingSource.getEyePosition());
        }

        if (direction.lengthSqr() < 0.0001D) {
            direction = defender.getLookAngle().scale(-1.0D);
        }

        direction = direction.normalize();

        WeaponProfile naturalProfile =
                WeaponClassifier.classifyNatural(defender.getMainHandItem());
        boolean twoHanded = naturalProfile.handStyle() == com.wckd.gyeokbu.weapon.HandStyle.TWO_HANDED;
        boolean dualWield = DualWieldRules.isDualWield(defender);

        PacketDistributor.sendToPlayersTrackingEntityAndSelf(
                defender,
                new ParryImpactPayload(
                        defender.getId(),
                        naturalProfile.parryStyle().ordinal(),
                        twoHanded,
                        dualWield,
                        (float) direction.x,
                        (float) direction.y,
                        (float) direction.z
                )
        );
    }

    private static LivingEntity getDirectLivingAttacker(LivingIncomingDamageEvent event) {
        Entity direct = event.getSource().getDirectEntity();
        return direct instanceof LivingEntity living ? living : null;
    }
}
