package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * ONE-HANDED guaranteed-critical rewards.
 *
 * NORMAL PARRY:
 * - reward is TARGET-BOUND;
 * - only the exact parried target is vulnerable;
 * - every direct melee hit by the parrying player is guaranteed-critical
 *   while that target remains in its 1H Parry slow.
 *
 * PERFECT PARRY:
 * - reward is PLAYER-BOUND;
 * - every direct melee attack by that player against ANY target is
 *   guaranteed-critical;
 * - duration is the same as the 1H Perfect-Parry slow duration;
 * - killing one enemy does not consume or end the remaining duration.
 *
 * This is intentionally separate from Counter State.
 */
@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class PerfectParryCritManager {

    /**
     * Normal-Parry target vulnerabilities.
     *
     * Key = vulnerable target UUID.
     */
    private static final Map<UUID, NormalVulnerability>
            NORMAL_VULNERABLE =
            new HashMap<>();

    /**
     * Perfect-Parry reward waiting for the matching 1H hard stun to begin.
     *
     * Key = parrying player UUID.
     */
    private static final Map<UUID, PendingPerfectReward>
            PENDING_PERFECT =
            new HashMap<>();

    /**
     * Active player-owned Perfect reward.
     *
     * Key = parrying player UUID.
     */
    private static final Map<UUID, ActivePerfectReward>
            ACTIVE_PERFECT =
            new HashMap<>();

    private PerfectParryCritManager() {
    }

    /**
     * NORMAL 1H PARRY:
     * mark only the exact parried target.
     */
    public static void markNormal(
            LivingEntity target,
            ServerPlayer owner
    ) {
        if (target == null
                || owner == null
                || target.isRemoved()
                || !target.isAlive()) {
            return;
        }

        NORMAL_VULNERABLE.put(
                target.getUUID(),
                new NormalVulnerability(
                        target,
                        owner.getUUID()
                )
        );
    }

    /**
     * PERFECT 1H PARRY:
     * prepare the player-owned reward.
     *
     * The timer starts when the corresponding hard stun actually activates,
     * so the guaranteed-crit duration matches the real stun window rather
     * than the earlier knockback / pending-stun delay.
     *
     * If the parried target dies before the hard stun can begin, StunManager
     * calls activatePerfectWithoutStun(...) so the player still receives the
     * full intended reward duration.
     */
    public static void preparePerfect(
            ServerPlayer owner,
            LivingEntity target,
            int durationTicks
    ) {
        if (owner == null
                || target == null
                || durationTicks <= 0) {
            return;
        }

        PENDING_PERFECT.put(
                owner.getUUID(),
                new PendingPerfectReward(
                        target.getUUID(),
                        durationTicks
                )
        );
    }

    /**
     * Called by StunManager exactly when the 1H hard stun becomes active.
     */
    public static void activatePerfectOnStunStart(
            ServerPlayer owner,
            LivingEntity target,
            int durationTicks
    ) {
        if (owner == null
                || target == null
                || durationTicks <= 0) {
            return;
        }

        PendingPerfectReward pending =
                PENDING_PERFECT.get(
                        owner.getUUID()
                );

        if (pending == null
                || !pending.targetId()
                .equals(target.getUUID())) {
            return;
        }

        PENDING_PERFECT.remove(
                owner.getUUID()
        );

        ACTIVE_PERFECT.put(
                owner.getUUID(),
                new ActivePerfectReward(
                        durationTicks
                )
        );
    }

    /**
     * If the Perfect-parried target dies before its pending stun can activate,
     * the player still receives the complete player-owned Perfect reward.
     */
    public static void activatePerfectWithoutStun(
            ServerPlayer owner,
            LivingEntity target,
            int durationTicks
    ) {
        if (owner == null
                || target == null
                || durationTicks <= 0) {
            return;
        }

        PendingPerfectReward pending =
                PENDING_PERFECT.get(
                        owner.getUUID()
                );

        if (pending == null
                || !pending.targetId()
                .equals(target.getUUID())) {
            return;
        }

        PENDING_PERFECT.remove(
                owner.getUUID()
        );

        ACTIVE_PERFECT.put(
                owner.getUUID(),
                new ActivePerfectReward(
                        durationTicks
                )
        );
    }

    /**
     * Re-parrying the same target replaces that target's old Normal-Parry
     * vulnerability.
     *
     * This does NOT remove a separate player-owned Perfect reward.
     */
    public static void clearTarget(
            LivingEntity target
    ) {
        if (target != null) {
            NORMAL_VULNERABLE.remove(
                    target.getUUID()
            );
        }
    }

    public static void applyGuaranteedCrit(
            LivingIncomingDamageEvent event
    ) {
        Entity direct =
                event.getSource()
                        .getDirectEntity();

        if (!(direct instanceof ServerPlayer attacker)) {
            return;
        }

        LivingEntity target =
                event.getEntity();

        /*
         * PERFECT takes priority:
         * player-owned and valid against ANY target.
         */
        ActivePerfectReward perfect =
                ACTIVE_PERFECT.get(
                        attacker.getUUID()
                );

        if (perfect != null
                && perfect.remainingTicks() > 0) {
            applyCriticalDamage(
                    event,
                    attacker,
                    target
            );

            return;
        }

        /*
         * NORMAL:
         * target-owned and only valid while this exact target remains in its
         * 1H Parry slow.
         */
        NormalVulnerability normal =
                NORMAL_VULNERABLE.get(
                        target.getUUID()
                );

        if (normal == null
                || !attacker.getUUID()
                .equals(normal.ownerId())) {
            return;
        }

        if (!OneHandedParrySlowManager.isActive(
                target
        )) {
            return;
        }

        applyCriticalDamage(
                event,
                attacker,
                target
        );
    }

    private static void applyCriticalDamage(
            LivingIncomingDamageEvent event,
            ServerPlayer attacker,
            LivingEntity target
    ) {
        /*
         * Keep the existing safe basis:
         * current ATTACK_DAMAGE x vanilla 1.5 critical multiplier.
         *
         * Do not multiply event.getAmount(), because Better Combat / other
         * mods may already have transformed that amount.
         */
        float attackDamage =
                (float) attacker.getAttributeValue(
                        Attributes.ATTACK_DAMAGE
                );

        event.setAmount(
                attackDamage * 1.5F
        );

        broadcastCritFeedback(
                target
        );
    }

    private static void broadcastCritFeedback(
            LivingEntity target
    ) {
        if (!(target.level()
                instanceof ServerLevel level)) {
            return;
        }

        level.sendParticles(
                ParticleTypes.CRIT,
                target.getX(),
                target.getY()
                        + target.getBbHeight() * 0.60D,
                target.getZ(),
                28,
                0.35D,
                0.40D,
                0.35D,
                0.12D
        );

        level.playSound(
                null,
                target.blockPosition(),
                SoundEvents.PLAYER_ATTACK_CRIT,
                SoundSource.PLAYERS,
                1.20F,
                1.0F
        );
    }

    @SubscribeEvent
    public static void onServerTick(
            ServerTickEvent.Post event
    ) {
        /*
         * NORMAL target-bound cleanup.
         */
        Iterator<Map.Entry<UUID, NormalVulnerability>> normalIterator =
                NORMAL_VULNERABLE.entrySet()
                        .iterator();

        while (normalIterator.hasNext()) {
            NormalVulnerability vulnerability =
                    normalIterator.next()
                            .getValue();

            LivingEntity target =
                    vulnerability.target();

            if (target == null
                    || target.isRemoved()
                    || !target.isAlive()) {
                normalIterator.remove();
                continue;
            }

            /*
             * The Normal target-bound crit reward now follows the exact
             * lifetime of the 1H Parry slow.
             */
            if (!OneHandedParrySlowManager.isActive(
                    target
            )) {
                normalIterator.remove();
            }
        }

        /*
         * PERFECT player-owned duration.
         *
         * Once active, it is independent of any particular enemy. Killing a
         * target therefore does not end the remaining duration.
         */
        Iterator<Map.Entry<UUID, ActivePerfectReward>> perfectIterator =
                ACTIVE_PERFECT.entrySet()
                        .iterator();

        while (perfectIterator.hasNext()) {
            Map.Entry<UUID, ActivePerfectReward> entry =
                    perfectIterator.next();

            int remaining =
                    entry.getValue()
                            .remainingTicks() - 1;

            if (remaining <= 0) {
                perfectIterator.remove();
                continue;
            }

            entry.setValue(
                    new ActivePerfectReward(
                            remaining
                    )
            );
        }
    }

    private record NormalVulnerability(
            LivingEntity target,
            UUID ownerId
    ) {
    }

    private record PendingPerfectReward(
            UUID targetId,
            int durationTicks
    ) {
    }

    private record ActivePerfectReward(
            int remainingTicks
    ) {
    }
}
