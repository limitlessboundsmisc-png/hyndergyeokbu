package com.wckd.gyeokbu.combat;

/**
 * Build 1 universal defense states.
 *
 * Perfect timing and future Block+ are not separate baseline states.
 * They can be layered on later by the Technique system without changing the
 * core Parry -> Block flow.
 */
public enum DefenseState {
    NEUTRAL,
    PARRY,
    BLOCK
}
