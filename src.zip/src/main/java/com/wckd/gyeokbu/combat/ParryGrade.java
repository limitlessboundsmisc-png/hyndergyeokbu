package com.wckd.gyeokbu.combat;

public enum ParryGrade {
    NONE,
    NORMAL,
    PERFECT
}