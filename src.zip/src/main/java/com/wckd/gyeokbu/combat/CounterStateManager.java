package com.wckd.gyeokbu.combat;

import com.wckd.gyeokbu.GyeokbuV2;
import com.wckd.gyeokbu.weapon.HandStyle;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

@EventBusSubscriber(modid = GyeokbuV2.MODID)
public final class CounterStateManager {


    private static final Map<UUID, CounterStateData> DATA =
            new HashMap<>();

    private CounterStateManager() {
    }

    public static int activate(
            ServerPlayer player,
            HandStyle style,
            long currentTick,
            int stunTicks,
            int maxDelayTicks
    ) {

        return activate(
                player,
                style,
                style,
                ParryGrade.NORMAL,
                currentTick,
                stunTicks,
                maxDelayTicks
        );
    }

    public static int activate(
            ServerPlayer player,
            HandStyle style,
            ParryGrade grade,
            long currentTick,
            int stunTicks,
            int maxDelayTicks
    ) {

        return activate(
                player,
                style,
                style,
                grade,
                currentTick,
                stunTicks,
                maxDelayTicks
        );
    }

    /**
     * movementStyle:
     *   the weapon's BASE 1H / 2H identity.
     *
     * damageStyle:
     *   selectively borrowed Counter damage behavior.
     *
     * This lets Katana keep its 2H movement identity while:
     * - Normal Counter damage uses 1H x1.5
     * - Perfect Counter damage uses 2H x2.0
     */
    public static int activate(
            ServerPlayer player,
            HandStyle movementStyle,
            HandStyle damageStyle,
            ParryGrade grade,
            long currentTick,
            int stunTicks,
            int maxDelayTicks
    ) {

        CounterStateData data =
                DATA.computeIfAbsent(
                        player.getUUID(),
                        uuid -> new CounterStateData()
                );

        data.generation++;

        data.active = true;

        data.movementStyle =
                movementStyle;

        data.damageStyle =
                damageStyle;

        data.perfectCreated =
                grade == ParryGrade.PERFECT;

        data.twoHandedHitEntities.clear();

        data.ownerItem =
                player.getMainHandItem()
                        .getItem();

        data.ownerItemId =
                BuiltInRegistries.ITEM.getKey(
                        data.ownerItem
                );

        data.endTick =
                currentTick
                        + maxDelayTicks
                        + stunTicks;

        return data.generation;
    }

    public static void updateEndTick(
            ServerPlayer player,
            int generation,
            long stunStartTick,
            int stunTicks
    ) {

        CounterStateData data =
                DATA.get(
                        player.getUUID()
                );

        if (data == null
                || !data.active
                || data.generation
                != generation) {

            return;
        }

        data.endTick =
                stunStartTick
                        + stunTicks;
    }

    public static void expireGeneration(
            ServerPlayer player,
            int generation
    ) {

        CounterStateData data =
                DATA.get(
                        player.getUUID()
                );

        if (data == null
                || !data.active
                || data.generation
                != generation) {

            return;
        }

        clear(
                player
        );
    }

    public static boolean hasCounterState(
            ServerPlayer player
    ) {

        CounterStateData data =
                DATA.get(
                        player.getUUID()
                );

        return data != null
                && data.active;
    }

    /*
     * IMPORTANT:
     *
     * Swapping weapons does NOT destroy Counter State.
     *
     * It only makes the reward temporarily unusable.
     *
     * Switch back before expiry and the reward
     * becomes usable again.
     */
    public static boolean isHoldingCounterWeapon(
            ServerPlayer player
    ) {

        CounterStateData data =
                DATA.get(
                        player.getUUID()
                );

        if (data == null
                || !data.active
                || data.ownerItem == null) {

            return false;
        }

        return player.getMainHandItem()
                .getItem()
                == data.ownerItem;
    }

    public static void applyCounterDamage(
            LivingIncomingDamageEvent event
    ) {

        if (!(event.getSource()
                .getDirectEntity()
                instanceof ServerPlayer player)) {

            return;
        }

        CounterStateData data =
                DATA.get(
                        player.getUUID()
                );

        if (data == null
                || !data.active) {

            return;
        }

        /*
         * Weapon swapped:
         *
         * do NOTHING.
         *
         * Counter State remains alive.
         */
        if (!isHoldingCounterWeapon(
                player
        )) {

            return;
        }

        LivingEntity target =
                event.getEntity();

        long currentTick =
                player.level()
                        .getGameTime();

        /*
         * =========================================
         * ONE-HANDED
         * =========================================
         *
         * V25: 1H Counter State has been removed entirely.
         * If a stale/legacy 1H Counter activation reaches this manager,
         * it grants no damage reward.
         */
        if (data.damageStyle
                == HandStyle.ONE_HANDED) {
            return;
        }

        /*
         * =========================================
         * TWO-HANDED
         * =========================================
         *
         * +100% / x2 damage.
         *
         * ANY target can receive the reward.
         *
         * But a target can receive it EXACTLY ONCE
         * during THIS Counter State generation.
         */
        if (data.damageStyle
                == HandStyle.TWO_HANDED) {

            UUID targetId =
                    target.getUUID();

            /*
             * Already used on this entity:
             *
             * NEVER boost it again until the NEXT
             * successful parry creates a fresh
             * Counter State.
             */
            if (data.twoHandedHitEntities
                    .contains(targetId)) {

                return;
            }

            /*
             * Mark BEFORE modifying damage.
             *
             * This prevents duplicate damage callbacks
             * from boosting the same entity twice.
             */
            data.twoHandedHitEntities.add(
                    targetId
            );

            float counterBaseDamage =
                    (float) player.getAttributeValue(
                            Attributes.ATTACK_DAMAGE
                    );

            event.setAmount(
                    counterBaseDamage
                            * 2.0F
            );

            broadcastCritFeedback(
                    target
            );
        }
    }

    /*
     * More visible but still vanilla CRIT feedback.
     *
     * Server-side particles/sound are visible/audible
     * to nearby multiplayer players.
     */
    public static void broadcastCritFeedback(
            LivingEntity target
    ) {

        if (!(target.level()
                instanceof ServerLevel level)) {

            return;
        }

        level.sendParticles(
                ParticleTypes.CRIT,
                target.getX(),
                target.getY()
                        + target.getBbHeight()
                        * 0.55D,
                target.getZ(),

                36,

                0.42D,
                0.48D,
                0.42D,

                0.16D
        );

        level.sendParticles(
                ParticleTypes.CRIT,
                target.getX(),
                target.getY()
                        + target.getBbHeight()
                        * 0.82D,
                target.getZ(),

                16,

                0.25D,
                0.25D,
                0.25D,

                0.10D
        );

        level.playSound(
                null,
                target.blockPosition(),
                SoundEvents.PLAYER_ATTACK_CRIT,
                SoundSource.PLAYERS,
                1.40F,
                1.0F
        );
    }

    public static void clear(
            ServerPlayer player
    ) {

        DATA.remove(
                player.getUUID()
        );

    }

    @SubscribeEvent
    public static void onServerTick(
            ServerTickEvent.Post event
    ) {

        long now =
                event.getServer()
                        .overworld()
                        .getGameTime();

        for (ServerPlayer player :
                event.getServer()
                        .getPlayerList()
                        .getPlayers()) {

            CounterStateData data =
                    DATA.get(
                            player.getUUID()
                    );

            if (data == null
                    || !data.active) {

                continue;
            }

            /*
             * Counter State still expires normally
             * even if the player has swapped weapons.
             */
            if (now > data.endTick) {

                clear(
                        player
                );

                continue;
            }

        }
    }

    private static final class CounterStateData {

        private boolean active = false;

        private HandStyle movementStyle = null;

        private HandStyle damageStyle = null;

        private boolean perfectCreated = false;

        private long endTick = 0L;

        private int generation = 0;

        private Item ownerItem = null;

        private ResourceLocation ownerItemId = null;

        /*
         * Per-generation target memory.
         *
         * Two-handed reward:
         * each UUID exactly once.
         */
        private final Set<UUID>
                twoHandedHitEntities =
                new HashSet<>();
    }
}